import type { ProgressBarStatus } from '@socium-design/angular-components';
import * as i0 from "@angular/core";
export type LabsProgressRingSize = 'sm' | 'md';
/**
 * ## Rôle
 * Jauge de progression circulaire : anneau + pourcentage affiché à côté. Pour une colonne
 * « Progression » de tableau, où une barre linéaire prendrait trop de place. Une progression peut
 * dépasser 100 % (objectif quantitatif dépassé) : le texte garde la valeur réelle, l'anneau est plein.
 *
 * Le pourcentage est écrit **à côté** de l'anneau (et non dedans) pour rester lisible à la taille du
 * texte courant, en couleur de texte principale (contraste ≥ 4,5:1).
 *
 * ## Accessibilité
 * `role="progressbar"` avec `aria-valuenow` (borné 0–100) et `aria-valuetext` (valeur réelle,
 * formatée en français). `label` donne le nom accessible (« Progression de Test bouton »).
 */
export declare class SocLabsProgressRing {
    /** Progression en pour cent. Peut dépasser 100. */
    readonly value: import("@angular/core").InputSignal<number>;
    readonly status: import("@angular/core").InputSignal<ProgressBarStatus>;
    readonly size: import("@angular/core").InputSignal<LabsProgressRingSize>;
    /** Nom accessible de la jauge. */
    readonly label: import("@angular/core").InputSignal<string | undefined>;
    /** Masque le pourcentage visible (il reste lu par `aria-valuetext`). */
    readonly hideValue: import("@angular/core").InputSignal<boolean>;
    protected readonly radius = 15.9155;
    protected readonly clamped: import("@angular/core").Signal<number>;
    protected readonly text: import("@angular/core").Signal<string>;
    protected readonly dashArray: import("@angular/core").Signal<string>;
    protected readonly svgClass: import("@angular/core").Signal<string>;
    protected readonly strokeClass: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsProgressRing, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocLabsProgressRing, "soc-labs-progress-ring", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "status": { "alias": "status"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "hideValue": { "alias": "hideValue"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
