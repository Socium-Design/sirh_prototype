import { TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
/** Contexte d'une cellule riche : la ligne et sa profondeur (0 = ligne, 1 = sous-ligne…). */
export interface LabsGroupedTableCellContext<T> {
    $implicit: T;
    depth: number;
}
/** Même forme que `DataTableColumn` du kit, plus une largeur optionnelle. */
export interface LabsGroupedTableColumn<T> {
    key: string;
    header: string;
    render: ((row: T) => string) | TemplateRef<LabsGroupedTableCellContext<T>>;
    /** Largeur CSS de la colonne (`'30%'`, `'10rem'`…). */
    width?: string;
}
export interface LabsGroupedTableGroup<G, T> {
    key: string;
    data: G;
    rows: T[];
}
/** Contexte du template d'en-tête de groupe. */
export interface LabsGroupedTableGroupContext<G, T> {
    $implicit: G;
    rows: T[];
    expanded: boolean;
}
interface VisibleRow<T> {
    row: T;
    key: string;
    depth: number;
    hasChildren: boolean;
    expanded: boolean;
}
/**
 * ## Rôle
 * Tableau dont les lignes sont regroupées (une ligne d'en-tête par groupe, repliable) et dont chaque
 * ligne peut porter des sous-lignes dépliables, indentées. Exemple : objectifs groupés par
 * collaborateur, un objectif dépliant ses sous-objectifs. `soc-data-table` reste le tableau par défaut
 * pour une liste plate.
 *
 * Présentationnel : la page fournit les groupes déjà filtrés et paginés, et pilote l'état replié via
 * `expandedGroups` / `expandedRows` (`model()`, pour un bouton « Tout déplier »). Un groupe ou une ligne
 * est déplié si sa clé est dans l'ensemble.
 *
 * ## Accessibilité
 * Vrai `<table>` : un `<tbody>` par groupe, en-tête de groupe en `<th scope="rowgroup">`. Les boutons
 * de repli sont de vrais `<button>` avec `aria-expanded` et un nom (« Déplier les lignes de … »),
 * construit avec `groupLabel` / `rowLabel`. `caption` (masquée) nomme le tableau.
 */
export declare class SocLabsGroupedTable<G, T> {
    readonly columns: import("@angular/core").InputSignal<LabsGroupedTableColumn<T>[]>;
    readonly groups: import("@angular/core").InputSignal<LabsGroupedTableGroup<G, T>[]>;
    readonly rowKey: import("@angular/core").InputSignal<(row: T) => string>;
    /** Sous-lignes d'une ligne (aucune par défaut). */
    readonly childRows: import("@angular/core").InputSignal<(row: T) => T[]>;
    /** Contenu de la ligne d'en-tête de groupe (à droite du bouton de repli). */
    readonly groupHeader: import("@angular/core").InputSignal<TemplateRef<LabsGroupedTableGroupContext<G, T>> | undefined>;
    /** Nom d'un groupe pour le bouton de repli (« Déplier {nom} »). */
    readonly groupLabel: import("@angular/core").InputSignal<(group: G) => string>;
    /** Nom d'une ligne pour son bouton de repli. */
    readonly rowLabel: import("@angular/core").InputSignal<(row: T) => string>;
    readonly caption: import("@angular/core").InputSignal<string | undefined>;
    readonly emptyText: import("@angular/core").InputSignal<string>;
    readonly expandedGroups: import("@angular/core").ModelSignal<Set<string>>;
    readonly expandedRows: import("@angular/core").ModelSignal<Set<string>>;
    protected readonly cellClass = "px-[var(--bridges-position-padding-md)] py-[var(--bridges-position-padding-sm)] align-middle text-[length:var(--bridges-size-text-text-size-sm)] text-[var(--bridges-color-text-primary)] [font-family:var(--bridges-shape-text-body-font)]";
    protected readonly emptyCellClass = "px-[var(--bridges-position-padding-md)] py-[var(--bridges-position-padding-md)] text-[length:var(--bridges-size-text-text-size-sm)] text-[var(--bridges-color-text-primary)] [font-family:var(--bridges-shape-text-body-font)]";
    protected readonly groupToggleClass = "outline-none focus-visible:outline-solid focus-visible:outline-[length:var(--bridges-shape-line-thick)] focus-visible:outline-offset-[length:var(--bridges-position-gap-xs)] focus-visible:outline-[var(--bridges-color-border-focus)] inline-flex shrink-0 items-center justify-center rounded-[var(--bridges-shape-figure-radius-sm)] text-[var(--bridges-color-icon-default)] hover:bg-[var(--bridges-color-background-layer-2-hover)] size-[var(--bridges-size-icon-xl)]";
    protected readonly rowToggleClass = "outline-none focus-visible:outline-solid focus-visible:outline-[length:var(--bridges-shape-line-thick)] focus-visible:outline-offset-[length:var(--bridges-position-gap-xs)] focus-visible:outline-[var(--bridges-color-border-focus)] inline-flex shrink-0 items-center justify-center rounded-[var(--bridges-shape-figure-radius-sm)] text-[var(--bridges-color-icon-default)] hover:bg-[var(--bridges-color-background-layer-2-hover)] size-[var(--bridges-size-icon-lg)]";
    protected isGroupExpanded(key: string): boolean;
    protected toggleGroup(key: string): void;
    protected toggleRow(key: string): void;
    /** Lignes affichées d'un groupe, sous-lignes dépliées comprises, dans l'ordre. */
    protected visibleRows(rows: T[], depth?: number): VisibleRow<T>[];
    protected isTemplate(render: unknown): render is TemplateRef<LabsGroupedTableCellContext<T>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsGroupedTable<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocLabsGroupedTable<any, any>, "soc-labs-grouped-table", never, { "columns": { "alias": "columns"; "required": true; "isSignal": true; }; "groups": { "alias": "groups"; "required": true; "isSignal": true; }; "rowKey": { "alias": "rowKey"; "required": true; "isSignal": true; }; "childRows": { "alias": "childRows"; "required": false; "isSignal": true; }; "groupHeader": { "alias": "groupHeader"; "required": false; "isSignal": true; }; "groupLabel": { "alias": "groupLabel"; "required": false; "isSignal": true; }; "rowLabel": { "alias": "rowLabel"; "required": false; "isSignal": true; }; "caption": { "alias": "caption"; "required": false; "isSignal": true; }; "emptyText": { "alias": "emptyText"; "required": false; "isSignal": true; }; "expandedGroups": { "alias": "expandedGroups"; "required": false; "isSignal": true; }; "expandedRows": { "alias": "expandedRows"; "required": false; "isSignal": true; }; }, { "expandedGroups": "expandedGroupsChange"; "expandedRows": "expandedRowsChange"; }, never, never, true, never>;
}
export {};
