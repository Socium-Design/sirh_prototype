import { type MultiSelectOption, type TabItem } from '@socium-design/angular-components';
import * as i0 from "@angular/core";
/** Un mode de ciblage (un onglet) : ses options et le libellé du champ de sélection. */
export interface LabsPopulationMode {
    id: string;
    /** Libellé de l'onglet (« Personne nommée »). */
    label: string;
    /** Libellé du champ de sélection multiple (« Employés »). */
    fieldLabel: string;
    placeholder?: string;
    /** Phrase sous les onglets qui explique le mode (« Les sous-structures sont incluses. »). */
    hint?: string;
    options: MultiSelectOption[];
}
/** Une personne de l'aperçu « N employé(s) concerné(s) ». */
export interface LabsPopulationPerson {
    id: string;
    initials: string;
    name: string;
    /** Deuxième ligne (structure, poste…). */
    subtitle?: string;
}
/**
 * ## Rôle
 * Champ « population » à onglets : on cible des personnes **d'une seule façon à la fois** (personnes
 * nommées, structures, postes…), puis on voit en direct qui est concerné. Les modes sont des données :
 * le composant n'en connaît aucun. Changer d'onglet **vide la sélection** (un seul mode actif).
 *
 * Présentationnel : la page calcule `people` (la population résolue, périmètre de l'utilisateur
 * appliqué) à partir de `mode` et `value`. Sans sélection, l'aperçu est masqué ; avec une sélection qui
 * ne donne personne, `emptyText` s'affiche dans l'aperçu.
 *
 * Compose les composants du kit : `soc-tabs` (pilule), `soc-multi-select`, `soc-avatar`.
 *
 * ## Accessibilité
 * `<fieldset>` + `<legend>` (= `label`, astérisque si `required`). Le compteur est une région
 * `aria-live="polite"` : la mise à jour de la population est annoncée. L'avertissement est relié au
 * champ par `aria-describedby` sur le groupe.
 */
export declare class SocLabsPopulationPicker {
    readonly label: import("@angular/core").InputSignal<string>;
    readonly description: import("@angular/core").InputSignal<string | undefined>;
    readonly required: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly modes: import("@angular/core").InputSignal<LabsPopulationMode[]>;
    /** Onglet actif (id d'un mode). */
    readonly mode: import("@angular/core").ModelSignal<string>;
    /** Valeurs sélectionnées dans le mode actif. */
    readonly value: import("@angular/core").ModelSignal<string[]>;
    /** Population résolue, calculée par la page. */
    readonly people: import("@angular/core").InputSignal<LabsPopulationPerson[]>;
    readonly warning: import("@angular/core").InputSignal<string | undefined>;
    readonly error: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly countLabel: import("@angular/core").InputSignal<(count: number) => string>;
    readonly emptyText: import("@angular/core").InputSignal<string>;
    protected readonly warningId: string;
    protected readonly tabs: import("@angular/core").Signal<TabItem[]>;
    protected readonly activeMode: import("@angular/core").Signal<LabsPopulationMode | undefined>;
    protected readonly legendClass = "mb-[var(--bridges-position-gap-xs)] [font-family:var(--bridges-shape-text-body-font)] text-[length:var(--bridges-size-text-text-size-sm)] text-[var(--bridges-color-text-primary)] [font-weight:var(--bridges-shape-text-label-weight)]";
    protected readonly secondaryText = "[font-family:var(--bridges-shape-text-body-font)] text-[length:var(--bridges-size-text-text-size-sm)] text-[var(--bridges-color-text-secondary)]";
    protected readonly countClass = "[font-family:var(--bridges-shape-text-body-font)] text-[length:var(--bridges-size-text-text-size-sm)] text-[var(--bridges-color-text-primary)] [font-weight:var(--bridges-shape-text-label-weight)]";
    protected readonly warningClass = "flex items-start gap-[var(--bridges-position-gap-xs)] [font-family:var(--bridges-shape-text-body-font)] text-[length:var(--bridges-size-text-text-size-sm)] text-[var(--bridges-color-text-warning)]";
    protected readonly emptyClass = "[font-family:var(--bridges-shape-text-body-font)] text-[length:var(--bridges-size-text-text-size-sm)] text-[var(--bridges-color-text-danger)]";
    /** Changer d'onglet vide la sélection : un seul mode de ciblage à la fois. */
    protected selectMode(id: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsPopulationPicker, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocLabsPopulationPicker, "soc-labs-population-picker", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "modes": { "alias": "modes"; "required": true; "isSignal": true; }; "mode": { "alias": "mode"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "people": { "alias": "people"; "required": false; "isSignal": true; }; "warning": { "alias": "warning"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "countLabel": { "alias": "countLabel"; "required": false; "isSignal": true; }; "emptyText": { "alias": "emptyText"; "required": false; "isSignal": true; }; }, { "mode": "modeChange"; "value": "valueChange"; }, never, never, true, never>;
}
