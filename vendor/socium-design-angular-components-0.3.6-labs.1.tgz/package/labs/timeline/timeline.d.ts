import { type LabsTagColor } from '../tag/tag';
import * as i0 from "@angular/core";
/** Ton d'un événement : couleur de sa pastille et de son tag (tags du kit + neutre). */
export type LabsTimelineTone = 'success' | 'warning' | 'information' | 'error' | 'neutral';
export interface LabsTimelineDetail {
    label: string;
    value: string;
}
export interface LabsTimelineEvent {
    id: string;
    /** Libellé de l'événement, affiché dans un tag (« Ajout validé »). */
    label: string;
    tone: LabsTimelineTone;
    /** Date déjà formatée (« 16/10/2026 · 10:38 »). */
    date: string;
    author?: string;
    /** Rôle de l'auteur (« Admin RH »). */
    role?: string;
    /** Motif saisi, affiché entre guillemets en italique. */
    reason?: string;
    details?: LabsTimelineDetail[];
}
export interface LabsTimelineLegendItem {
    tone: LabsTimelineTone;
    label: string;
    description?: string;
}
/**
 * ## Rôle
 * Chronologie verticale d'événements (historique d'un objet) : pastille de couleur sur une ligne
 * verticale, tag de l'événement, date, « Par {auteur} · {rôle} », motif et paires libellé / valeur.
 * Légende optionnelle au-dessus (couleur → signification).
 *
 * ## Accessibilité
 * Liste ordonnée (`<ol>`), chaque événement est un `<li>` ; les pastilles sont décoratives (le sens est
 * porté par le texte du tag). Détails en liste de définitions (`<dl>`). Textes en couleur primaire /
 * secondaire du kit (contraste ≥ 4,5:1).
 */
export declare class SocLabsTimeline {
    readonly events: import("@angular/core").InputSignal<LabsTimelineEvent[]>;
    readonly legend: import("@angular/core").InputSignal<LabsTimelineLegendItem[]>;
    readonly legendLabel: import("@angular/core").InputSignal<string>;
    readonly emptyText: import("@angular/core").InputSignal<string>;
    protected readonly primaryText = "[font-family:var(--bridges-shape-text-body-font)] text-[length:var(--bridges-size-text-text-size-sm)] text-[var(--bridges-color-text-primary)]";
    protected readonly secondaryText = "[font-family:var(--bridges-shape-text-body-font)] text-[length:var(--bridges-size-text-text-size-sm)] text-[var(--bridges-color-text-secondary)]";
    protected readonly legendItemClass = "flex items-center gap-[var(--bridges-position-gap-xs)] [font-family:var(--bridges-shape-text-body-font)] text-[length:var(--bridges-size-text-text-size-sm)] text-[var(--bridges-color-text-secondary)]";
    protected dotClass(tone: LabsTimelineTone): string;
    protected tagColor(tone: LabsTimelineTone): LabsTagColor;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsTimeline, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocLabsTimeline, "soc-labs-timeline", never, { "events": { "alias": "events"; "required": true; "isSignal": true; }; "legend": { "alias": "legend"; "required": false; "isSignal": true; }; "legendLabel": { "alias": "legendLabel"; "required": false; "isSignal": true; }; "emptyText": { "alias": "emptyText"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
