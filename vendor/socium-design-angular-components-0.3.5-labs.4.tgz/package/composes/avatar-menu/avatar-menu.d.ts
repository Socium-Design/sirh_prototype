import * as i0 from "@angular/core";
/**
 * Contenu du menu déroulant ouvert au clic sur l'avatar dans `HeaderApp` — à passer à sa prop
 * `avatarMenu` (rendu dans un `Popover` ancré à l'AvatarZone). Ne s'utilise jamais seul en dehors de
 * ce contexte : ce n'est qu'un panneau de contenu, pas un composant de déclenchement. Plain wrapper
 * (`soc-avatar-menu`); React's root `<div className>` is this host, so a literal `class` on
 * `<soc-avatar-menu>` replaces React's `className` prop.
 *
 * Maps 1:1 to Figma's "AvatarMenu" (node 630:2682) — reuses the popover surface tokens of
 * `Menu`/`Popover` (`Index/Conteneur/Menu/popover-*`), no distinct token set exists for this panel.
 *
 * GAP-DECISION (flagged, not decided silently): React shows the "Voir profil" / "Modifier avatar"
 * ghost buttons only when the matching `onViewProfile` / `onEditAvatar` prop is *passed* ("Omit to
 * hide"). An Angular `output()` has no public way to ask whether anyone subscribed, so that
 * presence-of-handler signal can't be reproduced. Mirrored with two explicit boolean inputs,
 * `showViewProfile` / `showEditAvatar` (both false by default, i.e. hidden — same default as
 * "handler omitted" in React), next to the `viewProfile` / `editAvatar` outputs. `disconnect` is
 * always rendered, like React's required `onDisconnect`.
 */
export declare class SocAvatarMenu {
    readonly userName: import("@angular/core").InputSignal<string>;
    readonly userEmail: import("@angular/core").InputSignal<string>;
    /** Initials shown in the profile circle — 2 characters max, forwarded to `Avatar`. */
    readonly avatarLabel: import("@angular/core").InputSignal<string>;
    readonly showViewProfile: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly showEditAvatar: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly viewProfile: import("@angular/core").OutputEmitterRef<void>;
    readonly editAvatar: import("@angular/core").OutputEmitterRef<void>;
    readonly disconnect: import("@angular/core").OutputEmitterRef<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocAvatarMenu, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocAvatarMenu, "soc-avatar-menu", never, { "userName": { "alias": "userName"; "required": true; "isSignal": true; }; "userEmail": { "alias": "userEmail"; "required": true; "isSignal": true; }; "avatarLabel": { "alias": "avatarLabel"; "required": true; "isSignal": true; }; "showViewProfile": { "alias": "showViewProfile"; "required": false; "isSignal": true; }; "showEditAvatar": { "alias": "showEditAvatar"; "required": false; "isSignal": true; }; }, { "viewProfile": "viewProfile"; "editAvatar": "editAvatar"; "disconnect": "disconnect"; }, never, never, true, never>;
}
