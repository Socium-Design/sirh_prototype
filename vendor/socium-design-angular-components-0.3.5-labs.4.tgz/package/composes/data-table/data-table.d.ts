import { TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
/** What a cell/card template receives: `let-row` (the implicit value) or `let-row="row"`. */
export interface DataTableCellContext<T> {
    $implicit: T;
    row: T;
}
/** What a `rowActionsMenu` template receives — call `close()` from each menu item's `(click)` once
 * the action is handled (the popover is controlled internally; nothing closes it automatically just
 * because a child was clicked). */
export interface DataTableRowActionsContext<T> {
    $implicit: T;
    row: T;
    close: () => void;
}
export interface DataTableColumn<T> {
    key: string;
    header: string;
    /** React's `render: (row) => ReactNode` has no Angular equivalent for rich content: a function
     * returning a plain `string` covers text cells; a `TemplateRef` (an `<ng-template let-row>` the
     * consumer owns, since only the consumer's template can instantiate its own components) covers
     * anything richer — a `soc-tag`, a `soc-badge`, a link, etc. */
    render: ((row: T) => string) | TemplateRef<DataTableCellContext<T>>;
}
/** What a single card shows in `mode="card"` — the card-mode counterpart to a table row built from
 * `columns`, one of these per row instead of one cell per column. No `icon` field on purpose:
 * `DataTable`'s cards never show `Card`'s icon area, unlike standalone `Card` usage. */
export interface DataTableCardContent<T> {
    title: string;
    subtitle?: string;
    /** Free-form card body — a `TemplateRef` (see `DataTableColumn.render`), same free-form idea as
     * a table column's `render`. */
    body?: TemplateRef<DataTableCellContext<T>>;
    footer?: TemplateRef<DataTableCellContext<T>>;
}
/** Plain data only — React's `onPageChange`/`onPageSizeChange` live on this object there; here they
 * are the `pageChange`/`pageSizeChange` outputs of `soc-data-table` itself. */
export interface DataTablePagination {
    currentPage: number;
    totalPages: number;
    totalEntries?: number;
    pageSize?: number;
}
export type DataTableMode = 'table' | 'detail' | 'card';
/** React `badge` — consumer-supplied Badge next to `title` (`table`/`card` mode), typically an
 * instance count when several objects of the same type are listed on one page. */
export declare class SocDataTableBadge {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocDataTableBadge, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocDataTableBadge, "[socDataTableBadge]", never, {}, {}, never, never, true, never>;
}
/** React `filters` — extra controls rendered next to the search bar — Selects, filters, etc. */
export declare class SocDataTableFilters {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocDataTableFilters, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocDataTableFilters, "[socDataTableFilters]", never, {}, {}, never, never, true, never>;
}
/** React `actions` — buttons rendered on the right of the action line, typically Button (icon-only
 * + primary). The right-hand wrapper only renders when something is projected here. */
export declare class SocDataTableActions {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocDataTableActions, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocDataTableActions, "[socDataTableActions]", never, {}, {}, never, never, true, never>;
}
/**
 * Maps 1:1 to "Index/Données/DataTable/*" tokens — see packages/tokens/tokens/components/données.json
 * in design_system (React reference repo, read only). Composes `soc-search-bar`, `soc-checkbox`,
 * `soc-pagination`, `soc-popover`/`soc-tooltip` and (card mode) `soc-card-grid`/`soc-card`, same as
 * React. Plain generic wrapper (`soc-data-table`, `<T>` = the row type).
 *
 * `mode`: "table" (Figma "Data Table 1", default) — full grid with search/actions/pagination.
 * "detail" ("Data Table 2") — a single record as a label/value list: columns become row labels,
 * `rows[0]` is the record. "card" (code-only mode) — the title/subtitle/search/filters/actions zone
 * is identical to "table"; only the row grid becomes a `soc-card-grid` of `soc-card`s, one per row
 * (`cardContent` builds each). Multi-select and sorting don't apply to card mode (see React's own
 * `DataTable.tsx` docstring for why; `DataTable` has never implemented sorting in any mode).
 *
 * ## Contraintes de composition (unchanged from React)
 * - `rowActions` (action unique, `(rowAction)`) ou `rowActionsMenu` (plusieurs actions
 *   conditionnelles) pour toute action de ligne — jamais de bouton d'action personnalisé en plus.
 * - `rowActionsMenu` pour toute liste d'actions conditionnelles par ligne — jamais une `Dialog`,
 *   toujours un menu contextuel (`soc-popover position="bottom-end"`, croît vers la gauche, jamais
 *   coupé par un tableau scrollable horizontalement).
 * - Le retrait gauche (première colonne — checkbox si `selectable`, sinon première colonne de
 *   données) est toujours `title-zone-pad-h`, jamais `header-pad-h`/`cell-pad-h`; l'écart checkbox →
 *   première colonne est le token dédié `checkbox-col-pad-right`.
 * - Le placeholder ("Rechercher ici...") et la largeur (260px) de la barre de recherche sont fixes
 *   au niveau du composant, jamais une prop.
 * - `mode="card"` réutilise `rowClick`/`rowAction`/`rowActionsMenu` tels quels; la grille est un
 *   `soc-card-grid` en `mode="fixed"`.
 *
 * ## GAP-DECISIONS (flagged, not decided silently) — React idioms with no Angular equivalent
 * 1. **Presence of a callback prop.** React turns features on by passing the handler: `onSearch`
 *    shows the search bar, `onRowClick` makes rows clickable/hoverable, `onRowAction` adds the
 *    "•••" column. An Angular `output()` can't be asked "does anyone listen?", so each is an
 *    explicit boolean input next to its output: `searchable`/`(search)`, `rowClickable`/
 *    `(rowClick)`, `rowActions`/`(rowAction)`. All default to false (= "handler omitted").
 *    `rowActionsMenu` is a template *input*, so its presence is directly detectable and also adds
 *    the "•••" column on its own, as in React.
 * 2. **`ReactNode`-returning functions.** `columns[].render`, `cardContent().body/footer` and
 *    `rowActionsMenu` return rich JSX in React; here they are `TemplateRef`s the consumer declares
 *    (`<ng-template let-row>`), with the row (and `close` for the menu) as context. `render` also
 *    accepts a plain `(row) => string` for text cells.
 * 3. **`ReactNode` slots** (`badge`, `filters`, `actions`) -> marker-directive content slots.
 * 4. **`selectedKeys`/`onSelectedKeysChange`** -> `selectedKeys` input + `selectedKeysChange`
 *    output (so `[(selectedKeys)]` works). **`pagination`'s callbacks** -> `pageChange`/
 *    `pageSizeChange` outputs on this component.
 */
export declare class SocDataTable<T> {
    readonly mode: import("@angular/core").InputSignal<DataTableMode>;
    readonly title: import("@angular/core").InputSignal<string | undefined>;
    readonly subtitle: import("@angular/core").InputSignal<string | undefined>;
    readonly columns: import("@angular/core").InputSignal<DataTableColumn<T>[]>;
    readonly cardContent: import("@angular/core").InputSignal<((row: T) => DataTableCardContent<T>) | undefined>;
    readonly rows: import("@angular/core").InputSignal<T[]>;
    readonly rowKey: import("@angular/core").InputSignal<(row: T) => string>;
    readonly selectable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly selectedKeys: import("@angular/core").InputSignal<Set<string> | undefined>;
    readonly selectedKeysChange: import("@angular/core").OutputEmitterRef<Set<string>>;
    readonly searchable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly search: import("@angular/core").OutputEmitterRef<string>;
    readonly rowClickable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly rowClick: import("@angular/core").OutputEmitterRef<T>;
    readonly rowActions: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly rowAction: import("@angular/core").OutputEmitterRef<T>;
    readonly rowActionsMenu: import("@angular/core").InputSignal<TemplateRef<DataTableRowActionsContext<T>> | undefined>;
    readonly pagination: import("@angular/core").InputSignal<DataTablePagination | undefined>;
    readonly pageChange: import("@angular/core").OutputEmitterRef<number>;
    readonly pageSizeChange: import("@angular/core").OutputEmitterRef<number>;
    private readonly actionsContent;
    protected readonly hasActions: import("@angular/core").Signal<boolean>;
    protected readonly hasRowActions: import("@angular/core").Signal<boolean>;
    protected readonly rowActionButtonClass = "inline-flex size-[var(--index-donn\u00E9es-datatable-action-icon-size)] cursor-pointer items-center justify-center text-[var(--index-donn\u00E9es-datatable-action-icon-color)] hover:text-[var(--index-donn\u00E9es-datatable-action-icon-hover)]";
    protected readonly cardActionButtonClass = "flex size-[24px] shrink-0 items-center justify-center rounded-[var(--index-conteneur-card-action-radius)] px-[var(--index-conteneur-card-action-pad-h)] py-[var(--index-conteneur-card-action-pad-v)] hover:bg-[var(--index-conteneur-card-action-bg-hover)]";
    protected readonly cardActionIconThickness = "var(--index-conteneur-card-action-icon-thickness)";
    protected readonly record: import("@angular/core").Signal<T>;
    protected readonly openActionsKey: import("@angular/core").WritableSignal<string | null>;
    protected setActionsOpen(key: string, open: boolean): void;
    protected readonly closeActions: () => void;
    protected templateOf(column: DataTableColumn<T>): TemplateRef<DataTableCellContext<T>> | null;
    protected textOf(column: DataTableColumn<T>, row: T): string;
    protected readonly allKeys: import("@angular/core").Signal<string[]>;
    protected readonly allSelected: import("@angular/core").Signal<boolean>;
    protected isSelected(key: string): boolean;
    protected toggleAll(): void;
    protected toggleRow(key: string): void;
    protected onRowClick(row: T): void;
    protected onCardAction(row: T): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocDataTable<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocDataTable<any>, "soc-data-table", never, { "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; "columns": { "alias": "columns"; "required": true; "isSignal": true; }; "cardContent": { "alias": "cardContent"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": true; "isSignal": true; }; "rowKey": { "alias": "rowKey"; "required": true; "isSignal": true; }; "selectable": { "alias": "selectable"; "required": false; "isSignal": true; }; "selectedKeys": { "alias": "selectedKeys"; "required": false; "isSignal": true; }; "searchable": { "alias": "searchable"; "required": false; "isSignal": true; }; "rowClickable": { "alias": "rowClickable"; "required": false; "isSignal": true; }; "rowActions": { "alias": "rowActions"; "required": false; "isSignal": true; }; "rowActionsMenu": { "alias": "rowActionsMenu"; "required": false; "isSignal": true; }; "pagination": { "alias": "pagination"; "required": false; "isSignal": true; }; }, { "selectedKeysChange": "selectedKeysChange"; "search": "search"; "rowClick": "rowClick"; "rowAction": "rowAction"; "pageChange": "pageChange"; "pageSizeChange": "pageSizeChange"; }, ["actionsContent"], ["[socDataTableBadge]", "[socDataTableFilters]", "[socDataTableActions]"], true, never>;
}
