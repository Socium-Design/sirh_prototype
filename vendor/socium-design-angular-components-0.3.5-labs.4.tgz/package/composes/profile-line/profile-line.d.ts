import { type AvatarColor } from '../../primitifs/avatar/avatar';
import * as i0 from "@angular/core";
/**
 * Maps 1:1 to "Index/Données/ProfileLine/*" tokens — see packages/tokens/tokens/components/données.json
 * in design_system (React reference repo, read only). Plain wrapper (`soc-profile-line`); React's
 * root `<div className>` is this host, so a literal `class` on `<soc-profile-line>` replaces its
 * `className` prop. The avatar is always LG/solid per Figma's component notes. Meta fields not
 * passed are simply omitted from the dot-separated row rather than rendered empty.
 *
 * React's `id` prop is the displayed employee id (e.g. "#123456789"), not a DOM id — kept as `id`
 * for parity, with the host's own `id` attribute cleared so a static `id="..."` isn't also left on
 * the element as a stray DOM id.
 */
export declare class SocProfileLine {
    /** Initials shown in the avatar circle — 2 characters max. */
    readonly avatarLabel: import("@angular/core").InputSignal<string>;
    readonly avatarColor: import("@angular/core").InputSignal<AvatarColor>;
    readonly name: import("@angular/core").InputSignal<string>;
    readonly id: import("@angular/core").InputSignal<string | undefined>;
    readonly role: import("@angular/core").InputSignal<string | undefined>;
    readonly department: import("@angular/core").InputSignal<string | undefined>;
    readonly email: import("@angular/core").InputSignal<string | undefined>;
    readonly company: import("@angular/core").InputSignal<string | undefined>;
    protected readonly metaItems: import("@angular/core").Signal<string[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocProfileLine, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocProfileLine, "soc-profile-line", never, { "avatarLabel": { "alias": "avatarLabel"; "required": true; "isSignal": true; }; "avatarColor": { "alias": "avatarColor"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": true; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "role": { "alias": "role"; "required": false; "isSignal": true; }; "department": { "alias": "department"; "required": false; "isSignal": true; }; "email": { "alias": "email"; "required": false; "isSignal": true; }; "company": { "alias": "company"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
