import { SocFormControl } from '../../internal/form-control';
import { type SelectOption } from '../select/select';
import * as i0 from "@angular/core";
/**
 * `soc-select` locked to `mode="labelHeader"` — the compact filter style (title stacked above the
 * value inside the field, no separate label row) used for filters above a `DataTable`/`PageList`.
 * `mode` isn't exposed here on purpose, same reasoning as React: use `soc-table-filter-select` for
 * every table filter and that choice is made once, here, not re-decided at each call site.
 *
 * Same inputs as `SocSelect` otherwise (React: `Omit<SelectProps, 'mode'>`), forwarded one by one —
 * Angular has no "spread the props" equivalent for a component. Like React (which returns `Select`
 * directly), no root element of its own: host is `display: contents`.
 */
export declare class SocTableFilterSelect extends SocFormControl<string | undefined> {
    readonly label: import("@angular/core").InputSignal<string | undefined>;
    readonly required: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly error: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly warning: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly helperText: import("@angular/core").InputSignal<string | undefined>;
    readonly placeholder: import("@angular/core").InputSignal<string>;
    readonly options: import("@angular/core").InputSignal<SelectOption[]>;
    readonly value: import("@angular/core").ModelSignal<string | undefined>;
    readonly defaultValue: import("@angular/core").InputSignal<string | undefined>;
    protected readonly valueModel: import("@angular/core").ModelSignal<string | undefined>;
    protected coerce(value: unknown): string | undefined;
    readonly id: import("@angular/core").InputSignal<string | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocTableFilterSelect, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocTableFilterSelect, "soc-table-filter-select", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "warning": { "alias": "warning"; "required": false; "isSignal": true; }; "helperText": { "alias": "helperText"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "defaultValue": { "alias": "defaultValue"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}
