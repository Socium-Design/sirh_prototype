import { SocFormControl } from '../../internal/form-control';
import * as i0 from "@angular/core";
export interface MultiSelectOption {
    value: string;
    label: string;
}
/**
 * Maps 1:1 to "Index/Selection/Select/*" tokens for the field box (Multi-select has no dedicated
 * field tokens of its own — its Figma dependency is Select + Chips) plus "Index/Selection/Chips/*"
 * (type=Input) for the selected-value tags — see packages/tokens/tokens/components/selection.json
 * in design_system (React reference repo, read only). Plain wrapper (`soc-multi-select`) built on
 * `soc-popover` + `soc-menu` (checkbox mode), same as React.
 *
 * `value`/`onChange` are both required in React (purely controlled). A `model()` here (`[(value)]`
 * or `[value]` + `(valueChange)`) so the component is also a form control (`formControl`,
 * `formControlName`, `ngModel`).
 */
export declare class SocMultiSelect extends SocFormControl<string[]> {
    readonly label: import("@angular/core").InputSignal<string | undefined>;
    readonly required: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly error: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly warning: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly helperText: import("@angular/core").InputSignal<string | undefined>;
    readonly placeholder: import("@angular/core").InputSignal<string>;
    readonly options: import("@angular/core").InputSignal<MultiSelectOption[]>;
    readonly value: import("@angular/core").ModelSignal<string[]>;
    readonly id: import("@angular/core").InputSignal<string | undefined>;
    protected readonly valueModel: import("@angular/core").ModelSignal<string[]>;
    protected coerce(value: unknown): string[];
    protected readonly iconThickness = "var(--index-selection-select-icon-thickness)";
    protected readonly helpIconThickness = "var(--index-selection-select-icon-help-thickness)";
    private readonly generatedId;
    protected get fieldId(): string;
    protected readonly selectedOptions: import("@angular/core").Signal<MultiSelectOption[]>;
    protected onOpenChange(open: boolean): void;
    protected toggle(optionValue: string): void;
    protected readonly labelClass: import("@angular/core").Signal<string>;
    protected readonly fieldClass: import("@angular/core").Signal<string>;
    protected readonly helperIconColorClass: import("@angular/core").Signal<"text-[var(--index-selection-select-icon-help-error)]" | "text-[var(--index-selection-select-icon-help-warning)]" | "text-[var(--index-selection-select-icon-help)]">;
    protected readonly helperTextColorClass: import("@angular/core").Signal<"text-[var(--index-selection-select-help-color-error)]" | "text-[var(--index-selection-select-help-color-warning)]" | "text-[var(--index-selection-select-help-color)]">;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocMultiSelect, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocMultiSelect, "soc-multi-select", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "warning": { "alias": "warning"; "required": false; "isSignal": true; }; "helperText": { "alias": "helperText"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}
