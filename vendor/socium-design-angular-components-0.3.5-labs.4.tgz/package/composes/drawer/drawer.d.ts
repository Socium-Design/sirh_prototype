import * as i0 from "@angular/core";
export type DrawerAnchor = 'left' | 'right' | 'bottom';
export interface DrawerAction {
    label: string;
    onClick?: () => void;
}
/**
 * Maps 1:1 to "Index/Conteneur/Drawer/*" tokens — see packages/tokens/tokens/components/conteneur.json
 * in design_system (React reference repo, read only). Plain wrapper (`soc-drawer`), same
 * open/close/portal/actions conventions as `SocDialog` (see its doc, not repeated here).
 */
export declare class SocDrawer {
    readonly open: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly title: import("@angular/core").InputSignal<string>;
    readonly topline: import("@angular/core").InputSignal<string | undefined>;
    readonly subtitle: import("@angular/core").InputSignal<string | undefined>;
    readonly anchor: import("@angular/core").InputSignal<DrawerAnchor>;
    readonly sectionTitle: import("@angular/core").InputSignal<string | undefined>;
    readonly sectionSubtitle: import("@angular/core").InputSignal<string | undefined>;
    readonly primaryAction: import("@angular/core").InputSignal<DrawerAction | undefined>;
    readonly secondaryAction: import("@angular/core").InputSignal<DrawerAction | undefined>;
    readonly close: import("@angular/core").OutputEmitterRef<void>;
    protected readonly closeIconThickness = "var(--index-conteneur-drawer-close-icon-thickness)";
    protected readonly panelClass: import("@angular/core").Signal<string>;
    private readonly overlayRef;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<SocDrawer, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocDrawer, "soc-drawer", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": true; "isSignal": true; }; "topline": { "alias": "topline"; "required": false; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; "anchor": { "alias": "anchor"; "required": false; "isSignal": true; }; "sectionTitle": { "alias": "sectionTitle"; "required": false; "isSignal": true; }; "sectionSubtitle": { "alias": "sectionSubtitle"; "required": false; "isSignal": true; }; "primaryAction": { "alias": "primaryAction"; "required": false; "isSignal": true; }; "secondaryAction": { "alias": "secondaryAction"; "required": false; "isSignal": true; }; }, { "close": "close"; }, never, ["*"], true, never>;
}
/** A label/value row matching Figma's Drawer "Détail" mode — see Index/Conteneur/Drawer/detail-*. */
export declare class SocDrawerDetailItem {
    readonly label: import("@angular/core").InputSignal<string>;
    readonly value: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocDrawerDetailItem, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocDrawerDetailItem, "soc-drawer-detail-item", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
