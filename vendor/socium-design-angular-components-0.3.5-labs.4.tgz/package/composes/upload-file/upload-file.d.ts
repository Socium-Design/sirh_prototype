import { SocFormControl } from '../../internal/form-control';
import * as i0 from "@angular/core";
/**
 * Maps 1:1 to "Index/Input/UploadFile/*" tokens — see packages/tokens/tokens/components/input.json
 * in design_system (React reference repo, read only). Plain wrapper (`soc-upload-file`): a drop zone
 * (div) + a `soc-button`-styled trigger + a hidden native `<input type="file">`, not one native
 * element. `onFilesSelected` -> `filesSelected` output (carries the `FileList`, same as React);
 * `accept`/`multiple`/`disabled` are forwarded to the hidden input.
 *
 * Also a form control (`formControl`, `formControlName`, `ngModel`) whose value is the selected
 * `File[]` (a `FileList` can't be assigned, so the form works with a plain array; `null` after
 * `reset()` empties it). React's component doesn't list the chosen files — neither does this one; the
 * consumer displays them from `(filesSelected)` or the form value.
 */
export declare class SocUploadFile extends SocFormControl<File[]> {
    readonly error: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly warning: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly helperText: import("@angular/core").InputSignal<string | undefined>;
    readonly accept: import("@angular/core").InputSignal<string | undefined>;
    readonly multiple: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly filesSelected: import("@angular/core").OutputEmitterRef<FileList>;
    readonly files: import("@angular/core").ModelSignal<File[]>;
    protected readonly valueModel: import("@angular/core").ModelSignal<File[]>;
    private readonly fileInput;
    protected coerce(value: unknown): File[];
    protected readonly dragging: import("@angular/core").WritableSignal<boolean>;
    protected onDragOver(e: DragEvent): void;
    protected onDrop(e: DragEvent): void;
    protected onChange(e: Event): void;
    private select;
    protected readonly zoneClass: import("@angular/core").Signal<string>;
    protected readonly helperClass: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocUploadFile, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocUploadFile, "soc-upload-file", never, { "error": { "alias": "error"; "required": false; "isSignal": true; }; "warning": { "alias": "warning"; "required": false; "isSignal": true; }; "helperText": { "alias": "helperText"; "required": false; "isSignal": true; }; "accept": { "alias": "accept"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "files": { "alias": "files"; "required": false; "isSignal": true; }; }, { "filesSelected": "filesSelected"; "files": "filesChange"; }, never, never, true, never>;
}
