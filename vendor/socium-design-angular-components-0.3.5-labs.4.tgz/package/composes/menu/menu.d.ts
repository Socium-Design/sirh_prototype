import * as i0 from "@angular/core";
export type MenuItemLevel = 1 | 2 | 3;
export type MenuItemMode = 'icon' | 'checkbox' | 'radio';
/** React `MenuItem`'s `icon?: ReactNode` — only rendered when `mode === 'icon'`. */
export declare class SocMenuItemIcon {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocMenuItemIcon, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocMenuItemIcon, "[socMenuItemIcon]", never, {}, {}, never, never, true, never>;
}
/**
 * Attribute selector on a real `<button>` (`button[socMenuItem]`) — React's `MenuItem` root IS a
 * single `<button type="button">`, same shape as `Button` itself, so `(click)` (React `onClick`),
 * `disabled`, `aria-*` etc. are just the native ones. Maps 1:1 to "Index/Conteneur/Menu/*" tokens —
 * see packages/tokens/tokens/components/conteneur.json in design_system (React reference repo,
 * read only). `icon` -> named content slot (`socMenuItemIcon`).
 *
 * `checked` is optional here exactly like in React: undefined leaves the inner `Checkbox`
 * uncontrolled (it keeps its own state), a value drives it. One known difference, only reachable by
 * passing `checked` without ever updating it on click: React's controlled `Checkbox` then ignores
 * the click, whereas `soc-checkbox`'s `model()` flips its own value locally until the bound value
 * next changes. Normal usage (parent toggles `checked` in its own `(click)` handler) is identical.
 */
export declare class SocMenuItem {
    readonly label: import("@angular/core").InputSignal<string>;
    readonly level: import("@angular/core").InputSignal<MenuItemLevel>;
    readonly mode: import("@angular/core").InputSignal<MenuItemMode>;
    readonly checked: import("@angular/core").InputSignal<boolean | undefined>;
    private readonly iconContent;
    protected readonly hasIcon: import("@angular/core").Signal<boolean>;
    protected readonly hostClasses: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocMenuItem, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocMenuItem, "button[socMenuItem]", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "level": { "alias": "level"; "required": false; "isSignal": true; }; "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "checked": { "alias": "checked"; "required": false; "isSignal": true; }; }, {}, ["iconContent"], ["[socMenuItemIcon]"], true, never>;
}
/**
 * No native HTML equivalent — plain wrapper (`soc-menu`). A list of `button[socMenuItem]`, meant to
 * be the projected content of a `soc-popover`. React's `className` merge needs no input here: a
 * literal `class="..."` on `<soc-menu>` composes with this host's own classes natively.
 */
export declare class SocMenu {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocMenu, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocMenu, "soc-menu", never, {}, {}, never, ["*"], true, never>;
}
