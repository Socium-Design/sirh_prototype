import * as i0 from "@angular/core";
export interface EnterpriseOption {
    value: string;
    company: string;
    subsidiary: string;
    /** Small trailing meta, e.g. a subsidiary index like "1/12". */
    count?: string;
}
/**
 * Maps 1:1 to "Index/Selection/Select/enterprise-*" tokens — a distinct always-dark trigger for
 * switching between companies/subsidiaries (used in HeaderApp), not a form field. Plain wrapper
 * (`soc-enterprise-select`) built on `soc-popover` + `soc-menu`, same as React. `value`/
 * `defaultValue`/`onChange` -> one `model()` (see `LanguageSelect`); React's `className` targets
 * the trigger button, exposed as `triggerClass` for the same reason (no root element of its own).
 */
export declare class SocEnterpriseSelect {
    readonly options: import("@angular/core").InputSignal<EnterpriseOption[]>;
    readonly value: import("@angular/core").ModelSignal<string | undefined>;
    readonly defaultValue: import("@angular/core").InputSignal<string | undefined>;
    readonly triggerClass: import("@angular/core").InputSignal<string | undefined>;
    protected readonly open: import("@angular/core").WritableSignal<boolean>;
    private readonly currentValue;
    protected readonly current: import("@angular/core").Signal<EnterpriseOption>;
    protected readonly triggerClasses: import("@angular/core").Signal<string>;
    protected selectOption(next: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocEnterpriseSelect, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocEnterpriseSelect, "soc-enterprise-select", never, { "options": { "alias": "options"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "defaultValue": { "alias": "defaultValue"; "required": false; "isSignal": true; }; "triggerClass": { "alias": "triggerClass"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}
