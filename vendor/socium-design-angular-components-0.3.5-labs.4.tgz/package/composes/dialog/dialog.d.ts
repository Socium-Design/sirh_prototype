import * as i0 from "@angular/core";
export interface DialogAction {
    label: string;
    onClick?: () => void;
}
/**
 * ## Rôle
 * Fenêtre modale bloquante, superposée au contenu de la page, pour une action ou une information
 * qui exige l'attention exclusive de l'utilisateur avant qu'il puisse continuer.
 *
 * ## Quand l'utiliser
 * - Toute action nécessitant une confirmation explicite avant exécution (suppression, annulation
 *   d'un processus en cours, désactivation, etc.).
 * - Saisie ou consultation ponctuelle qui ne justifie pas une page dédiée.
 *
 * ## Contraintes de composition
 * - Toute action nécessitant une confirmation de l'utilisateur (suppression, annulation, etc.) doit
 *   systématiquement passer par une instance de `soc-dialog` avec `[open]="true"` — jamais une
 *   confirmation inline (`window.confirm`, un simple changement d'état de bouton, une modification
 *   silencieuse sans dialogue) ne remplace ce composant.
 * - Un seul `soc-dialog` ouvert à la fois — ne jamais en empiler plusieurs.
 *
 * Maps 1:1 to "Index/Conteneur/Dialog/*" tokens — see packages/tokens/tokens/components/conteneur.json
 * in design_system (React reference repo, read only). Plain wrapper (`soc-dialog`). `onClose` ->
 * `close` output; `open` stays purely controlled (React has no internal fallback): plain `input()`.
 * `primaryAction`/`secondaryAction` keep React's `{ label, onClick? }` data shape (per-item
 * callbacks, like `Breadcrumb`'s items) — their *presence* decides whether the footer renders.
 *
 * Portaled to `document.body` via a direct `appendChild` while open, same technique as `Popover`/
 * `Tooltip` (React: `createPortal`). Unlike React, projected content is created once with the parent
 * (Angular content projection can't be unmounted/remounted by the child) — only its placement
 * follows `open`.
 */
export declare class SocDialog {
    readonly open: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly title: import("@angular/core").InputSignal<string>;
    readonly primaryAction: import("@angular/core").InputSignal<DialogAction | undefined>;
    readonly secondaryAction: import("@angular/core").InputSignal<DialogAction | undefined>;
    readonly close: import("@angular/core").OutputEmitterRef<void>;
    protected readonly closeIconThickness = "var(--index-conteneur-dialog-close-icon-thickness)";
    private readonly overlayRef;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<SocDialog, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocDialog, "soc-dialog", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": true; "isSignal": true; }; "primaryAction": { "alias": "primaryAction"; "required": false; "isSignal": true; }; "secondaryAction": { "alias": "secondaryAction"; "required": false; "isSignal": true; }; }, { "close": "close"; }, never, ["*"], true, never>;
}
