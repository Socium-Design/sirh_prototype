import * as i0 from "@angular/core";
export interface LanguageOption {
    value: string;
    label: string;
}
/**
 * Sélecteur de langue toujours affiché dans `HeaderApp` — un déclencheur compact (ex. "EN" +
 * chevron) qui ouvre un menu contextuel de choix. Plain wrapper (`soc-language-select`), built on
 * `soc-popover` + `soc-menu` like React. Uses `Index/Selection/Select/field-light-*` tokens (white
 * text/border) since it sits on HeaderApp's always-dark background.
 *
 * React's `value`/`defaultValue`/`onChange` collapse to one `model()` (`[(value)]`), same pattern
 * as `Select`; the fallback chain `defaultValue ?? options[0]` is kept. React's `className` targets
 * the *trigger button* (this component has no root element of its own — `Popover` is a fragment),
 * so it can't be a plain `class` on `<soc-language-select>`: exposed as `triggerClass` instead.
 */
export declare class SocLanguageSelect {
    readonly options: import("@angular/core").InputSignal<LanguageOption[]>;
    readonly value: import("@angular/core").ModelSignal<string | undefined>;
    readonly defaultValue: import("@angular/core").InputSignal<string | undefined>;
    readonly triggerClass: import("@angular/core").InputSignal<string | undefined>;
    protected readonly iconThickness = "var(--index-selection-select-icon-thickness)";
    protected readonly open: import("@angular/core").WritableSignal<boolean>;
    private readonly currentValue;
    protected readonly current: import("@angular/core").Signal<LanguageOption>;
    protected readonly triggerClasses: import("@angular/core").Signal<string>;
    protected selectOption(next: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLanguageSelect, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocLanguageSelect, "soc-language-select", never, { "options": { "alias": "options"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "defaultValue": { "alias": "defaultValue"; "required": false; "isSignal": true; }; "triggerClass": { "alias": "triggerClass"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}
