import { SocFormControl } from '../../internal/form-control';
import * as i0 from "@angular/core";
export interface SelectOption {
    value: string;
    label: string;
}
export type SelectMode = 'formulaire' | 'labelHeader';
export declare const SELECT_DEFAULT_PLACEHOLDER = "Select an option";
/**
 * No native HTML equivalent (label + custom trigger + popover list + helper row) — plain wrapper
 * (`soc-select`). Maps 1:1 to "Index/Selection/Select/*" tokens — see
 * packages/tokens/tokens/components/selection.json in design_system (React reference repo, read
 * only). Built on `soc-popover` + `soc-menu`, same as React.
 *
 * "formulaire" (default): label above the field. "labelHeader": no label above — `label` renders as
 * a small uppercase title inside the field, stacked above the value (compact inline filters).
 *
 * React's `value` (controlled) / `defaultValue` (uncontrolled) / `onChange` collapse to one `model()`
 * (`[(value)]`), same pattern as `Checkbox`/`Switch`; `defaultValue` is kept as its own input and
 * only used while `value` is still undefined, so an uncontrolled `defaultValue` behaves as in React
 * (first selection takes over).
 */
export declare class SocSelect extends SocFormControl<string | undefined> {
    readonly label: import("@angular/core").InputSignal<string | undefined>;
    readonly mode: import("@angular/core").InputSignal<SelectMode>;
    readonly required: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly error: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly warning: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly helperText: import("@angular/core").InputSignal<string | undefined>;
    readonly placeholder: import("@angular/core").InputSignal<string>;
    readonly options: import("@angular/core").InputSignal<SelectOption[]>;
    readonly value: import("@angular/core").ModelSignal<string | undefined>;
    protected readonly valueModel: import("@angular/core").ModelSignal<string | undefined>;
    protected coerce(value: unknown): string | undefined;
    readonly defaultValue: import("@angular/core").InputSignal<string | undefined>;
    readonly id: import("@angular/core").InputSignal<string | undefined>;
    protected readonly iconThickness = "var(--index-selection-select-icon-thickness)";
    protected readonly helpIconThickness = "var(--index-selection-select-icon-help-thickness)";
    private readonly generatedId;
    protected get selectId(): string;
    protected readonly open: import("@angular/core").WritableSignal<boolean>;
    protected readonly isOpen: import("@angular/core").Signal<boolean>;
    protected readonly currentValue: import("@angular/core").Signal<string | undefined>;
    protected readonly selectedOption: import("@angular/core").Signal<SelectOption | undefined>;
    private readonly helperIsError;
    private readonly helperIsWarning;
    protected onOpenChange(open: boolean): void;
    protected selectOption(optionValue: string): void;
    protected readonly labelClass: import("@angular/core").Signal<string>;
    protected readonly fieldClass: import("@angular/core").Signal<string>;
    protected valueColorClass(labelHeader: boolean): string;
    protected readonly helperIconColorClass: import("@angular/core").Signal<"text-[var(--index-selection-select-icon-help-error)]" | "text-[var(--index-selection-select-icon-help-warning)]" | "text-[var(--index-selection-select-icon-help)]">;
    protected readonly helperTextColorClass: import("@angular/core").Signal<"text-[var(--index-selection-select-help-color-error)]" | "text-[var(--index-selection-select-help-color-warning)]" | "text-[var(--index-selection-select-help-color)]">;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocSelect, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocSelect, "soc-select", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "warning": { "alias": "warning"; "required": false; "isSignal": true; }; "helperText": { "alias": "helperText"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "defaultValue": { "alias": "defaultValue"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}
