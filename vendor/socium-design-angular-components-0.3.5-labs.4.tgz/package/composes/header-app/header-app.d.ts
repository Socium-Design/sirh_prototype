import * as i0 from "@angular/core";
/** React `HeaderApp`'s `left: ReactNode` — typically an EnterpriseSelect or a Logo. */
export declare class SocHeaderAppLeft {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocHeaderAppLeft, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocHeaderAppLeft, "[socHeaderAppLeft]", never, {}, {}, never, never, true, never>;
}
/** React `avatar: ReactNode` — typically a `soc-avatar` (size="md", mode="solid"). */
export declare class SocHeaderAppAvatar {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocHeaderAppAvatar, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocHeaderAppAvatar, "[socHeaderAppAvatar]", never, {}, {}, never, never, true, never>;
}
/** React `avatarMenu?: ReactNode` — content of the dropdown opened by clicking the AvatarZone,
 * typically a `soc-avatar-menu`. Omit it to keep the AvatarZone a plain, non-interactive display
 * (no hover state, no click handler): the AvatarZone only becomes a button once this is present. */
export declare class SocHeaderAppAvatarMenu {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocHeaderAppAvatarMenu, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocHeaderAppAvatarMenu, "[socHeaderAppAvatarMenu]", never, {}, {}, never, never, true, never>;
}
/** React `languageSelect?: ReactNode` — rendered between the notification icon and the separator,
 * typically a `soc-language-select`. Omit to not show a language control at all. */
export declare class SocHeaderAppLanguageSelect {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocHeaderAppLanguageSelect, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocHeaderAppLanguageSelect, "[socHeaderAppLanguageSelect]", never, {}, {}, never, never, true, never>;
}
/**
 * Maps 1:1 to "Index/Navigation/HeaderApp/*" tokens — see
 * packages/tokens/tokens/components/navigation.json in design_system (React reference repo, read
 * only). Plain wrapper (`soc-header-app`, `role="banner"` to keep the landmark React's `<header>`
 * gives for free); React's `className` is a literal `class` on the host. The help/notification
 * icons are Lucide's `CircleHelp`/`Bell` (Figma names its icon instances after Lucide slugs).
 *
 * Every `ReactNode` prop -> named content slot with a marker directive. `avatar` is needed in two
 * mutually exclusive places (inside the AvatarZone button when `avatarMenu` is present, bare
 * otherwise) — Angular only reliably honours ONE physical `<ng-content>` per selector, so the
 * AvatarZone lives in a single `<ng-template>` rendered from either branch (same fix as `Message`/
 * `Tooltip`). `onHelpClick`/`onNotificationsClick` -> `helpClick`/`notificationsClick` outputs.
 *
 * No left padding on purpose — `left` (typically an EnterpriseSelect) must sit flush with
 * HeaderApp's own left edge, so it lines up with SideNavigation's left border below it in the
 * "Full Page" composition. `pad-h` still applies on the right, ahead of the icons/AvatarZone.
 */
export declare class SocHeaderApp {
    /** The signed-in user's display name, rendered inside HeaderApp's own AvatarZone next to the
     * `avatar` slot — not a free-form slot: the gap and typography between the two come from
     * `Index/Navigation/HeaderApp/avatar-*` tokens, matching Figma's AvatarZone exactly. */
    readonly userName: import("@angular/core").InputSignal<string>;
    readonly helpClick: import("@angular/core").OutputEmitterRef<void>;
    readonly notificationsClick: import("@angular/core").OutputEmitterRef<void>;
    protected readonly iconThickness = "var(--index-navigation-headerapp-icon-thickness)";
    protected readonly avatarMenuOpen: import("@angular/core").WritableSignal<boolean>;
    private readonly avatarMenuContent;
    protected readonly hasAvatarMenu: import("@angular/core").Signal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocHeaderApp, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocHeaderApp, "soc-header-app", never, { "userName": { "alias": "userName"; "required": true; "isSignal": true; }; }, { "helpClick": "helpClick"; "notificationsClick": "notificationsClick"; }, ["avatarMenuContent"], ["[socHeaderAppLeft]", "[socHeaderAppLanguageSelect]", "[socHeaderAppAvatarMenu]", "[socHeaderAppAvatar]"], true, never>;
}
