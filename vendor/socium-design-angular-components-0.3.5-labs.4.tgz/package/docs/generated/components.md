# @socium-design/angular-components — référence des composants (générée)

> Généré automatiquement depuis le code source (version 0.3.4). **Source de vérité pour les noms d'inputs/outputs/slots** : ne jamais deviner une prop par analogie avec le HTML natif.

## Conventions de lecture

- **Sélecteur d'attribut** (`button[socButton]`) : le composant se pose sur l'élément natif (`<button socButton>`).
- **Slots** : le contenu projeté se range avec un attribut marqueur (ex. `<svg socButtonLeftIcon>`). Slot `default` = contenu sans marqueur.
- **Formulaire** : « oui » = `formControl`, `formControlName` et `ngModel` fonctionnent dessus.
- Les inputs booléens acceptent l'attribut nu (`<soc-input-text required disabled>`). Les inputs `model` (↔) se lient en `[(x)]`.

## Index

| Composant | Sélecteur | Niveau |
|---|---|---|
| [SocAvatarMenu](#socavatarmenu) | `soc-avatar-menu` | composes |
| [SocCardGrid](#soccardgrid) | `soc-card-grid` | composes |
| [SocDataTable](#socdatatable) | `soc-data-table` | composes |
| [SocDialog](#socdialog) | `soc-dialog` | composes |
| [SocDrawer](#socdrawer) | `soc-drawer` | composes |
| [SocDrawerDetailItem](#socdrawerdetailitem) | `soc-drawer-detail-item` | composes |
| [SocEnterpriseSelect](#socenterpriseselect) | `soc-enterprise-select` | composes |
| [SocHeaderApp](#socheaderapp) | `soc-header-app` | composes |
| [SocLanguageSelect](#soclanguageselect) | `soc-language-select` | composes |
| [SocMenuItem](#socmenuitem) | `button[socMenuItem]` | composes |
| [SocMenu](#socmenu) | `soc-menu` | composes |
| [SocMultiSelect](#socmultiselect) | `soc-multi-select` | composes |
| [SocProfileLine](#socprofileline) | `soc-profile-line` | composes |
| [SocSelect](#socselect) | `soc-select` | composes |
| [SocTableFilterSelect](#soctablefilterselect) | `soc-table-filter-select` | composes |
| [SocUploadFile](#socuploadfile) | `soc-upload-file` | composes |
| [SocAccordion](#socaccordion) | `soc-accordion` | primitifs |
| [SocAppIconGlyph](#socappiconglyph) | `soc-app-icon-glyph` | primitifs |
| [SocSwitchLogo](#socswitchlogo) | `soc-switch-logo` | primitifs |
| [SocAppIcon](#socappicon) | `button[socAppIcon]` | primitifs |
| [SocAppSwitch](#socappswitch) | `soc-app-switch` | primitifs |
| [SocAvatar](#socavatar) | `soc-avatar` | primitifs |
| [SocBadge](#socbadge) | `soc-badge` | primitifs |
| [SocBreadcrumb](#socbreadcrumb) | `soc-breadcrumb` | primitifs |
| [SocButton](#socbutton) | `button[socButton]` | primitifs |
| [SocSplitButton](#socsplitbutton) | `soc-split-button` | primitifs |
| [SocCard](#soccard) | `soc-card` | primitifs |
| [SocCheckbox](#soccheckbox) | `soc-checkbox` | primitifs |
| [SocChips](#socchips) | `soc-chips` | primitifs |
| [SocSelectableChips](#socselectablechips) | `soc-selectable-chips` | primitifs |
| [SocInputChip](#socinputchip) | `soc-input-chip` | primitifs |
| [SocDocumentLine](#socdocumentline) | `soc-document-line` | primitifs |
| [SocInputArea](#socinputarea) | `soc-input-area` | primitifs |
| [SocInputNumber](#socinputnumber) | `soc-input-number` | primitifs |
| [SocInputText](#socinputtext) | `soc-input-text` | primitifs |
| [SocMessage](#socmessage) | `soc-message` | primitifs |
| [SocOverlay](#socoverlay) | `soc-overlay` | primitifs |
| [SocPagination](#socpagination) | `soc-pagination` | primitifs |
| [SocPassword](#socpassword) | `soc-password` | primitifs |
| [SocPopover](#socpopover) | `soc-popover` | primitifs |
| [SocProgressBar](#socprogressbar) | `soc-progress-bar` | primitifs |
| [SocRadioButton](#socradiobutton) | `soc-radio-button` | primitifs |
| [SocSearchBar](#socsearchbar) | `soc-search-bar` | primitifs |
| [SocSideNavSection](#socsidenavsection) | `soc-side-nav-section` | primitifs |
| [SocSideNavigation](#socsidenavigation) | `soc-side-navigation` | primitifs |
| [SocStepper](#socstepper) | `soc-stepper` | primitifs |
| [SocSwitch](#socswitch) | `soc-switch` | primitifs |
| [SocTabs](#soctabs) | `soc-tabs` | primitifs |
| [SocTag](#soctag) | `soc-tag` | primitifs |
| [SocTooltip](#soctooltip) | `soc-tooltip` | primitifs |
| [SocAppShell](#socappshell) | `soc-app-shell` | templates |
| [SocPageDetails](#socpagedetails) | `soc-page-details` | templates |
| [SocPageForm](#socpageform) | `soc-page-form` | templates |
| [SocPageHome](#socpagehome) | `soc-page-home` | templates |
| [SocPageList](#socpagelist) | `soc-page-list` | templates |
| [SocPageProfile](#socpageprofile) | `soc-page-profile` | templates |

**Labs (expérimental)** — point d'entrée séparé `@socium-design/angular-components/labs`, voir la section [Labs](#labs-expérimental) :

| Composant | Sélecteur |
|---|---|
| [SocLabsButton](#soclabsbutton) | `button[socLabsButton]` |
| [SocLabsChangesBar](#soclabschangesbar) | `soc-labs-changes-bar` |
| [SocLabsChartTypeChip](#soclabscharttypechip) | `soc-labs-chart-type-chip` |
| [SocLabsCompactField](#soclabscompactfield) | `soc-labs-compact-field` |
| [SocLabsDropZone](#soclabsdropzone) | `soc-labs-drop-zone` |
| [SocLabsFullscreenOverlay](#soclabsfullscreenoverlay) | `soc-labs-fullscreen-overlay` |
| [SocLabsIconButton](#soclabsiconbutton) | `soc-labs-icon-button` |
| [SocLabsIconTile](#soclabsicontile) | `soc-labs-icon-tile` |
| [SocLabsInlineEdit](#soclabsinlineedit) | `soc-labs-inline-edit` |
| [SocLabsListRow](#soclabslistrow) | `soc-labs-list-row` |
| [SocLabsNavList](#soclabsnavlist) | `soc-labs-nav-list` |
| [SocLabsOptionRow](#soclabsoptionrow) | `soc-labs-option-row` |
| [SocLabsPillToggle](#soclabspilltoggle) | `soc-labs-pill-toggle` |
| [SocLabsSettingsCard](#soclabssettingscard) | `soc-labs-settings-card` |
| [SocLabsTag](#soclabstag) | `soc-labs-tag` |
| [SocLabsWidgetCard](#soclabswidgetcard) | `soc-labs-widget-card` |
| [SocLabsWorkspaceLayout](#soclabsworkspacelayout) | `soc-labs-workspace-layout` |

---

## Primitifs (niveau 0)

### SocAccordion

- **Sélecteur** : `soc-accordion` — `<soc-accordion>…</soc-accordion>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/accordion/accordion.ts`

No native HTML equivalent (the disclosure triangle is hand-rolled with a `<button>` + rotating chevron, same as React — no `<details>`/`<summary>`) — plain wrapper (`soc-accordion`). Maps 1:1 to "Index/Conteneur/Accordion/*" tokens — see packages/tokens/tokens/components/conteneur.json in design_system (React reference repo, read only). React's controlled-vs-uncontrolled `open`/`defaultOpen` collapses to one `model()`, same reasoning as `Checkbox`/`Switch`.

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `label` | `string` | — | oui |  |
| `error` | `boolean` | `false` |  |  |
| `warning` | `boolean` | `false` |  |  |
| `open` ↔ | `boolean` | `false` |  |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `[socAccordionRightSlot]` | React `Accordion`'s `rightSlot?: ReactNode` — extra content next to the label (info text, a Tag, row actions, …). |
| `(contenu par défaut)` |  |

### SocAppIconGlyph

- **Sélecteur** : `soc-app-icon-glyph` — `<soc-app-icon-glyph>…</soc-app-icon-glyph>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/app-switch/app-icons.ts`

Renders one named glyph via a `@switch`, each shape's fill picked by `selected()` + whether that particular shape is an "accent" one — same three-class logic as React's own `renderShapes` helper, just inlined per shape here instead of mapped over a shape-description array (Angular templates can't easily interpolate arbitrary SVG element types — `<path>` vs `<circle>` vs `<ellipse>` — the way a single JS `.map()` callback can, so this stays closer to hand-written SVG markup per icon rather than porting `renderShapes`/`GlyphShape` as data).

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `name` | `AppIconName` | — | oui |  |
| `selected` | `boolean` | `false` |  |  |

### SocSwitchLogo

- **Sélecteur** : `soc-switch-logo` — `<soc-switch-logo>…</soc-switch-logo>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/app-switch/app-icons.ts`

Real vector mark exported from the Figma "Logo" node (rendered above the icon list in AppSwitch). Ported verbatim from React's own `SwitchLogo`.

### SocAppIcon

- **Sélecteur** : `button[socAppIcon]` — `<button socAppIcon>…</button>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/app-switch/app-switch.ts`

Attribute selector on a real `<button>` (`button[socAppIcon]`) — structurally just a button with a self-drawn icon inside, no siblings needed, same shape as `Button` itself. Maps 1:1 to "Index/Navigation/AppIcon/*" tokens — see packages/tokens/tokens/components/navigation.json in design_system (React reference repo, read only).

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `name` | `AppIconName` | — | oui |  |
| `label` | `string` | — | oui |  |
| `selected` | `boolean` | `false` |  |  |

### SocAppSwitch

- **Sélecteur** : `soc-app-switch` — `<soc-app-switch>…</soc-app-switch>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/app-switch/app-switch.ts`

No native HTML equivalent — plain wrapper (`soc-app-switch`). Maps 1:1 to "Index/Navigation/AppSwitch/*" tokens — see packages/tokens/tokens/components/navigation.json in design_system (React reference repo, read only). `onSelect` -> `select` output(); `logo` -> named content slot (`socAppSwitchLogo`), same reasoning as every other `ReactNode` slot this migration.

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `product` | `NavigationProduct` | — |  |  |
| `items` | `AppSwitchItemData[]` | — |  |  |
| `selectedId` | `string` | — |  |  |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(select)` | `string` |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `[socAppSwitchLogo]` | React `AppSwitch`'s `logo?: ReactNode` — rendered above the icon list (pass the Logo component, e.g. `SocSwitchLogo`, once it exists — same "not implemented yet" note as React's own doc comment). |

### SocAvatar

- **Sélecteur** : `soc-avatar` — `<soc-avatar>…</soc-avatar>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/avatar/avatar.ts`

No native HTML equivalent and no single element being wrapped — plain standalone wrapper component (`soc-avatar` element selector), not an attribute selector. `label`/`name`/`subtitle` are all plain strings (not ReactNode in the React source), so plain `input()`s, no content projection needed. Maps 1:1 to "Index/Social/Avatar/*" tokens — see packages/tokens/tokens/components/social.json in design_system (React reference repo, read only). Only the "initials" type is implemented — React `Avatar.tsx`'s own doc comment: a photo is a plain image-filled frame, a generic icon is a bare Lucide icon,…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `label` | `string` | — | oui |  |
| `color` | `AvatarColor` | `'blue'` |  |  |
| `size` | `AvatarSize` | `'md'` |  |  |
| `mode` | `AvatarMode` | `'soft'` |  |  |
| `name` | `string` | — |  |  |
| `subtitle` | `string` | — |  |  |
| `namePosition` | `AvatarNamePosition` | `'right'` |  |  |

### SocBadge

- **Sélecteur** : `soc-badge` — `<soc-badge>…</soc-badge>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/badge/badge.ts`

No native HTML equivalent — plain wrapper (`soc-badge` element selector). `children: ReactNode` becomes a default `<ng-content>` (no named slot needed, there's only one content region). Maps 1:1 to "Index/Feedback/Badge/*" tokens — see packages/tokens/tokens/components/feedback.json in design_system (React reference repo, read only).

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `color` | `BadgeColor` | `'primary'` |  |  |
| `size` | `BadgeSize` | `'sm'` |  |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `(contenu par défaut)` |  |

### SocBreadcrumb

- **Sélecteur** : `soc-breadcrumb` — `<soc-breadcrumb>…</soc-breadcrumb>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/breadcrumb/breadcrumb.ts`

No native HTML equivalent — plain wrapper (`soc-breadcrumb`). `items: BreadcrumbItemData[]` is plain data (not ReactNode), so a plain `input()`, same as `Message`'s `primaryAction` object — each item's own `onClick` stays a plain callback field on the data, since it's tied to that specific item, not a single component-wide event. `onHomeClick`, by contrast, IS a single component-wide handler (not nested in an array item) — that one becomes an `output()` (`homeClick`), matching how `SplitButton`'s direct handler props became outputs. Maps 1:1 to "Index/Navigation/Breadcrumb/*" tokens — see pac…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `items` | `BreadcrumbItemData[]` | — | oui |  |
| `truncated` | `boolean` | `false` |  |  |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(homeClick)` | `void` |  |

### SocButton

- **Sélecteur** : `button[socButton]` — `<button socButton>…</button>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/button/button.ts`

Attribute selector on a real `<button>` — not a wrapper component — so native attributes and events (`type`, `[disabled]`, `(click)`, `aria-label`, …) just work as plain HTML on the host element, the Angular equivalent of React `Button`'s `...props` spread onto its own `<button>`. No `output()`/`input()` re-declares any of them. See this repo's CLAUDE.md, "Attribute-selector components" — the pattern to reuse for every future component wrapping a single native interactive element (InputText, Checkbox, RadioButton, Switch…). `[class]` merges with any static `class` a consumer adds directly on…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `variant` | `ButtonVariant` | `'primary'` |  |  |
| `size` | `ButtonSize` | `'sm'` |  |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `[socButtonLeftIcon]` | Marks the element projected into `SocButton`'s leading icon slot (`<ng-content select="[socButtonLeftIcon]">`) — see `SocButtonRightIcon` for the trailing one. Angular's equivalent of React `Button`'s `leftIcon?: ReactN… |
| `(contenu par défaut)` |  |
| `[socButtonRightIcon]` | Trailing icon slot — see `SocButtonLeftIcon`. React `Button`'s `rightIcon?: ReactNode`. |

### SocSplitButton

- **Sélecteur** : `soc-split-button` — `<soc-split-button>…</soc-split-button>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/button/split-button.ts`

Two real `<button>` elements internally (main action + dropdown trigger) — unlike `SocButton`, this can't be a bare attribute selector: its host isn't itself a single clickable button, so native `(click)` doesn't just pass through one level. Exposes `click`/`triggerClick` outputs explicitly instead — matches React `SplitButtonProps` already being its own type rather than extending `ButtonProps`, and its `onClick`/`onTriggerClick` being two distinct handlers. Reuses `SocButtonLeftIcon` from `./button` for its leading icon slot (React `SplitButton` only has a `leftIcon` prop, no `rightIcon`) —…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `variant` | `ButtonVariant` | `'primary'` |  |  |
| `size` | `ButtonSize` | `'sm'` |  |  |
| `disabled` | `boolean` | `false` |  |  |
| `triggerLabel` | `string` | `"Plus d'options"` |  |  |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(click)` | `MouseEvent` |  |
| `(triggerClick)` | `MouseEvent` |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `[socButtonLeftIcon]` | Marks the element projected into `SocButton`'s leading icon slot (`<ng-content select="[socButtonLeftIcon]">`) — see `SocButtonRightIcon` for the trailing one. Angular's equivalent of React `Button`'s `leftIcon?: ReactN… |
| `(contenu par défaut)` |  |

### SocCard

- **Sélecteur** : `soc-card` — `<soc-card>…</soc-card>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/card/card.ts`

No native HTML equivalent — plain wrapper (`soc-card`). Maps 1:1 to "Index/Conteneur/Card/*" tokens — see packages/tokens/tokens/components/conteneur.json in design_system (React reference repo, read only). `colSpan`/`rowSpan` only matter inside a `soc-card-grid` in `mode="bento"` — see that component's own docstring for the 75%-of-row clamp rule. The *rendered* span is resolved here from `CARD_GRID_CONTEXT` (see `internal/card-grid-context.ts`), because React's `cloneElement` rewrite of a child's props has no Angular equivalent; a card with no grid ancestor renders exactly the span it was gi…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `title` | `string` | — | oui |  |
| `subtitle` | `string` | — |  |  |
| `type` | `CardType` | `'default'` |  |  |
| `colSpan` | `1 \| 2 \| 3` | `1` |  |  |
| `rowSpan` | `1 \| 2` | `1` |  |  |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(action)` | `void` |  |
| `(cardClick)` | `void` |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `[socCardIcon]` | Content slots — React's `icon`/`actionSlot`/`footer` (all `ReactNode`) and `children`. `children` stays the default unnamed `<ng-content>` (there's no ambiguity with the other three, all named). |
| `[socCardActionSlot]` |  |
| `(contenu par défaut)` |  |
| `[socCardFooter]` |  |

### SocCheckbox

- **Sélecteur** : `soc-checkbox` — `<soc-checkbox>…</soc-checkbox>`
- **Formulaire (ControlValueAccessor)** : oui
- **Fichier** : `primitifs/checkbox/checkbox.ts`

GAP-DECISION (flagged, not decided silently): the migration spec's rule for Checkbox was "attribute selector on `input[type=checkbox]`". Read the real React source before writing anything — Checkbox.tsx does NOT use a native `<input type="checkbox">` at all: it's a `<button role="checkbox" aria-checked>` wrapped in a `<label>`, with an optional sibling `<span>` for the label text. Same "can't render siblings from inside an attribute selector" problem as InputText's whole family (see that component's own docstring) — the `<label>` wrapper and text span sit OUTSIDE the button. Wrapper component…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `disabled` | `boolean` | `false` |  | `[disabled]` / bare `disabled` attribute. (An `input()` rather than a `model()` so the bare-attribute form works — models can't take a transform.) Templates read `isDisabled()`, not this. |
| `checked` ↔ | `boolean` | `false` |  |  |
| `label` | `string` | — |  |  |
| `id` | `string` | — |  |  |

### SocChips

- **Sélecteur** : `soc-chips` — `<soc-chips>…</soc-chips>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/chips/chips.ts`

React's Chips.tsx exports three components sharing one file — mirrored the same way here rather than splitting into three files, since they share the `ChipsSize` type and padding/text classes. `label` is a plain `string` in all three (not `ReactNode`), so plain `input()`s throughout, no content projection — same reasoning as `DocumentLine`. `onRemove`/`onClick` follow the same split as `Tag`'s `removable`/`remove`: a boolean input controls visibility, an output is the handler (an `output()` can't be introspected for "is anyone listening" the way an optional callback prop can). Maps 1:1 to "In…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `label` | `string` | — | oui |  |
| `size` | `ChipsSize` | `'sm'` |  |  |
| `removable` | `boolean` | `false` |  |  |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(remove)` | `void` |  |

### SocSelectableChips

- **Sélecteur** : `soc-selectable-chips` — `<soc-selectable-chips>…</soc-selectable-chips>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/chips/chips.ts`

Maps 1:1 to "Index/Selection/Chips/*" tokens (type=Selectable). Structurally this one IS just a bare `<button>{label}</button>`, same shape as `Button` — could have been an attribute selector. Kept as a wrapper element instead, consistent with the migration spec explicitly categorizing "Chips" (this whole file, all three exports) under the wrapper list rather than the native- element-attribute-selector one, and to stay consistent with its two siblings above/below sharing this same file.

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `label` | `string` | — | oui |  |
| `size` | `ChipsSize` | `'sm'` |  |  |
| `selected` | `boolean` | `false` |  |  |

### SocInputChip

- **Sélecteur** : `soc-input-chip` — `<soc-input-chip>…</soc-input-chip>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/chips/chips.ts`

Maps 1:1 to "Index/Selection/Chips/*" tokens (type=Input) — used for the tags shown inside a Multi-select's field once options are selected.

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `label` | `string` | — | oui |  |
| `removable` | `boolean` | `false` |  |  |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(remove)` | `void` |  |

### SocDocumentLine

- **Sélecteur** : `soc-document-line` — `<soc-document-line>…</soc-document-line>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/document-line/document-line.ts`

No native HTML equivalent — plain wrapper (`soc-document-line`). All three props are plain strings in React (`title`/`date`/`fileSize`), no ReactNode anywhere, so plain `input()`s, no content projection. The file icon is self-drawn (`LucideFileText`), same as React's own `<FileText />` — not a consumer-supplied slot. Maps 1:1 to "Index/Données/DocumentLine/*" tokens — see packages/tokens/tokens/components/données.json in design_system (React reference repo, read only).

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `title` | `string` | — | oui |  |
| `date` | `string` | — | oui |  |
| `fileSize` | `string` | — | oui |  |

### SocInputArea

- **Sélecteur** : `soc-input-area` — `<soc-input-area>…</soc-input-area>`
- **Formulaire (ControlValueAccessor)** : oui
- **Fichier** : `primitifs/input-area/input-area.ts`

Same structural GAP-DECISION as InputText — see that component's own docstring, not repeated here. Maps 1:1 to "Index/Input/Input area/*" tokens — see packages/tokens/tokens/components/input.json in design_system (React reference repo, read only). Grows with its content (auto-height) instead of scrolling internally, same as React's own `useLayoutEffect` — done here with `viewChild` + `effect()` instead, reading `value()` so it re-measures on every change exactly like React's `[value]` dependency array.

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `disabled` | `boolean` | `false` |  | `[disabled]` / bare `disabled` attribute. (An `input()` rather than a `model()` so the bare-attribute form works — models can't take a transform.) Templates read `isDisabled()`, not this. |
| `label` | `string` | — |  |  |
| `required` | `boolean` | `false` |  |  |
| `error` | `boolean` | `false` |  |  |
| `helperText` | `string` | — |  |  |
| `placeholder` | `string` | — |  |  |
| `id` | `string` | — |  |  |
| `name` | `string` | — |  |  |
| `autocomplete` | `string` | — |  |  |
| `readonly` | `boolean` | `false` |  |  |
| `inputClass` | `string` | — |  |  |
| `inputAttrs` | `NativeAttributes` | — |  |  |
| `rows` | `number` | `3` |  |  |
| `maxlength` | `number` | — |  |  |
| `value` ↔ | `string` | `''` |  |  |

### SocInputNumber

- **Sélecteur** : `soc-input-number` — `<soc-input-number>…</soc-input-number>`
- **Formulaire (ControlValueAccessor)** : oui
- **Fichier** : `primitifs/input-number/input-number.ts`

Same structural GAP-DECISION as InputText — see that component's own docstring, not repeated here. Maps 1:1 to "Index/Input/Input number/*" tokens — see packages/tokens/tokens/components/input.json in design_system (React reference repo, read only). `value`/`defaultValue`'s controlled-vs-uncontrolled split in React collapses to a single `model()` here — a signal always holds the current value regardless of whether the consumer binds `[(value)]` or just reads/sets the initial one, so there's no separate "was a value prop given" branch to reproduce.

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `disabled` | `boolean` | `false` |  | `[disabled]` / bare `disabled` attribute. (An `input()` rather than a `model()` so the bare-attribute form works — models can't take a transform.) Templates read `isDisabled()`, not this. |
| `label` | `string` | — |  |  |
| `required` | `boolean` | `false` |  |  |
| `error` | `boolean` | `false` |  |  |
| `helperText` | `string` | — |  |  |
| `placeholder` | `string` | — |  |  |
| `id` | `string` | — |  |  |
| `name` | `string` | — |  |  |
| `autocomplete` | `string` | — |  |  |
| `readonly` | `boolean` | `false` |  |  |
| `inputClass` | `string` | — |  |  |
| `inputAttrs` | `NativeAttributes` | — |  |  |
| `showSteppers` | `boolean` | `true` |  |  |
| `min` | `number` | — |  |  |
| `max` | `number` | — |  |  |
| `step` | `number` | `1` |  |  |
| `value` ↔ | `number \| null` | `0` |  | `null` = empty field (what a form `reset()` produces); React's version is always a number. |

### SocInputText

- **Sélecteur** : `soc-input-text` — `<soc-input-text>…</soc-input-text>`
- **Formulaire (ControlValueAccessor)** : oui
- **Fichier** : `primitifs/input-text/input-text.ts`

Maps 1:1 to "Index/Input/Input text/*" tokens — see packages/tokens/tokens/components/input.json in design_system (React reference repo, read only).

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `disabled` | `boolean` | `false` |  | `[disabled]` / bare `disabled` attribute. (An `input()` rather than a `model()` so the bare-attribute form works — models can't take a transform.) Templates read `isDisabled()`, not this. |
| `label` | `string` | — |  |  |
| `required` | `boolean` | `false` |  |  |
| `error` | `boolean` | `false` |  |  |
| `helperText` | `string` | — |  |  |
| `placeholder` | `string` | — |  |  |
| `id` | `string` | — |  |  |
| `name` | `string` | — |  |  |
| `autocomplete` | `string` | — |  |  |
| `readonly` | `boolean` | `false` |  |  |
| `inputClass` | `string` | — |  |  |
| `inputAttrs` | `NativeAttributes` | — |  |  |
| `type` | `string` | `'text'` |  |  |
| `maxlength` | `number` | — |  |  |
| `value` ↔ | `string` | `''` |  | The one property that actually needs two-way sync — `model()` gives `[(value)]` plus a `valueChange` output for free, the Angular equivalent of React's `value`+`onChange` pair (or `defaultValue` for the uncontrolled cas… |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `[socInputTextLeftIcon]` | GAP-DECISION (flagged, not decided silently): the migration spec's rule says text-input-like primitives should be attribute selectors on the native element, for free native attribute/event passthrough. That works for `B… |
| `[socInputTextRightIcon]` |  |

### SocMessage

- **Sélecteur** : `soc-message` — `<soc-message>…</soc-message>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/message/message.ts`

No native HTML equivalent — plain wrapper (`soc-message`). Maps 1:1 to "Index/Feedback/Message/*" tokens — see packages/tokens/tokens/components/feedback.json in design_system (React reference repo, read only). `primaryAction`/`secondaryAction` stay plain `input()` objects (`{ label, onClick? }`), matching React's own `MessageAction` shape exactly — the click handler is consumer-supplied data on the object itself, not a component-level notification, so no separate `output()` per action. Composition constraint carried over verbatim from React's own docstring — the "banner" variant always sits…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `status` | `MessageStatus` | `'info'` |  |  |
| `variant` | `MessageVariant` | `'banner'` |  |  |
| `hideIcon` | `boolean` | `false` |  | Equivalent of React's explicit `icon={null}` — suppresses the icon entirely, default (false) matches React's default behavior of always showing one. |
| `title` | `string` | — |  |  |
| `primaryAction` | `MessageAction` | — |  |  |
| `secondaryAction` | `MessageAction` | — |  |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `[socMessageContent]` | React `Message`'s required `content: ReactNode` — content projection (not a string input) since it accepts arbitrary rich content, same reasoning as `Button`'s icon slots. |
| `[socMessageIcon]` | Marks a consumer-projected custom icon — React `Message`'s `icon?: ReactNode \| null` prop, the "override" branch (a plain `ReactNode`). React's `icon === undefined` (nothing passed at all) defaults to a status-matching… |

### SocOverlay

- **Sélecteur** : `soc-overlay` — `<soc-overlay>…</soc-overlay>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/overlay/overlay.ts`

Full-bleed dark backdrop — sits behind a Dialog/Drawer/floating panel. Standalone: neither Dialog nor Drawer render one themselves yet (not migrated in this batch either), so pair this manually (`@if (open()) { <soc-overlay /> }`) until they do — same as React's own doc comment. Maps 1:1 to "Index/Conteneur/Overlay/*" tokens — see packages/tokens/tokens/components/conteneur.json in design_system (React reference repo, read only). `onClick` is a direct component-level handler -> output(), same reasoning as every other direct handler prop this batch.

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(overlayClick)` | `void` |  |

### SocPagination

- **Sélecteur** : `soc-pagination` — `<soc-pagination>…</soc-pagination>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/pagination/pagination.ts`

No native HTML equivalent — plain wrapper (`soc-pagination`). Maps 1:1 to "Index/Navigation/Pagination/*" tokens — see packages/tokens/tokens/components/navigation.json in design_system (React reference repo, read only). `onPageChange`/`onPageSizeChange` are direct component-level handlers (not per-item data), so both become `output()`s (`pageChange`/`pageSizeChange`) rather than input callbacks.

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `currentPage` | `number` | — | oui |  |
| `totalPages` | `number` | — | oui |  |
| `variant` | `PaginationVariant` | `'numbered'` |  |  |
| `hasFirstLast` | `boolean` | `true` |  |  |
| `totalEntries` | `number` | — |  |  |
| `pageSize` | `number` | — |  |  |
| `pageSizeOptions` | `number[]` | `[10, 20, 50, 100]` |  |  |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(pageChange)` | `number` |  |
| `(pageSizeChange)` | `number` |  |

### SocPassword

- **Sélecteur** : `soc-password` — `<soc-password>…</soc-password>`
- **Formulaire (ControlValueAccessor)** : oui
- **Fichier** : `primitifs/password/password.ts`

Same structural GAP-DECISION as InputText — see that component's own docstring, not repeated here. Maps 1:1 to "Index/Input/Input password/*" tokens — see packages/tokens/tokens/components/input.json in design_system (React reference repo, read only). The show/hide toggle is local component state (a plain `signal`), same as React's own `useState` — not exposed as an input/output, nothing outside this component needs to know or control it.

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `disabled` | `boolean` | `false` |  | `[disabled]` / bare `disabled` attribute. (An `input()` rather than a `model()` so the bare-attribute form works — models can't take a transform.) Templates read `isDisabled()`, not this. |
| `label` | `string` | — |  |  |
| `required` | `boolean` | `false` |  |  |
| `error` | `boolean` | `false` |  |  |
| `helperText` | `string` | — |  |  |
| `placeholder` | `string` | — |  |  |
| `id` | `string` | — |  |  |
| `name` | `string` | — |  |  |
| `autocomplete` | `string` | — |  |  |
| `readonly` | `boolean` | `false` |  |  |
| `inputClass` | `string` | — |  |  |
| `inputAttrs` | `NativeAttributes` | — |  |  |
| `maxlength` | `number` | — |  |  |
| `value` ↔ | `string` | `''` |  |  |

### SocPopover

- **Sélecteur** : `soc-popover` — `<soc-popover>…</soc-popover>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/popover/popover.ts`

No native HTML equivalent — plain wrapper (`soc-popover`). Maps 1:1 to "Index/Conteneur/Menu/popover-*" tokens (Figma has no standalone Popover token set — Menu is the only component that binds the floating-surface tokens) — see packages/tokens/tokens/components/conteneur.json in design_system (React reference repo, read only). `trigger` -> named content slot (`socPopoverTrigger`); panel content -> default unnamed slot, same split as `Card`'s icon-slots-vs-default-children precedent. Portaled to `document.body` via a direct `appendChild`, positioned with computed `position: fixed` — same reas…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `position` | `PopoverPosition` | `'bottom'` |  |  |
| `open` ↔ | `boolean` | `false` |  |  |
| `matchTriggerWidth` | `boolean` | `false` |  |  |
| `panelClass` | `string` | — |  | React `Popover`'s `className` — extra classes merged onto the portaled panel (e.g. `EnterpriseSelect`'s explicit `w-[400px]`). A literal `class` on `<soc-popover>` can't do this: the panel is portaled out to `document.b… |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `[socPopoverTrigger]` | React `Popover`'s `trigger: ReactElement` — receives a click handler (React clones it in; here the click listener lives on this component's own wrapper around the projected content instead, same workaround as `Tooltip`'… |
| `(contenu par défaut)` |  |

### SocProgressBar

- **Sélecteur** : `soc-progress-bar` — `<soc-progress-bar>…</soc-progress-bar>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/progress-bar/progress-bar.ts`

No native HTML equivalent (the `role="progressbar"` div is hand-rolled, same as React) — plain wrapper (`soc-progress-bar`). Maps 1:1 to "Index/Feedback/ProgressBar/*" tokens — see packages/tokens/tokens/components/feedback.json in design_system (React reference repo, read only). The `progress-indeterminate` keyframes it references live in src/styles/tailwind-entry.css (global), matching where React's own src/index.css defines them — not local to this component in either repo.

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `value` | `number` | `0` |  |  |
| `status` | `ProgressBarStatus` | `'information'` |  |  |
| `size` | `ProgressBarSize` | `'md'` |  |  |
| `label` | `string` | — |  |  |
| `helpTextLeft` | `string` | — |  |  |
| `helpTextRight` | `string` | — |  |  |
| `tinyLabel` | `string` | — |  |  |
| `indeterminate` | `boolean` | `false` |  |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `[socProgressBarTag]` | Marks the element projected into the extra row below the bar (typically a `<soc-tag>`) — React `ProgressBar`'s `tag?: ReactNode` prop. Ignored when `size()` is `"tiny"`, same as React. |

### SocRadioButton

- **Sélecteur** : `soc-radio-button` — `<soc-radio-button>…</soc-radio-button>`
- **Formulaire (ControlValueAccessor)** : oui
- **Fichier** : `primitifs/radio-button/radio-button.ts`

Same structural GAP-DECISION as Checkbox — see that component's own docstring, not repeated here. Maps 1:1 to "Index/Contrôleur/Radio/*" tokens — see packages/tokens/tokens/components/contrôleur.json in design_system (React reference repo, read only). Unlike Checkbox/Switch, React's `RadioButton` has no internal `useState`/`defaultSelected` at all — purely controlled (`selected` prop + `onSelect` callback) — so this is a plain `input()` + `output()` pair, no `model()`/uncontrolled-fallback needed.

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `selected` ↔ | `boolean` | `false` |  | Controlled like React (`selected` + `(select)`), but a `model()` so a form can drive it too. |
| `disabled` | `boolean` | `false` |  |  |
| `label` | `string` | — |  |  |
| `name` | `string` | — |  |  |
| `id` | `string` | — |  |  |
| `value` | `unknown` | — |  | Forms: the value this radio stands for. Give every radio of a group the same `formControlName`/ `[formControl]`/`ngModel` and its own `value` — the group's value selects the matching radio, and clicking one writes its `… |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(select)` | `void` |  |

### SocSearchBar

- **Sélecteur** : `soc-search-bar` — `<soc-search-bar>…</soc-search-bar>`
- **Formulaire (ControlValueAccessor)** : oui
- **Fichier** : `primitifs/search-bar/search-bar.ts`

Same structural GAP-DECISION as InputText — its outer element is a `<div>` with a sibling icon before and a sibling clear button after the `<input>`, not the `<input>` itself, so an attribute selector on `<input>` alone couldn't render them (see InputText's own docstring for the full reasoning; not repeated here). Wrapper component (`soc-search-bar`) instead. Maps 1:1 to "Index/Input/SearchBar/*" tokens — see packages/tokens/tokens/components/input.json in design_system (React reference repo, read only). No fixed height of its own on purpose, same as React — see that file's own doc comment: F…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `disabled` | `boolean` | `false` |  | `[disabled]` / bare `disabled` attribute. (An `input()` rather than a `model()` so the bare-attribute form works — models can't take a transform.) Templates read `isDisabled()`, not this. |
| `placeholder` | `string` | `'Rechercher...'` |  |  |
| `value` ↔ | `string` | `''` |  |  |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(clear)` | `void` |  |

### SocSideNavSection

- **Sélecteur** : `soc-side-nav-section` — `<soc-side-nav-section>…</soc-side-nav-section>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/side-navigation/side-navigation.ts`

Internal — one collapsible section of the nav (React's own local `NavSection` function component, promoted to its own Angular component since Angular doesn't have React's casual "just define another function in the same file" pattern for a stateful sub-view — this needs its own `open` signal per section instance). Not exported from `public-api.ts`.

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `section` | `SideNavSectionData` | — | oui |  |
| `selectedId` | `string` | — |  |  |
| `collapsed` | `boolean` | `false` |  |  |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(itemSelect)` | `string` |  |

### SocSideNavigation

- **Sélecteur** : `soc-side-navigation` — `<soc-side-navigation>…</soc-side-navigation>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/side-navigation/side-navigation.ts`

No native HTML equivalent — plain wrapper (`soc-side-navigation`). Maps 1:1 to "Index/Navigation/SideNavigation/*" tokens — see packages/tokens/tokens/components/navigation.json in design_system (React reference repo, read only). `collapsed` has no internal uncontrolled/default fallback in React either (purely controlled, parent owns it entirely via `onToggleCollapse`) — plain `input()`, not `model()`, unlike Accordion/Checkbox/Switch. `onSelect`/`onToggleCollapse` are direct component-level handlers -> `output()`s (`select`/`toggleCollapse`).

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `product` | `NavigationProduct` | — |  |  |
| `title` | `string` | — |  |  |
| `sections` | `SideNavSectionData[]` | — |  |  |
| `actionSection` | `{ title: string; items: SideNavActionData[] }` | — |  |  |
| `selectedId` | `string` | — |  |  |
| `collapsed` | `boolean` | `false` |  |  |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(select)` | `string` |  |
| `(toggleCollapse)` | `void` |  |

### SocStepper

- **Sélecteur** : `soc-stepper` — `<soc-stepper>…</soc-stepper>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/stepper/stepper.ts`

No native HTML equivalent — plain wrapper (`soc-stepper`). `items: StepperItemData[]` is plain data, a straight `input()`. Maps 1:1 to "Index/Navigation/Stepper/*" tokens — see packages/tokens/tokens/components/navigation.json in design_system (React reference repo, read only).

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `items` | `StepperItemData[]` | — | oui |  |
| `orientation` | `StepperOrientation` | `'horizontal'` |  |  |

### SocSwitch

- **Sélecteur** : `soc-switch` — `<soc-switch>…</soc-switch>`
- **Formulaire (ControlValueAccessor)** : oui
- **Fichier** : `primitifs/switch/switch.ts`

Same structural GAP-DECISION as Checkbox — see that component's own docstring, not repeated here. Maps 1:1 to "Index/Contrôleur/Switch/*" tokens — see packages/tokens/tokens/components/contrôleur.json in design_system (React reference repo, read only).

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `disabled` | `boolean` | `false` |  | `[disabled]` / bare `disabled` attribute. (An `input()` rather than a `model()` so the bare-attribute form works — models can't take a transform.) Templates read `isDisabled()`, not this. |
| `checked` ↔ | `boolean` | `false` |  |  |
| `size` | `SwitchSize` | `'sm'` |  |  |
| `label` | `string` | — |  |  |
| `id` | `string` | — |  |  |

### SocTabs

- **Sélecteur** : `soc-tabs` — `<soc-tabs>…</soc-tabs>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/tabs/tabs.ts`

No native HTML equivalent — plain wrapper (`soc-tabs`). Maps to "Index/Navigation/Tab/*" (underline) or "Index/Navigation/Tab2/*" (pill) tokens in design_system (React reference repo, read only). Both variants live in one component/template (an `@if`), same as React's own `Tabs` picking between its two internal `UnderlineTabs`/`PillTabs` functions.

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `items` | `TabItem[]` | — | oui |  |
| `value` | `string` | — | oui |  |
| `variant` | `TabsVariant` | `'underline'` |  |  |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(change)` | `string` |  |

### SocTag

- **Sélecteur** : `soc-tag` — `<soc-tag>…</soc-tag>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/tag/tag.ts`

No native HTML equivalent — plain wrapper (`soc-tag` element selector). `children: ReactNode` becomes a default `<ng-content>`. React's `onRemove?: () => void` prop doubles as both "show the remove button" and "the handler" — an `output()` can't be introspected the same way (no public "is anyone listening" signal), so this splits into a `removable` input (controls whether the button renders) plus a `remove` output (the handler) instead of inferring visibility from whether `(remove)` was bound. The remove (×) button draws its own icon (`LucideX`, `@lucide/angular`) rather than projecting one —…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `color` | `TagColor` | `'success'` |  |  |
| `size` | `TagSize` | `'sm'` |  |  |
| `removable` | `boolean` | `false` |  |  |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(remove)` | `void` |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `(contenu par défaut)` |  |

### SocTooltip

- **Sélecteur** : `soc-tooltip` — `<soc-tooltip>…</soc-tooltip>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `primitifs/tooltip/tooltip.ts`

No native HTML equivalent — plain wrapper (`soc-tooltip`). React's version uses `cloneElement` to inject `aria-describedby`/a composed `onClick` directly onto its `children` element — Angular has no equivalent of cloning an arbitrary projected element with extra props (there's no `TemplateRef`-free way to reach into projected content and add attributes/listeners to it). Worked around it rather than reproducing it: the hover/focus/click listeners live on this component's own HOST element instead (matching React's outer wrapper `<span ref={wrapperRef}>`, which already carries the hover/focus li…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `position` | `TooltipPosition` | `'top'` |  |  |
| `variant` | `TooltipVariant` | `'default'` |  |  |
| `title` | `string` | — |  |  |
| `status` | `TooltipMessageStatus` | `'info'` |  |  |
| `showIcon` | `boolean` | `true` |  |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `(contenu par défaut)` |  |
| `[socTooltipContent]` | React `Tooltip`'s `content: ReactNode` (extend variant only — its `title` stays a plain string input, it's typed `string` in React too). |
| `[socTooltipLabel]` | React `Tooltip`'s `label: ReactNode` (default/message variants). |

---

## Composés (niveau 1)

### SocAvatarMenu

- **Sélecteur** : `soc-avatar-menu` — `<soc-avatar-menu>…</soc-avatar-menu>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `composes/avatar-menu/avatar-menu.ts`

Contenu du menu déroulant ouvert au clic sur l'avatar dans `HeaderApp` — à passer à sa prop `avatarMenu` (rendu dans un `Popover` ancré à l'AvatarZone). Ne s'utilise jamais seul en dehors de ce contexte : ce n'est qu'un panneau de contenu, pas un composant de déclenchement. Plain wrapper (`soc-avatar-menu`); React's root `<div className>` is this host, so a literal `class` on `<soc-avatar-menu>` replaces React's `className` prop. Maps 1:1 to Figma's "AvatarMenu" (node 630:2682) — reuses the popover surface tokens of `Menu`/`Popover` (`Index/Conteneur/Menu/popover-*`), no distinct token set ex…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `userName` | `string` | — | oui |  |
| `userEmail` | `string` | — | oui |  |
| `avatarLabel` | `string` | — | oui | Initials shown in the profile circle — 2 characters max, forwarded to `Avatar`. |
| `showViewProfile` | `boolean` | `false` |  |  |
| `showEditAvatar` | `boolean` | `false` |  |  |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(viewProfile)` | `void` |  |
| `(editAvatar)` | `void` |  |
| `(disconnect)` | `void` |  |

### SocCardGrid

- **Sélecteur** : `soc-card-grid` — `<soc-card-grid>…</soc-card-grid>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `composes/card-grid/card-grid.ts`

Shared CSS Grid primitive behind both `DataTable`'s `mode="card"` and any bento-style card grid (e.g. a `PageHome` content section) — the single place grid-column/breakpoint/gap logic lives. No Figma source (code-only primitive), no masonry library — native CSS Grid only, `grid-auto-flow: dense` does all the gap-backfilling in `mode="bento"`. Plain wrapper (`soc-card-grid`); its children are `soc-card`s. - `mode` "fixed": every card is forced to span exactly 1 column × 1 row, regardless of any `colSpan`/`rowSpan` it was given. "bento": each card's own `colSpan` (1, 2 or 3) / `rowSpan` (1 or 2…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `mode` | `CardGridMode` | `'fixed'` |  |  |
| `gap` | `CardGridGap` | `'md'` |  |  |
| `rowHeight` | `number \| 'auto'` | `'auto'` |  | A plain `number` (px), not a Tailwind class, because it's an arbitrary continuous value the static class scanner can't pick up — applied as an inline style instead. |
| `columns` | `number` | — |  |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `(contenu par défaut)` |  |

### SocDataTable

- **Sélecteur** : `soc-data-table` — `<soc-data-table>…</soc-data-table>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `composes/data-table/data-table.ts`

Maps 1:1 to "Index/Données/DataTable/*" tokens — see packages/tokens/tokens/components/données.json in design_system (React reference repo, read only). Composes `soc-search-bar`, `soc-checkbox`, `soc-pagination`, `soc-popover`/`soc-tooltip` and (card mode) `soc-card-grid`/`soc-card`, same as React. Plain generic wrapper (`soc-data-table`, `<T>` = the row type). `mode`: "table" (Figma "Data Table 1", default) — full grid with search/actions/pagination. "detail" ("Data Table 2") — a single record as a label/value list: columns become row labels, `rows[0]` is the record. "card" (code-only mode)…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `mode` | `DataTableMode` | `'table'` |  |  |
| `title` | `string` | — |  |  |
| `subtitle` | `string` | — |  |  |
| `columns` | `DataTableColumn<T>[]` | — | oui |  |
| `cardContent` | `(row: T) => DataTableCardContent<T>` | — |  |  |
| `rows` | `T[]` | — | oui |  |
| `rowKey` | `(row: T) => string` | — | oui |  |
| `selectable` | `boolean` | `false` |  |  |
| `selectedKeys` | `Set<string>` | — |  |  |
| `searchable` | `boolean` | `false` |  |  |
| `rowClickable` | `boolean` | `false` |  |  |
| `rowActions` | `boolean` | `false` |  |  |
| `rowActionsMenu` | `TemplateRef<DataTableRowActionsContext<T>>` | — |  |  |
| `pagination` | `DataTablePagination` | — |  |  |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(selectedKeysChange)` | `Set<string>` |  |
| `(search)` | `string` |  |
| `(rowClick)` | `T` |  |
| `(rowAction)` | `T` |  |
| `(pageChange)` | `number` |  |
| `(pageSizeChange)` | `number` |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `[socDataTableBadge]` | React `badge` — consumer-supplied Badge next to `title` (`table`/`card` mode), typically an instance count when several objects of the same type are listed on one page. |
| `[socDataTableFilters]` | React `filters` — extra controls rendered next to the search bar — Selects, filters, etc. |
| `[socDataTableActions]` | React `actions` — buttons rendered on the right of the action line, typically Button (icon-only + primary). The right-hand wrapper only renders when something is projected here. |

### SocDialog

- **Sélecteur** : `soc-dialog` — `<soc-dialog>…</soc-dialog>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `composes/dialog/dialog.ts`

## Rôle Fenêtre modale bloquante, superposée au contenu de la page, pour une action ou une information qui exige l'attention exclusive de l'utilisateur avant qu'il puisse continuer. ## Quand l'utiliser - Toute action nécessitant une confirmation explicite avant exécution (suppression, annulation d'un processus en cours, désactivation, etc.). - Saisie ou consultation ponctuelle qui ne justifie pas une page dédiée. ## Contraintes de composition - Toute action nécessitant une confirmation de l'utilisateur (suppression, annulation, etc.) doit systématiquement passer par une instance de `soc-dialo…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `open` | `boolean` | `false` |  |  |
| `title` | `string` | — | oui |  |
| `primaryAction` | `DialogAction` | — |  |  |
| `secondaryAction` | `DialogAction` | — |  |  |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(close)` | `void` |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `(contenu par défaut)` |  |

### SocDrawer

- **Sélecteur** : `soc-drawer` — `<soc-drawer>…</soc-drawer>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `composes/drawer/drawer.ts`

Maps 1:1 to "Index/Conteneur/Drawer/*" tokens — see packages/tokens/tokens/components/conteneur.json in design_system (React reference repo, read only). Plain wrapper (`soc-drawer`), same open/close/portal/actions conventions as `SocDialog` (see its doc, not repeated here).

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `open` | `boolean` | `false` |  |  |
| `title` | `string` | — | oui |  |
| `topline` | `string` | — |  |  |
| `subtitle` | `string` | — |  |  |
| `anchor` | `DrawerAnchor` | `'right'` |  |  |
| `sectionTitle` | `string` | — |  |  |
| `sectionSubtitle` | `string` | — |  |  |
| `primaryAction` | `DrawerAction` | — |  |  |
| `secondaryAction` | `DrawerAction` | — |  |  |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(close)` | `void` |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `(contenu par défaut)` |  |

### SocDrawerDetailItem

- **Sélecteur** : `soc-drawer-detail-item` — `<soc-drawer-detail-item>…</soc-drawer-detail-item>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `composes/drawer/drawer.ts`

A label/value row matching Figma's Drawer "Détail" mode — see Index/Conteneur/Drawer/detail-*.

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `label` | `string` | — | oui |  |
| `value` | `string` | — | oui |  |

### SocEnterpriseSelect

- **Sélecteur** : `soc-enterprise-select` — `<soc-enterprise-select>…</soc-enterprise-select>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `composes/enterprise-select/enterprise-select.ts`

Maps 1:1 to "Index/Selection/Select/enterprise-*" tokens — a distinct always-dark trigger for switching between companies/subsidiaries (used in HeaderApp), not a form field. Plain wrapper (`soc-enterprise-select`) built on `soc-popover` + `soc-menu`, same as React. `value`/ `defaultValue`/`onChange` -> one `model()` (see `LanguageSelect`); React's `className` targets the trigger button, exposed as `triggerClass` for the same reason (no root element of its own).

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `options` | `EnterpriseOption[]` | — | oui |  |
| `value` ↔ | `string` | — |  |  |
| `defaultValue` | `string` | — |  |  |
| `triggerClass` | `string` | — |  |  |

### SocHeaderApp

- **Sélecteur** : `soc-header-app` — `<soc-header-app>…</soc-header-app>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `composes/header-app/header-app.ts`

Maps 1:1 to "Index/Navigation/HeaderApp/*" tokens — see packages/tokens/tokens/components/navigation.json in design_system (React reference repo, read only). Plain wrapper (`soc-header-app`, `role="banner"` to keep the landmark React's `<header>` gives for free); React's `className` is a literal `class` on the host. The help/notification icons are Lucide's `CircleHelp`/`Bell` (Figma names its icon instances after Lucide slugs). Every `ReactNode` prop -> named content slot with a marker directive. `avatar` is needed in two mutually exclusive places (inside the AvatarZone button when `avatarMen…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `userName` | `string` | — | oui | The signed-in user's display name, rendered inside HeaderApp's own AvatarZone next to the `avatar` slot — not a free-form slot: the gap and typography between the two come from `Index/Navigation/HeaderApp/avatar-*` toke… |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(helpClick)` | `void` |  |
| `(notificationsClick)` | `void` |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `[socHeaderAppLeft]` | React `HeaderApp`'s `left: ReactNode` — typically an EnterpriseSelect or a Logo. |
| `[socHeaderAppLanguageSelect]` | React `languageSelect?: ReactNode` — rendered between the notification icon and the separator, typically a `soc-language-select`. Omit to not show a language control at all. |
| `[socHeaderAppAvatarMenu]` | React `avatarMenu?: ReactNode` — content of the dropdown opened by clicking the AvatarZone, typically a `soc-avatar-menu`. Omit it to keep the AvatarZone a plain, non-interactive display (no hover state, no click handle… |
| `[socHeaderAppAvatar]` | React `avatar: ReactNode` — typically a `soc-avatar` (size="md", mode="solid"). |

### SocLanguageSelect

- **Sélecteur** : `soc-language-select` — `<soc-language-select>…</soc-language-select>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `composes/language-select/language-select.ts`

Sélecteur de langue toujours affiché dans `HeaderApp` — un déclencheur compact (ex. "EN" + chevron) qui ouvre un menu contextuel de choix. Plain wrapper (`soc-language-select`), built on `soc-popover` + `soc-menu` like React. Uses `Index/Selection/Select/field-light-*` tokens (white text/border) since it sits on HeaderApp's always-dark background. React's `value`/`defaultValue`/`onChange` collapse to one `model()` (`[(value)]`), same pattern as `Select`; the fallback chain `defaultValue ?? options[0]` is kept. React's `className` targets the *trigger button* (this component has no root elemen…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `options` | `LanguageOption[]` | — | oui |  |
| `value` ↔ | `string` | — |  |  |
| `defaultValue` | `string` | — |  |  |
| `triggerClass` | `string` | — |  |  |

### SocMenuItem

- **Sélecteur** : `button[socMenuItem]` — `<button socMenuItem>…</button>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `composes/menu/menu.ts`

Attribute selector on a real `<button>` (`button[socMenuItem]`) — React's `MenuItem` root IS a single `<button type="button">`, same shape as `Button` itself, so `(click)` (React `onClick`), `disabled`, `aria-*` etc. are just the native ones. Maps 1:1 to "Index/Conteneur/Menu/*" tokens — see packages/tokens/tokens/components/conteneur.json in design_system (React reference repo, read only). `icon` -> named content slot (`socMenuItemIcon`). `checked` is optional here exactly like in React: undefined leaves the inner `Checkbox` uncontrolled (it keeps its own state), a value drives it. One known…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `label` | `string` | — | oui |  |
| `level` | `MenuItemLevel` | `1` |  |  |
| `mode` | `MenuItemMode` | `'icon'` |  |  |
| `checked` | `boolean` | — |  |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `[socMenuItemIcon]` | React `MenuItem`'s `icon?: ReactNode` — only rendered when `mode === 'icon'`. |

### SocMenu

- **Sélecteur** : `soc-menu` — `<soc-menu>…</soc-menu>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `composes/menu/menu.ts`

No native HTML equivalent — plain wrapper (`soc-menu`). A list of `button[socMenuItem]`, meant to be the projected content of a `soc-popover`. React's `className` merge needs no input here: a literal `class="..."` on `<soc-menu>` composes with this host's own classes natively.

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `(contenu par défaut)` |  |

### SocMultiSelect

- **Sélecteur** : `soc-multi-select` — `<soc-multi-select>…</soc-multi-select>`
- **Formulaire (ControlValueAccessor)** : oui
- **Fichier** : `composes/multi-select/multi-select.ts`

Maps 1:1 to "Index/Selection/Select/*" tokens for the field box (Multi-select has no dedicated field tokens of its own — its Figma dependency is Select + Chips) plus "Index/Selection/Chips/*" (type=Input) for the selected-value tags — see packages/tokens/tokens/components/selection.json in design_system (React reference repo, read only). Plain wrapper (`soc-multi-select`) built on `soc-popover` + `soc-menu` (checkbox mode), same as React. `value`/`onChange` are both required in React (purely controlled). A `model()` here (`[(value)]` or `[value]` + `(valueChange)`) so the component is also a…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `disabled` | `boolean` | `false` |  | `[disabled]` / bare `disabled` attribute. (An `input()` rather than a `model()` so the bare-attribute form works — models can't take a transform.) Templates read `isDisabled()`, not this. |
| `label` | `string` | — |  |  |
| `required` | `boolean` | `false` |  |  |
| `error` | `boolean` | `false` |  |  |
| `warning` | `boolean` | `false` |  |  |
| `helperText` | `string` | — |  |  |
| `placeholder` | `string` | `'Select options'` |  |  |
| `options` | `MultiSelectOption[]` | — | oui |  |
| `value` ↔ | `string[]` | `[]` |  |  |
| `id` | `string` | — |  |  |

### SocProfileLine

- **Sélecteur** : `soc-profile-line` — `<soc-profile-line>…</soc-profile-line>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `composes/profile-line/profile-line.ts`

Maps 1:1 to "Index/Données/ProfileLine/*" tokens — see packages/tokens/tokens/components/données.json in design_system (React reference repo, read only). Plain wrapper (`soc-profile-line`); React's root `<div className>` is this host, so a literal `class` on `<soc-profile-line>` replaces its `className` prop. The avatar is always LG/solid per Figma's component notes. Meta fields not passed are simply omitted from the dot-separated row rather than rendered empty. React's `id` prop is the displayed employee id (e.g. "#123456789"), not a DOM id — kept as `id` for parity, with the host's own `id`…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `avatarLabel` | `string` | — | oui | Initials shown in the avatar circle — 2 characters max. |
| `avatarColor` | `AvatarColor` | `'blue'` |  |  |
| `name` | `string` | — | oui |  |
| `id` | `string` | — |  |  |
| `role` | `string` | — |  |  |
| `department` | `string` | — |  |  |
| `email` | `string` | — |  |  |
| `company` | `string` | — |  |  |

### SocSelect

- **Sélecteur** : `soc-select` — `<soc-select>…</soc-select>`
- **Formulaire (ControlValueAccessor)** : oui
- **Fichier** : `composes/select/select.ts`

No native HTML equivalent (label + custom trigger + popover list + helper row) — plain wrapper (`soc-select`). Maps 1:1 to "Index/Selection/Select/*" tokens — see packages/tokens/tokens/components/selection.json in design_system (React reference repo, read only). Built on `soc-popover` + `soc-menu`, same as React. "formulaire" (default): label above the field. "labelHeader": no label above — `label` renders as a small uppercase title inside the field, stacked above the value (compact inline filters). React's `value` (controlled) / `defaultValue` (uncontrolled) / `onChange` collapse to one `mo…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `disabled` | `boolean` | `false` |  | `[disabled]` / bare `disabled` attribute. (An `input()` rather than a `model()` so the bare-attribute form works — models can't take a transform.) Templates read `isDisabled()`, not this. |
| `label` | `string` | — |  |  |
| `mode` | `SelectMode` | `'formulaire'` |  |  |
| `required` | `boolean` | `false` |  |  |
| `error` | `boolean` | `false` |  |  |
| `warning` | `boolean` | `false` |  |  |
| `helperText` | `string` | — |  |  |
| `placeholder` | `unknown` | `SELECT_DEFAULT_PLACEHOLDER` |  |  |
| `options` | `SelectOption[]` | — | oui |  |
| `value` ↔ | `string` | — |  |  |
| `defaultValue` | `string` | — |  |  |
| `id` | `string` | — |  |  |

### SocTableFilterSelect

- **Sélecteur** : `soc-table-filter-select` — `<soc-table-filter-select>…</soc-table-filter-select>`
- **Formulaire (ControlValueAccessor)** : oui
- **Fichier** : `composes/table-filter-select/table-filter-select.ts`

`soc-select` locked to `mode="labelHeader"` — the compact filter style (title stacked above the value inside the field, no separate label row) used for filters above a `DataTable`/`PageList`. `mode` isn't exposed here on purpose, same reasoning as React: use `soc-table-filter-select` for every table filter and that choice is made once, here, not re-decided at each call site. Same inputs as `SocSelect` otherwise (React: `Omit<SelectProps, 'mode'>`), forwarded one by one — Angular has no "spread the props" equivalent for a component. Like React (which returns `Select` directly), no root element…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `disabled` | `boolean` | `false` |  | `[disabled]` / bare `disabled` attribute. (An `input()` rather than a `model()` so the bare-attribute form works — models can't take a transform.) Templates read `isDisabled()`, not this. |
| `label` | `string` | — |  |  |
| `required` | `boolean` | `false` |  |  |
| `error` | `boolean` | `false` |  |  |
| `warning` | `boolean` | `false` |  |  |
| `helperText` | `string` | — |  |  |
| `placeholder` | `unknown` | `SELECT_DEFAULT_PLACEHOLDER` |  |  |
| `options` | `SelectOption[]` | — | oui |  |
| `value` ↔ | `string` | — |  |  |
| `defaultValue` | `string` | — |  |  |
| `id` | `string` | — |  |  |

### SocUploadFile

- **Sélecteur** : `soc-upload-file` — `<soc-upload-file>…</soc-upload-file>`
- **Formulaire (ControlValueAccessor)** : oui
- **Fichier** : `composes/upload-file/upload-file.ts`

Maps 1:1 to "Index/Input/UploadFile/*" tokens — see packages/tokens/tokens/components/input.json in design_system (React reference repo, read only). Plain wrapper (`soc-upload-file`): a drop zone (div) + a `soc-button`-styled trigger + a hidden native `<input type="file">`, not one native element. `onFilesSelected` -> `filesSelected` output (carries the `FileList`, same as React); `accept`/`multiple`/`disabled` are forwarded to the hidden input. Also a form control (`formControl`, `formControlName`, `ngModel`) whose value is the selected `File[]` (a `FileList` can't be assigned, so the form w…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `disabled` | `boolean` | `false` |  | `[disabled]` / bare `disabled` attribute. (An `input()` rather than a `model()` so the bare-attribute form works — models can't take a transform.) Templates read `isDisabled()`, not this. |
| `error` | `boolean` | `false` |  |  |
| `warning` | `boolean` | `false` |  |  |
| `helperText` | `string` | — |  |  |
| `accept` | `string` | — |  |  |
| `multiple` | `boolean` | `false` |  |  |
| `files` ↔ | `File[]` | `[]` |  |  |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(filesSelected)` | `FileList` |  |

---

## Templates de page

### SocAppShell

- **Sélecteur** : `soc-app-shell` — `<soc-app-shell>…</soc-app-shell>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `templates/app-shell/app-shell.ts`

## Rôle Conteneur racine de toute page applicative du Design System: assemble AppSwitch, HeaderApp, SideNavigation et la Content Zone dans une seule structure fixe, identique quel que soit le produit ou l'écran. À utiliser systématiquement comme racine d'une page applicative (jamais deux imbriqués, jamais pour un écran hors-application: connexion, erreur plein écran). ## Cas particuliers - `product` pilote à la fois AppSwitch (icône sélectionnée) et SideNavigation (contenu du menu): les deux ne doivent jamais être synchronisés manuellement ni diverger. - SideNavigation reste scrollable indépe…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `product` ↔ | `AppShellProduct` | — | oui | Which app is active — drives AppSwitch's selected icon and SideNavigation's preset content at once. AppShell has no meaningful "no product" state, so this is required. |
| `headerUserName` | `string` | — | oui | Forwarded to HeaderApp's `userName` — rendered in its AvatarZone next to the avatar slot. |
| `user` | `AppShellHeaderUser` | — |  | Signed-in user shown in the avatar menu — standard way to get a clickable avatar menu. |
| `showViewProfile` | `boolean` | `false` |  |  |
| `showEditAvatar` | `boolean` | `false` |  |  |
| `languages` | `LanguageOption[]` | — |  | Standard way to get a language control next to the notification icon. |
| `language` ↔ | `string` | — |  |  |
| `navSelectedId` ↔ | `string` | — |  | Which item is highlighted within the product's preset menu. Kept in sync with the clicked item; the consumer reacts to `navSelectedIdChange` to show the matching page. |
| `navCollapsed` ↔ | `boolean` | `false` |  |  |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(helpClick)` | `void` |  |
| `(notificationsClick)` | `void` |  |
| `(viewProfile)` | `void` |  |
| `(editAvatar)` | `void` |  |
| `(disconnect)` | `void` |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `[socAppShellHeaderLeft]` | HeaderApp's `left` slot — typically a `soc-enterprise-select`. Never a fixed generic instance: its content depends on the signed-in user/enterprise context, which only the consumer has. |
| `[socAppShellHeaderAvatar]` | HeaderApp's `avatar` slot — typically a `soc-avatar` (size="md", mode="solid"). |
| `[socAppShellHeaderLanguageSelect]` | Advanced/custom escape hatch for the language control — same idea; wins over `languages`. |
| `[socAppShellHeaderAvatarMenu]` | Advanced/custom escape hatch — full control over the avatar menu's content, for cases `user` + `showViewProfile`/`showEditAvatar`/`(disconnect)` can't express. Wins over `user` if both are given. |
| `(contenu par défaut)` |  |

### SocPageDetails

- **Sélecteur** : `soc-page-details` — `<soc-page-details>…</soc-page-details>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `templates/page-details/page-details.ts`

## Rôle Présenter en lecture les informations complètes d'un seul objet métier (non-personne), organisées en sections, avec des actions contextuelles (modifier, supprimer, valider…). Pour une personne → `soc-page-profile`; créer/modifier → `soc-page-form`; une liste → `soc-page-list`. ## Contraintes de composition (inchangées par rapport à React) - Seul le Breadcrumb a son propre padding vertical; l'espacement entre zones vient du `content-gap` du conteneur scrollable. Padding-bottom fixe de 120px non exposé. Aucune surcharge de style. - Les boutons de `socPageActions` sont toujours en varian…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `showBack` | `boolean` | `false` |  |  |
| `backLabel` | `string` | `'Retour'` |  |  |
| `topStatusLabel` | `string` | — |  | Small label above the title. |
| `title` | `string` | — | oui |  |
| `statusLabel` | `string` | — |  |  |
| `description` | `string` | — |  |  |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(back)` | `void` |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `[socPageBreadcrumb]` | Content-slot markers shared by the page templates (`PageList`, `PageDetails`, `PageForm`, `PageProfile`, `PageHome`) — React's `ReactNode` props (`breadcrumb`, `badge`, `actions`, `tabs`, …) become named `<ng-content>`… |
| `[socPageBadge]` | Badge next to the title (`PageList`, `PageDetails`). |
| `[socPageTag]` | Tag next to the title (`PageDetails`, `PageProfile`). |
| `[socPageActions]` | Buttons rendered top-right of the header (`PageList`, `PageDetails`) or under the form (`PageForm`). |
| `[socPageTabs]` | Tab row below the header — typically a `soc-tabs`. |
| `(contenu par défaut)` |  |

### SocPageForm

- **Sélecteur** : `soc-page-form` — `<soc-page-form>…</soc-page-form>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `templates/page-form/page-form.ts`

Page de création/modification d'un objet: titre, stepper et message optionnels, une section de formulaire (`children`, colonne de 595px) avec ses actions alignées à droite, puis un second bloc optionnel (`socPageSecondContent`) avec son propre titre de section. `onBack` -> `showBack` + sortie `back` (voir `soc-page-details`). Slots: `socPageBreadcrumb`, `socPageStepper`, `socPageMessage`, `socPageActions`, `socPageSecondContent`. Padding-bottom fixe de 120px, comme `soc-page-list`. Les champs placés dans le slot par défaut sont typiquement des `soc-input-text`… liés à un `FormGroup` (voir Gui…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `showBack` | `boolean` | `false` |  |  |
| `backLabel` | `string` | `'Retour'` |  |  |
| `title` | `string` | — | oui |  |
| `description` | `string` | — |  |  |
| `sectionTitle` | `string` | — |  |  |
| `sectionSubtitle` | `string` | — |  |  |
| `secondSectionTitle` | `string` | — |  |  |
| `secondSectionSubtitle` | `string` | — |  |  |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(back)` | `void` |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `[socPageBreadcrumb]` | Content-slot markers shared by the page templates (`PageList`, `PageDetails`, `PageForm`, `PageProfile`, `PageHome`) — React's `ReactNode` props (`breadcrumb`, `badge`, `actions`, `tabs`, …) become named `<ng-content>`… |
| `[socPageStepper]` | Stepper zone (`PageForm`). |
| `[socPageMessage]` | Message zone (`PageForm`, `PageProfile`) — typically a `soc-message`. |
| `(contenu par défaut)` |  |
| `[socPageActions]` | Buttons rendered top-right of the header (`PageList`, `PageDetails`) or under the form (`PageForm`). |
| `[socPageSecondContent]` | Second content block with its own section title (`PageForm`). |

### SocPageHome

- **Sélecteur** : `soc-page-home` — `<soc-page-home>…</soc-page-home>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `templates/page-home/page-home.ts`

## Rôle Page d'accueil d'un produit Socium: bannière de bienvenue personnalisée, recherche globale, puis une section de contenu libre (`children`: grille de `soc-card`, `soc-data-table`, raccourcis…). Pour une liste → `soc-page-list`; un détail/profil → `soc-page-details`/`soc-page-profile`. ## Contraintes de composition Comme `soc-page-list`: seul le Breadcrumb a son propre padding vertical, le reste tire son espacement du `content-gap` du conteneur scrollable. `welcome-pad-h`/`search-pad-h`/`section-pad-h` sont trois tokens distincts (24px chacun aujourd'hui) pour pouvoir diverger si Figma…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `welcomeLabel` | `string` | — |  | Small label above the welcome title (Figma: "Accueil"). |
| `welcomeTitle` | `string` | — |  | The banner's headline, e.g. "Bienvenue {name}" — its presence shows/hides the whole banner. |
| `welcomeDescription` | `string` | — |  |  |
| `searchable` | `boolean` | `false` |  |  |
| `sectionTitle` | `string` | — |  |  |
| `sectionSubtitle` | `string` | — |  |  |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(search)` | `string` |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `[socPageBreadcrumb]` | Content-slot markers shared by the page templates (`PageList`, `PageDetails`, `PageForm`, `PageProfile`, `PageHome`) — React's `ReactNode` props (`breadcrumb`, `badge`, `actions`, `tabs`, …) become named `<ng-content>`… |
| `[socPageSectionActions]` | Buttons next to the section title (`PageHome`). |
| `(contenu par défaut)` |  |

### SocPageList

- **Sélecteur** : `soc-page-list` — `<soc-page-list>…</soc-page-list>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `templates/page-list/page-list.ts`

## Rôle Afficher une liste d'instances d'un même type d'objet métier, avec recherche, filtres et pagination, avant d'accéder au détail de l'un d'eux. ## Quand l'utiliser / ne pas l'utiliser Chaque fois qu'un écran présente plusieurs éléments du même type à parcourir ou filtrer. Pour un seul objet → `soc-page-details`; une personne → `soc-page-profile`; créer/modifier → `soc-page-form`. ## Contraintes de composition (inchangées par rapport à React) - Seul le Breadcrumb a son propre padding vertical; l'espacement entre les autres zones vient uniquement du `content-gap` du conteneur scrollable —…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `title` | `string` | — | oui |  |
| `statusLabel` | `string` | — |  |  |
| `description` | `string` | — |  |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `[socPageBreadcrumb]` | Content-slot markers shared by the page templates (`PageList`, `PageDetails`, `PageForm`, `PageProfile`, `PageHome`) — React's `ReactNode` props (`breadcrumb`, `badge`, `actions`, `tabs`, …) become named `<ng-content>`… |
| `[socPageSecondaryTabs]` | Secondary tab row above the page header (`PageList`) — typically a pill `soc-tabs`. |
| `[socPageBadge]` | Badge next to the title (`PageList`, `PageDetails`). |
| `[socPageActions]` | Buttons rendered top-right of the header (`PageList`, `PageDetails`) or under the form (`PageForm`). |
| `[socPageTabs]` | Tab row below the header — typically a `soc-tabs`. |
| `(contenu par défaut)` |  |

### SocPageProfile

- **Sélecteur** : `soc-page-profile` — `<soc-page-profile>…</soc-page-profile>`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `templates/page-profile/page-profile.ts`

## Rôle Présenter le profil complet d'une personne (employé, utilisateur connecté), avec une structure centrée sur l'identité — avatar, nom, poste en en-tête. Pour un objet non-personne → `soc-page-details`. ## Cas particuliers Plusieurs onglets/sections selon le produit; la structure d'en-tête (identité) reste fixe. "Vue par soi-même" vs "vue par un gestionnaire": même structure, actions différentes. ## Zone flexible (slot) et éléments optionnels Le contenu par défaut (`children`) est libre: choisir les composants du DS adaptés au besoin réel, ne jamais le laisser vide. Pour un élément optio…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `showBack` | `boolean` | `false` |  |  |
| `backLabel` | `string` | `'Retour'` |  |  |
| `statusLabel` | `string` | — |  |  |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(back)` | `void` |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `[socPageBreadcrumb]` | Content-slot markers shared by the page templates (`PageList`, `PageDetails`, `PageForm`, `PageProfile`, `PageHome`) — React's `ReactNode` props (`breadcrumb`, `badge`, `actions`, `tabs`, …) become named `<ng-content>`… |
| `[socPageHeader]` | Identity block (`PageProfile`) — typically a `soc-profile-line`. |
| `[socPageTag]` | Tag next to the title (`PageDetails`, `PageProfile`). |
| `[socPageTabs]` | Tab row below the header — typically a `soc-tabs`. |
| `[socPageMessage]` | Message zone (`PageForm`, `PageProfile`) — typically a `soc-message`. |
| `(contenu par défaut)` |  |

---

## Labs (expérimental)

> **Composants expérimentaux — non stabilisés.** Importés depuis `@socium-design/angular-components/labs` (jamais depuis le point d'entrée principal). Ils peuvent changer ou disparaître sans garantie de compatibilité, jusqu'à leur promotion dans le kit (renommés sans « Labs ») après accord de l'équipe design. Requiert `@angular/cdk` (glisser-déposer). Statut de chaque composant : `labs/README.md` du dépôt.

### SocLabsButton

- **Sélecteur** : `button[socLabsButton]` — `<button socLabsButton>…</button>`
- **Import** : `import { SocLabsButton } from '@socium-design/angular-components/labs';`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `labs/button/button.ts`

## Rôle Bouton à texte **teinté** (fond bleu clair, texte et icône bleus) : action secondaire mise en avant sans le poids d'un bouton `primary`, typiquement répétée sur chaque ligne d'une liste (« Visualiser »). Aucune des 5 variantes de `button[socButton]` ne la couvre : `secondary` est gris, `ghost` transparent, `primary` plein. Même gabarit que `button[socButton]` (paddings, rayon, typographie et taille d'icône du kit, tailles `sm`/`lg`), mêmes emplacements d'icône (`socButtonLeftIcon` / `socButtonRightIcon` du kit) ; seule la couleur change. Sélecteur d'attribut sur un vrai `<button>` (co…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `variant` | `LabsButtonVariant` | `'primary-subtle'` |  |  |
| `size` | `ButtonSize` | `'sm'` |  |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `[socButtonLeftIcon]` | Marks the element projected into `SocButton`'s leading icon slot (`<ng-content select="[socButtonLeftIcon]">`) — see `SocButtonRightIcon` for the trailing one. Angular's equivalent of React `Button`'s `leftIcon?: ReactN… |
| `(contenu par défaut)` |  |
| `[socButtonRightIcon]` | Trailing icon slot — see `SocButtonLeftIcon`. React `Button`'s `rightIcon?: ReactNode`. |

### SocLabsChangesBar

- **Sélecteur** : `soc-labs-changes-bar` — `<soc-labs-changes-bar>…</soc-labs-changes-bar>`
- **Import** : `import { SocLabsChangesBar } from '@socium-design/angular-components/labs';`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `labs/changes-bar/changes-bar.ts`

## Rôle Barre **fixe en bas** de la zone de contenu pour une page qui n'applique pas ses changements tout de suite (page de réglages) : « N modifications non enregistrées », « Annuler », « Enregistrer ». Après l'enregistrement, `saved` affiche « Enregistré ✓ » à la place, sans boutons. ## Visibilité Rendue seulement quand `count > 0` ou `saved` : rien à afficher sinon (l'hôte est vide). C'est le parent qui remet `saved` à `false` (après quelques secondes, ou à la modification suivante). ## Mise en page `position: sticky; bottom: 0` : placer `soc-labs-changes-bar` en **dernier enfant** du cont…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `count` | `number` | `0` |  | Nombre de modifications non enregistrées. |
| `saved` | `boolean` | `false` |  | Affiche « Enregistré ✓ » (prioritaire sur `count`). |
| `saving` | `boolean` | `false` |  | Désactive « Enregistrer » pendant l'enregistrement. |
| `saveLabel` | `string` | `'Enregistrer'` |  |  |
| `cancelLabel` | `string` | `'Annuler'` |  |  |
| `savedLabel` | `string` | `'Enregistré'` |  |  |
| `ariaLabel` | `string` | `'Modifications non enregistrées'` |  |  |
| `insetBottom` | `string` | `'120px'` |  | Padding-bottom du conteneur qui défile, à compenser (120px fixes dans les templates `soc-page-*` du kit). |
| `label` | `string` | — |  | Remplace le message par défaut (« 1 modification non enregistrée », « N modifications non enregistrées »). |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(save)` | `void` |  |
| `(cancel)` | `void` |  |

### SocLabsChartTypeChip

- **Sélecteur** : `soc-labs-chart-type-chip` — `<soc-labs-chart-type-chip>…</soc-labs-chart-type-chip>`
- **Import** : `import { SocLabsChartTypeChip } from '@socium-design/angular-components/labs';`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `labs/chart-type-chip/chart-type-chip.ts`

## Rôle Pastille identifiant un **type de graphique** (catalogue d'indicateurs, cartes de composition) : icône Lucide sur un fond teinté propre au type, tailles 20 et 28 px. ## Accessibilité `role="img"` nommé par le libellé du type (`label` pour le remplacer). À côté d'un texte qui dit déjà le type, passer `decorative` : la pastille est alors masquée aux technologies d'assistance.

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `type` | `LabsChartType` | — | oui |  |
| `size` | `LabsChartTypeChipSize` | `20` |  |  |
| `label` | `string` | — |  | Nom accessible ; défaut : libellé du type (`LABS_CHART_TYPE_LABELS`). |
| `decorative` | `boolean` | `false` |  |  |

### SocLabsCompactField

- **Sélecteur** : `soc-labs-compact-field` — `<soc-labs-compact-field>…</soc-labs-compact-field>`
- **Import** : `import { SocLabsCompactField } from '@socium-design/angular-components/labs';`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `labs/compact-field/compact-field.ts`

## Rôle Champ **compact pour panneau latéral** (≥ 220 px) : libellé en petites capitales, puis la valeur — en lecture (texte) ou en édition (champ texte, zone multiligne ou liste déroulante native, 28 px de haut). Un séparateur fin sous chaque champ (`separator`, actif par défaut) rythme le panneau. ## Taille (`size`) - **`md`** (défaut) : valeur et contrôles en 14 px, contrôles de 28 px de haut. - **`sm`** : panneaux denses — valeur et contrôles (texte, zone multiligne, liste, lecture) en 12 px, contrôles de 24 px de haut (icône `lg` du kit), chevron 12 px, espacements réduits. Le libellé re…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `disabled` | `boolean` | `false` |  |  |
| `label` | `string` | — | oui |  |
| `mode` | `LabsCompactFieldMode` | `'read'` |  |  |
| `control` | `LabsCompactFieldControl` | `'text'` |  |  |
| `value` ↔ | `string` | `''` |  |  |
| `options` | `LabsCompactFieldOption[]` | `[]` |  | Options de la liste déroulante (`control="select"`). |
| `placeholder` | `string` | — |  |  |
| `emptyText` | `string` | `'—'` |  | Texte affiché en lecture quand la valeur est vide. |
| `rows` | `number` | `3` |  |  |
| `separator` | `boolean` | `true` |  |  |
| `id` | `string` | — |  | Id du contrôle natif (sinon généré). |
| `size` | `LabsCompactFieldSize` | `'md'` |  | `md` (défaut, 14 px) ou `sm` (12 px, contrôles de 24 px) pour les panneaux denses. |

### SocLabsDropZone

- **Sélecteur** : `soc-labs-drop-zone` — `<soc-labs-drop-zone>…</soc-labs-drop-zone>`
- **Import** : `import { SocLabsDropZone } from '@socium-design/angular-components/labs';`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `labs/drop-zone/drop-zone.ts`

## Rôle Zone de dépôt, **cliquable** (le clic reste le chemin principal, le glisser un raccourci) : - `empty` : grand cadre pointillé avec une icône + et un texte — section ou liste vide ; - `slot` : emplacement compact « + Ajouter… » en bas d'une liste ; - état **survol de dépôt** (`data-state="over"`) : contour pointillé bleu et léger fond bleu. ## Glisser-déposer (`@angular/cdk/drag-drop`) Poser `cdkDropList` sur `<soc-labs-drop-zone>` : le composant écoute ses événements `entered` / `exited` / `dropped` et passe seul à l'état « survol de dépôt » ; le placeholder du CDK est masqué à l'inté…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `variant` | `LabsDropZoneVariant` | `'empty'` |  |  |
| `label` | `string` | — |  | Texte de la zone ; défaut selon la variante. |
| `hint` | `string` | — |  | Texte secondaire (variante `empty`). |
| `active` | `boolean` | `false` |  | Force l'état « survol de dépôt » (sans CDK, ou glisser natif). |
| `disabled` | `boolean` | `false` |  |  |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(activate)` | `void` | Clic, Entrée ou Espace sur la zone. |

### SocLabsFullscreenOverlay

- **Sélecteur** : `soc-labs-fullscreen-overlay` — `<soc-labs-fullscreen-overlay>…</soc-labs-fullscreen-overlay>`
- **Import** : `import { SocLabsFullscreenOverlay } from '@socium-design/angular-components/labs';`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `labs/fullscreen-overlay/fullscreen-overlay.ts`

## Rôle Calque **plein écran** qui recouvre toute l'application (bandeau et menu compris) : prévisualiser un tableau de bord, consulter un contenu dense sans le shell. Barre du haut (titre, sous-titre, badge, bouton Fermer) et contenu qui défile. ## Comportement et accessibilité - `role="dialog"` + `aria-modal`, nommé par le titre et décrit par le sous-titre. - À l'ouverture : le focus entre dans le calque, le défilement de la page est bloqué. - **Piège du focus** : Tab / Maj+Tab bouclent dans le calque. - **Échap** ou le bouton Fermer : `open` repasse à `false` et `(close)` est émis. - À la…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `open` ↔ | `boolean` | `false` |  |  |
| `title` | `string` | — | oui |  |
| `subtitle` | `string` | — |  |  |
| `closeLabel` | `string` | `'Fermer'` |  |  |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(close)` | `void` | Émis à la fermeture par Échap ou par le bouton Fermer. |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `[socLabsOverlayBadge]` | Badge à côté du titre (ex. `<soc-tag socLabsOverlayBadge>Données simulées</soc-tag>`). |
| `(contenu par défaut)` |  |

### SocLabsIconButton

- **Sélecteur** : `soc-labs-icon-button` — `<soc-labs-icon-button>…</soc-labs-icon-button>`
- **Import** : `import { SocLabsIconButton } from '@socium-design/angular-components/labs';`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `labs/icon-button/icon-button.ts`

## Rôle Bouton icône compact pour les barres d'outils denses (lignes de liste, en-têtes de panneau, cartes en composition) — là où `button[socButton]` (32px minimum) est trop haut. ## Accessibilité - `ariaLabel` est **obligatoire** (input requis : le build échoue sans lui) — un bouton sans texte visible n'a pas d'autre nom accessible. - `ariaExpanded` / `ariaControls` (optionnels) : bouton de divulgation (ex. replier un panneau). - `tooltip` (optionnel) affiche une info-bulle du kit (`soc-tooltip`) au survol et au focus. ## Écart avec la convention du kit (GAP-DECISION) Composant élément (`so…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `ariaLabel` | `string` | — | oui | Nom accessible du bouton (obligatoire). |
| `size` | `LabsIconButtonSize` | `'sm'` |  |  |
| `variant` | `LabsIconButtonVariant` | `'ghost'` |  |  |
| `shape` | `LabsIconButtonShape` | `'square'` |  |  |
| `tooltip` | `string` | — |  | Texte de l'info-bulle ; absent = pas d'info-bulle. |
| `tooltipPosition` | `TooltipPosition` | `'top'` |  |  |
| `disabled` | `boolean` | `false` |  |  |
| `type` | `'button' \| 'submit' \| 'reset'` | `'button'` |  |  |
| `pressed` | `boolean \| undefined` | `undefined` |  | Bouton bascule : `true`/`false` posent `aria-pressed` ; absent = bouton simple. |
| `ariaExpanded` | `boolean \| undefined` | `undefined` |  | Bouton de divulgation (repli d'un panneau…) : `true`/`false` posent `aria-expanded` ; absent = rien. |
| `ariaControls` | `string \| undefined` | `undefined` |  | `id` de l'élément contrôlé (`aria-controls`), avec `ariaExpanded`. |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `(contenu par défaut)` |  |

### SocLabsIconTile

- **Sélecteur** : `soc-labs-icon-tile` — `<soc-labs-icon-tile>…</soc-labs-icon-tile>`
- **Import** : `import { SocLabsIconTile } from '@socium-design/angular-components/labs';`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `labs/icon-tile/icon-tile.ts`

## Rôle Tuile carrée teintée portant une icône : repère visuel devant un libellé (nom d'un tableau de bord dans une liste, entrée de catalogue…). Générique, contrairement à `soc-labs-chart-type-chip` qui ne connaît que les types de graphique : l'icône est projetée et la couleur choisie parmi les accents du kit. L'icône est le contenu par défaut : `<svg lucideLayoutGrid class="size-full">`. ## Accessibilité Par défaut `role="img"` nommé par `label`. À côté d'un texte qui dit déjà la même chose (cas courant : le nom de la ligne), passer `decorative` : la tuile est masquée aux technologies d'ass…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `color` | `LabsIconTileColor` | `'blue'` |  |  |
| `size` | `LabsIconTileSize` | `32` |  |  |
| `label` | `string` | — |  | Nom accessible ; absent = tuile décorative. |
| `decorative` | `boolean` | `false` |  |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `(contenu par défaut)` |  |

### SocLabsInlineEdit

- **Sélecteur** : `soc-labs-inline-edit` — `<soc-labs-inline-edit>…</soc-labs-inline-edit>`
- **Import** : `import { SocLabsInlineEdit } from '@socium-design/angular-components/labs';`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `labs/inline-edit/inline-edit.ts`

## Rôle Libellé **modifiable sur place** (nom d'une section, titre d'un widget) : le texte s'affiche tel quel, un crayon apparaît au survol ; un clic le remplace par un champ **à la même place et à la même taille** (le champ hérite de la police du parent et s'élargit avec son contenu). ## Comportement - Entrée ou perte du focus : valide ; Échap : annule (le texte d'origine revient). - Valeur vide (après `trim`) : revient à `defaultValue`. - `value` est un `model` (↔) : `(valueChange)` n'est émis que si la valeur change réellement. ## Accessibilité Hors édition, le libellé est un `<button>` («…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `value` ↔ | `string` | `''` |  |  |
| `defaultValue` | `string` | `''` |  | Valeur reprise quand le champ est validé vide. |
| `ariaLabel` | `string` | `'le libellé'` |  | Ce qui est modifié (« le nom de la section ») — nomme le champ et le bouton. |
| `placeholder` | `string` | `'Sans titre'` |  | Texte affiché quand la valeur et la valeur par défaut sont vides. |
| `maxlength` | `number` | — |  |  |
| `disabled` | `boolean` | `false` |  |  |

### SocLabsListRow

- **Sélecteur** : `soc-labs-list-row` — `<soc-labs-list-row>…</soc-labs-list-row>`
- **Import** : `import { SocLabsListRow } from '@socium-design/angular-components/labs';`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `labs/list-row/list-row.ts`

## Rôle Ligne de liste **compacte** pour les catalogues en panneau latéral : slot à gauche, titre + sous-titre tronqués sur une ligne, slot d'action à droite. ## États - **survol** : fond léger ; si `draggable`, une poignée de glisser apparaît à gauche. - **sélectionné / ajouté** (`selected`) : fond bleu clair, titre bleu en gras, « Ajouté » lu par les lecteurs d'écran (`selectedLabel`). - **verrouillé** (`locked`) : opacité 50 %, curseur interdit, action inerte ; `lockedReason` s'affiche en info-bulle (`soc-tooltip` du kit) au survol et au focus clavier. ## Glisser-déposer (`@angular/cdk/dra…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `title` | `string` | — | oui |  |
| `subtitle` | `string` | — |  |  |
| `selected` | `boolean` | `false` |  | Ajouté / sélectionné. |
| `locked` | `boolean` | `false` |  |  |
| `lockedReason` | `string` | — |  | Raison du verrouillage, en info-bulle. |
| `draggable` | `boolean` | `false` |  | Affiche la poignée de glisser au survol (avec `cdkDrag` sur l'hôte). |
| `selectedLabel` | `string` | `'Ajouté'` |  | Texte lu par les lecteurs d'écran pour l'état sélectionné. |
| `appearance` | `LabsListRowAppearance` | `'card'` |  | `card` (défaut, bloc arrondi) ou `flush` (liste dense : lignes jointives séparées par un filet). |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `[socLabsListRowLeading]` | Slot à gauche de la ligne : icône, pastille (`soc-labs-chart-type-chip`), avatar… |
| `[socLabsListRowAction]` | Slot d'action à droite (typiquement un `soc-labs-icon-button`). Inerte quand la ligne est verrouillée. |

### SocLabsNavList

- **Sélecteur** : `soc-labs-nav-list` — `<soc-labs-nav-list>…</soc-labs-nav-list>`
- **Import** : `import { SocLabsNavList } from '@socium-design/angular-components/labs';`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `labs/nav-list/nav-list.ts`

## Rôle Navigation **verticale** d'une colonne de filtre, dans la page : une entrée par catégorie (produit…), avec un compteur à droite et, en option, l'icône du produit (`icon` : glyphe de l'AppSwitch du kit, à gauche du libellé ; dès qu'une entrée en a une, les entrées sans icône gardent la place vide pour aligner les libellés). L'entrée courante est surlignée (fond `surface-selected`, texte action en demi-gras). Diffère de `soc-tabs` (horizontal, sans compteur) et de `soc-side-navigation` (menu du shell, presets). ## Accessibilité `<nav>` nommée par `ariaLabel`, liste de `<button>` ; icône…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `items` | `LabsNavListItem[]` | — | oui |  |
| `value` ↔ | `string` | `''` |  | Id de l'entrée courante (↔). |
| `ariaLabel` | `string` | — | oui |  |

### SocLabsOptionRow

- **Sélecteur** : `soc-labs-option-row` — `<soc-labs-option-row>…</soc-labs-option-row>`
- **Import** : `import { SocLabsOptionRow } from '@socium-design/angular-components/labs';`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `labs/option-row/option-row.ts`

## Rôle Ligne d'une **liste d'options activables** (fonctionnalités d'un client, réglages) : interrupteur du kit, libellé cliquable (ouvre un détail : `(labelClick)`), description sur **une ligne** (tronquée par « … »), tags à droite (slot `socLabsOptionRowTags`) et badge « Nouveau » (`isNew`). ## Sous-options Des `soc-labs-option-row` projetées dans une ligne forment une liste imbriquée, en retrait sous leur parent (filet à gauche). Le parent ne pilote pas leurs états : c'est au consommateur de passer `disabled` aux sous-options tant que le parent est coupé, avec `disabledReason` (« Activez…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `label` | `string` | — | oui |  |
| `description` | `string` | — |  |  |
| `checked` ↔ | `boolean` | `false` |  | Option activée (↔). Avec `confirmMessage`, ne passe à `true` qu'après « Confirmer ». |
| `disabled` | `boolean` | `false` |  |  |
| `disabledReason` | `string` | — |  | Pourquoi l'option est désactivée (« Activez d'abord … »), affiché sous la description. |
| `isNew` | `boolean` | `false` |  | Badge « Nouveau » (tag `information` du kit, 5,9:1). |
| `newLabel` | `string` | `'Nouveau'` |  |  |
| `confirmMessage` | `string` | — |  | Message de la confirmation dans la ligne avant activation ; absent = activation directe. |
| `confirmLabel` | `string` | `'Confirmer'` |  |  |
| `cancelLabel` | `string` | `'Annuler'` |  |  |

**Outputs**

| Nom | Payload | Description |
|---|---|---|
| `(labelClick)` | `void` | Clic sur le libellé (ouvrir un panneau de détail). |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `[socLabsOptionRowTags]` | Tags de la ligne (offre : `soc-tag` du kit ou `soc-labs-tag`), alignés à droite. |
| `(contenu par défaut)` |  |

### SocLabsPillToggle

- **Sélecteur** : `soc-labs-pill-toggle` — `<soc-labs-pill-toggle>…</soc-labs-pill-toggle>`
- **Import** : `import { SocLabsPillToggle } from '@socium-design/angular-components/labs';`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `labs/pill-toggle/pill-toggle.ts`

## Rôle Bascule en pastilles, **choix unique** parmi 2 à 4 options courtes et immédiates : statut (Actif / Inactif / Archivé), opérateur logique (ET / OU) d'une population. ## Accessibilité `role="radiogroup"` (nommé par `ariaLabel`) contenant des `role="radio"` ; tabulation itinérante (une seule pastille dans l'ordre de tabulation) ; ← → ↑ ↓ déplacent le focus **et** la sélection, Origine / Fin vont aux extrémités ; les options désactivées sont sautées. Champ de formulaire (`formControl`, `formControlName`, `ngModel`) ; la valeur est `value` (↔). La couleur est propre à chaque option (`color…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `disabled` | `boolean` | `false` |  |  |
| `options` | `LabsPillOption<T>[]` | — | oui |  |
| `value` ↔ | `T \| null` | `null` |  |  |
| `size` | `LabsPillToggleSize` | `'md'` |  |  |
| `ariaLabel` | `string` | — |  | Nom accessible du groupe (ex. « Statut »). |

### SocLabsSettingsCard

- **Sélecteur** : `soc-labs-settings-card` — `<soc-labs-settings-card>…</soc-labs-settings-card>`
- **Import** : `import { SocLabsSettingsCard } from '@socium-design/angular-components/labs';`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `labs/settings-card/settings-card.ts`

## Rôle Carte d'un **bloc de réglages** dans une page de configuration : sur-titre en petites capitales (« BARÈME »), titre, contrôle à droite du titre (interrupteur), corps libre (champs du kit), puis une note optionnelle dans un encadré pointillé (« Règle de calcul »), sur le fond de la carte : `text-secondary` y garde 4,8:1 (sur `background-layer-1`, il tomberait à 4,4:1). Diffère de `soc-card` du kit : sur-titre, titre jamais tronqué, pas de bouton « ••• » (#15), état **désactivé** (#11) et encadré de note. ## État désactivé (`disabled`) Le corps et la note sont grisés (`--bridges-texture…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `title` | `string` | — | oui |  |
| `overline` | `string` | — |  | Sur-titre en petites capitales au-dessus du titre (« BARÈME »). |
| `disabled` | `boolean` | `false` |  | Corps et note grisés et inertes ; le contrôle d'en-tête reste actif. |
| `disabledNote` | `string` | — |  | Mention affichée sous l'en-tête quand la carte est désactivée (« Barème désactivé : … »). |
| `collapsible` | `boolean` | `false` |  | Carte repliable (en-tête cliquable + chevron). Faux par défaut : la carte est toujours ouverte. |
| `expanded` ↔ | `boolean` | `true` |  | Ouverte (↔). Ignoré si la carte n'est pas repliable. |
| `summary` | `string` | — |  | Résumé sous le titre quand la carte repliable est fermée. |
| `lockExpanded` | `boolean` | `false` |  | Empêche de refermer la carte (valeur à corriger) ; le chevron est `aria-disabled`. |
| `badge` | `string` | — |  | Pastille de l'en-tête (« Modifié », « Erreur ») ; absente si vide. |
| `badgeTone` | `TagColor` | `'information'` |  |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `[socLabsSettingsCardTags]` | Tags d'en-tête (`soc-tag` du kit), avant le badge, visibles carte ouverte ou fermée. |
| `[socLabsSettingsCardAction]` | Contrôle à droite du titre (typiquement un `soc-switch` qui active la carte). Jamais grisé. |
| `(contenu par défaut)` |  |
| `[socLabsSettingsCardFootnote]` | Note de bas de carte dans un encadré pointillé (règle de calcul, remarque). Grisée avec le corps. |
| `[socLabsSettingsCardDetails]` | Zone sous l'encadré de note (ex. un `soc-accordion` « Ce qui sera mis à jour »). Hors du corps : jamais grisée ni inerte quand la carte est désactivée ; repliée avec la carte. |

### SocLabsTag

- **Sélecteur** : `soc-labs-tag` — `<soc-labs-tag>…</soc-labs-tag>`
- **Import** : `import { SocLabsTag } from '@socium-design/angular-components/labs';`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `labs/tag/tag.ts`

## Rôle `soc-tag` du kit avec un ton **neutre** en plus (`color="neutral"`) : une étiquette qui ne doit ni attirer l'attention ni passer pour un état (offre « Standard » à côté de « Payant » et « Customisation client »). Même gabarit que `soc-tag` (tokens `--index-feedback-tag-*` : rayon, paddings, police) ; les autres couleurs reprennent exactement celles du kit, pour aligner des tags neutres et colorés sans écart visuel. ## Contraste Neutre : `text-primary` sur `background-layer-1` (9,4:1). Attention : `warning` du kit est à 2,9:1 (texte `#e17100` sur `#fef3c6`) — préférer `orange` (6,3:1)…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `color` | `LabsTagColor` | `'neutral'` |  |  |
| `size` | `TagSize` | `'sm'` |  |  |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `(contenu par défaut)` |  |

### SocLabsWidgetCard

- **Sélecteur** : `soc-labs-widget-card` — `<soc-labs-widget-card>…</soc-labs-widget-card>`
- **Import** : `import { SocLabsWidgetCard } from '@socium-design/angular-components/labs';`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `labs/widget-card/widget-card.ts`

## Rôle Carte d'un **widget de tableau de bord** (indicateur ou graphique) pour les grilles denses. Diffère de `soc-card` du kit : titre sur plusieurs lignes (`titleLines`, 2 par défaut) puis « … », pied de hauteur automatique, rangée de filtres, et aucun débordement horizontal. ## Slots - `socLabsWidgetCardIcon` (optionnel) : icône à gauche du titre, dans la pastille du kit (28 px). - `socLabsWidgetCardActions` (optionnel) : à droite du titre, alignées en haut, jamais rétrécies. - `socLabsWidgetCardFilters` (optionnel) : rangée `flex-wrap` sous le titre et la description. - contenu sans marq…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `title` | `string` | — | oui |  |
| `description` | `string` | — |  |  |
| `titleLines` | `number` | `2` |  | Nombre de lignes du titre avant « … ». |
| `descriptionLines` | `number` | `2` |  | Nombre de lignes de la description avant « … ». |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `[socLabsWidgetCardIcon]` | Icône à gauche du titre (≈ 28 px, pastille du kit). Optionnel. |
| `[socLabsWidgetCardActions]` | Actions à droite du titre (menu, bouton…), alignées en haut, jamais rétrécies. |
| `[socLabsWidgetCardFilters]` | Rangée de filtres sous le titre / la description, au-dessus du corps : les contrôles passent à la ligne suivante plutôt que de déborder. |
| `(contenu par défaut)` |  |
| `[socLabsWidgetCardFooter]` | Pied de carte (hauteur automatique), sous le corps. Optionnel. |

### SocLabsWorkspaceLayout

- **Sélecteur** : `soc-labs-workspace-layout` — `<soc-labs-workspace-layout>…</soc-labs-workspace-layout>`
- **Import** : `import { SocLabsWorkspaceLayout } from '@socium-design/angular-components/labs';`
- **Formulaire (ControlValueAccessor)** : non
- **Fichier** : `labs/workspace-layout/workspace-layout.ts`

## Rôle **Espace de travail plein écran** sous le bandeau de l'application (composition d'un tableau de bord) : barre du haut, panneau gauche, zone centrale sur le fond gris du kit, panneau droit. Chaque colonne défile indépendamment ; les panneaux sont blancs avec une bordure. ## Slots (tous optionnels) Barre du haut : `socLabsWorkspaceBack`, `socLabsWorkspaceTitle`, `socLabsWorkspaceHint`, `socLabsWorkspaceActions` (la barre n'est rendue que si l'un d'eux est présent). Colonnes : `socLabsWorkspaceLeft`, `socLabsWorkspaceRight` ; le contenu sans marqueur va au centre. ## Mise en page L'hôte…

**Inputs**

| Nom | Type | Défaut | Requis | Description |
|---|---|---|---|---|
| `leftWidth` | `string` | `'220px'` |  | Largeur du panneau gauche (longueur CSS). |
| `rightWidth` | `string` | `'240px'` |  | Largeur du panneau droit (longueur CSS). |
| `leftLabel` | `string` | `'Informations'` |  |  |
| `rightLabel` | `string` | `'Bibliothèque'` |  |  |
| `centerLabel` | `string` | `'Espace de travail'` |  |  |
| `collapsibleBelow` | `number \| null` | `null` |  | Largeur de fenêtre (px) sous laquelle les panneaux deviennent repliables (mode « étroit »). `null` (défaut) = jamais : panneaux toujours dépliés, aucun bouton. |
| `leftCollapsed` ↔ | `boolean` | `false` |  | Panneau gauche replié (effectif seulement en mode étroit). Mis à `true` en entrant dans ce mode. |
| `rightCollapsed` ↔ | `boolean` | `false` |  | Panneau droit replié (effectif seulement en mode étroit). Mis à `true` en entrant dans ce mode. |

**Slots (contenu projeté)**

| Marqueur | Rôle |
|---|---|
| `[socLabsWorkspaceBack]` | Barre du haut, à gauche : bouton retour (ex. `soc-labs-icon-button` avec une flèche). |
| `[socLabsWorkspaceTitle]` | Barre du haut : titre (texte, `soc-labs-inline-edit`…). |
| `[socLabsWorkspaceHint]` | Barre du haut, après le titre : badge ou indication (« Brouillon », « Ajoutez des graphes → »). |
| `[socLabsWorkspaceActions]` | Barre du haut, à droite : actions (Prévisualiser, Enregistrer…). |
| `[socLabsWorkspaceLeft]` | Panneau gauche (optionnel). |
| `(contenu par défaut)` |  |
| `[socLabsWorkspaceRight]` | Panneau droit (optionnel). |

---

## Types exportés (valeurs possibles, formes de données)

- `CardGridGap` (`composes/card-grid/card-grid.ts`)
  ```ts
  export type CardGridGap = 'sm' | 'md' | 'lg';
  ```
- `CardGridMode` (`composes/card-grid/card-grid.ts`)
  ```ts
  export type CardGridMode = 'fixed' | 'bento';
  ```
- `DataTableCardContent` (`composes/data-table/data-table.ts`) — What a single card shows in `mode="card"` — the card-mode counterpart to a table row built from `columns`, one of these per row instead of one cell per column.…
  ```ts
  export interface DataTableCardContent<T> { title: string; subtitle?: string; /** Free-form card body — a `TemplateRef` (see `DataTableColumn.render`), same free-form idea as * a table column's `render`. */ body?: TemplateRef<DataTableCellContext<T>>; footer?: TemplateRef<DataTableCellContext<T>>; }
  ```
- `DataTableCellContext` (`composes/data-table/data-table.ts`) — What a cell/card template receives: `let-row` (the implicit value) or `let-row="row"`.
  ```ts
  export interface DataTableCellContext<T> { $implicit: T; row: T; }
  ```
- `DataTableColumn` (`composes/data-table/data-table.ts`)
  ```ts
  export interface DataTableColumn<T> { key: string; header: string; /** React's `render: (row) => ReactNode` has no Angular equivalent for rich content: a function * returning a plain `string` covers text cells; a `TemplateRef` (an `<ng-template let-row>` the * consumer owns, since only the consumer's template can instantiate its own components) covers * anything richer — a `soc-tag`, a `soc-badge`, a link, etc. */ render: ((row: T) => string) | TemplateRef<DataTableCellContext<T>>; }
  ```
- `DataTableMode` (`composes/data-table/data-table.ts`)
  ```ts
  export type DataTableMode = 'table' | 'detail' | 'card';
  ```
- `DataTablePagination` (`composes/data-table/data-table.ts`) — Plain data only — React's `onPageChange`/`onPageSizeChange` live on this object there; here they are the `pageChange`/`pageSizeChange` outputs of `soc-data-tab…
  ```ts
  export interface DataTablePagination { currentPage: number; totalPages: number; totalEntries?: number; pageSize?: number; }
  ```
- `DataTableRowActionsContext` (`composes/data-table/data-table.ts`) — What a `rowActionsMenu` template receives — call `close()` from each menu item's `(click)` once the action is handled (the popover is controlled internally; no…
  ```ts
  export interface DataTableRowActionsContext<T> { $implicit: T; row: T; close: () => void; }
  ```
- `DialogAction` (`composes/dialog/dialog.ts`)
  ```ts
  export interface DialogAction { label: string; onClick?: () => void; }
  ```
- `DrawerAction` (`composes/drawer/drawer.ts`)
  ```ts
  export interface DrawerAction { label: string; onClick?: () => void; }
  ```
- `DrawerAnchor` (`composes/drawer/drawer.ts`)
  ```ts
  export type DrawerAnchor = 'left' | 'right' | 'bottom';
  ```
- `EnterpriseOption` (`composes/enterprise-select/enterprise-select.ts`)
  ```ts
  export interface EnterpriseOption { value: string; company: string; subsidiary: string; /** Small trailing meta, e.g. a subsidiary index like "1/12". */ count?: string; }
  ```
- `LanguageOption` (`composes/language-select/language-select.ts`)
  ```ts
  export interface LanguageOption { value: string; label: string; }
  ```
- `MenuItemLevel` (`composes/menu/menu.ts`)
  ```ts
  export type MenuItemLevel = 1 | 2 | 3;
  ```
- `MenuItemMode` (`composes/menu/menu.ts`)
  ```ts
  export type MenuItemMode = 'icon' | 'checkbox' | 'radio';
  ```
- `MultiSelectOption` (`composes/multi-select/multi-select.ts`)
  ```ts
  export interface MultiSelectOption { value: string; label: string; }
  ```
- `SelectMode` (`composes/select/select.ts`)
  ```ts
  export type SelectMode = 'formulaire' | 'labelHeader';
  ```
- `SelectOption` (`composes/select/select.ts`)
  ```ts
  export interface SelectOption { value: string; label: string; }
  ```
- `CardGridContext` (`internal/card-grid-context.ts`) — Angular's substitute for React `CardGrid`'s `cloneElement(child, { colSpan, className })`: there is no way to rewrite another component's inputs from the outsi…
  ```ts
  export interface CardGridContext { mode: Signal<'fixed' | 'bento'>; columns: Signal<number | undefined>; }
  ```
- `NativeAttributes` (`internal/form-control.ts`) — Plain native attributes forwarded to the inner control — the Angular counterpart of React's `{...props}` spread on `<input>`: anything without a dedicated inpu…
  ```ts
  export type NativeAttributes = Record<string, string | number | boolean | null | undefined>;
  ```
- `LabsButtonVariant` (`labs/button/button.ts`) — Only the variant the kit's `ButtonVariant` lacks; the other five stay on `button[socButton]`.
  ```ts
  export type LabsButtonVariant = 'primary-subtle';
  ```
- `LabsChartType` (`labs/chart-type-chip/chart-type-chip.ts`) — Identifiants alignés sur le `TypeGraphique` du prototype SIRH (et étendus aux 9 types).
  ```ts
  export type LabsChartType = 'courbe' | 'aire' | 'histogramme' | 'barres-horizontales' | 'barres-empilees' | 'camembert' | 'anneau' | 'jauge' | 'kpi';
  ```
- `LabsChartTypeChipSize` (`labs/chart-type-chip/chart-type-chip.ts`)
  ```ts
  export type LabsChartTypeChipSize = 20 | 28;
  ```
- `LabsCompactFieldControl` (`labs/compact-field/compact-field.ts`)
  ```ts
  export type LabsCompactFieldControl = 'text' | 'textarea' | 'select';
  ```
- `LabsCompactFieldMode` (`labs/compact-field/compact-field.ts`)
  ```ts
  export type LabsCompactFieldMode = 'read' | 'edit';
  ```
- `LabsCompactFieldOption` (`labs/compact-field/compact-field.ts`)
  ```ts
  export interface LabsCompactFieldOption { value: string; label: string; }
  ```
- `LabsCompactFieldSize` (`labs/compact-field/compact-field.ts`)
  ```ts
  export type LabsCompactFieldSize = 'md' | 'sm';
  ```
- `LabsDataTableColumn` (`labs/data-table-fit/data-table-fit.ts`) — `DataTableColumn` + per-column sizing, read by `socLabsFitWidth`. Structurally a `DataTableColumn`: pass it straight to `soc-data-table`'s `[columns]`.
  ```ts
  export interface LabsDataTableColumn<T> extends DataTableColumn<T> { /** CSS width of the column (`'30%'`, `'12rem'`, `'var(--…)'`). In an auto-layout table it is the * width the column gets when there is room, and the width it keeps longest when there isn't. */ width?: string; /** CSS minimum width: the column never gets narrower (its text wraps first). */ minWidth?: string; /** `false` keeps the column on one line (actions, dates, short codes). Default `true`: the text * wraps between words when the table runs out of room. */ wrap?: boolean; }
  ```
- `LabsDropZoneVariant` (`labs/drop-zone/drop-zone.ts`)
  ```ts
  export type LabsDropZoneVariant = 'empty' | 'slot';
  ```
- `LabsIconButtonShape` (`labs/icon-button/icon-button.ts`)
  ```ts
  export type LabsIconButtonShape = 'square' | 'round';
  ```
- `LabsIconButtonSize` (`labs/icon-button/icon-button.ts`)
  ```ts
  export type LabsIconButtonSize = 'xs' | 'sm' | 'md';
  ```
- `LabsIconButtonVariant` (`labs/icon-button/icon-button.ts`)
  ```ts
  export type LabsIconButtonVariant = 'ghost' | 'primary-subtle';
  ```
- `LabsIconTileColor` (`labs/icon-tile/icon-tile.ts`) — The kit's accent palettes (`--bridges-color-accent-*`), plus a neutral tile.
  ```ts
  export type LabsIconTileColor = 'blue' | 'indigo' | 'purple' | 'orange' | 'red' | 'green' | 'amber' | 'lime' | 'neutral';
  ```
- `LabsIconTileSize` (`labs/icon-tile/icon-tile.ts`)
  ```ts
  export type LabsIconTileSize = 20 | 28 | 32;
  ```
- `LabsListRowAppearance` (`labs/list-row/list-row.ts`)
  ```ts
  export type LabsListRowAppearance = 'card' | 'flush';
  ```
- `LabsNavListItem` (`labs/nav-list/nav-list.ts`)
  ```ts
  export interface LabsNavListItem { id: string; label: string; /** Compteur affiché à droite (« 4 / 23 »). */ count?: string; /** Compteur lu par les lecteurs d'écran à la place de `count` (« 4 activées sur 23 »). */ countLabel?: string; /** Icône de produit du kit (`soc-app-icon-glyph`, la même que dans l'AppSwitch), décorative. */ icon?: AppIconName; }
  ```
- `LabsPillColor` (`labs/pill-toggle/pill-toggle.ts`) — Accent of the kit (`--bridges-color-accent-*`) used when the option is selected; `gray` = neutral.
  ```ts
  export type LabsPillColor = 'blue' | 'green' | 'gray' | 'amber' | 'red' | 'indigo' | 'purple' | 'orange';
  ```
- `LabsPillOption` (`labs/pill-toggle/pill-toggle.ts`)
  ```ts
  export interface LabsPillOption<T = string> { value: T; label: string; /** Couleur de la pastille sélectionnée (défaut `blue`). */ color?: LabsPillColor; disabled?: boolean; }
  ```
- `LabsPillToggleSize` (`labs/pill-toggle/pill-toggle.ts`)
  ```ts
  export type LabsPillToggleSize = 'sm' | 'md';
  ```
- `LabsTagColor` (`labs/tag/tag.ts`) — Couleurs de `soc-tag` du kit, plus `neutral` (#68).
  ```ts
  export type LabsTagColor = TagColor | 'neutral';
  ```
- `AppIconName` (`primitifs/app-switch/app-icons.ts`) — Real vector glyphs exported from the Figma "AppIcon" component (Index/Navigation/AppIcon), one per named app. Fill colors mirror the exact bindings used on the…
  ```ts
  export type AppIconName = 'workspace' | 'job' | 'workflow' | 'performance' | 'doc' | 'payroll' | 'time' | 'baas';
  ```
- `AppSwitchItemData` (`primitifs/app-switch/app-switch-presets.ts`)
  ```ts
  export interface AppSwitchItemData { id: string; name: AppIconName; label: string; }
  ```
- `AvatarColor` (`primitifs/avatar/avatar.ts`)
  ```ts
  export type AvatarColor = 'blue' | 'green' | 'purple' | 'orange';
  ```
- `AvatarMode` (`primitifs/avatar/avatar.ts`)
  ```ts
  export type AvatarMode = 'soft' | 'solid';
  ```
- `AvatarNamePosition` (`primitifs/avatar/avatar.ts`)
  ```ts
  export type AvatarNamePosition = 'left' | 'right';
  ```
- `AvatarSize` (`primitifs/avatar/avatar.ts`)
  ```ts
  export type AvatarSize = 'xs' | 'sm' | 'md' | 'lg';
  ```
- `BadgeColor` (`primitifs/badge/badge.ts`)
  ```ts
  export type BadgeColor = 'primary' | 'success' | 'warning' | 'danger';
  ```
- `BadgeSize` (`primitifs/badge/badge.ts`)
  ```ts
  export type BadgeSize = 'sm' | 'lg';
  ```
- `BreadcrumbItemData` (`primitifs/breadcrumb/breadcrumb.ts`)
  ```ts
  export interface BreadcrumbItemData { label: string; onClick?: () => void; }
  ```
- `ButtonSize` (`primitifs/button/button.ts`)
  ```ts
  export type ButtonSize = 'sm' | 'lg';
  ```
- `ButtonVariant` (`primitifs/button/button.ts`)
  ```ts
  export type ButtonVariant = 'primary' | 'secondary' | 'tertiary' | 'danger' | 'ghost';
  ```
- `CardType` (`primitifs/card/card.ts`)
  ```ts
  export type CardType = 'default' | 'selectable';
  ```
- `ChipsSize` (`primitifs/chips/chips.ts`)
  ```ts
  export type ChipsSize = 'sm' | 'lg';
  ```
- `MessageAction` (`primitifs/message/message.ts`)
  ```ts
  export interface MessageAction { label: string; onClick?: () => void; }
  ```
- `MessageStatus` (`primitifs/message/message.ts`)
  ```ts
  export type MessageStatus = 'success' | 'error' | 'warning' | 'info';
  ```
- `MessageVariant` (`primitifs/message/message.ts`) — banner = "Type One" (filled, title+content+actions), inline = "Type Two" (pill bg), plain = "Type Three" (no bg) — see packages/tokens/tokens/components/feedba…
  ```ts
  export type MessageVariant = 'banner' | 'inline' | 'plain';
  ```
- `PaginationVariant` (`primitifs/pagination/pagination.ts`)
  ```ts
  export type PaginationVariant = 'numbered' | 'dots';
  ```
- `PopoverPosition` (`primitifs/popover/popover.ts`)
  ```ts
  export type PopoverPosition = 'top' | 'bottom' | 'left' | 'right' | 'bottom-end';
  ```
- `ProgressBarSize` (`primitifs/progress-bar/progress-bar.ts`)
  ```ts
  export type ProgressBarSize = 'tiny' | 'sm' | 'md' | 'lg';
  ```
- `ProgressBarStatus` (`primitifs/progress-bar/progress-bar.ts`)
  ```ts
  export type ProgressBarStatus = 'information' | 'success' | 'warning' | 'error';
  ```
- `IconComponent` (`primitifs/side-navigation/navigation-presets.ts`) — A reference to an icon COMPONENT CLASS (e.g. `LucideHouse` itself, not an instance) — the Angular equivalent of React storing a rendered `<House />` element di…
  ```ts
  export type IconComponent = Type<unknown>;
  ```
- `NavigationPreset` (`primitifs/side-navigation/navigation-presets.ts`)
  ```ts
  export interface NavigationPreset { title: string; sections: SideNavSectionData[]; actionSection?: { title: string; items: SideNavActionData[] }; }
  ```
- `NavigationProduct` (`primitifs/side-navigation/navigation-presets.ts`)
  ```ts
  export type NavigationProduct = 'workspace' | 'job' | 'workflow' | 'perfs' | 'doc' | 'payroll';
  ```
- `SideNavActionData` (`primitifs/side-navigation/navigation-presets.ts`)
  ```ts
  export interface SideNavActionData { id: string; label: string; icon: IconComponent; /** Matches React `SideNavAction`'s own `onClick?: () => void`. */ onClick?: () => void; }
  ```
- `SideNavItemData` (`primitifs/side-navigation/navigation-presets.ts`)
  ```ts
  export interface SideNavItemData { id: string; label: string; icon: IconComponent; /** Called in addition to the component's own `select` output whenever this item is clicked — * matches React `SideNavItem`'s own `onClick?: () => void`. None of the built-in presets above * set one (consistent with React's presets), but a consumer-supplied item can. */ onClick?: () => void; }
  ```
- `SideNavSectionData` (`primitifs/side-navigation/navigation-presets.ts`)
  ```ts
  export interface SideNavSectionData { title: string; items: SideNavItemData[]; }
  ```
- `StepperItemData` (`primitifs/stepper/stepper.ts`)
  ```ts
  export interface StepperItemData { label: string; status: StepperItemStatus; }
  ```
- `StepperItemStatus` (`primitifs/stepper/stepper.ts`)
  ```ts
  export type StepperItemStatus = 'completed' | 'current' | 'upcoming';
  ```
- `StepperOrientation` (`primitifs/stepper/stepper.ts`)
  ```ts
  export type StepperOrientation = 'horizontal' | 'vertical';
  ```
- `SwitchSize` (`primitifs/switch/switch.ts`)
  ```ts
  export type SwitchSize = 'sm' | 'md' | 'lg';
  ```
- `TabItem` (`primitifs/tabs/tabs.ts`)
  ```ts
  export interface TabItem { id: string; label: string; /** React's `icon?: ReactNode` — a per-item piece of arbitrary content embedded in a plain data * array, not a component's own content-projection slot. Angular's equivalent for "renderable * content living inside a data value" is a `TemplateRef`, not a plain input — the consumer * defines it with `<ng-template #tpl>...</ng-template>` in their own component and puts the * resulting `TemplateRef` in this field, same idea as Angular Material's own table cell * templates. */ icon?: TemplateRef<void>; disabled?: boolean; }
  ```
- `TabsVariant` (`primitifs/tabs/tabs.ts`)
  ```ts
  export type TabsVariant = 'underline' | 'pill';
  ```
- `TagColor` (`primitifs/tag/tag.ts`)
  ```ts
  export type TagColor = 'success' | 'warning' | 'error' | 'information' | 'purple' | 'orange';
  ```
- `TagSize` (`primitifs/tag/tag.ts`)
  ```ts
  export type TagSize = 'sm' | 'lg';
  ```
- `TooltipMessageStatus` (`primitifs/tooltip/tooltip.ts`)
  ```ts
  export type TooltipMessageStatus = 'success' | 'error' | 'warning' | 'info';
  ```
- `TooltipPosition` (`primitifs/tooltip/tooltip.ts`)
  ```ts
  export type TooltipPosition = 'top' | 'bottom' | 'left' | 'right';
  ```
- `TooltipVariant` (`primitifs/tooltip/tooltip.ts`)
  ```ts
  export type TooltipVariant = 'default' | 'extend' | 'message';
  ```
- `AppShellHeaderUser` (`templates/app-shell/app-shell.ts`)
  ```ts
  export interface AppShellHeaderUser { name: string; email: string; /** Initials shown in the avatar circle — 2 characters max. */ avatarLabel: string; }
  ```
- `AppShellProduct` (`templates/app-shell/app-shell.ts`)
  ```ts
  export type AppShellProduct = NavigationProduct;
  ```
- `Person` (`templates/stories-shared.ts`) — Shared fixtures for the template stories (not part of the public API).
  ```ts
  export interface Person { id: string; name: string; firstName: string; email: string; role: string; status: 'Actif' | 'Inactif'; }
  ```
