import * as i0 from "@angular/core";
/** Tags de la ligne (offre : `soc-tag` du kit ou `soc-labs-tag`), alignés à droite. */
export declare class SocLabsOptionRowTags {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsOptionRowTags, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocLabsOptionRowTags, "[socLabsOptionRowTags]", never, {}, {}, never, never, true, never>;
}
/**
 * ## Rôle
 * Ligne d'une **liste d'options activables** (fonctionnalités d'un client, réglages) : interrupteur du kit,
 * libellé cliquable (ouvre un détail : `(labelClick)`), description sur **une ligne** (tronquée par « … »),
 * tags à droite (slot `socLabsOptionRowTags`) et badge « Nouveau » (`isNew`).
 *
 * ## Sous-options
 * Des `soc-labs-option-row` projetées dans une ligne forment une liste imbriquée, en retrait sous leur parent
 * (filet à gauche). Le parent ne pilote pas leurs états : c'est au consommateur de passer `disabled` aux
 * sous-options tant que le parent est coupé, avec `disabledReason` (« Activez d'abord … »), affichée sous la
 * description.
 *
 * ## Confirmation dans la ligne (`confirmMessage`)
 * Si `confirmMessage` est fourni, **activer** l'option ne la change pas tout de suite : l'interrupteur passe
 * à « activé » en attente et une zone de confirmation s'ouvre sous la ligne (message + « Confirmer » /
 * « Annuler »), sans modale. Le focus va sur « Confirmer ». Confirmer : `checked` passe à `true` (émis par
 * `checkedChange`). Annuler (ou Échap dans la zone) : l'interrupteur revient à « désactivé », rien n'est
 * émis. Dans les deux cas, le focus revient sur l'interrupteur. Désactiver ne demande jamais de confirmation.
 *
 * ## Accessibilité
 * Hôte `role="listitem"` : placer les lignes dans un conteneur `role="list"` (les sous-options y sont déjà).
 * L'interrupteur (`role="switch"` du kit) est nommé par le libellé de l'option — le libellé de `soc-switch`
 * est masqué visuellement, le libellé visible étant un bouton (`aria-haspopup="dialog"`). La description
 * tronquée reste lue en entier. La zone de confirmation est un `role="group"` nommé par son message.
 * `data-state` sur l'hôte : `on` | `off` | `confirming` | `disabled`.
 */
export declare class SocLabsOptionRow {
    readonly label: import("@angular/core").InputSignal<string>;
    readonly description: import("@angular/core").InputSignal<string | undefined>;
    /** Option activée (↔). Avec `confirmMessage`, ne passe à `true` qu'après « Confirmer ». */
    readonly checked: import("@angular/core").ModelSignal<boolean>;
    readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /** Pourquoi l'option est désactivée (« Activez d'abord … »), affiché sous la description. */
    readonly disabledReason: import("@angular/core").InputSignal<string | undefined>;
    /** Badge « Nouveau » (tag `information` du kit, 5,9:1). */
    readonly isNew: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly newLabel: import("@angular/core").InputSignal<string>;
    /** Message de la confirmation dans la ligne avant activation ; absent = activation directe. */
    readonly confirmMessage: import("@angular/core").InputSignal<string | undefined>;
    readonly confirmLabel: import("@angular/core").InputSignal<string>;
    readonly cancelLabel: import("@angular/core").InputSignal<string>;
    /** Clic sur le libellé (ouvrir un panneau de détail). */
    readonly labelClick: import("@angular/core").OutputEmitterRef<void>;
    protected readonly switchId: string;
    protected readonly confirmMessageId: string;
    protected readonly labelClass = "self-start rounded-[var(--bridges-shape-figure-radius-sm)] text-left text-[length:var(--bridges-size-text-text-size-sm)] text-[var(--bridges-color-text-primary)] [font-family:var(--bridges-shape-text-body-font)] [font-weight:var(--bridges-shape-text-label-weight)] hover:text-[var(--bridges-color-text-action)] hover:underline outline-none focus-visible:outline-solid focus-visible:outline-[length:var(--bridges-shape-line-thick)] focus-visible:outline-offset-[length:var(--bridges-position-gap-xs)] focus-visible:outline-[var(--bridges-color-border-focus)]";
    /** État affiché par l'interrupteur : suit `checked`, sauf pendant une confirmation (activé en attente). */
    protected readonly switchOn: import("@angular/core").WritableSignal<boolean>;
    protected readonly confirming: import("@angular/core").WritableSignal<boolean>;
    private readonly tags;
    private readonly children;
    protected readonly hasTags: import("@angular/core").Signal<boolean>;
    protected readonly hasChildren: import("@angular/core").Signal<boolean>;
    protected readonly state: import("@angular/core").Signal<"disabled" | "confirming" | "on" | "off">;
    private readonly host;
    private readonly injector;
    protected onToggle(on: boolean): void;
    protected confirm(): void;
    protected cancelConfirm(): void;
    private focusAfterRender;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsOptionRow, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocLabsOptionRow, "soc-labs-option-row", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "disabledReason": { "alias": "disabledReason"; "required": false; "isSignal": true; }; "isNew": { "alias": "isNew"; "required": false; "isSignal": true; }; "newLabel": { "alias": "newLabel"; "required": false; "isSignal": true; }; "confirmMessage": { "alias": "confirmMessage"; "required": false; "isSignal": true; }; "confirmLabel": { "alias": "confirmLabel"; "required": false; "isSignal": true; }; "cancelLabel": { "alias": "cancelLabel"; "required": false; "isSignal": true; }; }, { "checked": "checkedChange"; "labelClick": "labelClick"; }, ["tags", "children"], ["[socLabsOptionRowTags]", "*"], true, never>;
}
