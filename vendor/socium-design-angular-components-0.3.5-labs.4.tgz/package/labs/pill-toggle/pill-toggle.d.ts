import { SocLabsFormControl } from '../internal/form-control';
import * as i0 from "@angular/core";
/** Accent of the kit (`--bridges-color-accent-*`) used when the option is selected; `gray` = neutral. */
export type LabsPillColor = 'blue' | 'green' | 'gray' | 'amber' | 'red' | 'indigo' | 'purple' | 'orange';
export type LabsPillToggleSize = 'sm' | 'md';
export interface LabsPillOption<T = string> {
    value: T;
    label: string;
    /** Couleur de la pastille sélectionnée (défaut `blue`). */
    color?: LabsPillColor;
    disabled?: boolean;
}
/**
 * ## Rôle
 * Bascule en pastilles, **choix unique** parmi 2 à 4 options courtes et immédiates : statut
 * (Actif / Inactif / Archivé), opérateur logique (ET / OU) d'une population.
 *
 * ## Accessibilité
 * `role="radiogroup"` (nommé par `ariaLabel`) contenant des `role="radio"` ; tabulation itinérante
 * (une seule pastille dans l'ordre de tabulation) ; ← → ↑ ↓ déplacent le focus **et** la sélection,
 * Origine / Fin vont aux extrémités ; les options désactivées sont sautées.
 *
 * Champ de formulaire (`formControl`, `formControlName`, `ngModel`) ; la valeur est `value` (↔).
 * La couleur est propre à chaque option (`color`, tokens `--bridges-color-accent-*`).
 */
export declare class SocLabsPillToggle<T = string> extends SocLabsFormControl<T | null> {
    readonly options: import("@angular/core").InputSignal<LabsPillOption<T>[]>;
    readonly value: import("@angular/core").ModelSignal<T | null>;
    readonly size: import("@angular/core").InputSignal<LabsPillToggleSize>;
    /** Nom accessible du groupe (ex. « Statut »). */
    readonly ariaLabel: import("@angular/core").InputSignal<string | undefined>;
    protected readonly valueModel: import("@angular/core").ModelSignal<T | null>;
    private readonly pills;
    /** Index of the only pill in the tab order: the selected one, else the first enabled one. */
    protected readonly tabStop: import("@angular/core").Signal<number>;
    protected coerce(value: unknown): T | null;
    protected isSelected(option: LabsPillOption<T>): boolean;
    protected select(option: LabsPillOption<T>): void;
    protected onKeydown(event: KeyboardEvent, index: number): void;
    protected pillClasses(option: LabsPillOption<T>): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsPillToggle<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocLabsPillToggle<any>, "soc-labs-pill-toggle", never, { "options": { "alias": "options"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}
