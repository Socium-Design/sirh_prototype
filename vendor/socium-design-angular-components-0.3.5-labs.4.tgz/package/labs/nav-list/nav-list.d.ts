import { type AppIconName } from '@socium-design/angular-components';
import * as i0 from "@angular/core";
export interface LabsNavListItem {
    id: string;
    label: string;
    /** Compteur affiché à droite (« 4 / 23 »). */
    count?: string;
    /** Compteur lu par les lecteurs d'écran à la place de `count` (« 4 activées sur 23 »). */
    countLabel?: string;
    /** Icône de produit du kit (`soc-app-icon-glyph`, la même que dans l'AppSwitch), décorative. */
    icon?: AppIconName;
}
/**
 * ## Rôle
 * Navigation **verticale** d'une colonne de filtre, dans la page : une entrée par catégorie (produit…), avec un
 * compteur à droite et, en option, l'icône du produit (`icon` : glyphe de l'AppSwitch du kit, à gauche du libellé ; dès
 * qu'une entrée en a une, les entrées sans icône gardent la place vide pour aligner les libellés). L'entrée courante est surlignée (fond `surface-selected`, texte action en demi-gras).
 * Diffère de `soc-tabs` (horizontal, sans compteur) et de `soc-side-navigation` (menu du shell, presets).
 *
 * ## Accessibilité
 * `<nav>` nommée par `ariaLabel`, liste de `<button>` ; icônes décoratives (`aria-hidden`) ; l'entrée courante porte `aria-current="true"`. Le compteur
 * visuel est masqué aux lecteurs d'écran quand `countLabel` est fourni, qui est lu à sa place. Tab parcourt
 * les entrées, Entrée / Espace sélectionne ; focus visible.
 */
export declare class SocLabsNavList {
    readonly items: import("@angular/core").InputSignal<LabsNavListItem[]>;
    /** Id de l'entrée courante (↔). */
    readonly value: import("@angular/core").ModelSignal<string>;
    readonly ariaLabel: import("@angular/core").InputSignal<string>;
    protected readonly withIcons: import("@angular/core").Signal<boolean>;
    /** Compteur : `text-secondary` tomberait à 4,1:1 sur `surface-selected` — l'entrée courante le passe en `text-action`. */
    protected countClass(current: boolean): string;
    protected itemClass(current: boolean): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsNavList, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocLabsNavList, "soc-labs-nav-list", never, { "items": { "alias": "items"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": true; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}
