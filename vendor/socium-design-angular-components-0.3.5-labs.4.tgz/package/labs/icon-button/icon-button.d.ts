import { type TooltipPosition } from '@socium-design/angular-components';
import * as i0 from "@angular/core";
export type LabsIconButtonSize = 'xs' | 'sm' | 'md';
export type LabsIconButtonVariant = 'ghost' | 'primary-subtle';
export type LabsIconButtonShape = 'square' | 'round';
/**
 * ## Rôle
 * Bouton icône compact pour les barres d'outils denses (lignes de liste, en-têtes de panneau,
 * cartes en composition) — là où `button[socButton]` (32px minimum) est trop haut.
 *
 * ## Accessibilité
 * - `ariaLabel` est **obligatoire** (input requis : le build échoue sans lui) — un bouton sans texte
 *   visible n'a pas d'autre nom accessible.
 * - `ariaExpanded` / `ariaControls` (optionnels) : bouton de divulgation (ex. replier un panneau).
 * - `tooltip` (optionnel) affiche une info-bulle du kit (`soc-tooltip`) au survol et au focus.
 *
 * ## Écart avec la convention du kit (GAP-DECISION)
 * Composant élément (`soc-labs-icon-button`) qui contient le `<button>`, et non un sélecteur
 * d'attribut : c'est ce qui permet de rendre `ariaLabel` obligatoire et d'envelopper le bouton dans
 * l'info-bulle. Le `(click)` natif du bouton remonte jusqu'à l'hôte : `(click)` s'écoute directement
 * sur `<soc-labs-icon-button>` (un bouton désactivé n'émet pas de clic).
 *
 * L'icône est projetée (contenu par défaut) : `<svg lucidePlus class="size-full">`.
 */
export declare class SocLabsIconButton {
    /** Nom accessible du bouton (obligatoire). */
    readonly ariaLabel: import("@angular/core").InputSignal<string>;
    readonly size: import("@angular/core").InputSignal<LabsIconButtonSize>;
    readonly variant: import("@angular/core").InputSignal<LabsIconButtonVariant>;
    readonly shape: import("@angular/core").InputSignal<LabsIconButtonShape>;
    /** Texte de l'info-bulle ; absent = pas d'info-bulle. */
    readonly tooltip: import("@angular/core").InputSignal<string | undefined>;
    readonly tooltipPosition: import("@angular/core").InputSignal<TooltipPosition>;
    readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly type: import("@angular/core").InputSignal<"button" | "submit" | "reset">;
    /** Bouton bascule : `true`/`false` posent `aria-pressed` ; absent = bouton simple. */
    readonly pressed: import("@angular/core").InputSignal<boolean | undefined>;
    /** Bouton de divulgation (repli d'un panneau…) : `true`/`false` posent `aria-expanded` ; absent = rien. */
    readonly ariaExpanded: import("@angular/core").InputSignal<boolean | undefined>;
    /** `id` de l'élément contrôlé (`aria-controls`), avec `ariaExpanded`. */
    readonly ariaControls: import("@angular/core").InputSignal<string | undefined>;
    protected readonly buttonClasses: import("@angular/core").Signal<string>;
    protected readonly iconClasses: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsIconButton, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocLabsIconButton, "soc-labs-icon-button", never, { "ariaLabel": { "alias": "ariaLabel"; "required": true; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "shape": { "alias": "shape"; "required": false; "isSignal": true; }; "tooltip": { "alias": "tooltip"; "required": false; "isSignal": true; }; "tooltipPosition": { "alias": "tooltipPosition"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "pressed": { "alias": "pressed"; "required": false; "isSignal": true; }; "ariaExpanded": { "alias": "ariaExpanded"; "required": false; "isSignal": true; }; "ariaControls": { "alias": "ariaControls"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
