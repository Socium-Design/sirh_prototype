import * as i0 from "@angular/core";
export type LabsDropZoneVariant = 'empty' | 'slot';
/**
 * ## Rôle
 * Zone de dépôt, **cliquable** (le clic reste le chemin principal, le glisser un raccourci) :
 * - `empty` : grand cadre pointillé avec une icône + et un texte — section ou liste vide ;
 * - `slot` : emplacement compact « + Ajouter… » en bas d'une liste ;
 * - état **survol de dépôt** (`data-state="over"`) : contour pointillé bleu et léger fond bleu.
 *
 * ## Glisser-déposer (`@angular/cdk/drag-drop`)
 * Poser `cdkDropList` sur `<soc-labs-drop-zone>` : le composant écoute ses événements `entered` /
 * `exited` / `dropped` et passe seul à l'état « survol de dépôt » ; le placeholder du CDK est masqué
 * à l'intérieur de la zone. Sans CDK (ou pour un autre mécanisme), forcer l'état avec `active`.
 *
 * ## Accessibilité
 * Un vrai `<button>` (texte visible = nom accessible) ; `(activate)` est émis au clic, à Entrée et à
 * Espace. `disabled` désactive le bouton et l'état de survol.
 */
export declare class SocLabsDropZone {
    readonly variant: import("@angular/core").InputSignal<LabsDropZoneVariant>;
    /** Texte de la zone ; défaut selon la variante. */
    readonly label: import("@angular/core").InputSignal<string | undefined>;
    /** Texte secondaire (variante `empty`). */
    readonly hint: import("@angular/core").InputSignal<string | undefined>;
    /** Force l'état « survol de dépôt » (sans CDK, ou glisser natif). */
    readonly active: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /** Clic, Entrée ou Espace sur la zone. */
    readonly activate: import("@angular/core").OutputEmitterRef<void>;
    private readonly cdkOver;
    protected readonly isOver: import("@angular/core").Signal<boolean>;
    protected readonly text: import("@angular/core").Signal<string>;
    constructor();
    protected readonly buttonClasses: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsDropZone, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocLabsDropZone, "soc-labs-drop-zone", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; "active": { "alias": "active"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "activate": "activate"; }, never, never, true, never>;
}
