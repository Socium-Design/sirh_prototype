import { type ButtonSize } from '@socium-design/angular-components';
import * as i0 from "@angular/core";
/** Only the variant the kit's `ButtonVariant` lacks; the other five stay on `button[socButton]`. */
export type LabsButtonVariant = 'primary-subtle';
/**
 * ## Rôle
 * Bouton à texte **teinté** (fond bleu clair, texte et icône bleus) : action secondaire mise en
 * avant sans le poids d'un bouton `primary`, typiquement répétée sur chaque ligne d'une liste
 * (« Visualiser »). Aucune des 5 variantes de `button[socButton]` ne la couvre : `secondary` est
 * gris, `ghost` transparent, `primary` plein.
 *
 * Même gabarit que `button[socButton]` (paddings, rayon, typographie et taille d'icône du kit, tailles
 * `sm`/`lg`), mêmes emplacements d'icône (`socButtonLeftIcon` / `socButtonRightIcon` du kit) ; seule
 * la couleur change. Sélecteur d'attribut sur un vrai `<button>` (convention du kit) : `type`,
 * `[disabled]`, `(click)`, `aria-*` sont natifs.
 *
 * ```html
 * <button socLabsButton (click)="visualiser(row)">
 *   <svg lucideLayoutGrid socButtonLeftIcon class="size-full" [strokeWidth]="1.5"></svg>
 *   Visualiser
 * </button>
 * ```
 *
 * ## Accessibilité
 * Anneau de focus visible au clavier (`focus-visible`, couleur de focus du kit). Contraste : texte
 * `text-action` sur `accent-blue-bg`.
 */
export declare class SocLabsButton {
    readonly variant: import("@angular/core").InputSignal<"primary-subtle">;
    readonly size: import("@angular/core").InputSignal<ButtonSize>;
    protected readonly iconSize = "var(--index-button-button-icon-size)";
    private readonly leftIconContent;
    private readonly rightIconContent;
    protected readonly hasLeftIcon: import("@angular/core").Signal<boolean>;
    protected readonly hasRightIcon: import("@angular/core").Signal<boolean>;
    protected readonly hostClasses: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsButton, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocLabsButton, "button[socLabsButton]", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, {}, ["leftIconContent", "rightIconContent"], ["[socButtonLeftIcon]", "*", "[socButtonRightIcon]"], true, never>;
}
