import * as i0 from "@angular/core";
/**
 * ## Rôle
 * Barre **fixe en bas** de la zone de contenu pour une page qui n'applique pas ses changements tout de suite
 * (page de réglages) : « N modifications non enregistrées », « Annuler », « Enregistrer ». Après
 * l'enregistrement, `saved` affiche « Enregistré ✓ » à la place, sans boutons.
 *
 * ## Visibilité
 * Rendue seulement quand `count > 0` ou `saved` : rien à afficher sinon (l'hôte est vide). C'est le parent
 * qui remet `saved` à `false` (après quelques secondes, ou à la modification suivante).
 *
 * ## Mise en page
 * `position: sticky; bottom: 0` : placer `soc-labs-changes-bar` en **dernier enfant** du conteneur qui défile
 * (la zone de contenu du shell) — elle reste visible en bas pendant le défilement et ne masque jamais la fin
 * du contenu. Fond blanc, filet en haut. Les templates de page du kit (`soc-page-list`, `soc-page-details`…) donnent à
 * ce conteneur un padding-bottom fixe de 120px, qui réduit la zone de collage : `insetBottom` (120px par défaut) le
 * compense pour que la barre touche le bas de l'écran. Hors de ces templates, passer `insetBottom="0px"`.
 *
 * ## Accessibilité
 * `role="region"` nommée (`ariaLabel`, « Modifications non enregistrées » par défaut). Le message est dans une
 * zone `aria-live="polite"` toujours présente (masquée visuellement, hors de la barre qui apparaît et disparaît) : le nombre de modifications puis « Enregistré » sont annoncés sans déplacer le
 * focus. Boutons du kit (`secondary` / `primary`).
 */
export declare class SocLabsChangesBar {
    /** Nombre de modifications non enregistrées. */
    readonly count: import("@angular/core").InputSignal<number>;
    /** Affiche « Enregistré ✓ » (prioritaire sur `count`). */
    readonly saved: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /** Désactive « Enregistrer » pendant l'enregistrement. */
    readonly saving: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly saveLabel: import("@angular/core").InputSignal<string>;
    readonly cancelLabel: import("@angular/core").InputSignal<string>;
    readonly savedLabel: import("@angular/core").InputSignal<string>;
    readonly ariaLabel: import("@angular/core").InputSignal<string>;
    /** Padding-bottom du conteneur qui défile, à compenser (120px fixes dans les templates `soc-page-*` du kit). */
    readonly insetBottom: import("@angular/core").InputSignal<string>;
    /** Remplace le message par défaut (« 1 modification non enregistrée », « N modifications non enregistrées »). */
    readonly label: import("@angular/core").InputSignal<string | undefined>;
    readonly save: import("@angular/core").OutputEmitterRef<void>;
    readonly cancel: import("@angular/core").OutputEmitterRef<void>;
    protected readonly state: import("@angular/core").Signal<"saved" | "dirty" | "idle">;
    protected readonly message: import("@angular/core").Signal<string>;
    protected readonly announcement: import("@angular/core").Signal<string>;
    protected readonly barClass: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsChangesBar, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocLabsChangesBar, "soc-labs-changes-bar", never, { "count": { "alias": "count"; "required": false; "isSignal": true; }; "saved": { "alias": "saved"; "required": false; "isSignal": true; }; "saving": { "alias": "saving"; "required": false; "isSignal": true; }; "saveLabel": { "alias": "saveLabel"; "required": false; "isSignal": true; }; "cancelLabel": { "alias": "cancelLabel"; "required": false; "isSignal": true; }; "savedLabel": { "alias": "savedLabel"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "insetBottom": { "alias": "insetBottom"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, { "save": "save"; "cancel": "cancel"; }, never, never, true, never>;
}
