import * as i0 from "@angular/core";
/** Icône à gauche du titre (≈ 28 px, pastille du kit). Optionnel. */
export declare class SocLabsWidgetCardIcon {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsWidgetCardIcon, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocLabsWidgetCardIcon, "[socLabsWidgetCardIcon]", never, {}, {}, never, never, true, never>;
}
/** Actions à droite du titre (menu, bouton…), alignées en haut, jamais rétrécies. */
export declare class SocLabsWidgetCardActions {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsWidgetCardActions, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocLabsWidgetCardActions, "[socLabsWidgetCardActions]", never, {}, {}, never, never, true, never>;
}
/**
 * Rangée de filtres sous le titre / la description, au-dessus du corps : les contrôles passent à la
 * ligne suivante plutôt que de déborder.
 */
export declare class SocLabsWidgetCardFilters {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsWidgetCardFilters, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocLabsWidgetCardFilters, "[socLabsWidgetCardFilters]", never, {}, {}, never, never, true, never>;
}
/** Pied de carte (hauteur automatique), sous le corps. Optionnel. */
export declare class SocLabsWidgetCardFooter {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsWidgetCardFooter, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocLabsWidgetCardFooter, "[socLabsWidgetCardFooter]", never, {}, {}, never, never, true, never>;
}
/**
 * ## Rôle
 * Carte d'un **widget de tableau de bord** (indicateur ou graphique) pour les grilles denses. Diffère
 * de `soc-card` du kit : titre sur plusieurs lignes (`titleLines`, 2 par défaut) puis « … », pied de
 * hauteur automatique, rangée de filtres, et aucun débordement horizontal.
 *
 * ## Slots
 * - `socLabsWidgetCardIcon` (optionnel) : icône à gauche du titre, dans la pastille du kit (28 px).
 * - `socLabsWidgetCardActions` (optionnel) : à droite du titre, alignées en haut, jamais rétrécies.
 * - `socLabsWidgetCardFilters` (optionnel) : rangée `flex-wrap` sous le titre et la description.
 * - contenu sans marqueur : le **corps** (valeur d'indicateur, graphique) — `flex-1`, `min-w-0`.
 * - `socLabsWidgetCardFooter` (optionnel) : pied, hauteur automatique.
 * Chaque région n'est rendue que si son slot est présent (`data-region` sur chacune).
 *
 * ## Mise en page
 * L'hôte est une colonne `flex h-full min-w-0` avec la surface de carte du kit (tokens
 * `--index-conteneur-card-*`) : dans une grille CSS, toutes les cartes d'une rangée prennent la même
 * hauteur et grandissent avec leur contenu. Rien ne déborde horizontalement (`min-w-0` partout).
 *
 * ## Typographie
 * Titre 13 px (dérivé : moyenne des tailles `xs` et `sm`), demi-gras
 * (`--bridges-shape-text-heading-2-weight`), couleur primaire, tronqué à `titleLines` lignes ; le titre
 * complet est dans l'attribut `title`. Description 12 px, couleur secondaire, tronquée à
 * `descriptionLines` lignes.
 *
 * ## Accessibilité
 * L'hôte porte `role="group"` et `aria-label` = titre. Le titre est un `<p>` (pas de niveau de titre
 * imposé : la page décide de sa hiérarchie).
 */
export declare class SocLabsWidgetCard {
    readonly title: import("@angular/core").InputSignal<string>;
    readonly description: import("@angular/core").InputSignal<string | undefined>;
    /** Nombre de lignes du titre avant « … ». */
    readonly titleLines: import("@angular/core").InputSignal<number>;
    /** Nombre de lignes de la description avant « … ». */
    readonly descriptionLines: import("@angular/core").InputSignal<number>;
    private readonly icon;
    private readonly actions;
    private readonly filters;
    private readonly footer;
    protected readonly hasIcon: import("@angular/core").Signal<boolean>;
    protected readonly hasActions: import("@angular/core").Signal<boolean>;
    protected readonly hasFilters: import("@angular/core").Signal<boolean>;
    protected readonly hasFooter: import("@angular/core").Signal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsWidgetCard, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocLabsWidgetCard, "soc-labs-widget-card", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "titleLines": { "alias": "titleLines"; "required": false; "isSignal": true; }; "descriptionLines": { "alias": "descriptionLines"; "required": false; "isSignal": true; }; }, {}, ["icon", "actions", "filters", "footer"], ["[socLabsWidgetCardIcon]", "[socLabsWidgetCardActions]", "[socLabsWidgetCardFilters]", "*", "[socLabsWidgetCardFooter]"], true, never>;
}
