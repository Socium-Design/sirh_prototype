import { SocLabsFormControl } from '../internal/form-control';
import * as i0 from "@angular/core";
export type LabsCompactFieldMode = 'read' | 'edit';
export type LabsCompactFieldControl = 'text' | 'textarea' | 'select';
export type LabsCompactFieldSize = 'md' | 'sm';
export interface LabsCompactFieldOption {
    value: string;
    label: string;
}
/**
 * ## Rôle
 * Champ **compact pour panneau latéral** (≥ 220 px) : libellé en petites capitales, puis la valeur
 * — en lecture (texte) ou en édition (champ texte, zone multiligne ou liste déroulante native, 28 px
 * de haut). Un séparateur fin sous chaque champ (`separator`, actif par défaut) rythme le panneau.
 *
 * ## Taille (`size`)
 * - **`md`** (défaut) : valeur et contrôles en 14 px, contrôles de 28 px de haut.
 * - **`sm`** : panneaux denses — valeur et contrôles (texte, zone multiligne, liste, lecture) en 12 px,
 *   contrôles de 24 px de haut (icône `lg` du kit), chevron 12 px, espacements réduits. Le libellé reste
 *   en petites capitales 10 px dans les deux tailles.
 * L'hôte expose `data-size` (`md` | `sm`).
 *
 * Même composant pour « Détail » et « Modifier » : on bascule `mode` sans changer la mise en page.
 *
 * Champ de formulaire (`formControl`, `formControlName`, `ngModel`) ; valeur `value` (↔, chaîne).
 * En lecture, une liste affiche le libellé de l'option, une valeur vide affiche `emptyText`.
 */
export declare class SocLabsCompactField extends SocLabsFormControl<string> {
    readonly label: import("@angular/core").InputSignal<string>;
    readonly mode: import("@angular/core").InputSignal<LabsCompactFieldMode>;
    readonly control: import("@angular/core").InputSignal<LabsCompactFieldControl>;
    readonly value: import("@angular/core").ModelSignal<string>;
    /** Options de la liste déroulante (`control="select"`). */
    readonly options: import("@angular/core").InputSignal<LabsCompactFieldOption[]>;
    readonly placeholder: import("@angular/core").InputSignal<string | undefined>;
    /** Texte affiché en lecture quand la valeur est vide. */
    readonly emptyText: import("@angular/core").InputSignal<string>;
    readonly rows: import("@angular/core").InputSignal<number>;
    readonly separator: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /** Id du contrôle natif (sinon généré). */
    readonly id: import("@angular/core").InputSignal<string | undefined>;
    /** `md` (défaut, 14 px) ou `sm` (12 px, contrôles de 24 px) pour les panneaux denses. */
    readonly size: import("@angular/core").InputSignal<LabsCompactFieldSize>;
    protected readonly valueModel: import("@angular/core").ModelSignal<string>;
    protected readonly labelClass = "uppercase tracking-wider [font-family:var(--bridges-shape-text-label-font)] [font-weight:var(--bridges-shape-text-label-weight)] text-[length:var(--bridges-size-text-text-size-tiny)] text-[var(--bridges-color-text-secondary)]";
    private readonly sz;
    protected readonly inputClass: import("@angular/core").Signal<string>;
    protected readonly selectClass: import("@angular/core").Signal<string>;
    protected readonly textareaClass: import("@angular/core").Signal<string>;
    protected readonly chevronClass: import("@angular/core").Signal<string>;
    protected readonly readClass: import("@angular/core").Signal<string>;
    private readonly generatedId;
    protected readonly controlId: import("@angular/core").Signal<string>;
    protected readonly selectedOption: import("@angular/core").Signal<LabsCompactFieldOption | undefined>;
    protected readonly readText: import("@angular/core").Signal<{
        text: string;
        empty: boolean;
    }>;
    protected readonly hostClasses: import("@angular/core").Signal<string>;
    protected coerce(value: unknown): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsCompactField, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocLabsCompactField, "soc-labs-compact-field", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "control": { "alias": "control"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "emptyText": { "alias": "emptyText"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "separator": { "alias": "separator"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}
