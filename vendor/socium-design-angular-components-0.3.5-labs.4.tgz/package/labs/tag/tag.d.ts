import type { TagColor, TagSize } from '@socium-design/angular-components';
import * as i0 from "@angular/core";
/** Couleurs de `soc-tag` du kit, plus `neutral` (#68). */
export type LabsTagColor = TagColor | 'neutral';
/**
 * ## Rôle
 * `soc-tag` du kit avec un ton **neutre** en plus (`color="neutral"`) : une étiquette qui ne doit ni attirer
 * l'attention ni passer pour un état (offre « Standard » à côté de « Payant » et « Customisation client »).
 * Même gabarit que `soc-tag` (tokens `--index-feedback-tag-*` : rayon, paddings, police) ; les autres couleurs
 * reprennent exactement celles du kit, pour aligner des tags neutres et colorés sans écart visuel.
 *
 * ## Contraste
 * Neutre : `text-primary` sur `background-layer-1` (9,4:1). Attention : `warning` du kit est à 2,9:1 (texte
 * `#e17100` sur `#fef3c6`) — préférer `orange` (6,3:1) pour un ton « attention » sur du texte.
 *
 * ## Accessibilité
 * Texte simple, sans rôle : la couleur ne porte jamais seule l'information, le libellé reste lisible.
 */
export declare class SocLabsTag {
    readonly color: import("@angular/core").InputSignal<LabsTagColor>;
    readonly size: import("@angular/core").InputSignal<TagSize>;
    protected readonly hostClass: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsTag, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocLabsTag, "soc-labs-tag", never, { "color": { "alias": "color"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
