import { type DataTableColumn } from '@socium-design/angular-components';
import * as i0 from "@angular/core";
/**
 * `DataTableColumn` + per-column sizing, read by `socLabsFitWidth`. Structurally a
 * `DataTableColumn`: pass it straight to `soc-data-table`'s `[columns]`.
 */
export interface LabsDataTableColumn<T> extends DataTableColumn<T> {
    /** CSS width of the column (`'30%'`, `'12rem'`, `'var(--…)'`). In an auto-layout table it is the
     * width the column gets when there is room, and the width it keeps longest when there isn't. */
    width?: string;
    /** CSS minimum width: the column never gets narrower (its text wraps first). */
    minWidth?: string;
    /** `false` keeps the column on one line (actions, dates, short codes). Default `true`: the text
     * wraps between words when the table runs out of room. */
    wrap?: boolean;
}
/**
 * ## Rôle
 * Fait tenir un `soc-data-table` (`mode="table"`) dans la largeur disponible : le `<table>` du kit
 * porte `min-w-max`, il prend toujours la largeur de son contenu et déborde (dernières colonnes,
 * dont les actions, coupées). Avec `socLabsFitWidth`, la table ne dépasse plus son conteneur : le
 * texte des cellules passe à la ligne, et chaque colonne peut recevoir une largeur, une largeur
 * minimale ou rester sur une ligne (`LabsDataTableColumn`).
 *
 * ```html
 * <soc-data-table socLabsFitWidth [columns]="columns" [rows]="rows" [rowKey]="rowKey" />
 * ```
 * ```ts
 * columns: LabsDataTableColumn<Tableau>[] = [
 *   { key: 'libelle', header: 'Libellé', render: libelleCell, minWidth: '12rem' },
 *   { key: 'actions', header: '', render: actionsCell, wrap: false },
 * ];
 * ```
 *
 * ## Fonctionnement (GAP-DECISION)
 * Directive posée sur le composant du kit, sans le modifier ni le copier : elle lit ses `columns`
 * / `rows` / `selectable` et pose, après chaque rendu, des styles en ligne sur le `<table>`
 * (`min-width: 0`, qui l'emporte sur `min-w-max`) et sur les cellules de chaque colonne. Sans
 * l'attribut, le tableau garde exactement son comportement actuel. Une table qui ne peut vraiment
 * pas tenir (somme des `minWidth` et des colonnes `wrap: false` plus large que le conteneur)
 * défile horizontalement, comme aujourd'hui.
 *
 * Sans effet sur `mode="detail"` et `mode="card"` (pas de `<table>`).
 */
export declare class SocLabsDataTableFit {
    private readonly table;
    private readonly host;
    constructor();
    private apply;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsDataTableFit, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocLabsDataTableFit, "soc-data-table[socLabsFitWidth]", never, {}, {}, never, never, true, never>;
}
