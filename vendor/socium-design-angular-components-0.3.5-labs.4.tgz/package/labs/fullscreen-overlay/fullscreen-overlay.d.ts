import * as i0 from "@angular/core";
/** Badge à côté du titre (ex. `<soc-tag socLabsOverlayBadge>Données simulées</soc-tag>`). */
export declare class SocLabsOverlayBadge {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsOverlayBadge, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocLabsOverlayBadge, "[socLabsOverlayBadge]", never, {}, {}, never, never, true, never>;
}
/**
 * ## Rôle
 * Calque **plein écran** qui recouvre toute l'application (bandeau et menu compris) : prévisualiser
 * un tableau de bord, consulter un contenu dense sans le shell. Barre du haut (titre, sous-titre,
 * badge, bouton Fermer) et contenu qui défile.
 *
 * ## Comportement et accessibilité
 * - `role="dialog"` + `aria-modal`, nommé par le titre et décrit par le sous-titre.
 * - À l'ouverture : le focus entre dans le calque, le défilement de la page est bloqué.
 * - **Piège du focus** : Tab / Maj+Tab bouclent dans le calque.
 * - **Échap** ou le bouton Fermer : `open` repasse à `false` et `(close)` est émis.
 * - À la fermeture : le focus revient à l'élément qui l'avait avant l'ouverture.
 *
 * `open` est un `model` (↔) : `[(open)]="apercu"` suit la fermeture tout seul. Rendu dans `<body>`
 * (comme `soc-dialog`), au-dessus des autres overlays du kit.
 */
export declare class SocLabsFullscreenOverlay {
    readonly open: import("@angular/core").ModelSignal<boolean>;
    readonly title: import("@angular/core").InputSignal<string>;
    readonly subtitle: import("@angular/core").InputSignal<string | undefined>;
    readonly closeLabel: import("@angular/core").InputSignal<string>;
    /** Émis à la fermeture par Échap ou par le bouton Fermer. */
    readonly close: import("@angular/core").OutputEmitterRef<void>;
    protected readonly titleId: string;
    protected readonly subtitleId: string;
    private readonly badge;
    protected readonly hasBadge: import("@angular/core").Signal<boolean>;
    private readonly panel;
    private returnFocusTo;
    private previousOverflow;
    constructor();
    protected dismiss(): void;
    protected trapFocus(event: KeyboardEvent): void;
    /** Unlocks page scroll and gives focus back (once per opening). */
    private release;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsFullscreenOverlay, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocLabsFullscreenOverlay, "soc-labs-fullscreen-overlay", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": true; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; "closeLabel": { "alias": "closeLabel"; "required": false; "isSignal": true; }; }, { "open": "openChange"; "close": "close"; }, ["badge"], ["[socLabsOverlayBadge]", "*"], true, never>;
}
