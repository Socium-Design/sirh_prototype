import * as i0 from "@angular/core";
/** Identifiants alignés sur le `TypeGraphique` du prototype SIRH (et étendus aux 9 types). */
export type LabsChartType = 'courbe' | 'aire' | 'histogramme' | 'barres-horizontales' | 'barres-empilees' | 'camembert' | 'anneau' | 'jauge' | 'kpi';
export type LabsChartTypeChipSize = 20 | 28;
/** Libellé (nom accessible par défaut) de chaque type. */
export declare const LABS_CHART_TYPE_LABELS: Record<LabsChartType, string>;
/**
 * ## Rôle
 * Pastille identifiant un **type de graphique** (catalogue d'indicateurs, cartes de composition) :
 * icône Lucide sur un fond teinté propre au type, tailles 20 et 28 px.
 *
 * ## Accessibilité
 * `role="img"` nommé par le libellé du type (`label` pour le remplacer). À côté d'un texte qui dit
 * déjà le type, passer `decorative` : la pastille est alors masquée aux technologies d'assistance.
 */
export declare class SocLabsChartTypeChip {
    readonly type: import("@angular/core").InputSignal<LabsChartType>;
    readonly size: import("@angular/core").InputSignal<LabsChartTypeChipSize>;
    /** Nom accessible ; défaut : libellé du type (`LABS_CHART_TYPE_LABELS`). */
    readonly label: import("@angular/core").InputSignal<string | undefined>;
    readonly decorative: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    protected readonly accessibleName: import("@angular/core").Signal<string>;
    protected readonly hostClasses: import("@angular/core").Signal<string>;
    protected readonly iconClass: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsChartTypeChip, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocLabsChartTypeChip, "soc-labs-chart-type-chip", never, { "type": { "alias": "type"; "required": true; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "decorative": { "alias": "decorative"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
