import * as i0 from "@angular/core";
/** The kit's accent palettes (`--bridges-color-accent-*`), plus a neutral tile. */
export type LabsIconTileColor = 'blue' | 'indigo' | 'purple' | 'orange' | 'red' | 'green' | 'amber' | 'lime' | 'neutral';
export type LabsIconTileSize = 20 | 28 | 32;
export declare const LABS_ICON_TILE_COLORS: LabsIconTileColor[];
/**
 * ## Rôle
 * Tuile carrée teintée portant une icône : repère visuel devant un libellé (nom d'un tableau de bord
 * dans une liste, entrée de catalogue…). Générique, contrairement à `soc-labs-chart-type-chip` qui
 * ne connaît que les types de graphique : l'icône est projetée et la couleur choisie parmi les
 * accents du kit.
 *
 * L'icône est le contenu par défaut : `<svg lucideLayoutGrid class="size-full">`.
 *
 * ## Accessibilité
 * Par défaut `role="img"` nommé par `label`. À côté d'un texte qui dit déjà la même chose (cas
 * courant : le nom de la ligne), passer `decorative` : la tuile est masquée aux technologies
 * d'assistance. Sans `label` ni `decorative`, la tuile est aussi traitée comme décorative (une image
 * sans nom n'apporte rien à un lecteur d'écran).
 */
export declare class SocLabsIconTile {
    readonly color: import("@angular/core").InputSignal<LabsIconTileColor>;
    readonly size: import("@angular/core").InputSignal<LabsIconTileSize>;
    /** Nom accessible ; absent = tuile décorative. */
    readonly label: import("@angular/core").InputSignal<string | undefined>;
    readonly decorative: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    protected readonly isDecorative: import("@angular/core").Signal<boolean>;
    protected readonly hostClasses: import("@angular/core").Signal<string>;
    protected readonly iconClass: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsIconTile, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocLabsIconTile, "soc-labs-icon-tile", never, { "color": { "alias": "color"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "decorative": { "alias": "decorative"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
