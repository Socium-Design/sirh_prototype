import { ModelSignal, Provider, Type } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import * as i0 from "@angular/core";
/**
 * Copy of the kit's `SocFormControl` (`src/internal/form-control.ts`), which is internal and not
 * exported by the primary entry point — a secondary entry point can only import the primary through
 * its public API. Same contract: the `model()` stays the source of truth, `writeValue` mutes the
 * change stream, `disabled` is an input OR'ed with the form's own state. On promotion to the kit, a
 * Labs component switches to the kit's base class and this file goes away.
 */
export declare function provideLabsFormControl(type: () => Type<unknown>): Provider;
export declare abstract class SocLabsFormControl<T> implements ControlValueAccessor {
    protected abstract readonly valueModel: ModelSignal<T>;
    readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    private readonly formDisabled;
    readonly isDisabled: import("@angular/core").Signal<boolean>;
    protected onTouched: () => void;
    private writing;
    private subscription?;
    protected abstract coerce(value: unknown): T;
    writeValue(value: unknown): void;
    registerOnChange(fn: (value: T) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsFormControl<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocLabsFormControl<any>, never, never, { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
