import * as i0 from "@angular/core";
/** Barre du haut, à gauche : bouton retour (ex. `soc-labs-icon-button` avec une flèche). */
export declare class SocLabsWorkspaceBack {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsWorkspaceBack, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocLabsWorkspaceBack, "[socLabsWorkspaceBack]", never, {}, {}, never, never, true, never>;
}
/** Barre du haut : titre (texte, `soc-labs-inline-edit`…). */
export declare class SocLabsWorkspaceTitle {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsWorkspaceTitle, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocLabsWorkspaceTitle, "[socLabsWorkspaceTitle]", never, {}, {}, never, never, true, never>;
}
/** Barre du haut, après le titre : badge ou indication (« Brouillon », « Ajoutez des graphes → »). */
export declare class SocLabsWorkspaceHint {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsWorkspaceHint, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocLabsWorkspaceHint, "[socLabsWorkspaceHint]", never, {}, {}, never, never, true, never>;
}
/** Barre du haut, à droite : actions (Prévisualiser, Enregistrer…). */
export declare class SocLabsWorkspaceActions {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsWorkspaceActions, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocLabsWorkspaceActions, "[socLabsWorkspaceActions]", never, {}, {}, never, never, true, never>;
}
/** Panneau gauche (optionnel). */
export declare class SocLabsWorkspaceLeft {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsWorkspaceLeft, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocLabsWorkspaceLeft, "[socLabsWorkspaceLeft]", never, {}, {}, never, never, true, never>;
}
/** Panneau droit (optionnel). */
export declare class SocLabsWorkspaceRight {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsWorkspaceRight, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocLabsWorkspaceRight, "[socLabsWorkspaceRight]", never, {}, {}, never, never, true, never>;
}
/**
 * ## Rôle
 * **Espace de travail plein écran** sous le bandeau de l'application (composition d'un tableau de
 * bord) : barre du haut, panneau gauche, zone centrale sur le fond gris du kit, panneau droit.
 * Chaque colonne défile indépendamment ; les panneaux sont blancs avec une bordure.
 *
 * ## Slots (tous optionnels)
 * Barre du haut : `socLabsWorkspaceBack`, `socLabsWorkspaceTitle`, `socLabsWorkspaceHint`,
 * `socLabsWorkspaceActions` (la barre n'est rendue que si l'un d'eux est présent). Colonnes :
 * `socLabsWorkspaceLeft`, `socLabsWorkspaceRight` ; le contenu sans marqueur va au centre.
 *
 * ## Mise en page
 * L'hôte prend toute la hauteur de son parent (`h-full`) : le placer dans une zone de hauteur
 * définie (contenu de `soc-app-shell`). Largeurs des panneaux : `leftWidth` (défaut 220px) et
 * `rightWidth` (défaut 240px), toute longueur CSS.
 *
 * **Panneaux repliables** (écrans de PC portables) : `collapsibleBelow` (px, défaut `null` = jamais)
 * fixe la largeur de fenêtre sous laquelle la mise en page passe en mode « étroit » (`matchMedia`,
 * suivi en direct). En entrant dans ce mode, les deux panneaux se replient ; en le quittant, ils se
 * déplient et les boutons disparaissent. Dans ce mode, chaque panneau présent porte un bouton
 * (`soc-labs-icon-button`) : déplié, en haut du panneau ; replié, le panneau devient un rail étroit
 * (largeur dérivée des tokens) avec le bouton et son libellé écrit verticalement. L'état est exposé
 * par `leftCollapsed` / `rightCollapsed` (`model`, liables en `[(leftCollapsed)]`) ; hors mode
 * étroit, les panneaux sont toujours dépliés quelle que soit leur valeur. Chaque `<aside>` porte
 * `data-state="collapsed|expanded"`.
 *
 * Le contenu d'un panneau replié reste dans le DOM (masqué par `hidden`) : son état (saisie,
 * recherche, composants) est conservé au dépliage.
 *
 * ## Accessibilité
 * Panneaux en `<aside>` et centre en `<section>`, nommés par `leftLabel` / `rightLabel` /
 * `centerLabel`. Boutons de repli : « Replier le panneau {libellé} » / « Déplier le panneau
 * {libellé} », avec `aria-expanded` et `aria-controls` vers le contenu du panneau ; le libellé
 * vertical du rail est décoratif (`aria-hidden`), l'`<aside>` restant nommé.
 */
export declare class SocLabsWorkspaceLayout {
    /** Largeur du panneau gauche (longueur CSS). */
    readonly leftWidth: import("@angular/core").InputSignal<string>;
    /** Largeur du panneau droit (longueur CSS). */
    readonly rightWidth: import("@angular/core").InputSignal<string>;
    readonly leftLabel: import("@angular/core").InputSignal<string>;
    readonly rightLabel: import("@angular/core").InputSignal<string>;
    readonly centerLabel: import("@angular/core").InputSignal<string>;
    /**
     * Largeur de fenêtre (px) sous laquelle les panneaux deviennent repliables (mode « étroit »).
     * `null` (défaut) = jamais : panneaux toujours dépliés, aucun bouton.
     */
    readonly collapsibleBelow: import("@angular/core").InputSignal<number | null>;
    /** Panneau gauche replié (effectif seulement en mode étroit). Mis à `true` en entrant dans ce mode. */
    readonly leftCollapsed: import("@angular/core").ModelSignal<boolean>;
    /** Panneau droit replié (effectif seulement en mode étroit). Mis à `true` en entrant dans ce mode. */
    readonly rightCollapsed: import("@angular/core").ModelSignal<boolean>;
    protected readonly leftClass = "flex min-h-0 shrink-0 flex-col gap-[var(--bridges-position-gap-md)] overflow-y-auto border-[var(--bridges-color-border-subtle)] bg-[var(--bridges-color-surface-neutral-white)] p-[var(--bridges-position-padding-md)] border-r-[length:var(--bridges-shape-line-hairline)]";
    protected readonly rightClass = "flex min-h-0 shrink-0 flex-col gap-[var(--bridges-position-gap-md)] overflow-y-auto border-[var(--bridges-color-border-subtle)] bg-[var(--bridges-color-surface-neutral-white)] p-[var(--bridges-position-padding-md)] border-l-[length:var(--bridges-shape-line-hairline)]";
    protected readonly leftRailClass = "flex min-h-0 shrink-0 flex-col items-center gap-[var(--bridges-position-gap-sm)] overflow-hidden border-[var(--bridges-color-border-subtle)] bg-[var(--bridges-color-surface-neutral-white)] py-[var(--bridges-position-padding-xs)] w-[calc(var(--bridges-size-icon-lg)+2*var(--bridges-position-padding-xs)+var(--bridges-shape-line-hairline))] border-r-[length:var(--bridges-shape-line-hairline)]";
    protected readonly rightRailClass = "flex min-h-0 shrink-0 flex-col items-center gap-[var(--bridges-position-gap-sm)] overflow-hidden border-[var(--bridges-color-border-subtle)] bg-[var(--bridges-color-surface-neutral-white)] py-[var(--bridges-position-padding-xs)] w-[calc(var(--bridges-size-icon-lg)+2*var(--bridges-position-padding-xs)+var(--bridges-shape-line-hairline))] border-l-[length:var(--bridges-shape-line-hairline)]";
    protected readonly contentClass = "flex shrink-0 flex-col gap-[var(--bridges-position-gap-md)]";
    protected readonly railLabelClass = "whitespace-nowrap [writing-mode:vertical-rl] text-[length:var(--bridges-size-text-text-size-sm)] text-[var(--bridges-color-text-secondary)] [font-family:var(--bridges-shape-text-label-font)] [font-weight:var(--bridges-shape-text-label-weight)]";
    protected readonly leftContentId: string;
    protected readonly rightContentId: string;
    /** Fenêtre plus étroite que `collapsibleBelow`. */
    protected readonly narrow: import("@angular/core").WritableSignal<boolean>;
    protected readonly leftIsCollapsed: import("@angular/core").Signal<boolean>;
    protected readonly rightIsCollapsed: import("@angular/core").Signal<boolean>;
    private readonly back;
    private readonly title;
    private readonly hint;
    private readonly actions;
    private readonly left;
    private readonly right;
    protected readonly hasBack: import("@angular/core").Signal<boolean>;
    protected readonly hasTitle: import("@angular/core").Signal<boolean>;
    protected readonly hasHint: import("@angular/core").Signal<boolean>;
    protected readonly hasActions: import("@angular/core").Signal<boolean>;
    protected readonly hasLeft: import("@angular/core").Signal<boolean>;
    protected readonly hasRight: import("@angular/core").Signal<boolean>;
    protected readonly hasTopBar: import("@angular/core").Signal<boolean>;
    constructor();
    /** Entrer en mode étroit replie les deux panneaux ; en sortir les déplie. */
    private setNarrow;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsWorkspaceLayout, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocLabsWorkspaceLayout, "soc-labs-workspace-layout", never, { "leftWidth": { "alias": "leftWidth"; "required": false; "isSignal": true; }; "rightWidth": { "alias": "rightWidth"; "required": false; "isSignal": true; }; "leftLabel": { "alias": "leftLabel"; "required": false; "isSignal": true; }; "rightLabel": { "alias": "rightLabel"; "required": false; "isSignal": true; }; "centerLabel": { "alias": "centerLabel"; "required": false; "isSignal": true; }; "collapsibleBelow": { "alias": "collapsibleBelow"; "required": false; "isSignal": true; }; "leftCollapsed": { "alias": "leftCollapsed"; "required": false; "isSignal": true; }; "rightCollapsed": { "alias": "rightCollapsed"; "required": false; "isSignal": true; }; }, { "leftCollapsed": "leftCollapsedChange"; "rightCollapsed": "rightCollapsedChange"; }, ["back", "title", "hint", "actions", "left", "right"], ["[socLabsWorkspaceBack]", "[socLabsWorkspaceTitle]", "[socLabsWorkspaceHint]", "[socLabsWorkspaceActions]", "[socLabsWorkspaceLeft]", "*", "[socLabsWorkspaceRight]"], true, never>;
}
