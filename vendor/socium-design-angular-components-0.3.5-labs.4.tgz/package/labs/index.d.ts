/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@socium-design/angular-components/labs" />
export * from './public-api';
