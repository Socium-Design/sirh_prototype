import * as i0 from '@angular/core';
import { Directive, input, booleanAttribute, model, contentChild, computed, ViewEncapsulation, ChangeDetectionStrategy, Component, output, InjectionToken, inject, forwardRef, effect, signal, viewChild, DestroyRef, Injector, afterNextRender, ElementRef, TemplateRef } from '@angular/core';
import { LucideChevronDown, LucideChevronRight, LucideHouse, LucideMoreHorizontal, LucideCheck, LucideX, LucideFileText, LucideInfo, LucideMinus, LucidePlus, LucideCircleAlert, LucideCircleCheck, LucideCircleX, LucideTriangleAlert, LucideChevronLeft, LucideChevronsLeft, LucideChevronsRight, LucideEye, LucideEyeOff, LucideSearch, LucideLayoutDashboard, LucideReceiptText, LucideHistory, LucideUsers, LucideCoins, LucideReceipt, LucideFileSpreadsheet, LucideCalculator, LucidePiggyBank, LucideChartPie, LucideBookOpen, LucideTrendingUp, LucideBuilding2, LucideInbox, LucideFileSignature, LucideFiles, LucideShieldCheck, LucideSettings, LucideTarget, LucideClipboardCheck, LucideAward, LucideGraduationCap, LucideGrid3x3, LucideSlidersHorizontal, LucideFileCheck, LucideMap, LucideCalendar, LucidePackage, LucideBanknote, LucideClipboardList, LucideWorkflow, LucideCalendarDays, LucideDownload, LucideUser, LucideCalendarCheck, LucidePackageCheck, LucideWallet, LucideClipboardPen, LucideBriefcaseBusiness, LucideFolderSearch, LucideFilePlus, LucideMail, LucideFilter, LucideFileChartColumn, LucideListFilter, LucidePresentation, LucideSend, LucideArrowDownUp, LucideGlobe, LucideLayoutTemplate, LucideAppWindow, LucideBriefcase, LucideNetwork, LucideGitFork, LucideList, LucideListChecks, LucidePanelLeftClose, LucidePanelLeftOpen, LucideLogOut, LucideBell, LucideCircleHelp, LucideUploadCloud, LucideArrowLeft } from '@lucide/angular';
import { NgTemplateOutlet, NgComponentOutlet } from '@angular/common';
import { NG_VALUE_ACCESSOR, NgControl } from '@angular/forms';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

/** React `Accordion`'s `rightSlot?: ReactNode` — extra content next to the label (info text, a
 * Tag, row actions, …). */
class SocAccordionRightSlot {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAccordionRightSlot, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocAccordionRightSlot, isStandalone: true, selector: "[socAccordionRightSlot]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAccordionRightSlot, decorators: [{
            type: Directive,
            args: [{ selector: '[socAccordionRightSlot]', standalone: true }]
        }] });
/**
 * No native HTML equivalent (the disclosure triangle is hand-rolled with a `<button>` + rotating
 * chevron, same as React — no `<details>`/`<summary>`) — plain wrapper (`soc-accordion`). Maps 1:1
 * to "Index/Conteneur/Accordion/*" tokens — see packages/tokens/tokens/components/conteneur.json
 * in design_system (React reference repo, read only). React's controlled-vs-uncontrolled
 * `open`/`defaultOpen` collapses to one `model()`, same reasoning as `Checkbox`/`Switch`.
 */
class SocAccordion {
    label = input.required();
    error = input(false, { transform: booleanAttribute });
    warning = input(false, { transform: booleanAttribute });
    open = model(false);
    iconThickness = 'var(--index-conteneur-accordion-icon-thickness)';
    rightSlotContent = contentChild(SocAccordionRightSlot);
    hasRightSlot = computed(() => !!this.rightSlotContent());
    toggle() {
        this.open.set(!this.open());
    }
    hostClasses = computed(() => {
        const border = this.error()
            ? 'border-[var(--index-conteneur-accordion-header-stroke-error)]'
            : this.warning()
                ? 'border-[var(--index-conteneur-accordion-header-stroke-warning)]'
                : this.open()
                    ? 'border-[var(--index-conteneur-accordion-header-stroke-open)]'
                    : 'border-[var(--index-conteneur-accordion-header-stroke)] hover:border-[var(--index-conteneur-accordion-header-stroke-hover)] focus-within:border-[var(--index-conteneur-accordion-header-stroke-focus)]';
        return `block w-full overflow-hidden rounded-[var(--index-conteneur-accordion-header-radius)] border-[length:var(--index-conteneur-accordion-header-stroke-width)] ${border}`;
    });
    headerClasses = computed(() => {
        const bg = this.error()
            ? 'bg-[var(--index-conteneur-accordion-header-bg-error)]'
            : this.warning()
                ? 'bg-[var(--index-conteneur-accordion-header-bg-warning)]'
                : this.open()
                    ? 'bg-[var(--index-conteneur-accordion-header-bg-open)]'
                    : 'bg-[var(--index-conteneur-accordion-header-bg)] hover:bg-[var(--index-conteneur-accordion-header-bg-hover)] active:bg-[var(--index-conteneur-accordion-header-bg-pressed)]';
        return `flex w-full items-center justify-between gap-[var(--index-conteneur-accordion-label-group-gap)] px-[var(--index-conteneur-accordion-header-pad-h)] py-[var(--index-conteneur-accordion-header-pad-v)] ${bg}`;
    });
    chevronClasses = computed(() => `size-[var(--index-conteneur-accordion-icon-size)] shrink-0 transition-transform ${this.open() ? 'rotate-180 text-[var(--index-conteneur-accordion-icon-chevron-open)]' : 'text-[var(--index-conteneur-accordion-icon-chevron)] group-hover:text-[var(--index-conteneur-accordion-icon-chevron-hover)]'}`);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAccordion, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocAccordion, isStandalone: true, selector: "soc-accordion", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, warning: { classPropertyName: "warning", publicName: "warning", isSignal: true, isRequired: false, transformFunction: null }, open: { classPropertyName: "open", publicName: "open", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { open: "openChange" }, host: { properties: { "class": "hostClasses()" } }, queries: [{ propertyName: "rightSlotContent", first: true, predicate: SocAccordionRightSlot, descendants: true, isSignal: true }], ngImport: i0, template: `
    <button type="button" (click)="toggle()" [attr.aria-expanded]="open()" [class]="headerClasses()">
      <span class="flex items-center gap-[var(--index-conteneur-accordion-label-group-gap)]">
        <span class="whitespace-nowrap text-[length:var(--index-conteneur-accordion-label-size)] text-[var(--index-conteneur-accordion-label-color)] [font-family:var(--index-conteneur-accordion-label-font)] [font-weight:var(--index-conteneur-accordion-label-weight)]">
          {{ label() }}
        </span>
        <ng-content select="[socAccordionRightSlot]" />
      </span>
      <span [class]="chevronClasses()">
        <svg lucideChevronDown class="size-full" [strokeWidth]="iconThickness"></svg>
      </span>
    </button>
    @if (open()) {
      <div class="w-full bg-[var(--index-conteneur-accordion-content-bg)] p-[var(--index-conteneur-accordion-content-slot-pad)] border-t-[length:var(--index-conteneur-accordion-header-stroke-width)] border-[var(--index-conteneur-accordion-content-border)]">
        <ng-content />
      </div>
    }
  `, isInline: true, dependencies: [{ kind: "component", type: LucideChevronDown, selector: "svg[lucideChevronDown]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAccordion, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-accordion',
                    standalone: true,
                    imports: [LucideChevronDown],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[class]': 'hostClasses()',
                    },
                    template: `
    <button type="button" (click)="toggle()" [attr.aria-expanded]="open()" [class]="headerClasses()">
      <span class="flex items-center gap-[var(--index-conteneur-accordion-label-group-gap)]">
        <span class="whitespace-nowrap text-[length:var(--index-conteneur-accordion-label-size)] text-[var(--index-conteneur-accordion-label-color)] [font-family:var(--index-conteneur-accordion-label-font)] [font-weight:var(--index-conteneur-accordion-label-weight)]">
          {{ label() }}
        </span>
        <ng-content select="[socAccordionRightSlot]" />
      </span>
      <span [class]="chevronClasses()">
        <svg lucideChevronDown class="size-full" [strokeWidth]="iconThickness"></svg>
      </span>
    </button>
    @if (open()) {
      <div class="w-full bg-[var(--index-conteneur-accordion-content-bg)] p-[var(--index-conteneur-accordion-content-slot-pad)] border-t-[length:var(--index-conteneur-accordion-header-stroke-width)] border-[var(--index-conteneur-accordion-content-border)]">
        <ng-content />
      </div>
    }
  `,
                }]
        }] });

const DEFAULT_HOVER_CLASS = 'fill-[var(--index-button-button-icon-default)] group-hover:fill-[var(--index-navigation-appicon-icon-hover)]';
const SELECTED_WHITE_CLASS = 'fill-[var(--index-navigation-appicon-icon-selected)]';
const SELECTED_ACCENT_CLASS = 'fill-[var(--index-navigation-appicon-icon-accent)]';
/**
 * Renders one named glyph via a `@switch`, each shape's fill picked by `selected()` + whether that
 * particular shape is an "accent" one — same three-class logic as React's own `renderShapes`
 * helper, just inlined per shape here instead of mapped over a shape-description array (Angular
 * templates can't easily interpolate arbitrary SVG element types — `<path>` vs `<circle>` vs
 * `<ellipse>` — the way a single JS `.map()` callback can, so this stays closer to hand-written SVG
 * markup per icon rather than porting `renderShapes`/`GlyphShape` as data).
 */
class SocAppIconGlyph {
    name = input.required();
    selected = input(false, { transform: booleanAttribute });
    shapeClass(accent) {
        if (!this.selected())
            return DEFAULT_HOVER_CLASS;
        return accent ? SELECTED_ACCENT_CLASS : SELECTED_WHITE_CLASS;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAppIconGlyph, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocAppIconGlyph, isStandalone: true, selector: "soc-app-icon-glyph", inputs: { name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: true, transformFunction: null }, selected: { classPropertyName: "selected", publicName: "selected", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    @switch (name()) {
      @case ('workspace') {
        <svg viewBox="0 0 21.2731 18" width="18" height="15" fill="none">
          <path
            d="M10.6367 10.6367C8.37743 10.6367 6.54599 13.3836 6.5459 16.7725C6.5459 17.3119 6.59255 17.7107 6.67969 18H3.27246L0 8.52637L10.6367 0V10.6367Z"
            [class]="shapeClass(false)"
          />
          <path
            d="M21.2731 8.52637L17.9996 18H14.5934C14.6805 17.7107 14.7272 17.3118 14.7272 16.7725C14.7271 13.4897 13.0086 10.8092 10.8473 10.6445L10.6364 10.6367V0L21.2731 8.52637Z"
            [class]="shapeClass(true)"
          />
        </svg>
      }
      @case ('job') {
        <svg viewBox="0 0 22.3981 24.1707" width="17" height="18" fill="none">
          <circle cx="17.2417" cy="12.0855" r="5.1564" transform="rotate(90 17.2417 12.0855)" [class]="shapeClass(true)" />
          <circle cx="5.1564" cy="5.1564" r="5.1564" transform="rotate(90 5.1564 5.1564)" [class]="shapeClass(false)" />
          <ellipse cx="5.1564" cy="19.0546" rx="5.11611" ry="5.1564" transform="rotate(90 5.1564 19.0546)" [class]="shapeClass(false)" />
        </svg>
      }
      @case ('workflow') {
        <svg viewBox="0 0 22.4788 19.4979" width="18" height="16" fill="none">
          <path d="M5.3212 14.0191L22.4788 14.0191V19.4977H0.000157928L5.3212 14.0191Z" [class]="shapeClass(true)" />
          <path d="M17.1576 5.47867L-3.57628e-07 5.47867V1.41561e-07H22.4787L17.1576 5.47867Z" [class]="shapeClass(false)" />
          <path d="M9.10442 9.34601L0.000157928 19.4977H9.10442V9.34601Z" [class]="shapeClass(true)" />
          <path d="M13.3744 10.1517L22.4787 7.77245e-05H13.3744V10.1517Z" [class]="shapeClass(false)" />
        </svg>
      }
      @case ('doc') {
        <svg viewBox="0 0 22.4787 16.5168" width="18" height="13" fill="none">
          <path d="M2.90049 6.20392H19.5782V10.3129H2.90049V6.20392Z" [class]="shapeClass(true)" />
          <path d="M0 0H22.4787L19.5427 4.109H2.84424L0 0Z" [class]="shapeClass(false)" />
          <path d="M22.4787 16.5168L4.36381e-05 16.5168L2.93603 12.4078L19.5427 12.4078L22.4787 16.5168Z" [class]="shapeClass(false)" />
        </svg>
      }
      @case ('payroll') {
        <svg viewBox="0 0 22.4453 20.2226" width="18" height="16" fill="none">
          <path d="M22.4453 4.55176V9.10449L11.2227 4.55176L0 9.10449V4.55176L11.2227 0L22.4453 4.55176Z" [class]="shapeClass(false)" />
          <path d="M22.4453 15.6709V11.1181L11.2227 15.6709L0 11.1181V15.6709L11.2227 20.2226L22.4453 15.6709Z" [class]="shapeClass(true)" />
        </svg>
      }
      @case ('time') {
        <svg viewBox="0 0 22.2725 23.2642" width="17" height="18" fill="none">
          <path d="M11.136 9.97038L16.8575 19.9408H5.41444L11.136 9.97038Z" [class]="shapeClass(false)" />
          <path d="M11.1359 9.97038L16.8574 2.79397e-07H5.41439L11.1359 9.97038Z" [class]="shapeClass(false)" />
          <path
            d="M11.1357 9.97043L2.96777 18.0945L0 7.01926L11.1357 9.97043ZM22.2725 12.9216L11.1357 9.97043L19.3047 1.8464L22.2725 12.9216Z"
            [class]="shapeClass(true)"
          />
        </svg>
      }
      @case ('baas') {
        <svg viewBox="0 0 13.2133 23.2642" width="10" height="18" fill="none">
          <path d="M6.60663 9.97041L12.3281 19.9408H0.885115L6.60663 9.97041Z" [class]="shapeClass(false)" />
          <path d="M6.60658 9.97041L12.3281 3.46117e-05H0.885064L6.60658 9.97041Z" [class]="shapeClass(true)" />
        </svg>
      }
      @case ('performance') {
        <!-- Two overlapping groups in Figma (a small diamond above a mountain/zigzag base)
             recomposed into one viewBox — matches React's own comment. -->
        <svg viewBox="0 0 22.3175 20.789" width="18" height="17" fill="none">
          <g transform="translate(6.5366, 0)">
            <path d="M4.62231 8.13802e-05V9.27594L0 4.65362L4.62231 8.13802e-05Z" [class]="shapeClass(true)" />
            <path d="M9.24435 4.65354L4.62204 9.27585V0L9.24435 4.65354Z" [class]="shapeClass(false)" />
          </g>
          <g transform="translate(0, 10.476)">
            <path d="M4.27014 1.6276e-05L0 10.3128H11.1588V1.6276e-05H4.27014Z" [class]="shapeClass(false)" />
            <path d="M18.0473 0L22.3175 10.3128H11.1587V0H18.0473Z" [class]="shapeClass(true)" />
          </g>
        </svg>
      }
    }
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAppIconGlyph, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-app-icon-glyph',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    template: `
    @switch (name()) {
      @case ('workspace') {
        <svg viewBox="0 0 21.2731 18" width="18" height="15" fill="none">
          <path
            d="M10.6367 10.6367C8.37743 10.6367 6.54599 13.3836 6.5459 16.7725C6.5459 17.3119 6.59255 17.7107 6.67969 18H3.27246L0 8.52637L10.6367 0V10.6367Z"
            [class]="shapeClass(false)"
          />
          <path
            d="M21.2731 8.52637L17.9996 18H14.5934C14.6805 17.7107 14.7272 17.3118 14.7272 16.7725C14.7271 13.4897 13.0086 10.8092 10.8473 10.6445L10.6364 10.6367V0L21.2731 8.52637Z"
            [class]="shapeClass(true)"
          />
        </svg>
      }
      @case ('job') {
        <svg viewBox="0 0 22.3981 24.1707" width="17" height="18" fill="none">
          <circle cx="17.2417" cy="12.0855" r="5.1564" transform="rotate(90 17.2417 12.0855)" [class]="shapeClass(true)" />
          <circle cx="5.1564" cy="5.1564" r="5.1564" transform="rotate(90 5.1564 5.1564)" [class]="shapeClass(false)" />
          <ellipse cx="5.1564" cy="19.0546" rx="5.11611" ry="5.1564" transform="rotate(90 5.1564 19.0546)" [class]="shapeClass(false)" />
        </svg>
      }
      @case ('workflow') {
        <svg viewBox="0 0 22.4788 19.4979" width="18" height="16" fill="none">
          <path d="M5.3212 14.0191L22.4788 14.0191V19.4977H0.000157928L5.3212 14.0191Z" [class]="shapeClass(true)" />
          <path d="M17.1576 5.47867L-3.57628e-07 5.47867V1.41561e-07H22.4787L17.1576 5.47867Z" [class]="shapeClass(false)" />
          <path d="M9.10442 9.34601L0.000157928 19.4977H9.10442V9.34601Z" [class]="shapeClass(true)" />
          <path d="M13.3744 10.1517L22.4787 7.77245e-05H13.3744V10.1517Z" [class]="shapeClass(false)" />
        </svg>
      }
      @case ('doc') {
        <svg viewBox="0 0 22.4787 16.5168" width="18" height="13" fill="none">
          <path d="M2.90049 6.20392H19.5782V10.3129H2.90049V6.20392Z" [class]="shapeClass(true)" />
          <path d="M0 0H22.4787L19.5427 4.109H2.84424L0 0Z" [class]="shapeClass(false)" />
          <path d="M22.4787 16.5168L4.36381e-05 16.5168L2.93603 12.4078L19.5427 12.4078L22.4787 16.5168Z" [class]="shapeClass(false)" />
        </svg>
      }
      @case ('payroll') {
        <svg viewBox="0 0 22.4453 20.2226" width="18" height="16" fill="none">
          <path d="M22.4453 4.55176V9.10449L11.2227 4.55176L0 9.10449V4.55176L11.2227 0L22.4453 4.55176Z" [class]="shapeClass(false)" />
          <path d="M22.4453 15.6709V11.1181L11.2227 15.6709L0 11.1181V15.6709L11.2227 20.2226L22.4453 15.6709Z" [class]="shapeClass(true)" />
        </svg>
      }
      @case ('time') {
        <svg viewBox="0 0 22.2725 23.2642" width="17" height="18" fill="none">
          <path d="M11.136 9.97038L16.8575 19.9408H5.41444L11.136 9.97038Z" [class]="shapeClass(false)" />
          <path d="M11.1359 9.97038L16.8574 2.79397e-07H5.41439L11.1359 9.97038Z" [class]="shapeClass(false)" />
          <path
            d="M11.1357 9.97043L2.96777 18.0945L0 7.01926L11.1357 9.97043ZM22.2725 12.9216L11.1357 9.97043L19.3047 1.8464L22.2725 12.9216Z"
            [class]="shapeClass(true)"
          />
        </svg>
      }
      @case ('baas') {
        <svg viewBox="0 0 13.2133 23.2642" width="10" height="18" fill="none">
          <path d="M6.60663 9.97041L12.3281 19.9408H0.885115L6.60663 9.97041Z" [class]="shapeClass(false)" />
          <path d="M6.60658 9.97041L12.3281 3.46117e-05H0.885064L6.60658 9.97041Z" [class]="shapeClass(true)" />
        </svg>
      }
      @case ('performance') {
        <!-- Two overlapping groups in Figma (a small diamond above a mountain/zigzag base)
             recomposed into one viewBox — matches React's own comment. -->
        <svg viewBox="0 0 22.3175 20.789" width="18" height="17" fill="none">
          <g transform="translate(6.5366, 0)">
            <path d="M4.62231 8.13802e-05V9.27594L0 4.65362L4.62231 8.13802e-05Z" [class]="shapeClass(true)" />
            <path d="M9.24435 4.65354L4.62204 9.27585V0L9.24435 4.65354Z" [class]="shapeClass(false)" />
          </g>
          <g transform="translate(0, 10.476)">
            <path d="M4.27014 1.6276e-05L0 10.3128H11.1588V1.6276e-05H4.27014Z" [class]="shapeClass(false)" />
            <path d="M18.0473 0L22.3175 10.3128H11.1587V0H18.0473Z" [class]="shapeClass(true)" />
          </g>
        </svg>
      }
    }
  `,
                }]
        }] });
/** Real vector mark exported from the Figma "Logo" node (rendered above the icon list in
 * AppSwitch). Ported verbatim from React's own `SwitchLogo`. */
class SocSwitchLogo {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocSwitchLogo, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.25", type: SocSwitchLogo, isStandalone: true, selector: "soc-switch-logo", ngImport: i0, template: `
    <svg viewBox="0 0 25.3047 25.3047" width="25" height="25" fill="none">
      <path
        d="M20.998 22.1582C18.7705 24.1153 15.8513 25.3044 12.6533 25.3047C9.45499 25.3047 6.53531 24.1154 4.30762 22.1582H20.998ZM22.8867 5.21777C23.659 6.27899 24.2695 7.46504 24.6846 8.73926H4.40234C4.07164 9.43435 3.82615 10.1776 3.67969 10.9561H24.3916V10.957H25.1895C25.2639 11.5115 25.3047 12.0774 25.3047 12.6523C25.3046 15.4311 24.4064 17.9996 22.8877 20.0869H2.41699C1.6449 19.0257 1.03401 17.8397 0.619141 16.5654H20.9023C21.2146 15.9092 21.4499 15.2098 21.5986 14.4785H0.133789C0.0473588 13.8822 2.18098e-05 13.2726 0 12.6523C8.48653e-05 9.87329 0.898986 7.30516 2.41797 5.21777H22.8867ZM12.6533 0C15.8871 0.000250383 18.8365 1.21554 21.0732 3.21191H4.23242C6.46928 1.21546 9.41923 0 12.6533 0Z"
        fill="var(--index-navigation-appswitch-logo-color)"
      />
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocSwitchLogo, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-switch-logo',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    template: `
    <svg viewBox="0 0 25.3047 25.3047" width="25" height="25" fill="none">
      <path
        d="M20.998 22.1582C18.7705 24.1153 15.8513 25.3044 12.6533 25.3047C9.45499 25.3047 6.53531 24.1154 4.30762 22.1582H20.998ZM22.8867 5.21777C23.659 6.27899 24.2695 7.46504 24.6846 8.73926H4.40234C4.07164 9.43435 3.82615 10.1776 3.67969 10.9561H24.3916V10.957H25.1895C25.2639 11.5115 25.3047 12.0774 25.3047 12.6523C25.3046 15.4311 24.4064 17.9996 22.8877 20.0869H2.41699C1.6449 19.0257 1.03401 17.8397 0.619141 16.5654H20.9023C21.2146 15.9092 21.4499 15.2098 21.5986 14.4785H0.133789C0.0473588 13.8822 2.18098e-05 13.2726 0 12.6523C8.48653e-05 9.87329 0.898986 7.30516 2.41797 5.21777H22.8867ZM12.6533 0C15.8871 0.000250383 18.8365 1.21554 21.0732 3.21191H4.23242C6.46928 1.21546 9.41923 0 12.6533 0Z"
        fill="var(--index-navigation-appswitch-logo-color)"
      />
    </svg>
  `,
                }]
        }] });

/**
 * One entry per "Produit" variant — the same 6 values `SocSideNavigation`'s `product` input
 * resolves against (see navigation-presets.ts). `name` maps to the matching AppIconName glyph;
 * note `perfs` (NavigationProduct) draws the `performance` glyph — the two are spelled
 * differently between Figma's SideNavigation and AppIcon components (carried over verbatim from
 * React's own appSwitchPresets.ts).
 */
const APP_SWITCH_ITEMS = {
    workspace: { id: 'workspace', name: 'workspace', label: 'Workspace' },
    job: { id: 'job', name: 'job', label: 'Job' },
    workflow: { id: 'workflow', name: 'workflow', label: 'Workflow' },
    perfs: { id: 'perfs', name: 'performance', label: 'Perfs' },
    doc: { id: 'doc', name: 'doc', label: 'Doc' },
    payroll: { id: 'payroll', name: 'payroll', label: 'Payroll' },
};
const APP_SWITCH_PRODUCTS = ['workspace', 'job', 'workflow', 'perfs', 'doc', 'payroll'];

/** React `AppSwitch`'s `logo?: ReactNode` — rendered above the icon list (pass the Logo
 * component, e.g. `SocSwitchLogo`, once it exists — same "not implemented yet" note as React's
 * own doc comment). */
class SocAppSwitchLogo {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAppSwitchLogo, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocAppSwitchLogo, isStandalone: true, selector: "[socAppSwitchLogo]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAppSwitchLogo, decorators: [{
            type: Directive,
            args: [{ selector: '[socAppSwitchLogo]', standalone: true }]
        }] });
/**
 * Attribute selector on a real `<button>` (`button[socAppIcon]`) — structurally just a button
 * with a self-drawn icon inside, no siblings needed, same shape as `Button` itself. Maps 1:1 to
 * "Index/Navigation/AppIcon/*" tokens — see packages/tokens/tokens/components/navigation.json in
 * design_system (React reference repo, read only).
 */
class SocAppIcon {
    name = input.required();
    label = input.required();
    selected = input(false, { transform: booleanAttribute });
    hostClasses = computed(() => `group flex size-[var(--index-navigation-appicon-item-size)] shrink-0 items-center justify-center rounded-[var(--index-button-button-radius)] ${this.selected() ? 'bg-[var(--index-navigation-appicon-bg-selected)]' : 'hover:bg-[var(--index-navigation-appicon-bg-hover)]'}`);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAppIcon, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.25", type: SocAppIcon, isStandalone: true, selector: "button[socAppIcon]", inputs: { name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: true, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, selected: { classPropertyName: "selected", publicName: "selected", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.aria-label": "label()", "attr.aria-pressed": "selected()", "attr.title": "label()", "class": "hostClasses()" } }, ngImport: i0, template: `<soc-app-icon-glyph [name]="name()" [selected]="selected()" />`, isInline: true, dependencies: [{ kind: "component", type: SocAppIconGlyph, selector: "soc-app-icon-glyph", inputs: ["name", "selected"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAppIcon, decorators: [{
            type: Component,
            args: [{
                    selector: 'button[socAppIcon]',
                    standalone: true,
                    imports: [SocAppIconGlyph],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[attr.aria-label]': 'label()',
                        '[attr.aria-pressed]': 'selected()',
                        '[attr.title]': 'label()',
                        '[class]': 'hostClasses()',
                    },
                    template: `<soc-app-icon-glyph [name]="name()" [selected]="selected()" />`,
                }]
        }] });
/**
 * No native HTML equivalent — plain wrapper (`soc-app-switch`). Maps 1:1 to
 * "Index/Navigation/AppSwitch/*" tokens — see packages/tokens/tokens/components/navigation.json
 * in design_system (React reference repo, read only). `onSelect` -> `select` output(); `logo` ->
 * named content slot (`socAppSwitchLogo`), same reasoning as every other `ReactNode` slot this
 * migration.
 */
class SocAppSwitch {
    product = input();
    items = input();
    selectedId = input();
    select = output();
    logoContent = contentChild(SocAppSwitchLogo);
    hasLogo = computed(() => !!this.logoContent());
    resolvedItems = computed(() => this.items() ?? (this.product() ? Object.values(APP_SWITCH_ITEMS) : []));
    resolvedSelectedId = computed(() => this.selectedId() ?? this.product());
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAppSwitch, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocAppSwitch, isStandalone: true, selector: "soc-app-switch", inputs: { product: { classPropertyName: "product", publicName: "product", isSignal: true, isRequired: false, transformFunction: null }, items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null }, selectedId: { classPropertyName: "selectedId", publicName: "selectedId", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { select: "select" }, host: { classAttribute: "flex h-full w-[var(--index-navigation-appswitch-bar-width)] flex-col items-center gap-[var(--index-navigation-appswitch-logo-gap)] bg-[var(--index-navigation-appswitch-bar-bg)] px-[var(--index-button-button-padding-h)] pt-[var(--index-navigation-appswitch-padding-top)] pb-[var(--index-navigation-appswitch-padding-bottom)]" }, queries: [{ propertyName: "logoContent", first: true, predicate: SocAppSwitchLogo, descendants: true, isSignal: true }], ngImport: i0, template: `
    @if (hasLogo()) {
      <div class="shrink-0 text-[var(--index-navigation-appswitch-logo-color)]">
        <ng-content select="[socAppSwitchLogo]" />
      </div>
    }
    <div class="flex w-full flex-col items-center gap-[var(--index-navigation-appicon-items-gap)]">
      @for (item of resolvedItems(); track item.id) {
        <button socAppIcon [name]="item.name" [label]="item.label" [selected]="item.id === resolvedSelectedId()" (click)="select.emit(item.id)"></button>
      }
    </div>
  `, isInline: true, dependencies: [{ kind: "component", type: SocAppIcon, selector: "button[socAppIcon]", inputs: ["name", "label", "selected"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAppSwitch, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-app-switch',
                    standalone: true,
                    imports: [SocAppIcon],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        class: 'flex h-full w-[var(--index-navigation-appswitch-bar-width)] flex-col items-center gap-[var(--index-navigation-appswitch-logo-gap)] bg-[var(--index-navigation-appswitch-bar-bg)] px-[var(--index-button-button-padding-h)] pt-[var(--index-navigation-appswitch-padding-top)] pb-[var(--index-navigation-appswitch-padding-bottom)]',
                    },
                    template: `
    @if (hasLogo()) {
      <div class="shrink-0 text-[var(--index-navigation-appswitch-logo-color)]">
        <ng-content select="[socAppSwitchLogo]" />
      </div>
    }
    <div class="flex w-full flex-col items-center gap-[var(--index-navigation-appicon-items-gap)]">
      @for (item of resolvedItems(); track item.id) {
        <button socAppIcon [name]="item.name" [label]="item.label" [selected]="item.id === resolvedSelectedId()" (click)="select.emit(item.id)"></button>
      }
    </div>
  `,
                }]
        }] });

const sizeClasses$3 = {
    xs: 'size-[var(--index-social-avatar-size-xs)] text-[length:var(--index-social-avatar-text-size-xs)]',
    sm: 'size-[var(--index-social-avatar-size-sm)] text-[length:var(--index-social-avatar-text-size-sm)]',
    md: 'size-[var(--index-social-avatar-size-md)] text-[length:var(--index-social-avatar-text-size-md)]',
    lg: 'size-[var(--index-social-avatar-size-lg)] text-[length:var(--index-social-avatar-text-size-lg)]',
};
const colorClasses$2 = {
    blue: {
        soft: 'bg-[var(--index-social-avatar-blue-bg)] text-[var(--index-social-avatar-blue-text)]',
        solid: 'bg-[var(--index-social-avatar-blue-text)] text-[var(--index-social-avatar-blue-bg)]',
    },
    green: {
        soft: 'bg-[var(--index-social-avatar-green-bg)] text-[var(--index-social-avatar-green-text)]',
        solid: 'bg-[var(--index-social-avatar-green-text)] text-[var(--index-social-avatar-green-bg)]',
    },
    purple: {
        soft: 'bg-[var(--index-social-avatar-purple-bg)] text-[var(--index-social-avatar-purple-text)]',
        solid: 'bg-[var(--index-social-avatar-purple-text)] text-[var(--index-social-avatar-purple-bg)]',
    },
    orange: {
        soft: 'bg-[var(--index-social-avatar-orange-bg)] text-[var(--index-social-avatar-orange-text)]',
        solid: 'bg-[var(--index-social-avatar-orange-text)] text-[var(--index-social-avatar-orange-bg)]',
    },
};
/**
 * No native HTML equivalent and no single element being wrapped — plain standalone wrapper
 * component (`soc-avatar` element selector), not an attribute selector. `label`/`name`/`subtitle`
 * are all plain strings (not ReactNode in the React source), so plain `input()`s, no content
 * projection needed.
 *
 * Maps 1:1 to "Index/Social/Avatar/*" tokens — see packages/tokens/tokens/components/social.json
 * in design_system (React reference repo, read only). Only the "initials" type is implemented —
 * React `Avatar.tsx`'s own doc comment: a photo is a plain image-filled frame, a generic icon is a
 * bare Lucide icon, neither goes through this component.
 */
class SocAvatar {
    label = input.required();
    color = input('blue');
    size = input('md');
    mode = input('soft');
    name = input();
    subtitle = input();
    namePosition = input('right');
    // React only adds `inline-flex items-center gap-[...]` on the outer wrapper when `name` is
    // given — without it, the wrapper carries no layout classes of its own, just the circle.
    hostClasses = computed(() => (this.name() ? 'inline-flex items-center gap-[var(--index-social-avatar-group-gap)]' : ''));
    circleClass = computed(() => `inline-flex shrink-0 items-center justify-center whitespace-nowrap rounded-[var(--index-social-avatar-radius)] [font-family:var(--index-social-avatar-text-font)] [font-weight:var(--index-social-avatar-text-weight)] ${sizeClasses$3[this.size()]} ${colorClasses$2[this.color()][this.mode()]}`);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAvatar, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocAvatar, isStandalone: true, selector: "soc-avatar", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, color: { classPropertyName: "color", publicName: "color", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, mode: { classPropertyName: "mode", publicName: "mode", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, subtitle: { classPropertyName: "subtitle", publicName: "subtitle", isSignal: true, isRequired: false, transformFunction: null }, namePosition: { classPropertyName: "namePosition", publicName: "namePosition", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0, template: `
    @if (name() && namePosition() === 'left') {
      <span class="flex flex-col items-start gap-[var(--index-social-avatar-text-gap)] whitespace-nowrap">
        <span class="text-[length:var(--index-social-avatar-label-size)] text-[var(--index-social-avatar-label-color)] [font-family:var(--index-social-avatar-label-font)] [font-weight:var(--index-social-avatar-label-weight)]">
          {{ name() }}
        </span>
        @if (subtitle()) {
          <span class="text-[length:var(--index-social-avatar-subtitle-size)] text-[var(--index-social-avatar-subtitle-color)] [font-family:var(--index-social-avatar-subtitle-font)] [font-weight:var(--index-social-avatar-subtitle-weight)]">
            {{ subtitle() }}
          </span>
        }
      </span>
    }
    <span [class]="circleClass()">{{ label() }}</span>
    @if (name() && namePosition() === 'right') {
      <span class="flex flex-col items-start gap-[var(--index-social-avatar-text-gap)] whitespace-nowrap">
        <span class="text-[length:var(--index-social-avatar-label-size)] text-[var(--index-social-avatar-label-color)] [font-family:var(--index-social-avatar-label-font)] [font-weight:var(--index-social-avatar-label-weight)]">
          {{ name() }}
        </span>
        @if (subtitle()) {
          <span class="text-[length:var(--index-social-avatar-subtitle-size)] text-[var(--index-social-avatar-subtitle-color)] [font-family:var(--index-social-avatar-subtitle-font)] [font-weight:var(--index-social-avatar-subtitle-weight)]">
            {{ subtitle() }}
          </span>
        }
      </span>
    }
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAvatar, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-avatar',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[class]': 'hostClasses()',
                    },
                    template: `
    @if (name() && namePosition() === 'left') {
      <span class="flex flex-col items-start gap-[var(--index-social-avatar-text-gap)] whitespace-nowrap">
        <span class="text-[length:var(--index-social-avatar-label-size)] text-[var(--index-social-avatar-label-color)] [font-family:var(--index-social-avatar-label-font)] [font-weight:var(--index-social-avatar-label-weight)]">
          {{ name() }}
        </span>
        @if (subtitle()) {
          <span class="text-[length:var(--index-social-avatar-subtitle-size)] text-[var(--index-social-avatar-subtitle-color)] [font-family:var(--index-social-avatar-subtitle-font)] [font-weight:var(--index-social-avatar-subtitle-weight)]">
            {{ subtitle() }}
          </span>
        }
      </span>
    }
    <span [class]="circleClass()">{{ label() }}</span>
    @if (name() && namePosition() === 'right') {
      <span class="flex flex-col items-start gap-[var(--index-social-avatar-text-gap)] whitespace-nowrap">
        <span class="text-[length:var(--index-social-avatar-label-size)] text-[var(--index-social-avatar-label-color)] [font-family:var(--index-social-avatar-label-font)] [font-weight:var(--index-social-avatar-label-weight)]">
          {{ name() }}
        </span>
        @if (subtitle()) {
          <span class="text-[length:var(--index-social-avatar-subtitle-size)] text-[var(--index-social-avatar-subtitle-color)] [font-family:var(--index-social-avatar-subtitle-font)] [font-weight:var(--index-social-avatar-subtitle-weight)]">
            {{ subtitle() }}
          </span>
        }
      </span>
    }
  `,
                }]
        }] });

// "primary" is the exact same green as "success" (bridges.color.accent.lime-text) — not blue, and
// not merely "a green": bound to success's own token so the two colors can never drift apart
// independently. Blue was retired as a Badge color entirely, not just swapped visually. The
// variant name stays "primary" in the API. (Verbatim from React Badge.tsx's own comment.)
const colorClasses$1 = {
    primary: 'bg-[var(--index-feedback-badge-bg-1)] text-[var(--index-feedback-badge-text-primary)]',
    success: 'bg-[var(--index-feedback-badge-bg-2)] text-[var(--index-feedback-badge-text-success)]',
    warning: 'bg-[var(--index-feedback-badge-bg-3)] text-[var(--index-feedback-badge-text-warning)]',
    danger: 'bg-[var(--index-feedback-badge-bg-4)] text-[var(--index-feedback-badge-text-danger)]',
};
const sizeClasses$2 = {
    sm: 'rounded-[var(--index-feedback-badge-radius-sm)] px-[var(--index-feedback-badge-padding-h-sm)] py-[var(--index-feedback-badge-padding-v-sm)] text-[length:var(--index-feedback-badge-font-size-sm)]',
    lg: 'rounded-[var(--index-feedback-badge-radius-lg)] px-[var(--index-feedback-badge-padding-h-lg)] py-[var(--index-feedback-badge-padding-v-lg)] text-[length:var(--index-feedback-badge-font-size-lg)]',
};
/**
 * No native HTML equivalent — plain wrapper (`soc-badge` element selector). `children: ReactNode`
 * becomes a default `<ng-content>` (no named slot needed, there's only one content region).
 *
 * Maps 1:1 to "Index/Feedback/Badge/*" tokens — see packages/tokens/tokens/components/feedback.json
 * in design_system (React reference repo, read only).
 */
class SocBadge {
    color = input('primary');
    size = input('sm');
    hostClasses = computed(() => `inline-flex items-center justify-center whitespace-nowrap text-center [font-family:var(--index-feedback-badge-font-family)] [font-weight:var(--index-feedback-badge-font-weight)] ${colorClasses$1[this.color()]} ${sizeClasses$2[this.size()]}`);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocBadge, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.25", type: SocBadge, isStandalone: true, selector: "soc-badge", inputs: { color: { classPropertyName: "color", publicName: "color", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0, template: `<ng-content />`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocBadge, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-badge',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[class]': 'hostClasses()',
                    },
                    template: `<ng-content />`,
                }]
        }] });

/**
 * No native HTML equivalent — plain wrapper (`soc-breadcrumb`). `items: BreadcrumbItemData[]` is
 * plain data (not ReactNode), so a plain `input()`, same as `Message`'s `primaryAction` object —
 * each item's own `onClick` stays a plain callback field on the data, since it's tied to that
 * specific item, not a single component-wide event. `onHomeClick`, by contrast, IS a single
 * component-wide handler (not nested in an array item) — that one becomes an `output()`
 * (`homeClick`), matching how `SplitButton`'s direct handler props became outputs.
 *
 * Maps 1:1 to "Index/Navigation/Breadcrumb/*" tokens — see packages/tokens/tokens/components/navigation.json
 * in design_system (React reference repo, read only).
 */
class SocBreadcrumb {
    items = input.required();
    truncated = input(false, { transform: booleanAttribute });
    homeClick = output();
    iconThickness = 'var(--index-navigation-breadcrumb-icon-thickness)';
    visibleItems = computed(() => {
        const all = this.items();
        return this.truncated() && all.length > 2 ? all.slice(-2) : all;
    });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocBreadcrumb, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocBreadcrumb, isStandalone: true, selector: "soc-breadcrumb", inputs: { items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: true, transformFunction: null }, truncated: { classPropertyName: "truncated", publicName: "truncated", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { homeClick: "homeClick" }, host: { attributes: { "role": "navigation", "aria-label": "Fil d'Ariane" }, classAttribute: "flex items-center gap-[var(--index-navigation-breadcrumb-item-gap)]" }, ngImport: i0, template: `
    <button
      type="button"
      (click)="homeClick.emit()"
      aria-label="Accueil"
      class="flex cursor-pointer items-center rounded px-[var(--index-navigation-breadcrumb-pad-h)] py-[var(--index-navigation-breadcrumb-pad-v)] text-[var(--index-navigation-breadcrumb-icon-default)] hover:text-[var(--index-navigation-breadcrumb-icon-hover)]"
    >
      <span class="size-[var(--index-navigation-breadcrumb-icon-size)]">
        <svg lucideHouse class="size-full" [strokeWidth]="iconThickness"></svg>
      </span>
    </button>

    @if (visibleItems().length > 0) {
      <ng-container [ngTemplateOutlet]="chevron" />
    }

    @if (truncated() && items().length > 2) {
      <span class="flex items-center px-[var(--index-navigation-breadcrumb-pad-h)] py-[var(--index-navigation-breadcrumb-pad-v)] text-[var(--index-navigation-breadcrumb-icon-default)]">
        <span class="size-[var(--index-navigation-breadcrumb-icon-size)]">
          <svg lucideMoreHorizontal class="size-full" [strokeWidth]="iconThickness"></svg>
        </span>
      </span>
      <ng-container [ngTemplateOutlet]="chevron" />
    }

    @for (item of visibleItems(); track item.label + $index) {
      <div class="flex items-center gap-[var(--index-navigation-breadcrumb-item-gap)]">
        @if ($index === visibleItems().length - 1) {
          <span class="rounded px-[var(--index-navigation-breadcrumb-pad-h)] py-[var(--index-navigation-breadcrumb-pad-v)] [font-family:var(--index-navigation-breadcrumb-font-family)] [font-weight:var(--index-navigation-breadcrumb-font-weight-pressed)] text-[length:var(--index-navigation-breadcrumb-font-size)] text-[var(--index-navigation-breadcrumb-text-pressed)]">
            {{ item.label }}
          </span>
        } @else {
          <button type="button" (click)="item.onClick?.()" class="cursor-pointer rounded px-[var(--index-navigation-breadcrumb-pad-h)] py-[var(--index-navigation-breadcrumb-pad-v)] [font-family:var(--index-navigation-breadcrumb-font-family)] [font-weight:var(--index-navigation-breadcrumb-font-weight-default)] text-[length:var(--index-navigation-breadcrumb-font-size)] text-[var(--index-navigation-breadcrumb-text-default)] hover:text-[var(--index-navigation-breadcrumb-text-hover)]">
            {{ item.label }}
          </button>
        }
        @if ($index !== visibleItems().length - 1) {
          <ng-container [ngTemplateOutlet]="chevron" />
        }
      </div>
    }

    <ng-template #chevron>
      <span class="size-[var(--index-navigation-breadcrumb-icon-size)] shrink-0 text-[var(--index-navigation-breadcrumb-chevron-color)]">
        <svg lucideChevronRight class="size-full" [strokeWidth]="iconThickness"></svg>
      </span>
    </ng-template>
  `, isInline: true, dependencies: [{ kind: "component", type: LucideChevronRight, selector: "svg[lucideChevronRight]" }, { kind: "component", type: LucideHouse, selector: "svg[lucideHouse], svg[lucideHome]" }, { kind: "component", type: LucideMoreHorizontal, selector: "svg[lucideEllipsis], svg[lucideMoreHorizontal]" }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocBreadcrumb, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-breadcrumb',
                    standalone: true,
                    imports: [LucideChevronRight, LucideHouse, LucideMoreHorizontal, NgTemplateOutlet],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        class: 'flex items-center gap-[var(--index-navigation-breadcrumb-item-gap)]',
                        role: 'navigation',
                        'aria-label': "Fil d'Ariane",
                    },
                    template: `
    <button
      type="button"
      (click)="homeClick.emit()"
      aria-label="Accueil"
      class="flex cursor-pointer items-center rounded px-[var(--index-navigation-breadcrumb-pad-h)] py-[var(--index-navigation-breadcrumb-pad-v)] text-[var(--index-navigation-breadcrumb-icon-default)] hover:text-[var(--index-navigation-breadcrumb-icon-hover)]"
    >
      <span class="size-[var(--index-navigation-breadcrumb-icon-size)]">
        <svg lucideHouse class="size-full" [strokeWidth]="iconThickness"></svg>
      </span>
    </button>

    @if (visibleItems().length > 0) {
      <ng-container [ngTemplateOutlet]="chevron" />
    }

    @if (truncated() && items().length > 2) {
      <span class="flex items-center px-[var(--index-navigation-breadcrumb-pad-h)] py-[var(--index-navigation-breadcrumb-pad-v)] text-[var(--index-navigation-breadcrumb-icon-default)]">
        <span class="size-[var(--index-navigation-breadcrumb-icon-size)]">
          <svg lucideMoreHorizontal class="size-full" [strokeWidth]="iconThickness"></svg>
        </span>
      </span>
      <ng-container [ngTemplateOutlet]="chevron" />
    }

    @for (item of visibleItems(); track item.label + $index) {
      <div class="flex items-center gap-[var(--index-navigation-breadcrumb-item-gap)]">
        @if ($index === visibleItems().length - 1) {
          <span class="rounded px-[var(--index-navigation-breadcrumb-pad-h)] py-[var(--index-navigation-breadcrumb-pad-v)] [font-family:var(--index-navigation-breadcrumb-font-family)] [font-weight:var(--index-navigation-breadcrumb-font-weight-pressed)] text-[length:var(--index-navigation-breadcrumb-font-size)] text-[var(--index-navigation-breadcrumb-text-pressed)]">
            {{ item.label }}
          </span>
        } @else {
          <button type="button" (click)="item.onClick?.()" class="cursor-pointer rounded px-[var(--index-navigation-breadcrumb-pad-h)] py-[var(--index-navigation-breadcrumb-pad-v)] [font-family:var(--index-navigation-breadcrumb-font-family)] [font-weight:var(--index-navigation-breadcrumb-font-weight-default)] text-[length:var(--index-navigation-breadcrumb-font-size)] text-[var(--index-navigation-breadcrumb-text-default)] hover:text-[var(--index-navigation-breadcrumb-text-hover)]">
            {{ item.label }}
          </button>
        }
        @if ($index !== visibleItems().length - 1) {
          <ng-container [ngTemplateOutlet]="chevron" />
        }
      </div>
    }

    <ng-template #chevron>
      <span class="size-[var(--index-navigation-breadcrumb-icon-size)] shrink-0 text-[var(--index-navigation-breadcrumb-chevron-color)]">
        <svg lucideChevronRight class="size-full" [strokeWidth]="iconThickness"></svg>
      </span>
    </ng-template>
  `,
                }]
        }] });

/**
 * Marks the element projected into `SocButton`'s leading icon slot (`<ng-content
 * select="[socButtonLeftIcon]">`) — see `SocButtonRightIcon` for the trailing one. Angular's
 * equivalent of React `Button`'s `leftIcon?: ReactNode` prop: the consumer supplies their own icon
 * (in `currentColor`), this component never draws one itself. A plain marker, not a real directive
 * behavior — only its selector matters, for `<ng-content>` routing and presence detection via
 * `contentChild()`.
 */
class SocButtonLeftIcon {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocButtonLeftIcon, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocButtonLeftIcon, isStandalone: true, selector: "[socButtonLeftIcon]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocButtonLeftIcon, decorators: [{
            type: Directive,
            args: [{ selector: '[socButtonLeftIcon]', standalone: true }]
        }] });
/** Trailing icon slot — see `SocButtonLeftIcon`. React `Button`'s `rightIcon?: ReactNode`. */
class SocButtonRightIcon {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocButtonRightIcon, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocButtonRightIcon, isStandalone: true, selector: "[socButtonRightIcon]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocButtonRightIcon, decorators: [{
            type: Directive,
            args: [{ selector: '[socButtonRightIcon]', standalone: true }]
        }] });
/**
 * Class names below must stay as literal strings (no template-built class names) — Tailwind's
 * compiler scans source text statically and can't see classes assembled at runtime. Each one maps
 * 1:1 to an "Index/Button/Button/*" or "Index/Button/Split/*" token from
 * packages/tokens/tokens/components/button.json in design_system (the React reference repo, read
 * only). Exported so `SocSplitButton` shares the exact same variant styling — mirrors React
 * `Button.tsx`'s own exported class maps verbatim.
 */
const buttonPaddingClasses = {
    sm: 'gap-[var(--index-button-button-gap-sm)] px-[var(--index-button-button-padding-h-sm)] py-[var(--index-button-button-padding-v-sm)]',
    lg: 'gap-[var(--index-button-button-gap-lg)] px-[var(--index-button-button-padding-h-lg)] py-[var(--index-button-button-padding-v-lg)]',
};
const buttonRadiusClasses = {
    sm: 'rounded-[var(--index-button-button-radius-sm)]',
    lg: 'rounded-[var(--index-button-button-radius-lg)]',
};
const buttonRadiusLeftClasses = {
    sm: 'rounded-l-[var(--index-button-button-radius-sm)]',
    lg: 'rounded-l-[var(--index-button-button-radius-lg)]',
};
const buttonRadiusRightClasses = {
    sm: 'rounded-r-[var(--index-button-button-radius-sm)]',
    lg: 'rounded-r-[var(--index-button-button-radius-lg)]',
};
const buttonTypographyClass = '[font-family:var(--index-button-button-text-font-family)] [font-weight:var(--index-button-button-text-font-weight)] text-[length:var(--index-button-button-text-size)]';
const buttonVariantClasses = {
    primary: 'bg-[var(--index-button-button-bg-primary-default)] text-[var(--index-button-button-text-on-fill)] hover:bg-[var(--index-button-button-bg-primary-hover)] active:bg-[var(--index-button-button-bg-primary-pressed)] disabled:bg-[var(--index-button-button-bg-primary-disabled)] disabled:text-[var(--index-button-button-text-disabled)]',
    secondary: 'bg-[var(--index-button-button-bg-secondary-default)] text-[var(--index-button-button-text-default)] hover:bg-[var(--index-button-button-bg-secondary-hover)] active:bg-[var(--index-button-button-bg-secondary-pressed)] disabled:bg-[var(--index-button-button-bg-secondary-disabled)] disabled:text-[var(--index-button-button-text-disabled)]',
    tertiary: 'border-[length:var(--index-button-button-stroke-width)] border-[var(--index-button-button-stroke-tertiary)] bg-[var(--index-button-button-bg-tertiary-default)] text-[var(--index-button-button-text-default)] hover:bg-[var(--index-button-button-bg-tertiary-hover)] active:bg-[var(--index-button-button-bg-tertiary-pressed)] disabled:bg-[var(--index-button-button-bg-tertiary-disabled)] disabled:border-[var(--index-button-button-stroke-tertiary-disabled)] disabled:text-[var(--index-button-button-text-disabled)]',
    danger: 'bg-[var(--index-button-button-bg-danger-default)] text-[var(--index-button-button-text-on-fill)] hover:bg-[var(--index-button-button-bg-danger-hover)] active:bg-[var(--index-button-button-bg-danger-pressed)] disabled:bg-[var(--index-button-button-bg-danger-disabled)] disabled:text-[var(--index-button-button-text-disabled)]',
    ghost: 'bg-transparent text-[var(--index-button-button-text-action)] hover:bg-[var(--index-button-button-bg-ghost-hover)] hover:text-[var(--index-button-button-text-action-hover)] active:bg-[var(--index-button-button-bg-ghost-pressed)] disabled:bg-transparent disabled:text-[var(--index-button-button-text-disabled)]',
};
/** Both dimensions bind to the same token — `Button.tsx`'s `buttonIconSizeStyle` has `width` and
 * `height` set to the identical `var(--index-button-button-icon-size)` value. */
const buttonIconSizeVar = 'var(--index-button-button-icon-size)';
const sizeClasses$1 = {
    sm: `${buttonPaddingClasses.sm} ${buttonRadiusClasses.sm}`,
    lg: `${buttonPaddingClasses.lg} ${buttonRadiusClasses.lg}`,
};
/**
 * Attribute selector on a real `<button>` — not a wrapper component — so native attributes and
 * events (`type`, `[disabled]`, `(click)`, `aria-label`, …) just work as plain HTML on the host
 * element, the Angular equivalent of React `Button`'s `...props` spread onto its own `<button>`.
 * No `output()`/`input()` re-declares any of them. See this repo's CLAUDE.md, "Attribute-selector
 * components" — the pattern to reuse for every future component wrapping a single native
 * interactive element (InputText, Checkbox, RadioButton, Switch…).
 *
 * `[class]` merges with any static `class` a consumer adds directly on the same `<button socButton
 * class="...">` — Angular composes host class bindings with a literal class attribute rather than
 * one overwriting the other, so there's no separate `className`-style input to accept and merge by
 * hand the way React's version needs one.
 */
class SocButton {
    variant = input('primary');
    size = input('sm');
    iconSize = buttonIconSizeVar;
    leftIconContent = contentChild(SocButtonLeftIcon);
    rightIconContent = contentChild(SocButtonRightIcon);
    hasLeftIcon = computed(() => !!this.leftIconContent());
    hasRightIcon = computed(() => !!this.rightIconContent());
    hostClasses = computed(() => `group inline-flex items-center justify-center whitespace-nowrap transition-colors disabled:cursor-not-allowed ${buttonTypographyClass} ${sizeClasses$1[this.size()]} ${buttonVariantClasses[this.variant()]}`);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocButton, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocButton, isStandalone: true, selector: "button[socButton]", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, queries: [{ propertyName: "leftIconContent", first: true, predicate: SocButtonLeftIcon, descendants: true, isSignal: true }, { propertyName: "rightIconContent", first: true, predicate: SocButtonRightIcon, descendants: true, isSignal: true }], ngImport: i0, template: `
    @if (hasLeftIcon()) {
      <span
        class="shrink-0 group-disabled:text-[var(--index-button-button-icon-disabled)]"
        [style.width]="iconSize"
        [style.height]="iconSize"
      >
        <ng-content select="[socButtonLeftIcon]" />
      </span>
    }
    <ng-content />
    @if (hasRightIcon()) {
      <span
        class="shrink-0 group-disabled:text-[var(--index-button-button-icon-disabled)]"
        [style.width]="iconSize"
        [style.height]="iconSize"
      >
        <ng-content select="[socButtonRightIcon]" />
      </span>
    }
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocButton, decorators: [{
            type: Component,
            args: [{
                    selector: 'button[socButton]',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    // Tailwind utility classes are global by design (one `.inline-flex` rule reused everywhere) —
                    // incompatible with Angular's default emulated encapsulation, which rewrites every selector in
                    // `styleUrl` to only match elements carrying its own auto-generated `_ngcontent-*` attribute.
                    // That rewritten selector never matches this component's own HOST element (`[class]` above
                    // targets the host directly, and the host gets `_nghost-*`, not `_ngcontent-*`) — verified this
                    // was silently eating every utility class before adding this. See CLAUDE.md's
                    // "ViewEncapsulation.None for Tailwind-styled components" convention.
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[class]': 'hostClasses()',
                    },
                    template: `
    @if (hasLeftIcon()) {
      <span
        class="shrink-0 group-disabled:text-[var(--index-button-button-icon-disabled)]"
        [style.width]="iconSize"
        [style.height]="iconSize"
      >
        <ng-content select="[socButtonLeftIcon]" />
      </span>
    }
    <ng-content />
    @if (hasRightIcon()) {
      <span
        class="shrink-0 group-disabled:text-[var(--index-button-button-icon-disabled)]"
        [style.width]="iconSize"
        [style.height]="iconSize"
      >
        <ng-content select="[socButtonRightIcon]" />
      </span>
    }
  `,
                }]
        }] });

/** Maps 1:1 to "Index/Button/Split/*" tokens — see packages/tokens/tokens/components/button.json
 * in design_system (React reference repo, read only). */
const dividerClasses = {
    primary: 'bg-[var(--index-button-split-divider-primary)]',
    secondary: 'bg-[var(--index-button-split-divider-secondary)]',
    tertiary: 'bg-[var(--index-button-split-divider-tertiary)]',
    danger: 'bg-[var(--index-button-split-divider-danger)]',
    ghost: 'bg-[var(--index-button-split-divider-ghost)]',
};
const chevronColorVar = {
    primary: 'var(--index-button-split-chevron-color-primary)',
    secondary: 'var(--index-button-split-chevron-color-secondary)',
    tertiary: 'var(--index-button-split-chevron-color-tertiary)',
    danger: 'var(--index-button-split-chevron-color-danger)',
    ghost: 'var(--index-button-split-chevron-color-ghost)',
};
/**
 * Two real `<button>` elements internally (main action + dropdown trigger) — unlike `SocButton`,
 * this can't be a bare attribute selector: its host isn't itself a single clickable button, so
 * native `(click)` doesn't just pass through one level. Exposes `click`/`triggerClick` outputs
 * explicitly instead — matches React `SplitButtonProps` already being its own type rather than
 * extending `ButtonProps`, and its `onClick`/`onTriggerClick` being two distinct handlers.
 *
 * Reuses `SocButtonLeftIcon` from `./button` for its leading icon slot (React `SplitButton` only
 * has a `leftIcon` prop, no `rightIcon`) — same content-projection mechanism as `SocButton`, one
 * marker directive shared between both instead of a second one that would behave identically.
 *
 * The chevron is the one icon this component draws itself (`ChevronDown`, via `@lucide/angular` —
 * Angular's equivalent of `lucide-react`, already a dependency of `design_system`) — React
 * `SplitButton.tsx` does the same with `lucide-react`'s `ChevronDown`, nothing for a consumer to
 * project there.
 */
class SocSplitButton {
    variant = input('primary');
    size = input('sm');
    disabled = input(false, { transform: booleanAttribute });
    triggerLabel = input("Plus d'options");
    click = output();
    triggerClick = output();
    iconSize = buttonIconSizeVar;
    dividerWidth = 'var(--index-button-split-divider-width)';
    splitPad = 'var(--index-button-split-split-pad)';
    chevronSize = 'var(--index-button-split-chevron-size)';
    chevronThickness = 'var(--index-button-split-chevron-thickness)';
    leftIconContent = contentChild(SocButtonLeftIcon);
    hasLeftIcon = computed(() => !!this.leftIconContent());
    mainButtonClasses = computed(() => `group inline-flex items-center justify-center whitespace-nowrap transition-colors disabled:cursor-not-allowed ${buttonTypographyClass} ${buttonPaddingClasses[this.size()]} ${buttonRadiusLeftClasses[this.size()]} ${buttonVariantClasses[this.variant()]}`);
    triggerButtonClasses = computed(() => `inline-flex items-center justify-center transition-colors disabled:cursor-not-allowed ${buttonRadiusRightClasses[this.size()]} ${buttonVariantClasses[this.variant()]}`);
    dividerClass = computed(() => dividerClasses[this.variant()]);
    chevronColor = computed(() => this.disabled() ? 'var(--index-button-split-chevron-color-disabled)' : chevronColorVar[this.variant()]);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocSplitButton, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocSplitButton, isStandalone: true, selector: "soc-split-button", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, triggerLabel: { classPropertyName: "triggerLabel", publicName: "triggerLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { click: "click", triggerClick: "triggerClick" }, host: { classAttribute: "inline-flex items-stretch" }, queries: [{ propertyName: "leftIconContent", first: true, predicate: SocButtonLeftIcon, descendants: true, isSignal: true }], ngImport: i0, template: `
    <button
      type="button"
      [disabled]="disabled()"
      (click)="click.emit($event)"
      [class]="mainButtonClasses()"
    >
      @if (hasLeftIcon()) {
        <span
          class="shrink-0 group-disabled:text-[var(--index-button-button-icon-disabled)]"
          [style.width]="iconSize"
          [style.height]="iconSize"
        >
          <ng-content select="[socButtonLeftIcon]" />
        </span>
      }
      <ng-content />
    </button>

    <span aria-hidden="true" [class]="dividerClass()" [style.width]="dividerWidth"></span>

    <button
      type="button"
      [attr.aria-label]="triggerLabel()"
      [disabled]="disabled()"
      (click)="triggerClick.emit($event)"
      [class]="triggerButtonClasses()"
      [style.padding]="splitPad"
    >
      <span class="shrink-0" [style.width]="chevronSize" [style.height]="chevronSize" [style.color]="chevronColor()">
        <svg lucideChevronDown class="size-full" [strokeWidth]="chevronThickness"></svg>
      </span>
    </button>
  `, isInline: true, dependencies: [{ kind: "component", type: LucideChevronDown, selector: "svg[lucideChevronDown]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocSplitButton, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-split-button',
                    standalone: true,
                    imports: [LucideChevronDown],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    // See SocButton's own docstring for why — same Tailwind-vs-emulated-encapsulation mismatch.
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        class: 'inline-flex items-stretch',
                    },
                    template: `
    <button
      type="button"
      [disabled]="disabled()"
      (click)="click.emit($event)"
      [class]="mainButtonClasses()"
    >
      @if (hasLeftIcon()) {
        <span
          class="shrink-0 group-disabled:text-[var(--index-button-button-icon-disabled)]"
          [style.width]="iconSize"
          [style.height]="iconSize"
        >
          <ng-content select="[socButtonLeftIcon]" />
        </span>
      }
      <ng-content />
    </button>

    <span aria-hidden="true" [class]="dividerClass()" [style.width]="dividerWidth"></span>

    <button
      type="button"
      [attr.aria-label]="triggerLabel()"
      [disabled]="disabled()"
      (click)="triggerClick.emit($event)"
      [class]="triggerButtonClasses()"
      [style.padding]="splitPad"
    >
      <span class="shrink-0" [style.width]="chevronSize" [style.height]="chevronSize" [style.color]="chevronColor()">
        <svg lucideChevronDown class="size-full" [strokeWidth]="chevronThickness"></svg>
      </span>
    </button>
  `,
                }]
        }] });

const CARD_GRID_CONTEXT = new InjectionToken('CARD_GRID_CONTEXT');

/** Content slots — React's `icon`/`actionSlot`/`footer` (all `ReactNode`) and `children`. `children`
 * stays the default unnamed `<ng-content>` (there's no ambiguity with the other three, all named). */
class SocCardIcon {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocCardIcon, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocCardIcon, isStandalone: true, selector: "[socCardIcon]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocCardIcon, decorators: [{
            type: Directive,
            args: [{ selector: '[socCardIcon]', standalone: true }]
        }] });
class SocCardActionSlot {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocCardActionSlot, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocCardActionSlot, isStandalone: true, selector: "[socCardActionSlot]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocCardActionSlot, decorators: [{
            type: Directive,
            args: [{ selector: '[socCardActionSlot]', standalone: true }]
        }] });
class SocCardFooter {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocCardFooter, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocCardFooter, isStandalone: true, selector: "[socCardFooter]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocCardFooter, decorators: [{
            type: Directive,
            args: [{ selector: '[socCardFooter]', standalone: true }]
        }] });
const colSpanClasses = { 1: 'col-span-1', 2: 'col-span-2', 3: 'col-span-3' };
const rowSpanClasses = { 1: 'row-span-1', 2: 'row-span-2' };
// A Card inside a `soc-card-grid` in "bento" mode never occupies more than 75% of its row —
// the base (2-column) tier's ceiling is always 1 (floor(2 * 0.75)), so every other tier's clamp is
// a responsive override on top of that shared `col-span-1` floor. Ported 1:1 from React
// CardGrid.tsx's BENTO_COLSPAN_75PCT_OVERRIDE; see that component's docstring for the full rule.
const BENTO_COLSPAN_75PCT_OVERRIDE = {
    2: '@min-[600px]:col-span-2',
    3: '@min-[600px]:col-span-2 @min-[900px]:col-span-3',
};
/**
 * No native HTML equivalent — plain wrapper (`soc-card`). Maps 1:1 to "Index/Conteneur/Card/*"
 * tokens — see packages/tokens/tokens/components/conteneur.json in design_system (React reference
 * repo, read only). `colSpan`/`rowSpan` only matter inside a `soc-card-grid` in `mode="bento"` —
 * see that component's own docstring for the 75%-of-row clamp rule. The *rendered* span is resolved
 * here from `CARD_GRID_CONTEXT` (see `internal/card-grid-context.ts`), because React's
 * `cloneElement` rewrite of a child's props has no Angular equivalent; a card with no grid ancestor
 * renders exactly the span it was given, same as React.
 *
 * `children` presence (`{children && <div>...}` in React) is checked via a content query — Angular
 * has no direct way to ask "was any content passed to the default `<ng-content>` slot", so this
 * uses `contentChild` against a broad marker... actually, kept simpler: unlike named slots, the
 * default slot's presence can't be queried the same way, so the content wrapper always renders
 * (an empty content region is harmless — no min-height without content, `min-h-0` already handles
 * that) rather than reproducing the exact conditional. Documented here since it's a deliberate,
 * minor behavior difference, not an oversight.
 */
class SocCard {
    title = input.required();
    subtitle = input();
    type = input('default');
    colSpan = input(1);
    rowSpan = input(1);
    action = output();
    cardClick = output();
    actionIconThickness = 'var(--index-conteneur-card-action-icon-thickness)';
    iconContent = contentChild(SocCardIcon);
    actionSlotContent = contentChild(SocCardActionSlot);
    footerContent = contentChild(SocCardFooter);
    hasIcon = computed(() => !!this.iconContent());
    hasActionSlot = computed(() => !!this.actionSlotContent());
    hasFooter = computed(() => !!this.footerContent());
    handleActionClick(event) {
        event.stopPropagation();
        this.action.emit();
    }
    handleHostClick() {
        if (this.type() === 'selectable')
            this.cardClick.emit();
    }
    // Present only when this card is declared inside a `soc-card-grid` (React: that grid cloned the
    // child with overridden props; here the card applies the same rules to itself).
    grid = inject(CARD_GRID_CONTEXT, { optional: true });
    placement = computed(() => {
        const requestedColSpan = this.colSpan();
        const requestedRowSpan = this.rowSpan();
        if (!this.grid)
            return { colSpan: requestedColSpan, rowSpan: requestedRowSpan, extraClass: '' };
        // "fixed": force 1×1 regardless of what the card was given — no card may claim more than a
        // single cell, so every row stays perfectly uniform.
        if (this.grid.mode() === 'fixed')
            return { colSpan: 1, rowSpan: 1, extraClass: '' };
        const columns = this.grid.columns();
        if (columns != null) {
            const ceiling = Math.max(1, Math.floor(columns * 0.75));
            return { colSpan: Math.max(1, Math.min(requestedColSpan, ceiling)), rowSpan: requestedRowSpan, extraClass: '' };
        }
        if (requestedColSpan === 1)
            return { colSpan: 1, rowSpan: requestedRowSpan, extraClass: '' }; // always within the 75% ceiling
        return { colSpan: 1, rowSpan: requestedRowSpan, extraClass: BENTO_COLSPAN_75PCT_OVERRIDE[requestedColSpan] };
    });
    hostClasses = computed(() => {
        const selectable = this.type() === 'selectable';
        const { colSpan, rowSpan, extraClass } = this.placement();
        return `flex w-full min-w-0 flex-col items-start rounded-[var(--index-conteneur-card-radius)] border-[length:var(--index-conteneur-card-border-width)] border-[var(--index-conteneur-card-border)] bg-[var(--index-conteneur-card-bg)] ${selectable ? 'cursor-pointer hover:bg-[var(--index-conteneur-card-hover-bg)]' : ''} ${colSpanClasses[colSpan]} ${rowSpanClasses[rowSpan]} ${extraClass}`;
    });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocCard, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocCard, isStandalone: true, selector: "soc-card", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, subtitle: { classPropertyName: "subtitle", publicName: "subtitle", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, colSpan: { classPropertyName: "colSpan", publicName: "colSpan", isSignal: true, isRequired: false, transformFunction: null }, rowSpan: { classPropertyName: "rowSpan", publicName: "rowSpan", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { action: "action", cardClick: "cardClick" }, host: { listeners: { "click": "handleHostClick()" }, properties: { "class": "hostClasses()" } }, queries: [{ propertyName: "iconContent", first: true, predicate: SocCardIcon, descendants: true, isSignal: true }, { propertyName: "actionSlotContent", first: true, predicate: SocCardActionSlot, descendants: true, isSignal: true }, { propertyName: "footerContent", first: true, predicate: SocCardFooter, descendants: true, isSignal: true }], ngImport: i0, template: `
    <div class="flex w-full items-start justify-between gap-[var(--index-conteneur-card-icon-gap)] px-[var(--index-conteneur-card-header-pad)] pt-[var(--index-conteneur-card-header-pad)]">
      <div class="flex min-w-0 flex-1 items-center gap-[var(--index-conteneur-card-icon-gap)]">
        @if (hasIcon()) {
          <span class="flex size-[34px] shrink-0 items-center justify-center rounded-[var(--index-conteneur-card-iconarea-bg-radius)] bg-[var(--index-conteneur-card-iconarea-bg)]">
            <span class="size-[var(--index-conteneur-card-iconarea-icon-size)] text-[var(--index-conteneur-card-iconarea-icon-color)]">
              <ng-content select="[socCardIcon]" />
            </span>
          </span>
        }
        <div class="flex min-w-0 flex-1 flex-col items-start">
          <p class="w-full truncate text-[length:var(--index-conteneur-card-title-size)] text-[var(--index-conteneur-card-title-color)] [font-family:var(--index-conteneur-card-title-font)] [font-weight:var(--index-conteneur-card-title-weight)]">
            {{ title() }}
          </p>
          @if (subtitle()) {
            <p class="w-full truncate text-[length:var(--index-conteneur-card-subtitle-size)] text-[var(--index-conteneur-card-subtitle-color)] [font-family:var(--index-conteneur-card-subtitle-font)] [font-weight:var(--index-conteneur-card-subtitle-weight)]">
              {{ subtitle() }}
            </p>
          }
        </div>
      </div>
      @if (hasActionSlot()) {
        <ng-content select="[socCardActionSlot]" />
      } @else {
        <button
          type="button"
          (click)="handleActionClick($event)"
          aria-label="Actions"
          class="flex size-[24px] shrink-0 items-center justify-center rounded-[var(--index-conteneur-card-action-radius)] px-[var(--index-conteneur-card-action-pad-h)] py-[var(--index-conteneur-card-action-pad-v)] hover:bg-[var(--index-conteneur-card-action-bg-hover)]"
        >
          <svg
            lucideMoreHorizontal
            class="size-[var(--index-conteneur-card-action-icon-size)] text-[var(--index-conteneur-card-action-icon-color)]"
            [strokeWidth]="actionIconThickness"
          ></svg>
        </button>
      }
    </div>

    <div class="flex min-h-0 w-full flex-1 flex-col items-start px-[var(--index-conteneur-card-content-pad-h)] py-[var(--index-conteneur-card-content-pad-v)]">
      <ng-content />
    </div>

    @if (hasFooter()) {
      <div class="flex h-[34px] w-full shrink-0 flex-col items-start px-[var(--index-conteneur-card-footer-pad)] pb-[var(--index-conteneur-card-footer-pad)]">
        <ng-content select="[socCardFooter]" />
      </div>
    }
  `, isInline: true, dependencies: [{ kind: "component", type: LucideMoreHorizontal, selector: "svg[lucideEllipsis], svg[lucideMoreHorizontal]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocCard, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-card',
                    standalone: true,
                    imports: [LucideMoreHorizontal, SocCardIcon, SocCardActionSlot, SocCardFooter],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[class]': 'hostClasses()',
                        '(click)': 'handleHostClick()',
                    },
                    template: `
    <div class="flex w-full items-start justify-between gap-[var(--index-conteneur-card-icon-gap)] px-[var(--index-conteneur-card-header-pad)] pt-[var(--index-conteneur-card-header-pad)]">
      <div class="flex min-w-0 flex-1 items-center gap-[var(--index-conteneur-card-icon-gap)]">
        @if (hasIcon()) {
          <span class="flex size-[34px] shrink-0 items-center justify-center rounded-[var(--index-conteneur-card-iconarea-bg-radius)] bg-[var(--index-conteneur-card-iconarea-bg)]">
            <span class="size-[var(--index-conteneur-card-iconarea-icon-size)] text-[var(--index-conteneur-card-iconarea-icon-color)]">
              <ng-content select="[socCardIcon]" />
            </span>
          </span>
        }
        <div class="flex min-w-0 flex-1 flex-col items-start">
          <p class="w-full truncate text-[length:var(--index-conteneur-card-title-size)] text-[var(--index-conteneur-card-title-color)] [font-family:var(--index-conteneur-card-title-font)] [font-weight:var(--index-conteneur-card-title-weight)]">
            {{ title() }}
          </p>
          @if (subtitle()) {
            <p class="w-full truncate text-[length:var(--index-conteneur-card-subtitle-size)] text-[var(--index-conteneur-card-subtitle-color)] [font-family:var(--index-conteneur-card-subtitle-font)] [font-weight:var(--index-conteneur-card-subtitle-weight)]">
              {{ subtitle() }}
            </p>
          }
        </div>
      </div>
      @if (hasActionSlot()) {
        <ng-content select="[socCardActionSlot]" />
      } @else {
        <button
          type="button"
          (click)="handleActionClick($event)"
          aria-label="Actions"
          class="flex size-[24px] shrink-0 items-center justify-center rounded-[var(--index-conteneur-card-action-radius)] px-[var(--index-conteneur-card-action-pad-h)] py-[var(--index-conteneur-card-action-pad-v)] hover:bg-[var(--index-conteneur-card-action-bg-hover)]"
        >
          <svg
            lucideMoreHorizontal
            class="size-[var(--index-conteneur-card-action-icon-size)] text-[var(--index-conteneur-card-action-icon-color)]"
            [strokeWidth]="actionIconThickness"
          ></svg>
        </button>
      }
    </div>

    <div class="flex min-h-0 w-full flex-1 flex-col items-start px-[var(--index-conteneur-card-content-pad-h)] py-[var(--index-conteneur-card-content-pad-v)]">
      <ng-content />
    </div>

    @if (hasFooter()) {
      <div class="flex h-[34px] w-full shrink-0 flex-col items-start px-[var(--index-conteneur-card-footer-pad)] pb-[var(--index-conteneur-card-footer-pad)]">
        <ng-content select="[socCardFooter]" />
      </div>
    }
  `,
                }]
        }] });

/** Registers a component as its own `ControlValueAccessor` (`formControl`, `formControlName`,
 * `ngModel`). `type` is a thunk because the class isn't defined yet where the decorator runs. */
function provideFormControl(type) {
    return { provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(type), multi: true };
}
/** Keeps `attrs()` applied on the element returned by `element()`; call from an injection context. */
function syncNativeAttributes(element, attrs) {
    let applied = new Set();
    effect(() => {
        const el = element();
        if (!el)
            return;
        const next = attrs() ?? {};
        for (const key of applied)
            if (!(key in next))
                el.removeAttribute(key);
        applied = new Set();
        for (const [key, value] of Object.entries(next)) {
            if (value == null || value === false)
                el.removeAttribute(key);
            else
                el.setAttribute(key, value === true ? '' : String(value));
            applied.add(key);
        }
    });
}
/**
 * Turns a component whose value already lives in a `model()` into a form control.
 *
 * The model stays the single source of truth (so `[(value)]`/`[(checked)]` keep working exactly as
 * before): `writeValue` sets it with change notification muted, and every *other* write — i.e. a user
 * interaction — is forwarded to the form through the model's own change stream. No template needs to
 * call `onChange` by hand; only `onTouched` is wired to blur/close where it makes sense.
 *
 * `disabled` is the plain input (`[disabled]="x"` or the bare attribute); `isDisabled()` combines it with
 * the state the form writes through `setDisabledState` — templates and computed classes read that one.
 */
class SocFormControl {
    /** `[disabled]` / bare `disabled` attribute. (An `input()` rather than a `model()` so the bare-attribute
     * form works — models can't take a transform.) Templates read `isDisabled()`, not this. */
    disabled = input(false, { transform: booleanAttribute });
    formDisabled = signal(false);
    /** The input OR'ed with the state the form writes through `setDisabledState`. */
    isDisabled = computed(() => this.disabled() || this.formDisabled());
    onTouched = () => { };
    writing = false;
    subscription;
    writeValue(value) {
        this.writing = true;
        try {
            this.valueModel.set(this.coerce(value));
        }
        finally {
            this.writing = false;
        }
    }
    registerOnChange(fn) {
        this.subscription?.unsubscribe();
        this.subscription = this.valueModel.subscribe((value) => {
            if (!this.writing)
                fn(value);
        });
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.formDisabled.set(isDisabled);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocFormControl, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "19.2.25", type: SocFormControl, isStandalone: true, inputs: { disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocFormControl, decorators: [{
            type: Directive
        }] });
/**
 * Shared surface of the label + bordered field + helper-text inputs (`InputText`, `InputArea`,
 * `InputNumber`, `Password`): everything React gets for free from `InputHTMLAttributes` spread.
 *
 * - dedicated inputs for the common native attributes (`id`, `name`, `autocomplete`, `readonly`);
 * - `inputClass` = React's `className` (lands on the inner control; a plain `class` on the host is
 *   React's `wrapperClassName`);
 * - `inputAttrs` = the escape hatch for every other native attribute.
 *
 * `id`/`name` are meant for the inner control, so the host's own copies are cleared — a static
 * `id="…"`/`name="…"` on `<soc-input-text>` would otherwise be a duplicate DOM id and a bogus
 * attribute on a custom element.
 */
class SocTextFieldBase extends SocFormControl {
    label = input();
    required = input(false, { transform: booleanAttribute });
    error = input(false, { transform: booleanAttribute });
    helperText = input();
    placeholder = input();
    id = input();
    name = input();
    autocomplete = input();
    readonly = input(false, { transform: booleanAttribute });
    inputClass = input();
    inputAttrs = input();
    constructor() {
        super();
        syncNativeAttributes(() => this.nativeField(), () => this.inputAttrs());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocTextFieldBase, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "19.2.25", type: SocTextFieldBase, isStandalone: true, inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, helperText: { classPropertyName: "helperText", publicName: "helperText", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, autocomplete: { classPropertyName: "autocomplete", publicName: "autocomplete", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, inputClass: { classPropertyName: "inputClass", publicName: "inputClass", isSignal: true, isRequired: false, transformFunction: null }, inputAttrs: { classPropertyName: "inputAttrs", publicName: "inputAttrs", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.id": "null", "attr.name": "null" } }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocTextFieldBase, decorators: [{
            type: Directive,
            args: [{ host: { '[attr.id]': 'null', '[attr.name]': 'null' } }]
        }], ctorParameters: () => [] });

let counter = 0;
/** Angular has no built-in equivalent of React's `useId()` — a plain incrementing counter is the
 * common substitute for generating a stable `id`/`for` pair per component instance (e.g. so a
 * `<label>` can target its `<input>` without the consumer having to supply an id themselves). Not
 * SSR-safe against hydration mismatches (React's `useId()` is), but this kit has no SSR consumer
 * today — revisit if one shows up. */
function nextUniqueId(prefix) {
    counter += 1;
    return `${prefix}-${counter}`;
}

/** GAP-DECISION (flagged, not decided silently): the migration spec's rule for Checkbox was
 * "attribute selector on `input[type=checkbox]`". Read the real React source before writing
 * anything — Checkbox.tsx does NOT use a native `<input type="checkbox">` at all: it's a
 * `<button role="checkbox" aria-checked>` wrapped in a `<label>`, with an optional sibling
 * `<span>` for the label text. Same "can't render siblings from inside an attribute selector"
 * problem as InputText's whole family (see that component's own docstring) — the `<label>`
 * wrapper and text span sit OUTSIDE the button. Wrapper component instead (`soc-checkbox`), self-
 * contained the same way React's `Checkbox` is (its own `label` prop, not something the consumer
 * assembles by hand). Same reasoning applies to RadioButton and Switch, not repeated on each.
 *
 * Maps 1:1 to "Index/Contrôleur/Checkbox/*" tokens — see packages/tokens/tokens/components/contrôleur.json
 * in design_system (React reference repo, read only). Figma only defines unchecked/checked (no
 * indeterminate variant yet), same as React.
 */
class SocCheckbox extends SocFormControl {
    checked = model(false);
    valueModel = this.checked;
    coerce(value) {
        return !!value;
    }
    label = input();
    id = input();
    generatedId = nextUniqueId('soc-checkbox');
    get checkboxId() {
        return this.id() ?? this.generatedId;
    }
    toggle() {
        if (this.isDisabled())
            return;
        this.checked.set(!this.checked());
    }
    // Applied to both the host and the inner <label> — this component's host IS effectively the
    // label wrapper (no separate outer element), matching React's own root-is-the-label structure.
    hostClass = computed(() => `inline-flex items-center gap-2 ${this.isDisabled() ? 'cursor-not-allowed' : 'cursor-pointer'}`);
    buttonClass = computed(() => {
        const base = 'group flex shrink-0 items-center justify-center rounded-[var(--index-contrôleur-checkbox-radius)] border-[length:var(--index-contrôleur-checkbox-stroke-weight)] size-[var(--index-contrôleur-checkbox-size)] transition-colors disabled:cursor-not-allowed';
        if (this.isDisabled()) {
            return `${base} ${this.checked()
                ? 'border-[var(--index-contrôleur-checkbox-bg-checked-disabled)] bg-[var(--index-contrôleur-checkbox-bg-checked-disabled)]'
                : 'border-[var(--index-contrôleur-checkbox-stroke-disabled)] bg-[var(--index-contrôleur-checkbox-bg-disabled)]'}`;
        }
        return `${base} ${this.checked()
            ? 'border-[var(--index-contrôleur-checkbox-bg-checked)] bg-[var(--index-contrôleur-checkbox-bg-checked)] hover:border-[var(--index-contrôleur-checkbox-bg-checked-hover)] hover:bg-[var(--index-contrôleur-checkbox-bg-checked-hover)] active:border-[var(--index-contrôleur-checkbox-bg-checked-pressed)] active:bg-[var(--index-contrôleur-checkbox-bg-checked-pressed)]'
            : 'border-[var(--index-contrôleur-checkbox-stroke-default)] bg-[var(--index-contrôleur-checkbox-bg-default)] hover:bg-[var(--index-contrôleur-checkbox-bg-hover)] active:bg-[var(--index-contrôleur-checkbox-bg-pressed)]'}`;
    });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocCheckbox, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocCheckbox, isStandalone: true, selector: "soc-checkbox", inputs: { checked: { classPropertyName: "checked", publicName: "checked", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { checked: "checkedChange" }, host: { properties: { "attr.id": "null" } }, providers: [provideFormControl(() => SocCheckbox)], usesInheritance: true, ngImport: i0, template: `
    <label [for]="checkboxId" [class]="hostClass()">
      <button
        [id]="checkboxId"
        type="button"
        role="checkbox"
        [attr.aria-checked]="checked()"
        [disabled]="isDisabled()"
        (click)="toggle()"
        (blur)="onTouched()"
        [class]="buttonClass()"
      >
        @if (checked()) {
          <svg lucideCheck [class]="isDisabled() ? 'text-[var(--index-contrôleur-checkbox-check-disabled)]' : 'text-[var(--index-contrôleur-checkbox-check-color)]'" [style.width.px]="14" [style.height.px]="14" [strokeWidth]="2.5"></svg>
        }
      </button>
      @if (label()) {
        <span class="text-[var(--bridges-color-text-primary)]">{{ label() }}</span>
      }
    </label>
  `, isInline: true, dependencies: [{ kind: "component", type: LucideCheck, selector: "svg[lucideCheck]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocCheckbox, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-checkbox',
                    standalone: true,
                    imports: [LucideCheck],
                    providers: [provideFormControl(() => SocCheckbox)],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    // `id` targets the inner control (the `<label for>` target), like React — a static `id="…"` on
                    // the element would otherwise also land on this host as a duplicate DOM id.
                    host: { '[attr.id]': 'null' },
                    template: `
    <label [for]="checkboxId" [class]="hostClass()">
      <button
        [id]="checkboxId"
        type="button"
        role="checkbox"
        [attr.aria-checked]="checked()"
        [disabled]="isDisabled()"
        (click)="toggle()"
        (blur)="onTouched()"
        [class]="buttonClass()"
      >
        @if (checked()) {
          <svg lucideCheck [class]="isDisabled() ? 'text-[var(--index-contrôleur-checkbox-check-disabled)]' : 'text-[var(--index-contrôleur-checkbox-check-color)]'" [style.width.px]="14" [style.height.px]="14" [strokeWidth]="2.5"></svg>
        }
      </button>
      @if (label()) {
        <span class="text-[var(--bridges-color-text-primary)]">{{ label() }}</span>
      }
    </label>
  `,
                }]
        }] });

const textSizeClasses = {
    sm: 'text-[length:var(--index-selection-chips-text-size-sm)]',
    lg: 'text-[length:var(--index-selection-chips-text-size-lg)]',
};
const paddingClasses = 'py-[var(--index-selection-chips-pad-v)] pl-[var(--index-selection-chips-pad-h-left)]';
/**
 * React's Chips.tsx exports three components sharing one file — mirrored the same way here rather
 * than splitting into three files, since they share the `ChipsSize` type and padding/text classes.
 * `label` is a plain `string` in all three (not `ReactNode`), so plain `input()`s throughout, no
 * content projection — same reasoning as `DocumentLine`. `onRemove`/`onClick` follow the same
 * split as `Tag`'s `removable`/`remove`: a boolean input controls visibility, an output is the
 * handler (an `output()` can't be introspected for "is anyone listening" the way an optional
 * callback prop can).
 *
 * Maps 1:1 to "Index/Selection/Chips/*" tokens — see packages/tokens/tokens/components/selection.json
 * in design_system (React reference repo, read only).
 */
class SocChips {
    label = input.required();
    size = input('sm');
    removable = input(false, { transform: booleanAttribute });
    remove = output();
    closeIconThickness = 'var(--index-selection-chips-close-icon-thickness)';
    hostClasses = computed(() => `inline-flex items-center gap-[var(--index-selection-chips-gap)] rounded-[var(--index-selection-chips-radius)] bg-[var(--index-selection-chips-bg-default)] pr-[var(--index-selection-chips-pad-h-right)] text-[var(--index-selection-chips-text-color)] [font-family:var(--index-selection-chips-text-font)] [font-weight:var(--index-selection-chips-text-weight)] ${paddingClasses} ${textSizeClasses[this.size()]}`);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocChips, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocChips, isStandalone: true, selector: "soc-chips", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, removable: { classPropertyName: "removable", publicName: "removable", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { remove: "remove" }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0, template: `
    {{ label() }}
    @if (removable()) {
      <button type="button" (click)="remove.emit()" [attr.aria-label]="'Retirer ' + label()" class="shrink-0 size-[var(--index-selection-chips-close-size)] text-[var(--index-selection-chips-icon-close-color)]">
        <svg lucideX class="size-full" [strokeWidth]="closeIconThickness"></svg>
      </button>
    }
  `, isInline: true, dependencies: [{ kind: "component", type: LucideX, selector: "svg[lucideX]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocChips, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-chips',
                    standalone: true,
                    imports: [LucideX],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[class]': 'hostClasses()',
                    },
                    template: `
    {{ label() }}
    @if (removable()) {
      <button type="button" (click)="remove.emit()" [attr.aria-label]="'Retirer ' + label()" class="shrink-0 size-[var(--index-selection-chips-close-size)] text-[var(--index-selection-chips-icon-close-color)]">
        <svg lucideX class="size-full" [strokeWidth]="closeIconThickness"></svg>
      </button>
    }
  `,
                }]
        }] });
/**
 * Maps 1:1 to "Index/Selection/Chips/*" tokens (type=Selectable). Structurally this one IS just a
 * bare `<button>{label}</button>`, same shape as `Button` — could have been an attribute selector.
 * Kept as a wrapper element instead, consistent with the migration spec explicitly categorizing
 * "Chips" (this whole file, all three exports) under the wrapper list rather than the native-
 * element-attribute-selector one, and to stay consistent with its two siblings above/below sharing
 * this same file.
 */
class SocSelectableChips {
    label = input.required();
    size = input('sm');
    selected = input(false, { transform: booleanAttribute });
    // No `click` output: a host listener `(click)` re-emitting an output named `click` subscribes to that
    // same output (Angular resolves a host listener against the host's own outputs first) and recursed
    // until the stack overflowed on every click. The native click of the inner <button> bubbles to the
    // host, so a consumer's `(click)="…"` on `<soc-selectable-chips>` still fires — exactly once.
    hostClasses = computed(() => `inline-flex items-center gap-[var(--index-selection-chips-gap)] rounded-[var(--index-selection-chips-radius)] px-[var(--index-selection-chips-pad-h-left)] [font-family:var(--index-selection-chips-text-font)] [font-weight:var(--index-selection-chips-text-weight)] focus-visible:outline-none focus-visible:border-[length:var(--index-selection-chips-border-width)] focus-visible:border-[var(--index-selection-chips-border-focus)] ${paddingClasses} ${textSizeClasses[this.size()]} ${this.selected()
        ? 'bg-[var(--index-selection-chips-bg-selected)] text-[var(--index-selection-chips-text-color-selected)]'
        : 'bg-[var(--index-selection-chips-bg-default)] text-[var(--index-selection-chips-text-color)] hover:bg-[var(--index-selection-chips-bg-hover)]'}`);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocSelectableChips, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.25", type: SocSelectableChips, isStandalone: true, selector: "soc-selectable-chips", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, selected: { classPropertyName: "selected", publicName: "selected", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <button type="button" [attr.aria-pressed]="selected()" [class]="hostClasses()">
      {{ label() }}
    </button>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocSelectableChips, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-selectable-chips',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    template: `
    <button type="button" [attr.aria-pressed]="selected()" [class]="hostClasses()">
      {{ label() }}
    </button>
  `,
                }]
        }] });
/** Maps 1:1 to "Index/Selection/Chips/*" tokens (type=Input) — used for the tags shown inside a
 * Multi-select's field once options are selected. */
class SocInputChip {
    label = input.required();
    removable = input(false, { transform: booleanAttribute });
    remove = output();
    closeIconThickness = 'var(--index-selection-chips-close-icon-input-thickness)';
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocInputChip, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocInputChip, isStandalone: true, selector: "soc-input-chip", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, removable: { classPropertyName: "removable", publicName: "removable", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { remove: "remove" }, host: { classAttribute: "inline-flex items-center gap-[var(--index-selection-chips-gap)] rounded-[var(--index-selection-chips-radius)] bg-[var(--index-selection-chips-input-bg-default)] py-[var(--index-selection-chips-pad-input-v)] pl-[var(--index-selection-chips-pad-h-left)] pr-[var(--index-selection-chips-pad-h-right)] text-[length:var(--index-selection-chips-text-input-size)] text-[var(--index-selection-chips-input-text-color)] [font-family:var(--index-selection-chips-text-font)] [font-weight:var(--index-selection-chips-text-weight)] hover:bg-[var(--index-selection-chips-input-bg-hover)]" }, ngImport: i0, template: `
    {{ label() }}
    @if (removable()) {
      <button type="button" (click)="remove.emit()" [attr.aria-label]="'Retirer ' + label()" class="size-[var(--index-selection-chips-close-input-size)] shrink-0 text-[var(--index-selection-chips-input-icon-color)]">
        <svg lucideX class="size-full" [strokeWidth]="closeIconThickness"></svg>
      </button>
    }
  `, isInline: true, dependencies: [{ kind: "component", type: LucideX, selector: "svg[lucideX]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocInputChip, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-input-chip',
                    standalone: true,
                    imports: [LucideX],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        class: 'inline-flex items-center gap-[var(--index-selection-chips-gap)] rounded-[var(--index-selection-chips-radius)] bg-[var(--index-selection-chips-input-bg-default)] py-[var(--index-selection-chips-pad-input-v)] pl-[var(--index-selection-chips-pad-h-left)] pr-[var(--index-selection-chips-pad-h-right)] text-[length:var(--index-selection-chips-text-input-size)] text-[var(--index-selection-chips-input-text-color)] [font-family:var(--index-selection-chips-text-font)] [font-weight:var(--index-selection-chips-text-weight)] hover:bg-[var(--index-selection-chips-input-bg-hover)]',
                    },
                    template: `
    {{ label() }}
    @if (removable()) {
      <button type="button" (click)="remove.emit()" [attr.aria-label]="'Retirer ' + label()" class="size-[var(--index-selection-chips-close-input-size)] shrink-0 text-[var(--index-selection-chips-input-icon-color)]">
        <svg lucideX class="size-full" [strokeWidth]="closeIconThickness"></svg>
      </button>
    }
  `,
                }]
        }] });

/**
 * No native HTML equivalent — plain wrapper (`soc-document-line`). All three props are plain
 * strings in React (`title`/`date`/`fileSize`), no ReactNode anywhere, so plain `input()`s, no
 * content projection. The file icon is self-drawn (`LucideFileText`), same as React's own
 * `<FileText />` — not a consumer-supplied slot.
 *
 * Maps 1:1 to "Index/Données/DocumentLine/*" tokens — see packages/tokens/tokens/components/données.json
 * in design_system (React reference repo, read only).
 */
class SocDocumentLine {
    title = input.required();
    date = input.required();
    fileSize = input.required();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocDocumentLine, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.25", type: SocDocumentLine, isStandalone: true, selector: "soc-document-line", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, date: { classPropertyName: "date", publicName: "date", isSignal: true, isRequired: true, transformFunction: null }, fileSize: { classPropertyName: "fileSize", publicName: "fileSize", isSignal: true, isRequired: true, transformFunction: null } }, host: { classAttribute: "flex items-center gap-[var(--index-donn\u00E9es-documentline-gap)]" }, ngImport: i0, template: `
    <div class="flex size-[var(--index-données-documentline-icon-size)] shrink-0 items-center justify-center rounded bg-[var(--bridges-color-surface-neutral-first)] text-[var(--bridges-color-icon-secondary)]">
      <svg lucideFileText class="size-1/2" [strokeWidth]="1.5"></svg>
    </div>
    <div class="flex flex-col gap-[var(--index-données-documentline-text-gap)]">
      <p class="whitespace-nowrap text-[length:var(--index-données-documentline-title-size)] text-[var(--index-données-documentline-title-color)] [font-family:var(--index-données-documentline-title-font)] [font-weight:var(--index-données-documentline-title-weight)]">
        {{ title() }}
      </p>
      <div class="flex items-center gap-[var(--index-données-documentline-meta-gap)]">
        <p class="whitespace-nowrap text-[length:var(--index-données-documentline-meta-size)] text-[var(--index-données-documentline-meta-color)] [font-family:var(--index-données-documentline-meta-font)] [font-weight:var(--index-données-documentline-meta-weight)]">
          {{ date() }}
        </p>
        <span class="h-3 w-px shrink-0 bg-[var(--index-données-documentline-separator-color)]"></span>
        <p class="whitespace-nowrap text-[length:var(--index-données-documentline-meta-size)] text-[var(--index-données-documentline-meta-color)] [font-family:var(--index-données-documentline-meta-font)] [font-weight:var(--index-données-documentline-meta-weight)]">
          {{ fileSize() }}
        </p>
      </div>
    </div>
  `, isInline: true, dependencies: [{ kind: "component", type: LucideFileText, selector: "svg[lucideFileText]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocDocumentLine, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-document-line',
                    standalone: true,
                    imports: [LucideFileText],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        class: 'flex items-center gap-[var(--index-données-documentline-gap)]',
                    },
                    template: `
    <div class="flex size-[var(--index-données-documentline-icon-size)] shrink-0 items-center justify-center rounded bg-[var(--bridges-color-surface-neutral-first)] text-[var(--bridges-color-icon-secondary)]">
      <svg lucideFileText class="size-1/2" [strokeWidth]="1.5"></svg>
    </div>
    <div class="flex flex-col gap-[var(--index-données-documentline-text-gap)]">
      <p class="whitespace-nowrap text-[length:var(--index-données-documentline-title-size)] text-[var(--index-données-documentline-title-color)] [font-family:var(--index-données-documentline-title-font)] [font-weight:var(--index-données-documentline-title-weight)]">
        {{ title() }}
      </p>
      <div class="flex items-center gap-[var(--index-données-documentline-meta-gap)]">
        <p class="whitespace-nowrap text-[length:var(--index-données-documentline-meta-size)] text-[var(--index-données-documentline-meta-color)] [font-family:var(--index-données-documentline-meta-font)] [font-weight:var(--index-données-documentline-meta-weight)]">
          {{ date() }}
        </p>
        <span class="h-3 w-px shrink-0 bg-[var(--index-données-documentline-separator-color)]"></span>
        <p class="whitespace-nowrap text-[length:var(--index-données-documentline-meta-size)] text-[var(--index-données-documentline-meta-color)] [font-family:var(--index-données-documentline-meta-font)] [font-weight:var(--index-données-documentline-meta-weight)]">
          {{ fileSize() }}
        </p>
      </div>
    </div>
  `,
                }]
        }] });

/** Same structural GAP-DECISION as InputText — see that component's own docstring, not repeated
 * here. Maps 1:1 to "Index/Input/Input area/*" tokens — see
 * packages/tokens/tokens/components/input.json in design_system (React reference repo, read
 * only). Grows with its content (auto-height) instead of scrolling internally, same as React's
 * own `useLayoutEffect` — done here with `viewChild` + `effect()` instead, reading `value()` so it
 * re-measures on every change exactly like React's `[value]` dependency array.
 */
class SocInputArea extends SocTextFieldBase {
    rows = input(3);
    maxlength = input();
    value = model('');
    valueModel = this.value;
    nativeField = () => this.textareaRef()?.nativeElement;
    coerce(value) {
        return value == null ? '' : String(value);
    }
    generatedId = nextUniqueId('soc-input-area');
    get inputId() {
        return this.id() ?? this.generatedId;
    }
    helpIconThickness = 'var(--index-input-input-area-icon-help-thickness)';
    textareaRef = viewChild('textareaEl');
    constructor() {
        super();
        effect(() => {
            this.value();
            const el = this.textareaRef()?.nativeElement;
            if (!el)
                return;
            el.style.height = 'auto';
            el.style.height = `${el.scrollHeight}px`;
        });
    }
    labelClass = computed(() => `[font-family:var(--index-input-input-area-label-font-family)] [font-weight:var(--index-input-input-area-label-font-weight)] text-[length:var(--index-input-input-area-label-font-size)] ${this.isDisabled() ? 'text-[var(--index-input-input-area-label-color-disabled)]' : 'text-[var(--index-input-input-area-label-color)]'}`);
    fieldClass = computed(() => `flex w-full rounded-[var(--index-input-input-area-field-radius)] border-[length:var(--index-input-input-area-field-stroke-width)] bg-[var(--index-input-input-area-field-bg)] px-[var(--index-input-input-area-field-pad-h)] py-[var(--index-input-input-area-field-pad-v)] ${this.isDisabled() ? 'opacity-[var(--index-input-input-area-disabled-opacity)]' : ''} ${this.error()
        ? 'border-[var(--index-input-input-area-field-stroke-error)]'
        : 'border-[var(--index-input-input-area-field-stroke)] hover:border-[var(--index-input-input-area-field-stroke-pressed)] has-[:focus]:border-[var(--index-input-input-area-field-stroke-focus)]'}`);
    helperTextClass = computed(() => `[font-family:var(--index-input-input-area-help-font-family)] [font-weight:var(--index-input-input-area-help-font-weight)] text-[length:var(--index-input-input-area-helper-font-size)] ${this.error() ? 'text-[var(--index-input-input-area-helper-color-error)]' : 'text-[var(--index-input-input-area-helper-color)]'}`);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocInputArea, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocInputArea, isStandalone: true, selector: "soc-input-area", inputs: { rows: { classPropertyName: "rows", publicName: "rows", isSignal: true, isRequired: false, transformFunction: null }, maxlength: { classPropertyName: "maxlength", publicName: "maxlength", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, host: { classAttribute: "flex w-full flex-col gap-[var(--index-input-input-area-label-gap)]" }, providers: [provideFormControl(() => SocInputArea)], viewQueries: [{ propertyName: "textareaRef", first: true, predicate: ["textareaEl"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: `
    @if (label()) {
      <label [for]="inputId" [class]="labelClass()">
        {{ label() }}
        @if (required()) {
          <span class="text-[var(--index-input-input-area-required-color)]"> *</span>
        }
      </label>
    }
    <div [class]="fieldClass()">
      <textarea
        #textareaEl
        [id]="inputId"
        [attr.name]="name()"
        [attr.autocomplete]="autocomplete()"
        [attr.maxlength]="maxlength()"
        [readOnly]="readonly()"
        [disabled]="isDisabled()"
        [required]="required()"
        [value]="value()"
        (input)="value.set($any($event.target).value)"
        (blur)="onTouched()"
        [rows]="rows()"
        [placeholder]="placeholder() ?? ''"
        [class]="inputClass()"
        class="w-full min-w-0 flex-1 resize-none bg-transparent text-[var(--index-input-input-area-value-color)] outline-none placeholder:text-[var(--index-input-input-area-placeholder-color)] disabled:cursor-not-allowed [font-family:var(--index-input-input-area-value-font-family)] [font-weight:var(--index-input-input-area-value-font-weight)] text-[length:var(--index-input-input-area-value-font-size)]"
      ></textarea>
    </div>
    @if (helperText()) {
      <div class="flex items-center gap-[var(--index-input-input-area-helper-gap)]">
        <span [class]="error() ? 'size-3.5 shrink-0 text-[var(--index-input-input-area-icon-helper-error)]' : 'size-3.5 shrink-0 text-[var(--index-input-input-area-icon-helper)]'">
          <svg lucideInfo class="size-full" [strokeWidth]="helpIconThickness"></svg>
        </span>
        <span [class]="helperTextClass()">{{ helperText() }}</span>
      </div>
    }
  `, isInline: true, dependencies: [{ kind: "component", type: LucideInfo, selector: "svg[lucideInfo]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocInputArea, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-input-area',
                    standalone: true,
                    imports: [LucideInfo],
                    providers: [provideFormControl(() => SocInputArea)],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        class: 'flex w-full flex-col gap-[var(--index-input-input-area-label-gap)]',
                    },
                    template: `
    @if (label()) {
      <label [for]="inputId" [class]="labelClass()">
        {{ label() }}
        @if (required()) {
          <span class="text-[var(--index-input-input-area-required-color)]"> *</span>
        }
      </label>
    }
    <div [class]="fieldClass()">
      <textarea
        #textareaEl
        [id]="inputId"
        [attr.name]="name()"
        [attr.autocomplete]="autocomplete()"
        [attr.maxlength]="maxlength()"
        [readOnly]="readonly()"
        [disabled]="isDisabled()"
        [required]="required()"
        [value]="value()"
        (input)="value.set($any($event.target).value)"
        (blur)="onTouched()"
        [rows]="rows()"
        [placeholder]="placeholder() ?? ''"
        [class]="inputClass()"
        class="w-full min-w-0 flex-1 resize-none bg-transparent text-[var(--index-input-input-area-value-color)] outline-none placeholder:text-[var(--index-input-input-area-placeholder-color)] disabled:cursor-not-allowed [font-family:var(--index-input-input-area-value-font-family)] [font-weight:var(--index-input-input-area-value-font-weight)] text-[length:var(--index-input-input-area-value-font-size)]"
      ></textarea>
    </div>
    @if (helperText()) {
      <div class="flex items-center gap-[var(--index-input-input-area-helper-gap)]">
        <span [class]="error() ? 'size-3.5 shrink-0 text-[var(--index-input-input-area-icon-helper-error)]' : 'size-3.5 shrink-0 text-[var(--index-input-input-area-icon-helper)]'">
          <svg lucideInfo class="size-full" [strokeWidth]="helpIconThickness"></svg>
        </span>
        <span [class]="helperTextClass()">{{ helperText() }}</span>
      </div>
    }
  `,
                }]
        }], ctorParameters: () => [] });

/** Same structural GAP-DECISION as InputText — see that component's own docstring, not repeated
 * here. Maps 1:1 to "Index/Input/Input number/*" tokens — see
 * packages/tokens/tokens/components/input.json in design_system (React reference repo, read
 * only). `value`/`defaultValue`'s controlled-vs-uncontrolled split in React collapses to a single
 * `model()` here — a signal always holds the current value regardless of whether the consumer
 * binds `[(value)]` or just reads/sets the initial one, so there's no separate "was a value prop
 * given" branch to reproduce.
 */
class SocInputNumber extends SocTextFieldBase {
    showSteppers = input(true, { transform: booleanAttribute });
    min = input();
    max = input();
    step = input(1);
    /** `null` = empty field (what a form `reset()` produces); React's version is always a number. */
    value = model(0);
    valueModel = this.value;
    fieldRef = viewChild('field');
    nativeField = () => this.fieldRef()?.nativeElement;
    coerce(value) {
        if (value == null || value === '')
            return null;
        const n = Number(value);
        return Number.isNaN(n) ? null : n;
    }
    generatedId = nextUniqueId('soc-input-number');
    get inputId() {
        return this.id() ?? this.generatedId;
    }
    helpIconThickness = 'var(--index-input-input-number-icon-help-thickness)';
    atMax = computed(() => this.max() !== undefined && (this.value() ?? 0) >= this.max());
    atMin = computed(() => this.min() !== undefined && (this.value() ?? 0) <= this.min());
    commit(next) {
        const max = this.max() ?? Infinity;
        const min = this.min() ?? -Infinity;
        this.value.set(Math.min(max, Math.max(min, next)));
    }
    handleInputChange(event) {
        const next = event.target.valueAsNumber;
        if (Number.isNaN(next))
            this.value.set(null);
        else
            this.commit(next);
    }
    labelClass = computed(() => `[font-family:var(--index-input-input-number-label-font-family)] [font-weight:var(--index-input-input-number-label-font-weight)] text-[length:var(--index-input-input-number-label-font-size)] ${this.isDisabled() ? 'text-[var(--index-input-input-number-label-color-disabled)]' : 'text-[var(--index-input-input-number-label-color)]'}`);
    fieldClass = computed(() => `flex w-full items-center overflow-hidden rounded-[var(--index-input-input-number-field-radius)] border-[length:var(--index-input-input-number-field-stroke-width)] bg-[var(--index-input-input-number-field-bg)] ${this.isDisabled() ? 'opacity-[var(--index-input-input-number-disabled-opacity)]' : ''} ${this.error()
        ? 'border-[var(--index-input-input-number-field-stroke-error)]'
        : 'border-[var(--index-input-input-number-field-stroke)] hover:border-[var(--index-input-input-number-field-stroke-pressed)] has-[:focus]:border-[var(--index-input-input-number-field-stroke-focus)]'}`);
    helperTextClass = computed(() => `[font-family:var(--index-input-input-number-help-font-family)] [font-weight:var(--index-input-input-number-help-font-weight)] text-[length:var(--index-input-input-number-helper-font-size)] ${this.error() ? 'text-[var(--index-input-input-number-helper-color-error)]' : 'text-[var(--index-input-input-number-helper-color)]'}`);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocInputNumber, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocInputNumber, isStandalone: true, selector: "soc-input-number", inputs: { showSteppers: { classPropertyName: "showSteppers", publicName: "showSteppers", isSignal: true, isRequired: false, transformFunction: null }, min: { classPropertyName: "min", publicName: "min", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, step: { classPropertyName: "step", publicName: "step", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, host: { classAttribute: "flex w-full flex-col gap-[var(--index-input-input-number-label-gap)]" }, providers: [provideFormControl(() => SocInputNumber)], viewQueries: [{ propertyName: "fieldRef", first: true, predicate: ["field"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: `
    @if (label()) {
      <label [for]="inputId" [class]="labelClass()">
        {{ label() }}
        @if (required()) {
          <span class="text-[var(--index-input-input-number-required-color)]"> *</span>
        }
      </label>
    }
    <div [class]="fieldClass()">
      <input
        #field
        [id]="inputId"
        type="number"
        [attr.name]="name()"
        [attr.autocomplete]="autocomplete()"
        [readOnly]="readonly()"
        [placeholder]="placeholder() ?? ''"
        [required]="required()"
        [disabled]="isDisabled()"
        [attr.min]="min()"
        [attr.max]="max()"
        [step]="step()"
        [value]="value() ?? ''"
        (change)="handleInputChange($event)"
        (blur)="onTouched()"
        [class]="inputClass()"
        class="w-full min-w-0 flex-1 bg-transparent py-[var(--index-input-input-number-field-pad-v)] pl-[var(--index-input-input-number-field-pad-h)] text-[var(--index-input-input-number-value-color)] outline-none placeholder:text-[var(--index-input-input-number-placeholder-color)] disabled:cursor-not-allowed [font-family:var(--index-input-input-number-value-font-family)] [font-weight:var(--index-input-input-number-value-font-weight)] text-[length:var(--index-input-input-number-value-font-size)] [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none"
      />
      @if (showSteppers()) {
        <span class="h-6 w-px shrink-0 bg-[var(--index-input-input-number-stepper-border)]"></span>
        <button
          type="button"
          [disabled]="isDisabled() || readonly() || atMin()"
          (click)="commit((value() ?? 0) - step())"
          aria-label="Diminuer"
          class="flex h-full w-9 shrink-0 items-center justify-center text-[var(--index-input-input-number-stepper-icon)] disabled:cursor-not-allowed disabled:text-[var(--index-input-input-number-stepper-icon-disabled)]"
        >
          <span class="size-4">
            <svg lucideMinus class="size-full" [strokeWidth]="1.5"></svg>
          </span>
        </button>
        <span class="h-6 w-px shrink-0 bg-[var(--index-input-input-number-stepper-border)]"></span>
        <button
          type="button"
          [disabled]="isDisabled() || readonly() || atMax()"
          (click)="commit((value() ?? 0) + step())"
          aria-label="Augmenter"
          class="flex h-full w-9 shrink-0 items-center justify-center text-[var(--index-input-input-number-stepper-icon)] disabled:cursor-not-allowed disabled:text-[var(--index-input-input-number-stepper-icon-disabled)]"
        >
          <span class="size-4">
            <svg lucidePlus class="size-full" [strokeWidth]="1.5"></svg>
          </span>
        </button>
      }
    </div>
    @if (helperText()) {
      <div class="flex items-center gap-[var(--index-input-input-number-helper-gap)]">
        <span [class]="error() ? 'size-3.5 shrink-0 text-[var(--index-input-input-number-icon-helper-error)]' : 'size-3.5 shrink-0 text-[var(--index-input-input-number-icon-helper)]'">
          <svg lucideInfo class="size-full" [strokeWidth]="helpIconThickness"></svg>
        </span>
        <span [class]="helperTextClass()">{{ helperText() }}</span>
      </div>
    }
  `, isInline: true, dependencies: [{ kind: "component", type: LucideInfo, selector: "svg[lucideInfo]" }, { kind: "component", type: LucideMinus, selector: "svg[lucideMinus]" }, { kind: "component", type: LucidePlus, selector: "svg[lucidePlus]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocInputNumber, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-input-number',
                    standalone: true,
                    imports: [LucideInfo, LucideMinus, LucidePlus],
                    providers: [provideFormControl(() => SocInputNumber)],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        class: 'flex w-full flex-col gap-[var(--index-input-input-number-label-gap)]',
                    },
                    template: `
    @if (label()) {
      <label [for]="inputId" [class]="labelClass()">
        {{ label() }}
        @if (required()) {
          <span class="text-[var(--index-input-input-number-required-color)]"> *</span>
        }
      </label>
    }
    <div [class]="fieldClass()">
      <input
        #field
        [id]="inputId"
        type="number"
        [attr.name]="name()"
        [attr.autocomplete]="autocomplete()"
        [readOnly]="readonly()"
        [placeholder]="placeholder() ?? ''"
        [required]="required()"
        [disabled]="isDisabled()"
        [attr.min]="min()"
        [attr.max]="max()"
        [step]="step()"
        [value]="value() ?? ''"
        (change)="handleInputChange($event)"
        (blur)="onTouched()"
        [class]="inputClass()"
        class="w-full min-w-0 flex-1 bg-transparent py-[var(--index-input-input-number-field-pad-v)] pl-[var(--index-input-input-number-field-pad-h)] text-[var(--index-input-input-number-value-color)] outline-none placeholder:text-[var(--index-input-input-number-placeholder-color)] disabled:cursor-not-allowed [font-family:var(--index-input-input-number-value-font-family)] [font-weight:var(--index-input-input-number-value-font-weight)] text-[length:var(--index-input-input-number-value-font-size)] [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none"
      />
      @if (showSteppers()) {
        <span class="h-6 w-px shrink-0 bg-[var(--index-input-input-number-stepper-border)]"></span>
        <button
          type="button"
          [disabled]="isDisabled() || readonly() || atMin()"
          (click)="commit((value() ?? 0) - step())"
          aria-label="Diminuer"
          class="flex h-full w-9 shrink-0 items-center justify-center text-[var(--index-input-input-number-stepper-icon)] disabled:cursor-not-allowed disabled:text-[var(--index-input-input-number-stepper-icon-disabled)]"
        >
          <span class="size-4">
            <svg lucideMinus class="size-full" [strokeWidth]="1.5"></svg>
          </span>
        </button>
        <span class="h-6 w-px shrink-0 bg-[var(--index-input-input-number-stepper-border)]"></span>
        <button
          type="button"
          [disabled]="isDisabled() || readonly() || atMax()"
          (click)="commit((value() ?? 0) + step())"
          aria-label="Augmenter"
          class="flex h-full w-9 shrink-0 items-center justify-center text-[var(--index-input-input-number-stepper-icon)] disabled:cursor-not-allowed disabled:text-[var(--index-input-input-number-stepper-icon-disabled)]"
        >
          <span class="size-4">
            <svg lucidePlus class="size-full" [strokeWidth]="1.5"></svg>
          </span>
        </button>
      }
    </div>
    @if (helperText()) {
      <div class="flex items-center gap-[var(--index-input-input-number-helper-gap)]">
        <span [class]="error() ? 'size-3.5 shrink-0 text-[var(--index-input-input-number-icon-helper-error)]' : 'size-3.5 shrink-0 text-[var(--index-input-input-number-icon-helper)]'">
          <svg lucideInfo class="size-full" [strokeWidth]="helpIconThickness"></svg>
        </span>
        <span [class]="helperTextClass()">{{ helperText() }}</span>
      </div>
    }
  `,
                }]
        }] });

/** GAP-DECISION (flagged, not decided silently): the migration spec's rule says text-input-like
 * primitives should be attribute selectors on the native element, for free native
 * attribute/event passthrough. That works for `Button` (a `<button>` can have projected content
 * around it inside its own tag), but `InputText` — read from the real source before writing this —
 * isn't a thin wrapper around a bare `<input>`: it renders a `<label>` BEFORE the field and a
 * helper-text row AFTER it, around a bordered container with icon slots. An attribute-selector
 * component's template can only fill the CONTENT of the element it decorates, and `<input>` is a
 * void element — it can't have any injected content at all, so there is no way to make an
 * attribute selector on `<input>` also render a sibling `<label>`/helper text. Used a wrapper
 * component instead (`soc-input-text`). What an attribute selector would have given for free is
 * rebuilt explicitly (see `SocTextFieldBase`): dedicated inputs for `id`/`name`/`autocomplete`/
 * `readonly`/`maxlength`, `inputClass` (React's `className` on the `<input>`), and `inputAttrs`
 * for any other native attribute; it is also a `ControlValueAccessor` (`formControl`,
 * `formControlName`, `ngModel`). Same shape applies to InputArea, InputNumber, Password.
 */
class SocInputTextLeftIcon {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocInputTextLeftIcon, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocInputTextLeftIcon, isStandalone: true, selector: "[socInputTextLeftIcon]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocInputTextLeftIcon, decorators: [{
            type: Directive,
            args: [{ selector: '[socInputTextLeftIcon]', standalone: true }]
        }] });
class SocInputTextRightIcon {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocInputTextRightIcon, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocInputTextRightIcon, isStandalone: true, selector: "[socInputTextRightIcon]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocInputTextRightIcon, decorators: [{
            type: Directive,
            args: [{ selector: '[socInputTextRightIcon]', standalone: true }]
        }] });
/** Maps 1:1 to "Index/Input/Input text/*" tokens — see packages/tokens/tokens/components/input.json
 * in design_system (React reference repo, read only). */
class SocInputText extends SocTextFieldBase {
    type = input('text');
    maxlength = input();
    /** The one property that actually needs two-way sync — `model()` gives `[(value)]` plus a
     * `valueChange` output for free, the Angular equivalent of React's `value`+`onChange` pair
     * (or `defaultValue` for the uncontrolled case, via the initial signal value). */
    value = model('');
    valueModel = this.value;
    fieldRef = viewChild('field');
    nativeField = () => this.fieldRef()?.nativeElement;
    coerce(value) {
        return value == null ? '' : String(value);
    }
    generatedId = nextUniqueId('soc-input-text');
    get inputId() {
        return this.id() ?? this.generatedId;
    }
    helpIconThickness = 'var(--index-input-input-text-icon-help-thickness)';
    leftIconContent = contentChild(SocInputTextLeftIcon);
    rightIconContent = contentChild(SocInputTextRightIcon);
    hasLeftIcon = computed(() => !!this.leftIconContent());
    hasRightIcon = computed(() => !!this.rightIconContent());
    labelClass = computed(() => `[font-family:var(--index-input-input-text-label-font-family)] [font-weight:var(--index-input-input-text-label-font-weight)] text-[length:var(--index-input-input-text-label-font-size)] ${this.isDisabled() ? 'text-[var(--index-input-input-text-label-color-disabled)]' : 'text-[var(--index-input-input-text-label-color)]'}`);
    fieldClass = computed(() => `flex w-full items-center gap-2 rounded-[var(--index-input-input-text-field-radius)] border-[length:var(--index-input-input-text-field-stroke-width)] bg-[var(--index-input-input-text-field-bg)] px-[var(--index-input-input-text-field-pad-h)] py-[var(--index-input-input-text-field-pad-v)] has-[:disabled]:opacity-[var(--index-input-input-text-disabled-opacity)] ${this.error()
        ? 'border-[var(--index-input-input-text-field-stroke-error)]'
        : 'border-[var(--index-input-input-text-field-stroke)] hover:border-[var(--index-input-input-text-field-stroke-pressed)] has-[:focus]:border-[var(--index-input-input-text-field-stroke-focus)]'}`);
    helperTextClass = computed(() => `[font-family:var(--index-input-input-text-help-font-family)] [font-weight:var(--index-input-input-text-help-font-weight)] text-[length:var(--index-input-input-text-helper-font-size)] ${this.error() ? 'text-[var(--index-input-input-text-helper-color-error)]' : 'text-[var(--index-input-input-text-helper-color)]'}`);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocInputText, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocInputText, isStandalone: true, selector: "soc-input-text", inputs: { type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, maxlength: { classPropertyName: "maxlength", publicName: "maxlength", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, host: { classAttribute: "flex w-full flex-col gap-[var(--index-input-input-text-label-gap)]" }, providers: [provideFormControl(() => SocInputText)], queries: [{ propertyName: "leftIconContent", first: true, predicate: SocInputTextLeftIcon, descendants: true, isSignal: true }, { propertyName: "rightIconContent", first: true, predicate: SocInputTextRightIcon, descendants: true, isSignal: true }], viewQueries: [{ propertyName: "fieldRef", first: true, predicate: ["field"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: `
    @if (label()) {
      <label [for]="inputId" [class]="labelClass()">
        {{ label() }}
        @if (required()) {
          <span class="text-[var(--index-input-input-text-required-color)]"> *</span>
        }
      </label>
    }
    <div [class]="fieldClass()">
      @if (hasLeftIcon()) {
        <span class="size-4 shrink-0 text-[var(--index-input-input-text-icon-helper)]">
          <ng-content select="[socInputTextLeftIcon]" />
        </span>
      }
      <input
        #field
        [id]="inputId"
        [type]="type()"
        [attr.name]="name()"
        [attr.autocomplete]="autocomplete()"
        [attr.maxlength]="maxlength()"
        [readOnly]="readonly()"
        [placeholder]="placeholder() ?? ''"
        [disabled]="isDisabled()"
        [required]="required()"
        [value]="value()"
        (input)="value.set($any($event.target).value)"
        (blur)="onTouched()"
        [class]="inputClass()"
        class="w-full min-w-0 flex-1 bg-transparent text-[var(--index-input-input-text-value-color)] outline-none placeholder:text-[var(--index-input-input-text-placeholder-color)] disabled:cursor-not-allowed [font-family:var(--index-input-input-text-value-font-family)] [font-weight:var(--index-input-input-text-value-font-weight)] text-[length:var(--index-input-input-text-value-font-size)]"
      />
      @if (hasRightIcon()) {
        <span class="size-4 shrink-0 text-[var(--index-input-input-text-icon-helper)]">
          <ng-content select="[socInputTextRightIcon]" />
        </span>
      }
    </div>
    @if (helperText()) {
      <div class="flex items-center gap-[var(--index-input-input-text-helper-gap)]">
        <span [class]="error() ? 'size-3.5 shrink-0 text-[var(--index-input-input-text-icon-helper-error)]' : 'size-3.5 shrink-0 text-[var(--index-input-input-text-icon-helper)]'">
          <svg lucideInfo class="size-full" [strokeWidth]="helpIconThickness"></svg>
        </span>
        <span [class]="helperTextClass()">{{ helperText() }}</span>
      </div>
    }
  `, isInline: true, dependencies: [{ kind: "component", type: LucideInfo, selector: "svg[lucideInfo]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocInputText, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-input-text',
                    standalone: true,
                    imports: [LucideInfo, SocInputTextLeftIcon, SocInputTextRightIcon],
                    providers: [provideFormControl(() => SocInputText)],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        class: 'flex w-full flex-col gap-[var(--index-input-input-text-label-gap)]',
                    },
                    template: `
    @if (label()) {
      <label [for]="inputId" [class]="labelClass()">
        {{ label() }}
        @if (required()) {
          <span class="text-[var(--index-input-input-text-required-color)]"> *</span>
        }
      </label>
    }
    <div [class]="fieldClass()">
      @if (hasLeftIcon()) {
        <span class="size-4 shrink-0 text-[var(--index-input-input-text-icon-helper)]">
          <ng-content select="[socInputTextLeftIcon]" />
        </span>
      }
      <input
        #field
        [id]="inputId"
        [type]="type()"
        [attr.name]="name()"
        [attr.autocomplete]="autocomplete()"
        [attr.maxlength]="maxlength()"
        [readOnly]="readonly()"
        [placeholder]="placeholder() ?? ''"
        [disabled]="isDisabled()"
        [required]="required()"
        [value]="value()"
        (input)="value.set($any($event.target).value)"
        (blur)="onTouched()"
        [class]="inputClass()"
        class="w-full min-w-0 flex-1 bg-transparent text-[var(--index-input-input-text-value-color)] outline-none placeholder:text-[var(--index-input-input-text-placeholder-color)] disabled:cursor-not-allowed [font-family:var(--index-input-input-text-value-font-family)] [font-weight:var(--index-input-input-text-value-font-weight)] text-[length:var(--index-input-input-text-value-font-size)]"
      />
      @if (hasRightIcon()) {
        <span class="size-4 shrink-0 text-[var(--index-input-input-text-icon-helper)]">
          <ng-content select="[socInputTextRightIcon]" />
        </span>
      }
    </div>
    @if (helperText()) {
      <div class="flex items-center gap-[var(--index-input-input-text-helper-gap)]">
        <span [class]="error() ? 'size-3.5 shrink-0 text-[var(--index-input-input-text-icon-helper-error)]' : 'size-3.5 shrink-0 text-[var(--index-input-input-text-icon-helper)]'">
          <svg lucideInfo class="size-full" [strokeWidth]="helpIconThickness"></svg>
        </span>
        <span [class]="helperTextClass()">{{ helperText() }}</span>
      </div>
    }
  `,
                }]
        }] });

/** Marks a consumer-projected custom icon — React `Message`'s `icon?: ReactNode | null` prop, the
 * "override" branch (a plain `ReactNode`). React's `icon === undefined` (nothing passed at all)
 * defaults to a status-matching icon, and explicit `icon={null}` renders none — content projection
 * can't distinguish "nothing projected" from "explicitly told: render nothing" the way an optional
 * `ReactNode | null` prop can, so that second case is `hideIcon` below instead. */
class SocMessageIcon {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocMessageIcon, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocMessageIcon, isStandalone: true, selector: "[socMessageIcon]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocMessageIcon, decorators: [{
            type: Directive,
            args: [{ selector: '[socMessageIcon]', standalone: true }]
        }] });
/** React `Message`'s required `content: ReactNode` — content projection (not a string input)
 * since it accepts arbitrary rich content, same reasoning as `Button`'s icon slots. */
class SocMessageContent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocMessageContent, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocMessageContent, isStandalone: true, selector: "[socMessageContent]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocMessageContent, decorators: [{
            type: Directive,
            args: [{ selector: '[socMessageContent]', standalone: true }]
        }] });
const bannerBgClasses = {
    success: 'bg-[var(--index-feedback-message-bg-success)]',
    error: 'bg-[var(--index-feedback-message-bg-error)]',
    warning: 'bg-[var(--index-feedback-message-bg-warning)]',
    info: 'bg-[var(--index-feedback-message-bg-info)]',
};
const inlineBgClasses = {
    success: 'bg-[var(--index-feedback-message-inline-bg-success)]',
    error: 'bg-[var(--index-feedback-message-inline-bg-error)]',
    warning: 'bg-[var(--index-feedback-message-inline-bg-warning)]',
    info: 'bg-[var(--index-feedback-message-inline-bg-info)]',
};
const inlineTextClasses = {
    success: 'text-[var(--index-feedback-message-inline-text-success)]',
    error: 'text-[var(--index-feedback-message-inline-text-error)]',
    warning: 'text-[var(--index-feedback-message-inline-text-warning)]',
    info: 'text-[var(--index-feedback-message-inline-text-info)]',
};
const inlineIconClasses = {
    success: 'text-[var(--index-feedback-message-inline-icon-success)]',
    error: 'text-[var(--index-feedback-message-inline-icon-error)]',
    warning: 'text-[var(--index-feedback-message-inline-icon-warning)]',
    info: 'text-[var(--index-feedback-message-inline-icon-info)]',
};
/**
 * No native HTML equivalent — plain wrapper (`soc-message`). Maps 1:1 to
 * "Index/Feedback/Message/*" tokens — see packages/tokens/tokens/components/feedback.json in
 * design_system (React reference repo, read only). `primaryAction`/`secondaryAction` stay plain
 * `input()` objects (`{ label, onClick? }`), matching React's own `MessageAction` shape exactly —
 * the click handler is consumer-supplied data on the object itself, not a component-level
 * notification, so no separate `output()` per action.
 *
 * Composition constraint carried over verbatim from React's own docstring — the "banner" variant
 * always sits top-right of the main content zone (24px from its right/top edges, right of
 * SiteNavigation, never relative to the whole window); this is fixed positioning, not a per-screen
 * choice. No 4th "outlined" variant either — Figma defines exactly banner/inline/plain.
 */
class SocMessage {
    status = input('info');
    variant = input('banner');
    /** Equivalent of React's explicit `icon={null}` — suppresses the icon entirely, default (false)
     * matches React's default behavior of always showing one. */
    hideIcon = input(false, { transform: booleanAttribute });
    title = input();
    primaryAction = input();
    secondaryAction = input();
    iconThickness = 'var(--index-feedback-message-icon-thickness)';
    inlineIconClasses = inlineIconClasses;
    inlineTextClasses = inlineTextClasses;
    customIconContent = contentChild(SocMessageIcon);
    hasCustomIcon = computed(() => !!this.customIconContent());
    hostClasses = computed(() => {
        if (this.variant() === 'banner') {
            return `flex w-full flex-col gap-[var(--index-feedback-message-button-gap)] rounded-[var(--index-feedback-message-radius)] p-[var(--index-feedback-message-padding)] ${bannerBgClasses[this.status()]}`;
        }
        const inline = this.variant() === 'inline';
        return `inline-flex items-center gap-[var(--index-feedback-message-icon-gap)] px-[var(--index-feedback-message-inline-padding-h)] py-[var(--index-feedback-message-inline-padding-v)] ${inline ? `rounded-[var(--index-feedback-message-inline-radius)] ${inlineBgClasses[this.status()]}` : ''}`;
    });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocMessage, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocMessage, isStandalone: true, selector: "soc-message", inputs: { status: { classPropertyName: "status", publicName: "status", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, hideIcon: { classPropertyName: "hideIcon", publicName: "hideIcon", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, primaryAction: { classPropertyName: "primaryAction", publicName: "primaryAction", isSignal: true, isRequired: false, transformFunction: null }, secondaryAction: { classPropertyName: "secondaryAction", publicName: "secondaryAction", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, queries: [{ propertyName: "customIconContent", first: true, predicate: SocMessageIcon, descendants: true, isSignal: true }], ngImport: i0, template: `
    @if (variant() === 'banner') {
      <div class="flex w-full items-start gap-[var(--index-feedback-message-icon-gap)]">
        @if (!hideIcon()) {
          <span class="size-6 shrink-0 text-[var(--index-feedback-message-icon-color)]">
            <ng-container [ngTemplateOutlet]="iconSlot" />
          </span>
        }
        <div class="flex min-w-0 flex-1 flex-col gap-[var(--index-feedback-message-content-gap)]">
          @if (title()) {
            <p class="text-[length:var(--index-feedback-message-title-size)] text-[var(--index-feedback-message-title-color)] [font-family:var(--index-feedback-message-title-font)] [font-weight:var(--index-feedback-message-title-weight)]">
              {{ title() }}
            </p>
          }
          <p class="text-[length:var(--index-feedback-message-content-size)] text-[var(--index-feedback-message-content-color)] [font-family:var(--index-feedback-message-content-font)] [font-weight:var(--index-feedback-message-content-weight)]">
            <ng-container [ngTemplateOutlet]="contentSlot" />
          </p>
        </div>
      </div>
      @if (primaryAction() || secondaryAction()) {
        <div class="flex w-full items-start justify-end gap-2">
          @if (primaryAction(); as action) {
            <button
              type="button"
              (click)="action.onClick?.()"
              class="rounded-[var(--index-button-oncolor-radius)] bg-[var(--index-button-oncolor-primary-bg)] px-[var(--index-button-oncolor-padding-h)] py-[var(--index-button-oncolor-padding-v)] text-[length:var(--index-button-oncolor-font-size)] text-[var(--index-button-oncolor-primary-text)] [font-family:var(--index-button-oncolor-font-family)] [font-weight:var(--index-button-oncolor-font-weight)]"
            >
              {{ action.label }}
            </button>
          }
          @if (secondaryAction(); as action) {
            <button
              type="button"
              (click)="action.onClick?.()"
              class="rounded-[var(--index-button-oncolor-radius)] border-[length:var(--index-button-oncolor-border-width)] border-[var(--index-button-oncolor-secondary-border)] px-[var(--index-button-oncolor-padding-h)] py-[var(--index-button-oncolor-padding-v)] text-[length:var(--index-button-oncolor-font-size)] text-[var(--index-button-oncolor-secondary-text)] [font-family:var(--index-button-oncolor-font-family)] [font-weight:var(--index-button-oncolor-font-weight)]"
            >
              {{ action.label }}
            </button>
          }
        </div>
      }
    } @else {
      @if (!hideIcon()) {
        <span [class]="'size-5 shrink-0 ' + inlineIconClasses[status()]">
          <ng-container [ngTemplateOutlet]="iconSlot" />
        </span>
      }
      <p [class]="'text-[length:var(--index-feedback-message-inline-size)] [font-family:var(--index-feedback-message-inline-font)] [font-weight:var(--index-feedback-message-inline-weight)] ' + inlineTextClasses[status()]">
        <ng-container [ngTemplateOutlet]="contentSlot" />
      </p>
    }

    <!-- Declared once each and reused via ngTemplateOutlet from both variant branches above —
         Angular allocates each distinct ng-content selector to exactly one static slot bucket at
         compile time, so the same selector written in two different ng-content instances (one per
         @if/@else branch) silently drops whichever one isn't the canonical slot, even though only
         one branch is ever active at runtime. Verified this empirically: with two separate
         <ng-content select="[socMessageContent]"> instances (one per branch), the "banner" one
         worked and the "inline"/"plain" one silently rendered nothing. A single ng-content inside
         an <ng-template>, outlet-referenced from wherever it's needed, has only one bucket to
         begin with, so there's no ambiguity regardless of how many places instantiate it. -->
    <ng-template #iconSlot>
      @if (hasCustomIcon()) {
        <ng-content select="[socMessageIcon]" />
      } @else {
        <ng-container [ngTemplateOutlet]="defaultIcon" />
      }
    </ng-template>
    <ng-template #contentSlot>
      <ng-content select="[socMessageContent]" />
    </ng-template>

    <ng-template #defaultIcon>
      @switch (status()) {
        @case ('success') {
          <svg lucideCircleCheck class="size-full" [strokeWidth]="iconThickness"></svg>
        }
        @case ('error') {
          <svg lucideCircleX class="size-full" [strokeWidth]="iconThickness"></svg>
        }
        @case ('warning') {
          <svg lucideTriangleAlert class="size-full" [strokeWidth]="iconThickness"></svg>
        }
        @case ('info') {
          <svg lucideCircleAlert class="size-full" [strokeWidth]="iconThickness"></svg>
        }
      }
    </ng-template>
  `, isInline: true, dependencies: [{ kind: "component", type: LucideCircleAlert, selector: "svg[lucideCircleAlert], svg[lucideAlertCircle]" }, { kind: "component", type: LucideCircleCheck, selector: "svg[lucideCircleCheck], svg[lucideCheckCircle2]" }, { kind: "component", type: LucideCircleX, selector: "svg[lucideCircleX], svg[lucideXCircle]" }, { kind: "component", type: LucideTriangleAlert, selector: "svg[lucideTriangleAlert], svg[lucideAlertTriangle]" }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocMessage, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-message',
                    standalone: true,
                    imports: [LucideCircleAlert, LucideCircleCheck, LucideCircleX, LucideTriangleAlert, NgTemplateOutlet],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[class]': 'hostClasses()',
                    },
                    template: `
    @if (variant() === 'banner') {
      <div class="flex w-full items-start gap-[var(--index-feedback-message-icon-gap)]">
        @if (!hideIcon()) {
          <span class="size-6 shrink-0 text-[var(--index-feedback-message-icon-color)]">
            <ng-container [ngTemplateOutlet]="iconSlot" />
          </span>
        }
        <div class="flex min-w-0 flex-1 flex-col gap-[var(--index-feedback-message-content-gap)]">
          @if (title()) {
            <p class="text-[length:var(--index-feedback-message-title-size)] text-[var(--index-feedback-message-title-color)] [font-family:var(--index-feedback-message-title-font)] [font-weight:var(--index-feedback-message-title-weight)]">
              {{ title() }}
            </p>
          }
          <p class="text-[length:var(--index-feedback-message-content-size)] text-[var(--index-feedback-message-content-color)] [font-family:var(--index-feedback-message-content-font)] [font-weight:var(--index-feedback-message-content-weight)]">
            <ng-container [ngTemplateOutlet]="contentSlot" />
          </p>
        </div>
      </div>
      @if (primaryAction() || secondaryAction()) {
        <div class="flex w-full items-start justify-end gap-2">
          @if (primaryAction(); as action) {
            <button
              type="button"
              (click)="action.onClick?.()"
              class="rounded-[var(--index-button-oncolor-radius)] bg-[var(--index-button-oncolor-primary-bg)] px-[var(--index-button-oncolor-padding-h)] py-[var(--index-button-oncolor-padding-v)] text-[length:var(--index-button-oncolor-font-size)] text-[var(--index-button-oncolor-primary-text)] [font-family:var(--index-button-oncolor-font-family)] [font-weight:var(--index-button-oncolor-font-weight)]"
            >
              {{ action.label }}
            </button>
          }
          @if (secondaryAction(); as action) {
            <button
              type="button"
              (click)="action.onClick?.()"
              class="rounded-[var(--index-button-oncolor-radius)] border-[length:var(--index-button-oncolor-border-width)] border-[var(--index-button-oncolor-secondary-border)] px-[var(--index-button-oncolor-padding-h)] py-[var(--index-button-oncolor-padding-v)] text-[length:var(--index-button-oncolor-font-size)] text-[var(--index-button-oncolor-secondary-text)] [font-family:var(--index-button-oncolor-font-family)] [font-weight:var(--index-button-oncolor-font-weight)]"
            >
              {{ action.label }}
            </button>
          }
        </div>
      }
    } @else {
      @if (!hideIcon()) {
        <span [class]="'size-5 shrink-0 ' + inlineIconClasses[status()]">
          <ng-container [ngTemplateOutlet]="iconSlot" />
        </span>
      }
      <p [class]="'text-[length:var(--index-feedback-message-inline-size)] [font-family:var(--index-feedback-message-inline-font)] [font-weight:var(--index-feedback-message-inline-weight)] ' + inlineTextClasses[status()]">
        <ng-container [ngTemplateOutlet]="contentSlot" />
      </p>
    }

    <!-- Declared once each and reused via ngTemplateOutlet from both variant branches above —
         Angular allocates each distinct ng-content selector to exactly one static slot bucket at
         compile time, so the same selector written in two different ng-content instances (one per
         @if/@else branch) silently drops whichever one isn't the canonical slot, even though only
         one branch is ever active at runtime. Verified this empirically: with two separate
         <ng-content select="[socMessageContent]"> instances (one per branch), the "banner" one
         worked and the "inline"/"plain" one silently rendered nothing. A single ng-content inside
         an <ng-template>, outlet-referenced from wherever it's needed, has only one bucket to
         begin with, so there's no ambiguity regardless of how many places instantiate it. -->
    <ng-template #iconSlot>
      @if (hasCustomIcon()) {
        <ng-content select="[socMessageIcon]" />
      } @else {
        <ng-container [ngTemplateOutlet]="defaultIcon" />
      }
    </ng-template>
    <ng-template #contentSlot>
      <ng-content select="[socMessageContent]" />
    </ng-template>

    <ng-template #defaultIcon>
      @switch (status()) {
        @case ('success') {
          <svg lucideCircleCheck class="size-full" [strokeWidth]="iconThickness"></svg>
        }
        @case ('error') {
          <svg lucideCircleX class="size-full" [strokeWidth]="iconThickness"></svg>
        }
        @case ('warning') {
          <svg lucideTriangleAlert class="size-full" [strokeWidth]="iconThickness"></svg>
        }
        @case ('info') {
          <svg lucideCircleAlert class="size-full" [strokeWidth]="iconThickness"></svg>
        }
      }
    </ng-template>
  `,
                }]
        }] });

/**
 * Full-bleed dark backdrop — sits behind a Dialog/Drawer/floating panel. Standalone: neither
 * Dialog nor Drawer render one themselves yet (not migrated in this batch either), so pair this
 * manually (`@if (open()) { <soc-overlay /> }`) until they do — same as React's own doc comment.
 * Maps 1:1 to "Index/Conteneur/Overlay/*" tokens — see packages/tokens/tokens/components/conteneur.json
 * in design_system (React reference repo, read only). `onClick` is a direct component-level
 * handler -> output(), same reasoning as every other direct handler prop this batch.
 */
class SocOverlay {
    overlayClick = output();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocOverlay, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.25", type: SocOverlay, isStandalone: true, selector: "soc-overlay", outputs: { overlayClick: "overlayClick" }, host: { listeners: { "click": "overlayClick.emit()" }, classAttribute: "fixed inset-0 bg-[var(--index-conteneur-overlay-background-color)] opacity-[var(--index-conteneur-overlay-background-opacity)]" }, ngImport: i0, template: ``, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocOverlay, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-overlay',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        class: 'fixed inset-0 bg-[var(--index-conteneur-overlay-background-color)] opacity-[var(--index-conteneur-overlay-background-opacity)]',
                        '(click)': 'overlayClick.emit()',
                    },
                    template: ``,
                }]
        }] });

/** Builds a windowed page list with ellipsis markers, e.g. [1, '…', 4, 5, 6, '…', 20]. Ported 1:1
 * from React Pagination.tsx's own `buildPageWindow`. */
function buildPageWindow(current, total) {
    if (total <= 7)
        return Array.from({ length: total }, (_, i) => i + 1);
    const pages = new Set([1, total, current - 1, current, current + 1]);
    const sorted = [...pages].filter((p) => p >= 1 && p <= total).sort((a, b) => a - b);
    const result = [];
    sorted.forEach((page, i) => {
        if (i > 0 && page - sorted[i - 1] > 1)
            result.push('ellipsis');
        result.push(page);
    });
    return result;
}
const navButtonClass = 'flex size-[var(--index-navigation-pagination-item-size)] items-center justify-center rounded-[var(--index-navigation-pagination-item-radius)] text-[var(--index-navigation-pagination-icon-default)] hover:text-[var(--index-navigation-pagination-icon-hover)] disabled:cursor-not-allowed disabled:text-[var(--index-navigation-pagination-icon-disabled)]';
/**
 * No native HTML equivalent — plain wrapper (`soc-pagination`). Maps 1:1 to
 * "Index/Navigation/Pagination/*" tokens — see packages/tokens/tokens/components/navigation.json
 * in design_system (React reference repo, read only). `onPageChange`/`onPageSizeChange` are direct
 * component-level handlers (not per-item data), so both become `output()`s
 * (`pageChange`/`pageSizeChange`) rather than input callbacks.
 */
class SocPagination {
    currentPage = input.required();
    totalPages = input.required();
    variant = input('numbered');
    hasFirstLast = input(true, { transform: booleanAttribute });
    totalEntries = input();
    pageSize = input();
    pageSizeOptions = input([10, 20, 50, 100]);
    pageChange = output();
    pageSizeChange = output();
    navButtonClass = navButtonClass;
    iconThickness = 'var(--index-navigation-pagination-icon-thickness)';
    pages = computed(() => buildPageWindow(this.currentPage(), this.totalPages()));
    dotPages = computed(() => Array.from({ length: this.totalPages() }, (_, i) => i + 1));
    showPageSize = computed(() => this.pageSize() !== undefined);
    fromEntry = computed(() => {
        const size = this.pageSize();
        return this.totalEntries() !== undefined && size ? (this.currentPage() - 1) * size + 1 : undefined;
    });
    toEntry = computed(() => {
        const size = this.pageSize();
        const total = this.totalEntries();
        return total !== undefined && size ? Math.min(this.currentPage() * size, total) : undefined;
    });
    dotClass(page) {
        const base = 'size-[var(--index-navigation-pagination-dot-size)] shrink-0 rounded-full focus-visible:outline-none focus-visible:border-[length:var(--index-navigation-pagination-item-border-width)] focus-visible:border-[var(--index-navigation-pagination-dot-border-focus)]';
        return `${base} ${page === this.currentPage()
            ? 'bg-[var(--index-navigation-pagination-dot-bg-selected)]'
            : 'bg-[var(--index-navigation-pagination-dot-bg-default)] hover:bg-[var(--index-navigation-pagination-dot-bg-hover)] active:bg-[var(--index-navigation-pagination-dot-bg-pressed)]'}`;
    }
    pageButtonClass(page) {
        const base = 'flex size-[var(--index-navigation-pagination-item-size)] items-center justify-center rounded-[var(--index-navigation-pagination-item-radius)] text-[length:var(--index-navigation-pagination-font-size)] [font-family:var(--index-navigation-pagination-font-family)]';
        return `${base} ${page === this.currentPage()
            ? 'bg-[var(--index-navigation-pagination-item-bg-selected)] text-[var(--index-navigation-pagination-item-text-selected)] [font-weight:var(--index-navigation-pagination-font-weight-selected)]'
            : 'border-[length:var(--index-navigation-pagination-item-border-width)] border-[var(--index-navigation-pagination-item-border-default)] bg-[var(--index-navigation-pagination-item-bg-default)] text-[var(--index-navigation-pagination-item-text-default)] [font-weight:var(--index-navigation-pagination-font-weight)] hover:border-[var(--index-navigation-pagination-item-border-hover)] hover:bg-[var(--index-navigation-pagination-item-bg-hover)] hover:text-[var(--index-navigation-pagination-item-text-hover)]'}`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPagination, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocPagination, isStandalone: true, selector: "soc-pagination", inputs: { currentPage: { classPropertyName: "currentPage", publicName: "currentPage", isSignal: true, isRequired: true, transformFunction: null }, totalPages: { classPropertyName: "totalPages", publicName: "totalPages", isSignal: true, isRequired: true, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, hasFirstLast: { classPropertyName: "hasFirstLast", publicName: "hasFirstLast", isSignal: true, isRequired: false, transformFunction: null }, totalEntries: { classPropertyName: "totalEntries", publicName: "totalEntries", isSignal: true, isRequired: false, transformFunction: null }, pageSize: { classPropertyName: "pageSize", publicName: "pageSize", isSignal: true, isRequired: false, transformFunction: null }, pageSizeOptions: { classPropertyName: "pageSizeOptions", publicName: "pageSizeOptions", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { pageChange: "pageChange", pageSizeChange: "pageSizeChange" }, host: { properties: { "class": "variant() === \"dots\" ? \"flex items-center justify-center gap-[var(--index-navigation-pagination-dot-gap)]\" : \"flex items-center justify-between\"", "attr.aria-label": "variant() === \"dots\" ? \"Pagination\" : null" } }, ngImport: i0, template: `
    @if (variant() === 'dots') {
      @for (page of dotPages(); track page) {
        <button
          type="button"
          [attr.aria-label]="'Page ' + page"
          [attr.aria-current]="page === currentPage() ? 'page' : null"
          (click)="pageChange.emit(page)"
          [class]="dotClass(page)"
        ></button>
      }
    } @else {
      <nav aria-label="Pagination" class="flex items-center gap-[var(--index-navigation-pagination-item-gap)]">
        @if (hasFirstLast()) {
          <button type="button" [disabled]="currentPage() <= 1" (click)="pageChange.emit(1)" aria-label="Première page" [class]="navButtonClass">
            <span class="size-[var(--index-navigation-pagination-icon-size)]">
              <svg lucideChevronsLeft class="size-full" [strokeWidth]="iconThickness"></svg>
            </span>
          </button>
        }
        <button type="button" [disabled]="currentPage() <= 1" (click)="pageChange.emit(currentPage() - 1)" aria-label="Page précédente" [class]="navButtonClass">
          <span class="size-[var(--index-navigation-pagination-icon-size)]">
            <svg lucideChevronLeft class="size-full" [strokeWidth]="iconThickness"></svg>
          </span>
        </button>

        @for (page of pages(); track $index) {
          @if (page === 'ellipsis') {
            <span class="flex size-[var(--index-navigation-pagination-item-size)] items-center justify-center text-[var(--index-navigation-pagination-item-text-default)]"> … </span>
          } @else {
            <button
              type="button"
              [attr.aria-current]="page === currentPage() ? 'page' : null"
              (click)="pageChange.emit(page)"
              [class]="pageButtonClass(page)"
            >
              {{ page }}
            </button>
          }
        }

        <button type="button" [disabled]="currentPage() >= totalPages()" (click)="pageChange.emit(currentPage() + 1)" aria-label="Page suivante" [class]="navButtonClass">
          <span class="size-[var(--index-navigation-pagination-icon-size)]">
            <svg lucideChevronRight class="size-full" [strokeWidth]="iconThickness"></svg>
          </span>
        </button>
        @if (hasFirstLast()) {
          <button type="button" [disabled]="currentPage() >= totalPages()" (click)="pageChange.emit(totalPages())" aria-label="Dernière page" [class]="navButtonClass">
            <span class="size-[var(--index-navigation-pagination-icon-size)]">
              <svg lucideChevronsRight class="size-full" [strokeWidth]="iconThickness"></svg>
            </span>
          </button>
        }
      </nav>

      @if (totalEntries() !== undefined || showPageSize()) {
        <div class="flex items-center gap-[var(--index-navigation-pagination-section-gap)]">
          @if (totalEntries() !== undefined) {
            <p class="whitespace-nowrap text-[length:var(--index-navigation-pagination-font-size)] text-[var(--index-navigation-pagination-info-text)] [font-family:var(--index-navigation-pagination-font-family)]">
              Affichage de {{ fromEntry() }} à {{ toEntry() }} sur {{ totalEntries() }}
            </p>
          }
          @if (showPageSize()) {
            <select
              [value]="pageSize()"
              (change)="pageSizeChange.emit(+$any($event.target).value)"
              class="rounded-[var(--index-navigation-pagination-item-radius)] border-[length:var(--index-navigation-pagination-item-border-width)] border-[var(--index-navigation-pagination-item-border-default)] bg-[var(--index-navigation-pagination-item-bg-default)] px-2 py-1.5 text-[length:var(--index-navigation-pagination-font-size)] text-[var(--index-navigation-pagination-item-text-default)] [font-family:var(--index-navigation-pagination-font-family)]"
            >
              @for (size of pageSizeOptions(); track size) {
                <option [value]="size">{{ size }}</option>
              }
            </select>
          }
        </div>
      }
    }
  `, isInline: true, dependencies: [{ kind: "component", type: LucideChevronLeft, selector: "svg[lucideChevronLeft]" }, { kind: "component", type: LucideChevronRight, selector: "svg[lucideChevronRight]" }, { kind: "component", type: LucideChevronsLeft, selector: "svg[lucideChevronsLeft]" }, { kind: "component", type: LucideChevronsRight, selector: "svg[lucideChevronsRight]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPagination, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-pagination',
                    standalone: true,
                    imports: [LucideChevronLeft, LucideChevronRight, LucideChevronsLeft, LucideChevronsRight],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[class]': 'variant() === "dots" ? "flex items-center justify-center gap-[var(--index-navigation-pagination-dot-gap)]" : "flex items-center justify-between"',
                        '[attr.aria-label]': 'variant() === "dots" ? "Pagination" : null',
                    },
                    template: `
    @if (variant() === 'dots') {
      @for (page of dotPages(); track page) {
        <button
          type="button"
          [attr.aria-label]="'Page ' + page"
          [attr.aria-current]="page === currentPage() ? 'page' : null"
          (click)="pageChange.emit(page)"
          [class]="dotClass(page)"
        ></button>
      }
    } @else {
      <nav aria-label="Pagination" class="flex items-center gap-[var(--index-navigation-pagination-item-gap)]">
        @if (hasFirstLast()) {
          <button type="button" [disabled]="currentPage() <= 1" (click)="pageChange.emit(1)" aria-label="Première page" [class]="navButtonClass">
            <span class="size-[var(--index-navigation-pagination-icon-size)]">
              <svg lucideChevronsLeft class="size-full" [strokeWidth]="iconThickness"></svg>
            </span>
          </button>
        }
        <button type="button" [disabled]="currentPage() <= 1" (click)="pageChange.emit(currentPage() - 1)" aria-label="Page précédente" [class]="navButtonClass">
          <span class="size-[var(--index-navigation-pagination-icon-size)]">
            <svg lucideChevronLeft class="size-full" [strokeWidth]="iconThickness"></svg>
          </span>
        </button>

        @for (page of pages(); track $index) {
          @if (page === 'ellipsis') {
            <span class="flex size-[var(--index-navigation-pagination-item-size)] items-center justify-center text-[var(--index-navigation-pagination-item-text-default)]"> … </span>
          } @else {
            <button
              type="button"
              [attr.aria-current]="page === currentPage() ? 'page' : null"
              (click)="pageChange.emit(page)"
              [class]="pageButtonClass(page)"
            >
              {{ page }}
            </button>
          }
        }

        <button type="button" [disabled]="currentPage() >= totalPages()" (click)="pageChange.emit(currentPage() + 1)" aria-label="Page suivante" [class]="navButtonClass">
          <span class="size-[var(--index-navigation-pagination-icon-size)]">
            <svg lucideChevronRight class="size-full" [strokeWidth]="iconThickness"></svg>
          </span>
        </button>
        @if (hasFirstLast()) {
          <button type="button" [disabled]="currentPage() >= totalPages()" (click)="pageChange.emit(totalPages())" aria-label="Dernière page" [class]="navButtonClass">
            <span class="size-[var(--index-navigation-pagination-icon-size)]">
              <svg lucideChevronsRight class="size-full" [strokeWidth]="iconThickness"></svg>
            </span>
          </button>
        }
      </nav>

      @if (totalEntries() !== undefined || showPageSize()) {
        <div class="flex items-center gap-[var(--index-navigation-pagination-section-gap)]">
          @if (totalEntries() !== undefined) {
            <p class="whitespace-nowrap text-[length:var(--index-navigation-pagination-font-size)] text-[var(--index-navigation-pagination-info-text)] [font-family:var(--index-navigation-pagination-font-family)]">
              Affichage de {{ fromEntry() }} à {{ toEntry() }} sur {{ totalEntries() }}
            </p>
          }
          @if (showPageSize()) {
            <select
              [value]="pageSize()"
              (change)="pageSizeChange.emit(+$any($event.target).value)"
              class="rounded-[var(--index-navigation-pagination-item-radius)] border-[length:var(--index-navigation-pagination-item-border-width)] border-[var(--index-navigation-pagination-item-border-default)] bg-[var(--index-navigation-pagination-item-bg-default)] px-2 py-1.5 text-[length:var(--index-navigation-pagination-font-size)] text-[var(--index-navigation-pagination-item-text-default)] [font-family:var(--index-navigation-pagination-font-family)]"
            >
              @for (size of pageSizeOptions(); track size) {
                <option [value]="size">{{ size }}</option>
              }
            </select>
          }
        </div>
      }
    }
  `,
                }]
        }] });

/** Same structural GAP-DECISION as InputText — see that component's own docstring, not repeated
 * here. Maps 1:1 to "Index/Input/Input password/*" tokens — see
 * packages/tokens/tokens/components/input.json in design_system (React reference repo, read
 * only). The show/hide toggle is local component state (a plain `signal`), same as React's own
 * `useState` — not exposed as an input/output, nothing outside this component needs to know or
 * control it.
 */
class SocPassword extends SocTextFieldBase {
    maxlength = input();
    value = model('');
    valueModel = this.value;
    fieldRef = viewChild('field');
    nativeField = () => this.fieldRef()?.nativeElement;
    coerce(value) {
        return value == null ? '' : String(value);
    }
    visible = signal(false);
    generatedId = nextUniqueId('soc-password');
    get inputId() {
        return this.id() ?? this.generatedId;
    }
    helpIconThickness = 'var(--index-input-input-password-icon-help-thickness)';
    eyeThickness = 'var(--index-input-input-password-icon-eye-thickness)';
    labelClass = computed(() => `[font-family:var(--index-input-input-password-label-font-family)] [font-weight:var(--index-input-input-password-label-font-weight)] text-[length:var(--index-input-input-password-label-font-size)] ${this.isDisabled() ? 'text-[var(--index-input-input-password-label-color-disabled)]' : 'text-[var(--index-input-input-password-label-color)]'}`);
    fieldClass = computed(() => `flex w-full items-center gap-2 rounded-[var(--index-input-input-password-field-radius)] border-[length:var(--index-input-input-password-field-stroke-width)] bg-[var(--index-input-input-password-field-bg)] ${this.isDisabled() ? 'opacity-[var(--index-input-input-password-disabled-opacity)]' : ''} ${this.error()
        ? 'border-[var(--index-input-input-password-field-stroke-error)]'
        : 'border-[var(--index-input-input-password-field-stroke)] hover:border-[var(--index-input-input-password-field-stroke-pressed)] has-[:focus]:border-[var(--index-input-input-password-field-stroke-focus)]'} px-[var(--index-input-input-password-field-pad-h)] py-[var(--index-input-input-password-field-pad-v)]`);
    helperTextClass = computed(() => `[font-family:var(--index-input-input-password-help-font-family)] [font-weight:var(--index-input-input-password-help-font-weight)] text-[length:var(--index-input-input-password-helper-font-size)] ${this.error() ? 'text-[var(--index-input-input-password-helper-color-error)]' : 'text-[var(--index-input-input-password-helper-color)]'}`);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPassword, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocPassword, isStandalone: true, selector: "soc-password", inputs: { maxlength: { classPropertyName: "maxlength", publicName: "maxlength", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, host: { classAttribute: "flex w-full flex-col gap-[var(--index-input-input-password-label-gap)]" }, providers: [provideFormControl(() => SocPassword)], viewQueries: [{ propertyName: "fieldRef", first: true, predicate: ["field"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: `
    @if (label()) {
      <label [for]="inputId" [class]="labelClass()">
        {{ label() }}
        @if (required()) {
          <span class="text-[var(--index-input-input-password-required-color)]"> *</span>
        }
      </label>
    }
    <div [class]="fieldClass()">
      <input
        #field
        [id]="inputId"
        [type]="visible() ? 'text' : 'password'"
        [attr.name]="name()"
        [attr.autocomplete]="autocomplete()"
        [attr.maxlength]="maxlength()"
        [readOnly]="readonly()"
        [placeholder]="placeholder() ?? ''"
        [required]="required()"
        [disabled]="isDisabled()"
        [value]="value()"
        (input)="value.set($any($event.target).value)"
        (blur)="onTouched()"
        [class]="inputClass()"
        class="w-full min-w-0 flex-1 bg-transparent text-[var(--index-input-input-password-value-color)] outline-none placeholder:text-[var(--index-input-input-password-placeholder-color)] disabled:cursor-not-allowed [font-family:var(--index-input-input-password-value-font-family)] [font-weight:var(--index-input-input-password-value-font-weight)] text-[length:var(--index-input-input-password-value-font-size)]"
      />
      <button
        type="button"
        [disabled]="isDisabled()"
        (click)="visible.set(!visible())"
        [attr.aria-label]="visible() ? 'Masquer le mot de passe' : 'Afficher le mot de passe'"
        class="size-[var(--index-input-input-password-icon-field-size)] shrink-0 text-[var(--index-input-input-password-toggle-icon)] disabled:cursor-not-allowed disabled:text-[var(--index-input-input-password-toggle-icon-disabled)]"
      >
        @if (visible()) {
          <svg lucideEyeOff class="size-full" [strokeWidth]="eyeThickness"></svg>
        } @else {
          <svg lucideEye class="size-full" [strokeWidth]="eyeThickness"></svg>
        }
      </button>
    </div>
    @if (helperText()) {
      <div class="flex items-center gap-[var(--index-input-input-password-helper-gap)]">
        <span [class]="error() ? 'size-3.5 shrink-0 text-[var(--index-input-input-password-icon-helper-error)]' : 'size-3.5 shrink-0 text-[var(--index-input-input-password-icon-helper)]'">
          <svg lucideInfo class="size-full" [strokeWidth]="helpIconThickness"></svg>
        </span>
        <span [class]="helperTextClass()">{{ helperText() }}</span>
      </div>
    }
  `, isInline: true, dependencies: [{ kind: "component", type: LucideEye, selector: "svg[lucideEye]" }, { kind: "component", type: LucideEyeOff, selector: "svg[lucideEyeOff]" }, { kind: "component", type: LucideInfo, selector: "svg[lucideInfo]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPassword, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-password',
                    standalone: true,
                    imports: [LucideEye, LucideEyeOff, LucideInfo],
                    providers: [provideFormControl(() => SocPassword)],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        class: 'flex w-full flex-col gap-[var(--index-input-input-password-label-gap)]',
                    },
                    template: `
    @if (label()) {
      <label [for]="inputId" [class]="labelClass()">
        {{ label() }}
        @if (required()) {
          <span class="text-[var(--index-input-input-password-required-color)]"> *</span>
        }
      </label>
    }
    <div [class]="fieldClass()">
      <input
        #field
        [id]="inputId"
        [type]="visible() ? 'text' : 'password'"
        [attr.name]="name()"
        [attr.autocomplete]="autocomplete()"
        [attr.maxlength]="maxlength()"
        [readOnly]="readonly()"
        [placeholder]="placeholder() ?? ''"
        [required]="required()"
        [disabled]="isDisabled()"
        [value]="value()"
        (input)="value.set($any($event.target).value)"
        (blur)="onTouched()"
        [class]="inputClass()"
        class="w-full min-w-0 flex-1 bg-transparent text-[var(--index-input-input-password-value-color)] outline-none placeholder:text-[var(--index-input-input-password-placeholder-color)] disabled:cursor-not-allowed [font-family:var(--index-input-input-password-value-font-family)] [font-weight:var(--index-input-input-password-value-font-weight)] text-[length:var(--index-input-input-password-value-font-size)]"
      />
      <button
        type="button"
        [disabled]="isDisabled()"
        (click)="visible.set(!visible())"
        [attr.aria-label]="visible() ? 'Masquer le mot de passe' : 'Afficher le mot de passe'"
        class="size-[var(--index-input-input-password-icon-field-size)] shrink-0 text-[var(--index-input-input-password-toggle-icon)] disabled:cursor-not-allowed disabled:text-[var(--index-input-input-password-toggle-icon-disabled)]"
      >
        @if (visible()) {
          <svg lucideEyeOff class="size-full" [strokeWidth]="eyeThickness"></svg>
        } @else {
          <svg lucideEye class="size-full" [strokeWidth]="eyeThickness"></svg>
        }
      </button>
    </div>
    @if (helperText()) {
      <div class="flex items-center gap-[var(--index-input-input-password-helper-gap)]">
        <span [class]="error() ? 'size-3.5 shrink-0 text-[var(--index-input-input-password-icon-helper-error)]' : 'size-3.5 shrink-0 text-[var(--index-input-input-password-icon-helper)]'">
          <svg lucideInfo class="size-full" [strokeWidth]="helpIconThickness"></svg>
        </span>
        <span [class]="helperTextClass()">{{ helperText() }}</span>
      </div>
    }
  `,
                }]
        }] });

/** Marks the element projected into the extra row below the bar (typically a `<soc-tag>`) — React
 * `ProgressBar`'s `tag?: ReactNode` prop. Ignored when `size()` is `"tiny"`, same as React. */
class SocProgressBarTag {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocProgressBarTag, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocProgressBarTag, isStandalone: true, selector: "[socProgressBarTag]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocProgressBarTag, decorators: [{
            type: Directive,
            args: [{ selector: '[socProgressBarTag]', standalone: true }]
        }] });
const fillClasses = {
    information: 'bg-[var(--index-feedback-progressbar-fill-information)]',
    success: 'bg-[var(--index-feedback-progressbar-fill-success)]',
    warning: 'bg-[var(--index-feedback-progressbar-fill-warning)]',
    error: 'bg-[var(--index-feedback-progressbar-fill-error)]',
};
const barHeightClasses = {
    tiny: 'h-[var(--index-feedback-progressbar-bar-height-tiny)]',
    sm: 'h-[var(--index-feedback-progressbar-bar-height-sm)]',
    md: 'h-[var(--index-feedback-progressbar-bar-height-md)]',
    lg: 'h-[var(--index-feedback-progressbar-bar-height-lg)]',
};
/**
 * No native HTML equivalent (the `role="progressbar"` div is hand-rolled, same as React) — plain
 * wrapper (`soc-progress-bar`). Maps 1:1 to "Index/Feedback/ProgressBar/*" tokens — see
 * packages/tokens/tokens/components/feedback.json in design_system (React reference repo, read
 * only). The `progress-indeterminate` keyframes it references live in
 * src/styles/tailwind-entry.css (global), matching where React's own src/index.css defines them —
 * not local to this component in either repo.
 */
class SocProgressBar {
    value = input(0);
    status = input('information');
    size = input('md');
    label = input();
    helpTextLeft = input();
    helpTextRight = input();
    tinyLabel = input();
    indeterminate = input(false, { transform: booleanAttribute });
    tagContent = contentChild(SocProgressBarTag);
    hasTag = computed(() => !!this.tagContent());
    isTiny = computed(() => this.size() === 'tiny');
    clamped = computed(() => Math.min(100, Math.max(0, this.value())));
    trackClass = computed(() => `relative w-full overflow-hidden bg-[var(--index-feedback-progressbar-track-bg)] ${this.isTiny() ? 'rounded-[var(--index-feedback-progressbar-tiny-radius)]' : 'rounded-[var(--index-feedback-progressbar-radius-lg)]'} ${barHeightClasses[this.size()]}`);
    fillClass = computed(() => `flex h-full items-center justify-center text-[length:var(--index-feedback-progressbar-fill-size)] text-[var(--index-feedback-progressbar-fill-text-color)] [font-family:var(--index-feedback-progressbar-fill-font)] [font-weight:var(--index-feedback-progressbar-fill-weight)] ${fillClasses[this.status()]} ${this.indeterminate() ? 'animate-[progress-indeterminate_1.4s_ease-in-out_infinite] w-1/3' : ''}`);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocProgressBar, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocProgressBar, isStandalone: true, selector: "soc-progress-bar", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, status: { classPropertyName: "status", publicName: "status", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, helpTextLeft: { classPropertyName: "helpTextLeft", publicName: "helpTextLeft", isSignal: true, isRequired: false, transformFunction: null }, helpTextRight: { classPropertyName: "helpTextRight", publicName: "helpTextRight", isSignal: true, isRequired: false, transformFunction: null }, tinyLabel: { classPropertyName: "tinyLabel", publicName: "tinyLabel", isSignal: true, isRequired: false, transformFunction: null }, indeterminate: { classPropertyName: "indeterminate", publicName: "indeterminate", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "flex w-full flex-col gap-[var(--index-feedback-progressbar-label-gap)]" }, queries: [{ propertyName: "tagContent", first: true, predicate: SocProgressBarTag, descendants: true, isSignal: true }], ngImport: i0, template: `
    @if (label() && !isTiny()) {
      <p class="w-full text-[length:var(--index-feedback-progressbar-label-size)] text-[var(--index-feedback-progressbar-label-color)] [font-family:var(--index-feedback-progressbar-label-font)] [font-weight:var(--index-feedback-progressbar-label-weight)]">
        {{ label() }}
      </p>
    }
    <div
      role="progressbar"
      [attr.aria-valuenow]="indeterminate() ? null : clamped()"
      aria-valuemin="0"
      aria-valuemax="100"
      [class]="trackClass()"
    >
      <div [class]="fillClass()" [style.width]="indeterminate() ? null : clamped() + '%'">
        @if (size() === 'lg' && !indeterminate()) {
          {{ clamped() }}%
        }
      </div>
    </div>
    @if (isTiny() && tinyLabel()) {
      <p class="w-full pt-[var(--index-feedback-progressbar-tiny-label-gap)] text-[length:var(--index-feedback-progressbar-tiny-label-size)] text-[var(--index-feedback-progressbar-tiny-label-color)] [font-family:var(--index-feedback-progressbar-tiny-label-font)] [font-weight:var(--index-feedback-progressbar-tiny-label-weight)]">
        {{ tinyLabel() }}
      </p>
    }
    @if (!isTiny() && (helpTextLeft() || helpTextRight())) {
      <div class="flex w-full items-start justify-between gap-[var(--index-feedback-progressbar-bar-bottom-gap)] text-[length:var(--index-feedback-progressbar-help-size)] [font-family:var(--index-feedback-progressbar-help-font)] [font-weight:var(--index-feedback-progressbar-help-weight)]">
        @if (helpTextLeft()) {
          <p class="min-w-0 flex-1 text-[var(--index-feedback-progressbar-help-text-color)]">{{ helpTextLeft() }}</p>
        }
        @if (helpTextRight()) {
          <p class="shrink-0 whitespace-nowrap text-[var(--index-feedback-progressbar-progress-text-color)]">{{ helpTextRight() }}</p>
        }
      </div>
    }
    @if (!isTiny() && hasTag()) {
      <div class="flex w-full items-start pt-[var(--index-feedback-progressbar-help-tag-gap)]">
        <ng-content select="[socProgressBarTag]" />
      </div>
    }
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocProgressBar, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-progress-bar',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        class: 'flex w-full flex-col gap-[var(--index-feedback-progressbar-label-gap)]',
                    },
                    template: `
    @if (label() && !isTiny()) {
      <p class="w-full text-[length:var(--index-feedback-progressbar-label-size)] text-[var(--index-feedback-progressbar-label-color)] [font-family:var(--index-feedback-progressbar-label-font)] [font-weight:var(--index-feedback-progressbar-label-weight)]">
        {{ label() }}
      </p>
    }
    <div
      role="progressbar"
      [attr.aria-valuenow]="indeterminate() ? null : clamped()"
      aria-valuemin="0"
      aria-valuemax="100"
      [class]="trackClass()"
    >
      <div [class]="fillClass()" [style.width]="indeterminate() ? null : clamped() + '%'">
        @if (size() === 'lg' && !indeterminate()) {
          {{ clamped() }}%
        }
      </div>
    </div>
    @if (isTiny() && tinyLabel()) {
      <p class="w-full pt-[var(--index-feedback-progressbar-tiny-label-gap)] text-[length:var(--index-feedback-progressbar-tiny-label-size)] text-[var(--index-feedback-progressbar-tiny-label-color)] [font-family:var(--index-feedback-progressbar-tiny-label-font)] [font-weight:var(--index-feedback-progressbar-tiny-label-weight)]">
        {{ tinyLabel() }}
      </p>
    }
    @if (!isTiny() && (helpTextLeft() || helpTextRight())) {
      <div class="flex w-full items-start justify-between gap-[var(--index-feedback-progressbar-bar-bottom-gap)] text-[length:var(--index-feedback-progressbar-help-size)] [font-family:var(--index-feedback-progressbar-help-font)] [font-weight:var(--index-feedback-progressbar-help-weight)]">
        @if (helpTextLeft()) {
          <p class="min-w-0 flex-1 text-[var(--index-feedback-progressbar-help-text-color)]">{{ helpTextLeft() }}</p>
        }
        @if (helpTextRight()) {
          <p class="shrink-0 whitespace-nowrap text-[var(--index-feedback-progressbar-progress-text-color)]">{{ helpTextRight() }}</p>
        }
      </div>
    }
    @if (!isTiny() && hasTag()) {
      <div class="flex w-full items-start pt-[var(--index-feedback-progressbar-help-tag-gap)]">
        <ng-content select="[socProgressBarTag]" />
      </div>
    }
  `,
                }]
        }] });

/** React `Popover`'s `trigger: ReactElement` — receives a click handler (React clones it in;
 * here the click listener lives on this component's own wrapper around the projected content
 * instead, same workaround as `Tooltip`'s trigger — see that component's own docstring for why
 * cloning has no Angular equivalent). */
class SocPopoverTrigger {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPopoverTrigger, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocPopoverTrigger, isStandalone: true, selector: "[socPopoverTrigger]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPopoverTrigger, decorators: [{
            type: Directive,
            args: [{ selector: '[socPopoverTrigger]', standalone: true }]
        }] });
const GAP$1 = 4;
const VIEWPORT_MARGIN$1 = 4;
/** Ported 1:1 from React Popover.tsx's own `computePosition`. */
function computePosition(position, triggerRect, panelRect) {
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    if (position === 'left' || position === 'right') {
        const spaceLeft = triggerRect.left;
        const spaceRight = vw - triggerRect.right;
        const needed = panelRect.width + GAP$1;
        let openRight = position === 'right';
        if (openRight && spaceRight < needed && spaceLeft > spaceRight)
            openRight = false;
        if (!openRight && spaceLeft < needed && spaceRight > spaceLeft)
            openRight = true;
        const left = openRight ? triggerRect.right + GAP$1 : triggerRect.left - panelRect.width - GAP$1;
        const top = Math.min(Math.max(VIEWPORT_MARGIN$1, triggerRect.top), vh - panelRect.height - VIEWPORT_MARGIN$1);
        return { top, left: Math.min(Math.max(VIEWPORT_MARGIN$1, left), vw - panelRect.width - VIEWPORT_MARGIN$1) };
    }
    const spaceBelow = vh - triggerRect.bottom;
    const spaceAbove = triggerRect.top;
    const needed = panelRect.height + GAP$1;
    let openBelow = position !== 'top';
    if (openBelow && spaceBelow < needed && spaceAbove > spaceBelow)
        openBelow = false;
    if (!openBelow && spaceAbove < needed && spaceBelow > spaceAbove)
        openBelow = true;
    const top = openBelow ? triggerRect.bottom + GAP$1 : triggerRect.top - panelRect.height - GAP$1;
    const alignEnd = position === 'bottom-end';
    const left = alignEnd ? triggerRect.right - panelRect.width : triggerRect.left;
    return { top, left: Math.min(Math.max(VIEWPORT_MARGIN$1, left), vw - panelRect.width - VIEWPORT_MARGIN$1) };
}
/**
 * No native HTML equivalent — plain wrapper (`soc-popover`). Maps 1:1 to
 * "Index/Conteneur/Menu/popover-*" tokens (Figma has no standalone Popover token set — Menu is
 * the only component that binds the floating-surface tokens) — see
 * packages/tokens/tokens/components/conteneur.json in design_system (React reference repo, read
 * only). `trigger` -> named content slot (`socPopoverTrigger`); panel content -> default
 * unnamed slot, same split as `Card`'s icon-slots-vs-default-children precedent.
 *
 * Portaled to `document.body` via a direct `appendChild`, positioned with computed `position:
 * fixed` — same reasoning and same technique as `Tooltip`'s own bubble (see its docstring).
 * `computePosition` ported 1:1 from React. React's controlled-vs-uncontrolled `open` collapses to
 * one `model()`, same pattern as `Checkbox`/`Accordion`.
 */
class SocPopover {
    position = input('bottom');
    open = model(false);
    matchTriggerWidth = input(false, { transform: booleanAttribute });
    /** React `Popover`'s `className` — extra classes merged onto the portaled panel (e.g.
     * `EnterpriseSelect`'s explicit `w-[400px]`). A literal `class` on `<soc-popover>` can't do this:
     * the panel is portaled out to `document.body`, away from the host element. */
    panelClass = input();
    triggerWrapperRef = viewChild('triggerWrapper');
    panelRef = viewChild('panel');
    appended = false;
    topPx = signal(0);
    leftPx = signal(0);
    triggerWidthPx = signal(0);
    constructor() {
        effect(() => {
            const isOpen = this.open();
            this.position();
            this.matchTriggerWidth();
            const panelEl = this.panelRef()?.nativeElement;
            if (!panelEl)
                return;
            if (!this.appended) {
                document.body.appendChild(panelEl);
                this.appended = true;
            }
            if (isOpen)
                this.reposition();
        });
        const onWindowChange = () => {
            if (this.open())
                this.reposition();
        };
        const onPointerDown = (e) => {
            if (!this.open())
                return;
            const target = e.target;
            if (this.triggerWrapperRef()?.nativeElement.contains(target))
                return;
            if (this.panelRef()?.nativeElement.contains(target))
                return;
            this.open.set(false);
        };
        const onKeyDown = (e) => {
            if (this.open() && e.key === 'Escape')
                this.open.set(false);
        };
        window.addEventListener('resize', onWindowChange);
        window.addEventListener('scroll', onWindowChange, true);
        document.addEventListener('mousedown', onPointerDown);
        document.addEventListener('keydown', onKeyDown);
        inject(DestroyRef).onDestroy(() => {
            window.removeEventListener('resize', onWindowChange);
            window.removeEventListener('scroll', onWindowChange, true);
            document.removeEventListener('mousedown', onPointerDown);
            document.removeEventListener('keydown', onKeyDown);
            this.panelRef()?.nativeElement.remove();
        });
    }
    toggle() {
        this.open.set(!this.open());
    }
    reposition() {
        const triggerEl = this.triggerWrapperRef()?.nativeElement;
        const panelEl = this.panelRef()?.nativeElement;
        if (!triggerEl || !panelEl)
            return;
        const triggerRect = triggerEl.getBoundingClientRect();
        this.triggerWidthPx.set(triggerRect.width);
        const { top, left } = computePosition(this.position(), triggerRect, panelEl.getBoundingClientRect());
        this.topPx.set(top);
        this.leftPx.set(left);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPopover, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "19.2.25", type: SocPopover, isStandalone: true, selector: "soc-popover", inputs: { position: { classPropertyName: "position", publicName: "position", isSignal: true, isRequired: false, transformFunction: null }, open: { classPropertyName: "open", publicName: "open", isSignal: true, isRequired: false, transformFunction: null }, matchTriggerWidth: { classPropertyName: "matchTriggerWidth", publicName: "matchTriggerWidth", isSignal: true, isRequired: false, transformFunction: null }, panelClass: { classPropertyName: "panelClass", publicName: "panelClass", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { open: "openChange" }, host: { classAttribute: "contents" }, viewQueries: [{ propertyName: "triggerWrapperRef", first: true, predicate: ["triggerWrapper"], descendants: true, isSignal: true }, { propertyName: "panelRef", first: true, predicate: ["panel"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <div #triggerWrapper class="relative inline-flex" (click)="toggle()">
      <ng-content select="[socPopoverTrigger]" />
    </div>
    <div
      #panel
      role="dialog"
      [style.position]="'fixed'"
      [style.top.px]="topPx()"
      [style.left.px]="leftPx()"
      [style.width.px]="matchTriggerWidth() && open() ? triggerWidthPx() : null"
      [style.visibility]="open() ? 'visible' : 'hidden'"
      [class]="panelClass()"
      class="z-20 flex min-w-[200px] flex-col items-start rounded-[var(--index-conteneur-menu-popover-radius)] bg-[var(--index-conteneur-menu-popover-bg)] py-[var(--index-conteneur-menu-popover-pad)] drop-shadow-[0px_var(--index-conteneur-menu-popover-shadow-y)_var(--index-conteneur-menu-popover-shadow-blur)_rgba(68,84,111,var(--index-conteneur-menu-popover-shadow-opacity))]"
    >
      <ng-content />
    </div>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPopover, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-popover',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    // React's Popover returns a fragment (no wrapper element of its own) — `contents` keeps the
                    // trigger wrapper a direct layout child of the consumer's container, e.g. a `w-full` trigger
                    // inside a flex column (Select) still fills the column.
                    host: { class: 'contents' },
                    template: `
    <div #triggerWrapper class="relative inline-flex" (click)="toggle()">
      <ng-content select="[socPopoverTrigger]" />
    </div>
    <div
      #panel
      role="dialog"
      [style.position]="'fixed'"
      [style.top.px]="topPx()"
      [style.left.px]="leftPx()"
      [style.width.px]="matchTriggerWidth() && open() ? triggerWidthPx() : null"
      [style.visibility]="open() ? 'visible' : 'hidden'"
      [class]="panelClass()"
      class="z-20 flex min-w-[200px] flex-col items-start rounded-[var(--index-conteneur-menu-popover-radius)] bg-[var(--index-conteneur-menu-popover-bg)] py-[var(--index-conteneur-menu-popover-pad)] drop-shadow-[0px_var(--index-conteneur-menu-popover-shadow-y)_var(--index-conteneur-menu-popover-shadow-blur)_rgba(68,84,111,var(--index-conteneur-menu-popover-shadow-opacity))]"
    >
      <ng-content />
    </div>
  `,
                }]
        }], ctorParameters: () => [] });

/** Same structural GAP-DECISION as Checkbox — see that component's own docstring, not repeated
 * here. Maps 1:1 to "Index/Contrôleur/Radio/*" tokens — see
 * packages/tokens/tokens/components/contrôleur.json in design_system (React reference repo, read
 * only). Unlike Checkbox/Switch, React's `RadioButton` has no internal `useState`/`defaultSelected`
 * at all — purely controlled (`selected` prop + `onSelect` callback) — so this is a plain
 * `input()` + `output()` pair, no `model()`/uncontrolled-fallback needed.
 */
class SocRadioButton {
    /** Controlled like React (`selected` + `(select)`), but a `model()` so a form can drive it too. */
    selected = model(false);
    disabled = input(false, { transform: booleanAttribute });
    formDisabled = signal(false);
    isDisabled = computed(() => this.disabled() || this.formDisabled());
    label = input();
    name = input();
    id = input();
    select = output();
    /** Forms: the value this radio stands for. Give every radio of a group the same `formControlName`/
     * `[formControl]`/`ngModel` and its own `value` — the group's value selects the matching radio, and
     * clicking one writes its `value` back to the control (the standard pattern for custom radios). */
    value = input();
    onChange = () => { };
    onTouched = () => { };
    constructor() {
        // Angular only calls `writeValue` on the radio that was clicked (the one whose view changed the
        // control); its siblings sharing the same FormControl hear nothing (native radios use a
        // dedicated registry for this). Listening to the control itself keeps the whole group in sync.
        // Deferred: `NgControl` injects this accessor, and the control is only attached once the form
        // directive has initialised.
        const injector = inject(Injector);
        const destroyRef = inject(DestroyRef);
        afterNextRender(() => {
            const control = injector.get(NgControl, null)?.control;
            control?.valueChanges.pipe(takeUntilDestroyed(destroyRef)).subscribe((groupValue) => this.writeValue(groupValue));
        });
    }
    handleClick() {
        if (this.isDisabled())
            return;
        this.selected.set(true);
        this.select.emit();
        this.onChange(this.value());
    }
    writeValue(groupValue) {
        this.selected.set(this.value() !== undefined && groupValue === this.value());
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.formDisabled.set(isDisabled);
    }
    hostClass = computed(() => `inline-flex items-center gap-2 ${this.isDisabled() ? 'cursor-not-allowed opacity-50' : 'cursor-pointer'}`);
    buttonClass = computed(() => {
        const base = 'group flex size-[var(--index-contrôleur-radio-size)] shrink-0 items-center justify-center rounded-full border-[length:var(--index-contrôleur-radio-stroke-weight)] transition-colors disabled:cursor-not-allowed';
        if (this.isDisabled()) {
            return `${base} ${this.selected() ? 'border-[var(--index-contrôleur-radio-dot-selected-disabled)]' : 'border-[var(--index-contrôleur-radio-dot-disabled)]'}`;
        }
        return `${base} ${this.selected()
            ? 'border-[var(--index-contrôleur-radio-dot-selected)] hover:border-[var(--index-contrôleur-radio-dot-selected-hover)] active:border-[var(--index-contrôleur-radio-dot-selected-pressed)]'
            : 'border-[var(--index-contrôleur-radio-dot-default)] hover:border-[var(--index-contrôleur-radio-dot-hover)] active:border-[var(--index-contrôleur-radio-dot-pressed)]'}`;
    });
    dotClass = computed(() => `size-[var(--index-contrôleur-radio-dot-size)] rounded-full transition-colors ${this.isDisabled()
        ? 'bg-[var(--index-contrôleur-radio-dot-selected-disabled)]'
        : 'bg-[var(--index-contrôleur-radio-dot-selected)] group-hover:bg-[var(--index-contrôleur-radio-dot-selected-hover)] group-active:bg-[var(--index-contrôleur-radio-dot-selected-pressed)]'}`);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocRadioButton, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocRadioButton, isStandalone: true, selector: "soc-radio-button", inputs: { selected: { classPropertyName: "selected", publicName: "selected", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selected: "selectedChange", select: "select" }, host: { properties: { "attr.id": "null" } }, providers: [provideFormControl(() => SocRadioButton)], ngImport: i0, template: `
    <label [for]="id()" [class]="hostClass()">
      <button
        [id]="id()"
        type="button"
        role="radio"
        [name]="name()"
        [attr.aria-checked]="selected()"
        [disabled]="isDisabled()"
        (click)="handleClick()"
        (blur)="onTouched()"
        [class]="buttonClass()"
      >
        @if (selected()) {
          <span [class]="dotClass()"></span>
        }
      </button>
      @if (label()) {
        <span class="text-[var(--bridges-color-text-primary)]">{{ label() }}</span>
      }
    </label>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocRadioButton, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-radio-button',
                    standalone: true,
                    providers: [provideFormControl(() => SocRadioButton)],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    // `id` targets the inner control (the `<label for>` target), like React — a static `id="…"` on
                    // the element would otherwise also land on this host as a duplicate DOM id.
                    host: { '[attr.id]': 'null' },
                    template: `
    <label [for]="id()" [class]="hostClass()">
      <button
        [id]="id()"
        type="button"
        role="radio"
        [name]="name()"
        [attr.aria-checked]="selected()"
        [disabled]="isDisabled()"
        (click)="handleClick()"
        (blur)="onTouched()"
        [class]="buttonClass()"
      >
        @if (selected()) {
          <span [class]="dotClass()"></span>
        }
      </button>
      @if (label()) {
        <span class="text-[var(--bridges-color-text-primary)]">{{ label() }}</span>
      }
    </label>
  `,
                }]
        }], ctorParameters: () => [] });

/** Same structural GAP-DECISION as InputText — its outer element is a `<div>` with a sibling icon
 * before and a sibling clear button after the `<input>`, not the `<input>` itself, so an attribute
 * selector on `<input>` alone couldn't render them (see InputText's own docstring for the full
 * reasoning; not repeated here). Wrapper component (`soc-search-bar`) instead.
 *
 * Maps 1:1 to "Index/Input/SearchBar/*" tokens — see packages/tokens/tokens/components/input.json
 * in design_system (React reference repo, read only). No fixed height of its own on purpose, same
 * as React — see that file's own doc comment: Figma gives this field a different flat height per
 * usage context, so each consumer applies its own height token via `class` rather than this
 * component picking one to hardcode.
 */
class SocSearchBar extends SocFormControl {
    placeholder = input('Rechercher...');
    value = model('');
    valueModel = this.value;
    coerce(value) {
        return value == null ? '' : String(value);
    }
    clear = output();
    inputRef = viewChild('inputEl');
    iconThickness = 'var(--index-input-searchbar-icon-thickness)';
    hasValue = computed(() => this.value().length > 0);
    handleClear() {
        this.value.set('');
        this.clear.emit();
        this.inputRef()?.nativeElement.focus();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocSearchBar, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocSearchBar, isStandalone: true, selector: "soc-search-bar", inputs: { placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", clear: "clear" }, host: { classAttribute: "group flex w-full items-center gap-[var(--index-input-searchbar-icon-gap)] rounded-[var(--index-input-searchbar-field-radius)] border-[length:var(--index-input-searchbar-field-stroke-width)] border-[var(--index-input-searchbar-field-stroke)] bg-[var(--index-input-searchbar-field-bg)] px-[var(--index-input-searchbar-field-pad-h)] py-[var(--index-input-searchbar-field-pad-v)] hover:border-[var(--index-input-searchbar-field-stroke-hover)] has-[:focus]:border-[var(--index-input-searchbar-field-stroke-focus)]" }, providers: [provideFormControl(() => SocSearchBar)], viewQueries: [{ propertyName: "inputRef", first: true, predicate: ["inputEl"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: `
    <span class="size-4 shrink-0 text-[var(--index-input-searchbar-icon-search)] group-has-[:focus]:text-[var(--index-input-searchbar-icon-search-focus)]">
      <svg lucideSearch class="size-full" [strokeWidth]="iconThickness"></svg>
    </span>
    <input
      #inputEl
      type="text"
      [placeholder]="placeholder()"
      [disabled]="isDisabled()"
      [value]="value()"
      (input)="value.set($any($event.target).value)"
      (blur)="onTouched()"
      class="w-full min-w-0 flex-1 bg-transparent text-[var(--index-input-searchbar-value-color)] outline-none placeholder:text-[var(--index-input-searchbar-placeholder-color)] [font-family:var(--index-input-searchbar-value-font-family)] [font-weight:var(--index-input-searchbar-value-font-weight)] text-[length:var(--index-input-searchbar-value-font-size)]"
    />
    @if (hasValue()) {
      <button type="button" (click)="handleClear()" aria-label="Effacer la recherche" class="size-4 shrink-0 text-[var(--index-input-searchbar-icon-clear)]">
        <svg lucideX class="size-full" [strokeWidth]="iconThickness"></svg>
      </button>
    }
  `, isInline: true, dependencies: [{ kind: "component", type: LucideSearch, selector: "svg[lucideSearch]" }, { kind: "component", type: LucideX, selector: "svg[lucideX]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocSearchBar, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-search-bar',
                    standalone: true,
                    imports: [LucideSearch, LucideX],
                    providers: [provideFormControl(() => SocSearchBar)],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        class: 'group flex w-full items-center gap-[var(--index-input-searchbar-icon-gap)] rounded-[var(--index-input-searchbar-field-radius)] border-[length:var(--index-input-searchbar-field-stroke-width)] border-[var(--index-input-searchbar-field-stroke)] bg-[var(--index-input-searchbar-field-bg)] px-[var(--index-input-searchbar-field-pad-h)] py-[var(--index-input-searchbar-field-pad-v)] hover:border-[var(--index-input-searchbar-field-stroke-hover)] has-[:focus]:border-[var(--index-input-searchbar-field-stroke-focus)]',
                    },
                    template: `
    <span class="size-4 shrink-0 text-[var(--index-input-searchbar-icon-search)] group-has-[:focus]:text-[var(--index-input-searchbar-icon-search-focus)]">
      <svg lucideSearch class="size-full" [strokeWidth]="iconThickness"></svg>
    </span>
    <input
      #inputEl
      type="text"
      [placeholder]="placeholder()"
      [disabled]="isDisabled()"
      [value]="value()"
      (input)="value.set($any($event.target).value)"
      (blur)="onTouched()"
      class="w-full min-w-0 flex-1 bg-transparent text-[var(--index-input-searchbar-value-color)] outline-none placeholder:text-[var(--index-input-searchbar-placeholder-color)] [font-family:var(--index-input-searchbar-value-font-family)] [font-weight:var(--index-input-searchbar-value-font-weight)] text-[length:var(--index-input-searchbar-value-font-size)]"
    />
    @if (hasValue()) {
      <button type="button" (click)="handleClear()" aria-label="Effacer la recherche" class="size-4 shrink-0 text-[var(--index-input-searchbar-icon-clear)]">
        <svg lucideX class="size-full" [strokeWidth]="iconThickness"></svg>
      </button>
    }
  `,
                }]
        }] });

/**
 * One preset per "Produit" variant of Figma's SiteNavigation component — transcribed label-by-
 * label and icon-by-icon from design_system (React)'s own navigationPresets.ts, itself
 * transcribed from the Figma file (icons identified there by comparing each exported SVG's
 * geometry against lucide-react's own icon path data, not guessed from the label text — carried
 * over verbatim, not re-derived here). Section/item ids are slugs of their label, prefixed with
 * the product, so the same label reused across products never collides.
 */
const NAVIGATION_PRESETS = {
    workspace: {
        title: 'Workspace',
        sections: [
            {
                title: 'MENU PRINCIPAL',
                items: [
                    { id: 'workspace-accueil', label: 'Accueil', icon: LucideHouse },
                    { id: 'workspace-tableau-de-bord', label: 'Tableau de bord', icon: LucideLayoutDashboard },
                    { id: 'workspace-rapports-rh', label: 'Rapports RH', icon: LucideFileChartColumn },
                    { id: 'workspace-entreprises', label: 'Entreprises', icon: LucideBuilding2 },
                    { id: 'workspace-imports-exports', label: 'Imports / Exports', icon: LucideArrowDownUp },
                    { id: 'workspace-pays', label: 'Pays', icon: LucideGlobe },
                    { id: 'workspace-historique', label: 'Historique', icon: LucideHistory },
                    { id: 'workspace-template', label: 'Template', icon: LucideLayoutTemplate },
                ],
            },
            {
                title: 'GESTION ENTREPRISE',
                items: [
                    { id: 'workspace-infos-generales', label: 'Infos générales', icon: LucideInfo },
                    { id: 'workspace-demandes-recues', label: 'Demandes reçues', icon: LucideInbox },
                    { id: 'workspace-applications', label: 'Applications', icon: LucideAppWindow },
                    { id: 'workspace-employes', label: 'Employés', icon: LucideUsers },
                    { id: 'workspace-permissions', label: 'Permissions', icon: LucideShieldCheck },
                    { id: 'workspace-postes', label: 'Postes', icon: LucideBriefcase },
                    { id: 'workspace-structures', label: 'Structures', icon: LucideNetwork },
                    { id: 'workspace-organigramme', label: 'Organigramme', icon: LucideGitFork },
                    { id: 'workspace-configurations', label: 'Configurations', icon: LucideSettings },
                ],
            },
            {
                title: 'PARAMÈTRES DE PAIE',
                items: [
                    { id: 'workspace-rubriques-de-paie', label: 'Rubriques de paie', icon: LucideList },
                    { id: 'workspace-etat-de-paie', label: 'État de paie', icon: LucideFileText },
                    { id: 'workspace-controle-cycle-paie', label: 'Contrôle cycle paie', icon: LucideCircleCheck },
                ],
            },
            {
                title: 'MON ESPACE',
                items: [
                    { id: 'workspace-profil', label: 'Profil', icon: LucideUser },
                    { id: 'workspace-mes-taches', label: 'Mes tâches', icon: LucideListChecks },
                ],
            },
        ],
    },
    job: {
        title: 'Job',
        sections: [
            {
                title: 'MENU PRINCIPAL',
                items: [
                    { id: 'job-accueil', label: 'Accueil', icon: LucideHouse },
                    { id: 'job-tableau-de-bord', label: 'Tableau de bord', icon: LucideLayoutDashboard },
                ],
            },
            {
                title: 'GESTION & SUIVI',
                items: [
                    { id: 'job-offres', label: 'Offres', icon: LucideBriefcaseBusiness },
                    { id: 'job-cvtheque', label: 'CvThèque', icon: LucideFolderSearch },
                ],
            },
            {
                title: 'GESTION DES MODÈLES',
                items: [
                    { id: 'job-modeles-d-offres', label: "Modèles d'offres", icon: LucideFilePlus },
                    { id: 'job-modeles-pre-qualif', label: 'Modèles pré-qualif.', icon: LucideFileCheck },
                    { id: 'job-modeles-d-emails', label: "Modèles d'emails", icon: LucideMail },
                    { id: 'job-modeles-de-pipeline', label: 'Modèles de pipeline', icon: LucideFilter },
                    { id: 'job-modeles-de-rapport', label: 'Modèles de rapport', icon: LucideFileChartColumn },
                    { id: 'job-modeles-de-criteres', label: 'Modèles de critères', icon: LucideListFilter },
                ],
            },
            {
                title: 'PARAMÉTRAGE',
                items: [
                    { id: 'job-workflow', label: 'Workflow', icon: LucideWorkflow },
                    { id: 'job-jours-feries', label: 'Jours fériés', icon: LucideCalendarDays },
                    { id: 'job-configuration', label: 'Configuration', icon: LucideSettings },
                    { id: 'job-templates-d-export', label: "Templates d'export", icon: LucideDownload },
                ],
            },
            {
                title: 'MON ESPACE',
                items: [
                    { id: 'job-mon-organisation', label: 'Mon organisation', icon: LucideBuilding2 },
                    { id: 'job-ma-presentation', label: 'Ma présentation', icon: LucidePresentation },
                    { id: 'job-listes-diffusion', label: 'Listes diffusion', icon: LucideSend },
                ],
            },
        ],
    },
    workflow: {
        title: 'Workflow',
        sections: [
            {
                title: 'MENU PRINCIPAL',
                items: [
                    { id: 'workflow-accueil', label: 'Accueil', icon: LucideHouse },
                    { id: 'workflow-dashboard', label: 'Dashboard', icon: LucideLayoutDashboard },
                    { id: 'workflow-historique', label: 'Historique', icon: LucideHistory },
                    { id: 'workflow-conge', label: 'Congé', icon: LucideCalendar },
                    { id: 'workflow-note-de-frais', label: 'Note de frais', icon: LucideReceipt },
                    { id: 'workflow-demande-moyen', label: 'Demande moyen', icon: LucidePackage },
                    { id: 'workflow-avance-salaire', label: 'Avance salaire', icon: LucideBanknote },
                    { id: 'workflow-autres-demandes', label: 'Autres demandes', icon: LucideClipboardList },
                ],
            },
            {
                title: 'PARAMÈTRES',
                items: [
                    { id: 'workflow-workflow', label: 'Workflow', icon: LucideWorkflow },
                    { id: 'workflow-jours-feries', label: 'Jours fériés', icon: LucideCalendarDays },
                    { id: 'workflow-configuration', label: 'Configuration', icon: LucideSettings },
                    { id: 'workflow-templates-d-export', label: "Templates d'export", icon: LucideDownload },
                ],
            },
            {
                title: 'MON ESPACE',
                items: [
                    { id: 'workflow-mon-profil', label: 'Mon profil', icon: LucideUser },
                    { id: 'workflow-mes-conges', label: 'Mes congés', icon: LucideCalendarCheck },
                    { id: 'workflow-mes-notes-de-frais', label: 'Mes notes de frais', icon: LucideReceiptText },
                    { id: 'workflow-mes-demandes-moyens', label: 'Mes demandes moyens', icon: LucidePackageCheck },
                    { id: 'workflow-mes-avances-salaire', label: 'Mes avances salaire', icon: LucideWallet },
                    { id: 'workflow-mes-demandes-perso', label: 'Mes demandes perso.', icon: LucideClipboardPen },
                ],
            },
        ],
    },
    perfs: {
        title: 'Perfs',
        sections: [
            {
                title: 'MENU PRINCIPAL',
                items: [
                    { id: 'perfs-tableau-de-bord', label: 'Tableau de bord', icon: LucideLayoutDashboard },
                    { id: 'perfs-objectifs', label: 'Objectifs', icon: LucideTarget },
                    { id: 'perfs-evaluations', label: 'Évaluations', icon: LucideClipboardCheck },
                    { id: 'perfs-competences', label: 'Compétences', icon: LucideAward },
                    { id: 'perfs-carrieres', label: 'Carrières', icon: LucideTrendingUp },
                    { id: 'perfs-catalogue', label: 'Catalogue', icon: LucideGraduationCap },
                    { id: 'perfs-matrice-9-box', label: 'Matrice 9-box', icon: LucideGrid3x3 },
                    { id: 'perfs-employes', label: 'Employés', icon: LucideUsers },
                    { id: 'perfs-configurations', label: 'Configurations', icon: LucideSlidersHorizontal },
                    { id: 'perfs-historiques', label: 'Historiques', icon: LucideHistory },
                ],
            },
            {
                title: 'MON ESPACE',
                items: [
                    { id: 'perfs-mes-objectifs', label: 'Mes objectifs', icon: LucideTarget },
                    { id: 'perfs-mes-contrats', label: 'Mes contrats', icon: LucideFileCheck },
                    { id: 'perfs-mes-plans', label: 'Mes plans', icon: LucideMap },
                ],
            },
        ],
    },
    doc: {
        title: 'Doc',
        sections: [
            {
                title: 'MENU PRINCIPAL',
                items: [
                    { id: 'doc-accueil', label: 'Accueil', icon: LucideHouse },
                    { id: 'doc-tableau-de-bord', label: 'Tableau de bord', icon: LucideLayoutDashboard },
                    { id: 'doc-demandes', label: 'Demandes', icon: LucideInbox },
                    { id: 'doc-contrats', label: 'Contrats', icon: LucideFileSignature },
                    { id: 'doc-modeles', label: 'Modèles', icon: LucideFiles },
                    { id: 'doc-employes', label: 'Employés', icon: LucideUsers },
                    { id: 'doc-conformite', label: 'Conformité', icon: LucideShieldCheck },
                    { id: 'doc-bulletins-de-paie', label: 'Bulletins de paie', icon: LucideReceipt },
                    { id: 'doc-parametres', label: 'Paramètres', icon: LucideSettings },
                ],
            },
        ],
    },
    payroll: {
        title: 'Payroll',
        sections: [
            {
                title: 'MENU PRINCIPAL',
                items: [
                    { id: 'payroll-accueil', label: 'Accueil', icon: LucideHouse },
                    { id: 'payroll-tableau-de-bord', label: 'Tableau de bord', icon: LucideLayoutDashboard },
                    { id: 'payroll-mes-bulletins-de-paie', label: 'Mes bulletins de paie', icon: LucideReceiptText },
                    { id: 'payroll-historique', label: 'Historique', icon: LucideHistory },
                ],
            },
            {
                title: 'GESTION ENTREPRISES',
                items: [
                    { id: 'payroll-employes', label: 'Employés', icon: LucideUsers },
                    { id: 'payroll-elements-remuneration', label: 'Éléments rémunération', icon: LucideCoins },
                    { id: 'payroll-bulletins-de-paie', label: 'Bulletins de paie', icon: LucideReceipt },
                    { id: 'payroll-etats-de-paie', label: 'États de paie', icon: LucideFileSpreadsheet },
                    { id: 'payroll-simulateur-de-paie', label: 'Simulateur de paie', icon: LucideCalculator },
                    { id: 'payroll-provisions', label: 'Provisions', icon: LucidePiggyBank },
                    { id: 'payroll-centres-analytiques', label: 'Centres analytiques', icon: LucideChartPie },
                    { id: 'payroll-comptes-comptables', label: 'Comptes comptables', icon: LucideBookOpen },
                    { id: 'payroll-augm-salariales', label: 'Augm. salariales', icon: LucideTrendingUp },
                ],
            },
            {
                title: 'CONFIG. GLOBALE',
                items: [{ id: 'payroll-gestion-des-entreprises', label: 'Gestion des entreprises', icon: LucideBuilding2 }],
            },
        ],
    },
};

/**
 * Internal — one collapsible section of the nav (React's own local `NavSection` function
 * component, promoted to its own Angular component since Angular doesn't have React's casual
 * "just define another function in the same file" pattern for a stateful sub-view — this needs
 * its own `open` signal per section instance). Not exported from `public-api.ts`.
 */
class SocSideNavSection {
    section = input.required();
    selectedId = input();
    collapsed = input(false, { transform: booleanAttribute });
    itemSelect = output();
    open = signal(true);
    chevronThickness = 'var(--index-navigation-sidenavigation-menu-title-chevron-thickness)';
    // React's `navIcon()` helper renders every preset icon as `<Icon className="size-full"
    // strokeWidth="…-item-icon-thickness" />`; a bare NgComponentOutlet instantiates the Lucide
    // component with its own defaults (24px, stroke 2), so the same two inputs are passed explicitly.
    itemIconInputs = { class: 'size-full', strokeWidth: 'var(--index-navigation-sidenavigation-item-icon-thickness)' };
    itemClick(item) {
        item.onClick?.();
        this.itemSelect.emit(item.id);
    }
    itemClass(id) {
        const base = 'flex h-9 w-full items-center gap-[var(--index-navigation-sidenavigation-item-gap)] rounded-l-[var(--index-navigation-sidenavigation-item-radius-left)] rounded-r-[var(--index-navigation-sidenavigation-item-radius-right)] px-[var(--index-navigation-sidenavigation-item-padding-h)] py-[var(--index-navigation-sidenavigation-item-padding-v)] text-[length:var(--index-navigation-sidenavigation-item-size)] [font-family:var(--index-navigation-sidenavigation-item-font)] [font-weight:var(--index-navigation-sidenavigation-item-weight)]';
        return `${base} ${id === this.selectedId()
            ? 'border-r-[length:var(--index-navigation-sidenavigation-item-border-width)] border-[var(--index-navigation-sidenavigation-item-border-selected)] bg-[var(--index-navigation-sidenavigation-item-bg-selected)] text-[var(--index-navigation-sidenavigation-item-text-selected)]'
            : 'text-[var(--index-navigation-sidenavigation-item-text-default)] hover:bg-[var(--index-navigation-sidenavigation-item-bg-hover)] hover:text-[var(--index-navigation-sidenavigation-item-text-hover)]'}`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocSideNavSection, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocSideNavSection, isStandalone: true, selector: "soc-side-nav-section", inputs: { section: { classPropertyName: "section", publicName: "section", isSignal: true, isRequired: true, transformFunction: null }, selectedId: { classPropertyName: "selectedId", publicName: "selectedId", isSignal: true, isRequired: false, transformFunction: null }, collapsed: { classPropertyName: "collapsed", publicName: "collapsed", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { itemSelect: "itemSelect" }, host: { classAttribute: "flex w-full flex-col gap-[var(--index-navigation-sidenavigation-menu-gap)]" }, ngImport: i0, template: `
    @if (!collapsed()) {
      <button type="button" (click)="open.set(!open())" class="flex h-7 w-full items-center justify-between pl-[var(--index-navigation-sidenavigation-item-padding-h)] pr-4">
        <span class="whitespace-nowrap text-[length:var(--index-navigation-sidenavigation-menu-title-size)] tracking-[1.12px] text-[var(--index-navigation-sidenavigation-menu-title-text)] [font-family:var(--index-navigation-sidenavigation-menu-title-font)] [font-weight:var(--index-navigation-sidenavigation-menu-title-weight)]">
          {{ section().title }}
        </span>
        <span [class]="'size-[var(--index-navigation-sidenavigation-menu-title-chevron-size)] text-[var(--index-navigation-sidenavigation-menu-title-chevron)] transition-transform ' + (open() ? '' : '-rotate-90')">
          <svg lucideChevronDown class="size-full" [strokeWidth]="chevronThickness"></svg>
        </span>
      </button>
    }
    @if (open() || collapsed()) {
      <div class="flex w-full flex-col items-start gap-[var(--index-navigation-sidenavigation-items-gap)]">
        @for (item of section().items; track item.id) {
          <button
            type="button"
            (click)="itemClick(item)"
            [title]="collapsed() ? item.label : null"
            [class]="itemClass(item.id)"
          >
            <span [class]="item.id === selectedId() ? 'size-[18px] shrink-0 text-[var(--index-navigation-sidenavigation-item-icon-selected)]' : 'size-[18px] shrink-0 text-[var(--index-navigation-sidenavigation-item-icon-default)]'">
              <ng-container [ngComponentOutlet]="item.icon" [ngComponentOutletInputs]="itemIconInputs" />
            </span>
            @if (!collapsed()) {
              <span class="flex-1 truncate text-left">{{ item.label }}</span>
            }
          </button>
        }
      </div>
    }
  `, isInline: true, dependencies: [{ kind: "component", type: LucideChevronDown, selector: "svg[lucideChevronDown]" }, { kind: "directive", type: NgComponentOutlet, selector: "[ngComponentOutlet]", inputs: ["ngComponentOutlet", "ngComponentOutletInputs", "ngComponentOutletInjector", "ngComponentOutletContent", "ngComponentOutletNgModule", "ngComponentOutletNgModuleFactory"], exportAs: ["ngComponentOutlet"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocSideNavSection, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-side-nav-section',
                    standalone: true,
                    imports: [LucideChevronDown, NgComponentOutlet],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: { class: 'flex w-full flex-col gap-[var(--index-navigation-sidenavigation-menu-gap)]' },
                    template: `
    @if (!collapsed()) {
      <button type="button" (click)="open.set(!open())" class="flex h-7 w-full items-center justify-between pl-[var(--index-navigation-sidenavigation-item-padding-h)] pr-4">
        <span class="whitespace-nowrap text-[length:var(--index-navigation-sidenavigation-menu-title-size)] tracking-[1.12px] text-[var(--index-navigation-sidenavigation-menu-title-text)] [font-family:var(--index-navigation-sidenavigation-menu-title-font)] [font-weight:var(--index-navigation-sidenavigation-menu-title-weight)]">
          {{ section().title }}
        </span>
        <span [class]="'size-[var(--index-navigation-sidenavigation-menu-title-chevron-size)] text-[var(--index-navigation-sidenavigation-menu-title-chevron)] transition-transform ' + (open() ? '' : '-rotate-90')">
          <svg lucideChevronDown class="size-full" [strokeWidth]="chevronThickness"></svg>
        </span>
      </button>
    }
    @if (open() || collapsed()) {
      <div class="flex w-full flex-col items-start gap-[var(--index-navigation-sidenavigation-items-gap)]">
        @for (item of section().items; track item.id) {
          <button
            type="button"
            (click)="itemClick(item)"
            [title]="collapsed() ? item.label : null"
            [class]="itemClass(item.id)"
          >
            <span [class]="item.id === selectedId() ? 'size-[18px] shrink-0 text-[var(--index-navigation-sidenavigation-item-icon-selected)]' : 'size-[18px] shrink-0 text-[var(--index-navigation-sidenavigation-item-icon-default)]'">
              <ng-container [ngComponentOutlet]="item.icon" [ngComponentOutletInputs]="itemIconInputs" />
            </span>
            @if (!collapsed()) {
              <span class="flex-1 truncate text-left">{{ item.label }}</span>
            }
          </button>
        }
      </div>
    }
  `,
                }]
        }] });
/**
 * No native HTML equivalent — plain wrapper (`soc-side-navigation`). Maps 1:1 to
 * "Index/Navigation/SideNavigation/*" tokens — see packages/tokens/tokens/components/navigation.json
 * in design_system (React reference repo, read only). `collapsed` has no internal
 * uncontrolled/default fallback in React either (purely controlled, parent owns it entirely via
 * `onToggleCollapse`) — plain `input()`, not `model()`, unlike Accordion/Checkbox/Switch.
 * `onSelect`/`onToggleCollapse` are direct component-level handlers -> `output()`s
 * (`select`/`toggleCollapse`).
 */
class SocSideNavigation {
    product = input();
    title = input();
    sections = input();
    actionSection = input();
    selectedId = input();
    collapsed = input(false, { transform: booleanAttribute });
    select = output();
    toggleCollapse = output();
    titleIconThickness = 'var(--index-navigation-sidenavigation-title-icon-thickness)';
    actionIconInputs = { class: 'size-full', strokeWidth: 'var(--index-navigation-sidenavigation-action-icon-thickness)' };
    preset = computed(() => {
        const product = this.product();
        return product ? NAVIGATION_PRESETS[product] : undefined;
    });
    hostClasses = computed(() => `flex h-full min-h-0 flex-col overflow-hidden rounded-t-[var(--index-navigation-sidenavigation-nav-radius)] bg-[var(--index-navigation-sidenavigation-nav-bg)] pl-[var(--index-navigation-sidenavigation-nav-padding-h)] pt-[var(--index-navigation-sidenavigation-nav-padding-v)] ${this.collapsed() ? 'w-[var(--index-navigation-sidenavigation-nav-width-closed)]' : 'w-[var(--index-navigation-sidenavigation-nav-width-open)]'}`);
    resolvedTitle = computed(() => this.title() ?? this.preset()?.title ?? '');
    resolvedSections = computed(() => this.sections() ?? this.preset()?.sections ?? []);
    resolvedActionSection = computed(() => this.actionSection() ?? this.preset()?.actionSection);
    actionClick(action) {
        // Matches React exactly: onClick={action.onClick} on the action button, with no onSelect
        // call — React's own doc comment: "Not called for actionSection items — those are commands,
        // not navigation destinations."
        action.onClick?.();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocSideNavigation, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocSideNavigation, isStandalone: true, selector: "soc-side-navigation", inputs: { product: { classPropertyName: "product", publicName: "product", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, sections: { classPropertyName: "sections", publicName: "sections", isSignal: true, isRequired: false, transformFunction: null }, actionSection: { classPropertyName: "actionSection", publicName: "actionSection", isSignal: true, isRequired: false, transformFunction: null }, selectedId: { classPropertyName: "selectedId", publicName: "selectedId", isSignal: true, isRequired: false, transformFunction: null }, collapsed: { classPropertyName: "collapsed", publicName: "collapsed", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { select: "select", toggleCollapse: "toggleCollapse" }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0, template: `
    <div class="flex w-full shrink-0 items-center justify-between py-1 pl-[var(--index-navigation-sidenavigation-title-padding-h)] pr-4">
      @if (!collapsed()) {
        <span class="flex-1 truncate text-[length:var(--index-navigation-sidenavigation-title-size)] text-[var(--index-navigation-sidenavigation-title-text)] [font-family:var(--index-navigation-sidenavigation-title-font)] [font-weight:var(--index-navigation-sidenavigation-title-weight)]">
          {{ resolvedTitle() }}
        </span>
      }
      <button
        type="button"
        (click)="toggleCollapse.emit()"
        [attr.aria-label]="collapsed() ? 'Déplier le menu' : 'Replier le menu'"
        class="size-[18px] shrink-0 text-[var(--index-navigation-sidenavigation-title-icon)]"
      >
        @if (collapsed()) {
          <svg lucidePanelLeftOpen class="size-full" [strokeWidth]="titleIconThickness"></svg>
        } @else {
          <svg lucidePanelLeftClose class="size-full" [strokeWidth]="titleIconThickness"></svg>
        }
      </button>
    </div>

    <div class="scrollbar-hide flex w-full min-h-0 flex-1 flex-col items-start gap-[var(--index-navigation-sidenavigation-section-gap)] overflow-y-auto pt-2 pb-[var(--index-navigation-sidenavigation-nav-padding-v)]">
      @for (section of resolvedSections(); track section.title) {
        <soc-side-nav-section [section]="section" [selectedId]="selectedId()" [collapsed]="collapsed()" (itemSelect)="select.emit($event)" />
      }

      @if (resolvedActionSection(); as actionSection) {
        <div class="flex w-full flex-col gap-[var(--index-navigation-sidenavigation-menu-gap)]">
          @if (!collapsed()) {
            <div class="flex h-7 w-full items-center pl-[var(--index-navigation-sidenavigation-item-padding-h)] pr-4">
              <span class="whitespace-nowrap text-[length:var(--index-navigation-sidenavigation-menu-title-size)] tracking-[1.12px] text-[var(--index-navigation-sidenavigation-menu-title-text)] [font-family:var(--index-navigation-sidenavigation-menu-title-font)] [font-weight:var(--index-navigation-sidenavigation-menu-title-weight)]">
                {{ actionSection.title }}
              </span>
            </div>
          }
          <div class="flex w-full flex-col items-start gap-[2px]">
            @for (action of actionSection.items; track action.id) {
              <button
                type="button"
                (click)="actionClick(action)"
                [title]="collapsed() ? action.label : null"
                class="flex h-10 w-full items-center gap-[var(--index-navigation-sidenavigation-action-gap)] rounded px-[var(--index-navigation-sidenavigation-action-padding-h)] py-[var(--index-navigation-sidenavigation-action-padding-v)] text-[length:var(--index-navigation-sidenavigation-item-size)] text-[var(--index-navigation-sidenavigation-action-text-default)] [font-family:var(--index-navigation-sidenavigation-item-font)] [font-weight:var(--index-navigation-sidenavigation-item-weight)] hover:bg-[var(--index-navigation-sidenavigation-action-bg-hover)]"
              >
                <span class="flex size-[var(--index-navigation-sidenavigation-action-icon-square)] shrink-0 items-center justify-center rounded-[var(--index-navigation-sidenavigation-action-icon-radius)] bg-[var(--index-navigation-sidenavigation-action-icon-bg)] text-[var(--index-navigation-sidenavigation-action-icon-color)]">
                  <span class="size-3.5">
                    <ng-container [ngComponentOutlet]="action.icon" [ngComponentOutletInputs]="actionIconInputs" />
                  </span>
                </span>
                @if (!collapsed()) {
                  <span class="flex-1 truncate text-left">{{ action.label }}</span>
                }
              </button>
            }
          </div>
        </div>
      }
    </div>
  `, isInline: true, dependencies: [{ kind: "component", type: LucidePanelLeftClose, selector: "svg[lucidePanelLeftClose], svg[lucideSidebarClose]" }, { kind: "component", type: LucidePanelLeftOpen, selector: "svg[lucidePanelLeftOpen], svg[lucideSidebarOpen]" }, { kind: "component", type: SocSideNavSection, selector: "soc-side-nav-section", inputs: ["section", "selectedId", "collapsed"], outputs: ["itemSelect"] }, { kind: "directive", type: NgComponentOutlet, selector: "[ngComponentOutlet]", inputs: ["ngComponentOutlet", "ngComponentOutletInputs", "ngComponentOutletInjector", "ngComponentOutletContent", "ngComponentOutletNgModule", "ngComponentOutletNgModuleFactory"], exportAs: ["ngComponentOutlet"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocSideNavigation, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-side-navigation',
                    standalone: true,
                    imports: [LucidePanelLeftClose, LucidePanelLeftOpen, SocSideNavSection, NgComponentOutlet],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[class]': 'hostClasses()',
                    },
                    template: `
    <div class="flex w-full shrink-0 items-center justify-between py-1 pl-[var(--index-navigation-sidenavigation-title-padding-h)] pr-4">
      @if (!collapsed()) {
        <span class="flex-1 truncate text-[length:var(--index-navigation-sidenavigation-title-size)] text-[var(--index-navigation-sidenavigation-title-text)] [font-family:var(--index-navigation-sidenavigation-title-font)] [font-weight:var(--index-navigation-sidenavigation-title-weight)]">
          {{ resolvedTitle() }}
        </span>
      }
      <button
        type="button"
        (click)="toggleCollapse.emit()"
        [attr.aria-label]="collapsed() ? 'Déplier le menu' : 'Replier le menu'"
        class="size-[18px] shrink-0 text-[var(--index-navigation-sidenavigation-title-icon)]"
      >
        @if (collapsed()) {
          <svg lucidePanelLeftOpen class="size-full" [strokeWidth]="titleIconThickness"></svg>
        } @else {
          <svg lucidePanelLeftClose class="size-full" [strokeWidth]="titleIconThickness"></svg>
        }
      </button>
    </div>

    <div class="scrollbar-hide flex w-full min-h-0 flex-1 flex-col items-start gap-[var(--index-navigation-sidenavigation-section-gap)] overflow-y-auto pt-2 pb-[var(--index-navigation-sidenavigation-nav-padding-v)]">
      @for (section of resolvedSections(); track section.title) {
        <soc-side-nav-section [section]="section" [selectedId]="selectedId()" [collapsed]="collapsed()" (itemSelect)="select.emit($event)" />
      }

      @if (resolvedActionSection(); as actionSection) {
        <div class="flex w-full flex-col gap-[var(--index-navigation-sidenavigation-menu-gap)]">
          @if (!collapsed()) {
            <div class="flex h-7 w-full items-center pl-[var(--index-navigation-sidenavigation-item-padding-h)] pr-4">
              <span class="whitespace-nowrap text-[length:var(--index-navigation-sidenavigation-menu-title-size)] tracking-[1.12px] text-[var(--index-navigation-sidenavigation-menu-title-text)] [font-family:var(--index-navigation-sidenavigation-menu-title-font)] [font-weight:var(--index-navigation-sidenavigation-menu-title-weight)]">
                {{ actionSection.title }}
              </span>
            </div>
          }
          <div class="flex w-full flex-col items-start gap-[2px]">
            @for (action of actionSection.items; track action.id) {
              <button
                type="button"
                (click)="actionClick(action)"
                [title]="collapsed() ? action.label : null"
                class="flex h-10 w-full items-center gap-[var(--index-navigation-sidenavigation-action-gap)] rounded px-[var(--index-navigation-sidenavigation-action-padding-h)] py-[var(--index-navigation-sidenavigation-action-padding-v)] text-[length:var(--index-navigation-sidenavigation-item-size)] text-[var(--index-navigation-sidenavigation-action-text-default)] [font-family:var(--index-navigation-sidenavigation-item-font)] [font-weight:var(--index-navigation-sidenavigation-item-weight)] hover:bg-[var(--index-navigation-sidenavigation-action-bg-hover)]"
              >
                <span class="flex size-[var(--index-navigation-sidenavigation-action-icon-square)] shrink-0 items-center justify-center rounded-[var(--index-navigation-sidenavigation-action-icon-radius)] bg-[var(--index-navigation-sidenavigation-action-icon-bg)] text-[var(--index-navigation-sidenavigation-action-icon-color)]">
                  <span class="size-3.5">
                    <ng-container [ngComponentOutlet]="action.icon" [ngComponentOutletInputs]="actionIconInputs" />
                  </span>
                </span>
                @if (!collapsed()) {
                  <span class="flex-1 truncate text-left">{{ action.label }}</span>
                }
              </button>
            }
          </div>
        </div>
      }
    </div>
  `,
                }]
        }] });

/**
 * No native HTML equivalent — plain wrapper (`soc-stepper`). `items: StepperItemData[]` is plain
 * data, a straight `input()`. Maps 1:1 to "Index/Navigation/Stepper/*" tokens — see
 * packages/tokens/tokens/components/navigation.json in design_system (React reference repo, read
 * only).
 */
class SocStepper {
    items = input.required();
    orientation = input('horizontal');
    vertical = computed(() => this.orientation() === 'vertical');
    hostClasses = computed(() => `flex ${this.vertical() ? 'flex-col items-start gap-0' : 'items-center gap-[var(--index-navigation-stepper-item-gap)]'}`);
    active(status) {
        return status !== 'upcoming';
    }
    horizontalSeparatorClass(status) {
        return `h-[var(--index-navigation-stepper-separator-thickness)] w-[var(--index-navigation-stepper-separator-length)] ${this.active(status) ? 'bg-[var(--index-navigation-stepper-separator-color-activated)]' : 'bg-[var(--index-navigation-stepper-separator-color-default)]'}`;
    }
    verticalSeparatorClass(status) {
        return `ml-[calc(var(--index-navigation-stepper-circle-size)/2-1px)] my-1 w-[var(--index-navigation-stepper-separator-thickness)] h-[var(--index-navigation-stepper-separator-length)] ${this.active(status) ? 'bg-[var(--index-navigation-stepper-separator-color-activated)]' : 'bg-[var(--index-navigation-stepper-separator-color-default)]'}`;
    }
    circleClass(status) {
        const base = 'flex size-[var(--index-navigation-stepper-circle-size)] shrink-0 items-center justify-center rounded-[var(--index-navigation-stepper-circle-radius)] text-center text-[length:var(--index-navigation-stepper-font-size)] [font-family:var(--index-navigation-stepper-font-family)]';
        return `${base} ${this.active(status)
            ? 'bg-[var(--index-navigation-stepper-circle-bg-activated)] text-[var(--index-navigation-stepper-circle-text-activated)] [font-weight:var(--index-navigation-stepper-font-weight-activated)]'
            : 'bg-[var(--index-navigation-stepper-circle-bg-default)] text-[var(--index-navigation-stepper-circle-text-default)] [font-weight:var(--index-navigation-stepper-font-weight)]'}`;
    }
    labelClass(status) {
        const base = 'whitespace-nowrap text-[length:var(--index-navigation-stepper-font-size)] [font-family:var(--index-navigation-stepper-font-family)]';
        return `${base} ${this.active(status)
            ? 'text-[var(--index-navigation-stepper-label-activated)] [font-weight:var(--index-navigation-stepper-font-weight-activated)]'
            : 'text-[var(--index-navigation-stepper-label-default)] [font-weight:var(--index-navigation-stepper-font-weight)]'}`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocStepper, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocStepper, isStandalone: true, selector: "soc-stepper", inputs: { items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: true, transformFunction: null }, orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0, template: `
    @for (item of items(); track item.label + $index; let index = $index, isLast = $last) {
      <div [class]="vertical() ? 'flex flex-col items-start' : 'flex items-center gap-[var(--index-navigation-stepper-separator-gap)]'">
        @if (index > 0 && !vertical()) {
          <span [class]="horizontalSeparatorClass(item.status)"></span>
        }
        <div class="flex items-center gap-[var(--index-navigation-stepper-circle-label-gap)]">
          <span [class]="circleClass(item.status)">{{ index + 1 }}</span>
          <span [class]="labelClass(item.status)">{{ item.label }}</span>
        </div>
        @if (vertical() && !isLast) {
          <span [class]="verticalSeparatorClass(item.status)"></span>
        }
      </div>
    }
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocStepper, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-stepper',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[class]': 'hostClasses()',
                    },
                    template: `
    @for (item of items(); track item.label + $index; let index = $index, isLast = $last) {
      <div [class]="vertical() ? 'flex flex-col items-start' : 'flex items-center gap-[var(--index-navigation-stepper-separator-gap)]'">
        @if (index > 0 && !vertical()) {
          <span [class]="horizontalSeparatorClass(item.status)"></span>
        }
        <div class="flex items-center gap-[var(--index-navigation-stepper-circle-label-gap)]">
          <span [class]="circleClass(item.status)">{{ index + 1 }}</span>
          <span [class]="labelClass(item.status)">{{ item.label }}</span>
        </div>
        @if (vertical() && !isLast) {
          <span [class]="verticalSeparatorClass(item.status)"></span>
        }
      </div>
    }
  `,
                }]
        }] });

const trackSizeClasses = {
    sm: 'h-[var(--index-contrôleur-switch-track-h-sm)] w-[var(--index-contrôleur-switch-track-w-sm)]',
    md: 'h-[var(--index-contrôleur-switch-track-h-md)] w-[var(--index-contrôleur-switch-track-w-md)]',
    lg: 'h-[var(--index-contrôleur-switch-track-h-lg)] w-[var(--index-contrôleur-switch-track-w-lg)]',
};
const thumbSizeClasses = {
    sm: 'size-[var(--index-contrôleur-switch-thumb-sm)]',
    md: 'size-[var(--index-contrôleur-switch-thumb-md)]',
    lg: 'size-[var(--index-contrôleur-switch-thumb-lg)]',
};
const thumbTranslateClasses = {
    sm: 'translate-x-[calc(var(--index-contrôleur-switch-track-w-sm)-var(--index-contrôleur-switch-thumb-sm)-2*var(--index-contrôleur-switch-track-padding))]',
    md: 'translate-x-[calc(var(--index-contrôleur-switch-track-w-md)-var(--index-contrôleur-switch-thumb-md)-2*var(--index-contrôleur-switch-track-padding))]',
    lg: 'translate-x-[calc(var(--index-contrôleur-switch-track-w-lg)-var(--index-contrôleur-switch-thumb-lg)-2*var(--index-contrôleur-switch-track-padding))]',
};
/** Same structural GAP-DECISION as Checkbox — see that component's own docstring, not repeated
 * here. Maps 1:1 to "Index/Contrôleur/Switch/*" tokens — see
 * packages/tokens/tokens/components/contrôleur.json in design_system (React reference repo, read
 * only).
 */
class SocSwitch extends SocFormControl {
    checked = model(false);
    size = input('sm');
    valueModel = this.checked;
    coerce(value) {
        return !!value;
    }
    label = input();
    id = input();
    generatedId = nextUniqueId('soc-switch');
    get switchId() {
        return this.id() ?? this.generatedId;
    }
    toggle() {
        if (this.isDisabled())
            return;
        this.checked.set(!this.checked());
    }
    hostClass = computed(() => `inline-flex items-center gap-2 ${this.isDisabled() ? `cursor-not-allowed opacity-[var(--index-contrôleur-switch-opacity-disabled)]` : 'cursor-pointer'}`);
    trackClass = computed(() => `relative flex shrink-0 items-center rounded-[var(--index-contrôleur-switch-radius-track)] p-[var(--index-contrôleur-switch-track-padding)] transition-colors ${trackSizeClasses[this.size()]} ${this.checked()
        ? 'bg-[var(--index-contrôleur-switch-track-on-default)] hover:bg-[var(--index-contrôleur-switch-track-on-hover)] active:bg-[var(--index-contrôleur-switch-track-on-pressed)]'
        : 'bg-[var(--index-contrôleur-switch-track-off-default)] hover:bg-[var(--index-contrôleur-switch-track-off-hover)] active:bg-[var(--index-contrôleur-switch-track-off-pressed)]'}`);
    thumbClass = computed(() => `block shrink-0 rounded-full bg-[var(--index-contrôleur-switch-thumb-fill)] transition-transform ${thumbSizeClasses[this.size()]} ${this.checked() ? thumbTranslateClasses[this.size()] : 'translate-x-0'}`);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocSwitch, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocSwitch, isStandalone: true, selector: "soc-switch", inputs: { checked: { classPropertyName: "checked", publicName: "checked", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { checked: "checkedChange" }, host: { properties: { "attr.id": "null" } }, providers: [provideFormControl(() => SocSwitch)], usesInheritance: true, ngImport: i0, template: `
    <label [for]="switchId" [class]="hostClass()">
      <button
        [id]="switchId"
        type="button"
        role="switch"
        [attr.aria-checked]="checked()"
        [disabled]="isDisabled()"
        (click)="toggle()"
        (blur)="onTouched()"
        class="inline-flex shrink-0 items-center justify-center rounded-[var(--index-contrôleur-switch-radius-track)] p-[var(--index-contrôleur-switch-outer-padding)] focus-visible:outline-none focus-visible:ring-[length:var(--index-contrôleur-switch-border-focus-stroke)] focus-visible:ring-[var(--index-contrôleur-switch-border-focus-color)]"
      >
        <span [class]="trackClass()">
          <span [class]="thumbClass()"></span>
        </span>
      </button>
      @if (label()) {
        <span class="text-[var(--bridges-color-text-primary)]">{{ label() }}</span>
      }
    </label>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocSwitch, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-switch',
                    standalone: true,
                    providers: [provideFormControl(() => SocSwitch)],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    // `id` targets the inner control (the `<label for>` target), like React — a static `id="…"` on
                    // the element would otherwise also land on this host as a duplicate DOM id.
                    host: { '[attr.id]': 'null' },
                    template: `
    <label [for]="switchId" [class]="hostClass()">
      <button
        [id]="switchId"
        type="button"
        role="switch"
        [attr.aria-checked]="checked()"
        [disabled]="isDisabled()"
        (click)="toggle()"
        (blur)="onTouched()"
        class="inline-flex shrink-0 items-center justify-center rounded-[var(--index-contrôleur-switch-radius-track)] p-[var(--index-contrôleur-switch-outer-padding)] focus-visible:outline-none focus-visible:ring-[length:var(--index-contrôleur-switch-border-focus-stroke)] focus-visible:ring-[var(--index-contrôleur-switch-border-focus-color)]"
      >
        <span [class]="trackClass()">
          <span [class]="thumbClass()"></span>
        </span>
      </button>
      @if (label()) {
        <span class="text-[var(--bridges-color-text-primary)]">{{ label() }}</span>
      }
    </label>
  `,
                }]
        }] });

/**
 * No native HTML equivalent — plain wrapper (`soc-tabs`). Maps to "Index/Navigation/Tab/*"
 * (underline) or "Index/Navigation/Tab2/*" (pill) tokens in design_system (React reference repo,
 * read only). Both variants live in one component/template (an `@if`), same as React's own
 * `Tabs` picking between its two internal `UnderlineTabs`/`PillTabs` functions.
 */
class SocTabs {
    items = input.required();
    value = input.required();
    variant = input('underline');
    change = output();
    hostClasses = computed(() => this.variant() === 'pill'
        ? 'inline-flex items-center gap-[var(--index-navigation-tab2-container-gap)] rounded-[var(--index-navigation-tab2-container-radius)] bg-[var(--index-navigation-tab2-container-bg)] p-[var(--index-navigation-tab2-container-padding)]'
        : 'flex border-b-[1px] border-[var(--index-navigation-tab-border-bottom)]');
    pillItemClass(item) {
        const selected = item.id === this.value();
        return `rounded-[var(--index-navigation-tab2-item-radius)] px-[var(--index-navigation-tab2-item-padding-h)] py-[var(--index-navigation-tab2-item-padding-v)] disabled:cursor-not-allowed disabled:opacity-50 [font-family:var(--index-navigation-tab2-font-family)] [font-weight:var(--index-navigation-tab2-font-weight)] text-[length:var(--index-navigation-tab2-font-size)] ${selected
            ? 'bg-[var(--index-navigation-tab2-item-bg-selected)] text-[var(--index-navigation-tab2-item-text-selected)] shadow-sm'
            : 'bg-[var(--index-navigation-tab2-item-bg-default)] text-[var(--index-navigation-tab2-item-text-default)] hover:bg-[var(--index-navigation-tab2-item-bg-hover)] hover:text-[var(--index-navigation-tab2-item-text-hover)]'}`;
    }
    underlineButtonClass(item) {
        const selected = item.id === this.value();
        return `group flex flex-col items-center disabled:cursor-not-allowed disabled:opacity-50 [font-family:var(--index-navigation-tab-font-family)] text-[length:var(--index-navigation-tab-font-size)] ${selected ? '[font-weight:var(--index-navigation-tab-font-weight-selected)]' : '[font-weight:var(--index-navigation-tab-font-weight-default)]'}`;
    }
    underlineInnerClass(item) {
        const selected = item.id === this.value();
        return `flex items-center gap-[var(--index-navigation-tab-icon-gap)] px-[var(--index-navigation-tab-pad-h)] py-[var(--index-navigation-tab-pad-v)] ${selected ? 'text-[var(--index-navigation-tab-text-selected)]' : 'text-[var(--index-navigation-tab-text-default)] group-hover:text-[var(--index-navigation-tab-text-hover)]'}`;
    }
    underlineIconClass(item) {
        const selected = item.id === this.value();
        return `size-[var(--index-navigation-tab-icon-size)] shrink-0 ${selected ? 'text-[var(--index-navigation-tab-icon-selected)]' : 'text-[var(--index-navigation-tab-icon-default)] group-hover:text-[var(--index-navigation-tab-icon-hover)]'}`;
    }
    underlineIndicatorClass(item) {
        const selected = item.id === this.value();
        return `h-[var(--index-navigation-tab-indicator-height)] w-full ${selected ? 'bg-[var(--index-navigation-tab-indicator-selected)]' : 'bg-transparent group-hover:bg-[var(--index-navigation-tab-indicator-hover)]'}`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocTabs, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocTabs, isStandalone: true, selector: "soc-tabs", inputs: { items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: true, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: true, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { change: "change" }, host: { attributes: { "role": "tablist" }, properties: { "class": "hostClasses()" } }, ngImport: i0, template: `
    @if (variant() === 'pill') {
      @for (item of items(); track item.id) {
        <button
          type="button"
          role="tab"
          [attr.aria-selected]="item.id === value()"
          [disabled]="item.disabled"
          (click)="change.emit(item.id)"
          [class]="pillItemClass(item)"
        >
          {{ item.label }}
        </button>
      }
    } @else {
      @for (item of items(); track item.id) {
        <button
          type="button"
          role="tab"
          [attr.aria-selected]="item.id === value()"
          [disabled]="item.disabled"
          (click)="change.emit(item.id)"
          [class]="underlineButtonClass(item)"
        >
          <span [class]="underlineInnerClass(item)">
            @if (item.icon) {
              <span [class]="underlineIconClass(item)">
                <ng-container [ngTemplateOutlet]="item.icon" />
              </span>
            }
            {{ item.label }}
          </span>
          <span [class]="underlineIndicatorClass(item)"></span>
        </button>
      }
    }
  `, isInline: true, dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocTabs, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-tabs',
                    standalone: true,
                    imports: [NgTemplateOutlet],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        role: 'tablist',
                        '[class]': 'hostClasses()',
                    },
                    template: `
    @if (variant() === 'pill') {
      @for (item of items(); track item.id) {
        <button
          type="button"
          role="tab"
          [attr.aria-selected]="item.id === value()"
          [disabled]="item.disabled"
          (click)="change.emit(item.id)"
          [class]="pillItemClass(item)"
        >
          {{ item.label }}
        </button>
      }
    } @else {
      @for (item of items(); track item.id) {
        <button
          type="button"
          role="tab"
          [attr.aria-selected]="item.id === value()"
          [disabled]="item.disabled"
          (click)="change.emit(item.id)"
          [class]="underlineButtonClass(item)"
        >
          <span [class]="underlineInnerClass(item)">
            @if (item.icon) {
              <span [class]="underlineIconClass(item)">
                <ng-container [ngTemplateOutlet]="item.icon" />
              </span>
            }
            {{ item.label }}
          </span>
          <span [class]="underlineIndicatorClass(item)"></span>
        </button>
      }
    }
  `,
                }]
        }] });

const colorClasses = {
    success: 'bg-[var(--index-feedback-tag-bg-success)] text-[var(--index-feedback-tag-text-success)]',
    warning: 'bg-[var(--index-feedback-tag-bg-warning)] text-[var(--index-feedback-tag-text-warning)]',
    error: 'bg-[var(--index-feedback-tag-bg-error)] text-[var(--index-feedback-tag-text-error)]',
    information: 'bg-[var(--index-feedback-tag-bg-information)] text-[var(--index-feedback-tag-text-information)]',
    purple: 'bg-[var(--index-feedback-tag-bg-purple)] text-[var(--index-feedback-tag-text-purple)]',
    orange: 'bg-[var(--index-feedback-tag-bg-orange)] text-[var(--index-feedback-tag-text-orange)]',
};
const sizeClasses = {
    sm: 'px-[var(--index-feedback-tag-padding-h-sm)] py-[var(--index-feedback-tag-padding-v-sm)] text-[length:var(--index-feedback-tag-font-size-sm)]',
    lg: 'px-[var(--index-feedback-tag-padding-h-lg)] py-[var(--index-feedback-tag-padding-v-lg)] text-[length:var(--index-feedback-tag-font-size-lg)]',
};
/**
 * No native HTML equivalent — plain wrapper (`soc-tag` element selector). `children: ReactNode`
 * becomes a default `<ng-content>`.
 *
 * React's `onRemove?: () => void` prop doubles as both "show the remove button" and "the handler"
 * — an `output()` can't be introspected the same way (no public "is anyone listening" signal), so
 * this splits into a `removable` input (controls whether the button renders) plus a `remove`
 * output (the handler) instead of inferring visibility from whether `(remove)` was bound.
 *
 * The remove (×) button draws its own icon (`LucideX`, `@lucide/angular`) rather than projecting
 * one — same as React's own `<X className="size-3" .../>`, not a consumer-supplied slot.
 *
 * Maps 1:1 to "Index/Feedback/Tag/*" tokens — see packages/tokens/tokens/components/feedback.json
 * in design_system (React reference repo, read only).
 */
class SocTag {
    color = input('success');
    size = input('sm');
    removable = input(false, { transform: booleanAttribute });
    remove = output();
    hostClasses = computed(() => `inline-flex items-center gap-1 whitespace-nowrap rounded-[var(--index-feedback-tag-radius)] text-center [font-family:var(--index-feedback-tag-font-family)] [font-weight:var(--index-feedback-tag-font-weight)] ${colorClasses[this.color()]} ${sizeClasses[this.size()]}`);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocTag, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocTag, isStandalone: true, selector: "soc-tag", inputs: { color: { classPropertyName: "color", publicName: "color", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, removable: { classPropertyName: "removable", publicName: "removable", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { remove: "remove" }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0, template: `
    <ng-content />
    @if (removable()) {
      <button type="button" (click)="remove.emit()" aria-label="Retirer" class="shrink-0 opacity-70 hover:opacity-100">
        <svg lucideX class="size-3" [strokeWidth]="1.5"></svg>
      </button>
    }
  `, isInline: true, dependencies: [{ kind: "component", type: LucideX, selector: "svg[lucideX]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocTag, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-tag',
                    standalone: true,
                    imports: [LucideX],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[class]': 'hostClasses()',
                    },
                    template: `
    <ng-content />
    @if (removable()) {
      <button type="button" (click)="remove.emit()" aria-label="Retirer" class="shrink-0 opacity-70 hover:opacity-100">
        <svg lucideX class="size-3" [strokeWidth]="1.5"></svg>
      </button>
    }
  `,
                }]
        }] });

/** React `Tooltip`'s `label: ReactNode` (default/message variants). */
class SocTooltipLabel {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocTooltipLabel, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocTooltipLabel, isStandalone: true, selector: "[socTooltipLabel]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocTooltipLabel, decorators: [{
            type: Directive,
            args: [{ selector: '[socTooltipLabel]', standalone: true }]
        }] });
/** React `Tooltip`'s `content: ReactNode` (extend variant only — its `title` stays a plain
 * string input, it's typed `string` in React too). */
class SocTooltipContent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocTooltipContent, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocTooltipContent, isStandalone: true, selector: "[socTooltipContent]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocTooltipContent, decorators: [{
            type: Directive,
            args: [{ selector: '[socTooltipContent]', standalone: true }]
        }] });
/** Gap (px) between trigger and bubble. Also reused as `flipIfNeeded`'s margin so a flip and the
 * resulting gap agree on how much room counts as "enough". Ported 1:1 from React Tooltip.tsx. */
const GAP = 8;
const VIEWPORT_MARGIN = 4;
function computeFixedPosition(position, triggerRect, bubbleRect) {
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    if (position === 'left' || position === 'right') {
        const left = position === 'right' ? triggerRect.right + GAP : triggerRect.left - bubbleRect.width - GAP;
        const top = triggerRect.top + triggerRect.height / 2 - bubbleRect.height / 2;
        return { top: Math.min(Math.max(VIEWPORT_MARGIN, top), vh - bubbleRect.height - VIEWPORT_MARGIN), left };
    }
    const top = position === 'bottom' ? triggerRect.bottom + GAP : triggerRect.top - bubbleRect.height - GAP;
    const left = triggerRect.left + triggerRect.width / 2 - bubbleRect.width / 2;
    return { top, left: Math.min(Math.max(VIEWPORT_MARGIN, left), vw - bubbleRect.width - VIEWPORT_MARGIN) };
}
function flipIfNeeded(preferred, triggerRect, bubbleRect) {
    if (preferred === 'top' || preferred === 'bottom') {
        const spaceAbove = triggerRect.top;
        const spaceBelow = window.innerHeight - triggerRect.bottom;
        const needed = bubbleRect.height + GAP;
        if (preferred === 'top' && spaceAbove < needed && spaceBelow > spaceAbove)
            return 'bottom';
        if (preferred === 'bottom' && spaceBelow < needed && spaceAbove > spaceBelow)
            return 'top';
        return preferred;
    }
    const spaceLeft = triggerRect.left;
    const spaceRight = window.innerWidth - triggerRect.right;
    const needed = bubbleRect.width + GAP;
    if (preferred === 'left' && spaceLeft < needed && spaceRight > spaceLeft)
        return 'right';
    if (preferred === 'right' && spaceRight < needed && spaceLeft > spaceRight)
        return 'left';
    return preferred;
}
/** Figma no longer exposes a bound "arrow-size" variable — the arrow is a fixed 10px-wide
 * triangle directly in the source art, hardcoded here too (matches React). */
const arrowPositionClasses = {
    top: 'top-full left-1/2 -translate-x-1/2 border-x-[5px] border-x-transparent border-t-[5px]',
    bottom: 'bottom-full left-1/2 -translate-x-1/2 border-x-[5px] border-x-transparent border-b-[5px]',
    left: 'left-full top-1/2 -translate-y-1/2 border-y-[5px] border-y-transparent border-l-[5px]',
    right: 'right-full top-1/2 -translate-y-1/2 border-y-[5px] border-y-transparent border-r-[5px]',
};
const messageBgClasses = {
    success: 'bg-[var(--index-feedback-tooltip-msg-bg-success)]',
    error: 'bg-[var(--index-feedback-tooltip-msg-bg-error)]',
    warning: 'bg-[var(--index-feedback-tooltip-msg-bg-warning)]',
    info: 'bg-[var(--index-feedback-tooltip-msg-bg-info)]',
};
const messageTextClasses = {
    success: 'text-[var(--index-feedback-tooltip-msg-text-success)]',
    error: 'text-[var(--index-feedback-tooltip-msg-text-error)]',
    warning: 'text-[var(--index-feedback-tooltip-msg-text-warning)]',
    info: 'text-[var(--index-feedback-tooltip-msg-text-info)]',
};
const messageArrowColorVar = {
    success: 'var(--index-feedback-tooltip-msg-bg-success)',
    error: 'var(--index-feedback-tooltip-msg-bg-error)',
    warning: 'var(--index-feedback-tooltip-msg-bg-warning)',
    info: 'var(--index-feedback-tooltip-msg-bg-info)',
};
/**
 * No native HTML equivalent — plain wrapper (`soc-tooltip`). React's version uses `cloneElement`
 * to inject `aria-describedby`/a composed `onClick` directly onto its `children` element — Angular
 * has no equivalent of cloning an arbitrary projected element with extra props (there's no
 * `TemplateRef`-free way to reach into projected content and add attributes/listeners to it).
 * Worked around it rather than reproducing it: the hover/focus/click listeners live on this
 * component's own HOST element instead (matching React's outer wrapper `<span ref={wrapperRef}>`,
 * which already carries the hover/focus listeners in React too) — `(focusout)`/`(focusin)` bubble
 * from any projected content the same way React's synthetic `onFocus`/`onBlur` do, and a host
 * `(click)` catches bubbled clicks from the trigger to dismiss the tooltip, without needing to
 * clone or modify the projected element itself. The one bit of fidelity this trades away:
 * `aria-describedby` lands on the wrapper host rather than the actual trigger element.
 *
 * Bubble is portaled to `document.body` via a direct `appendChild` in `ngAfterViewInit` (Angular
 * has no CDK Overlay in this project) — same reasoning as React's `createPortal`: a relatively-
 * positioned bubble gets silently clipped by any scrollable/`overflow` ancestor. Position-computing
 * functions (`computeFixedPosition`/`flipIfNeeded`) are ported 1:1 from React's own.
 *
 * Maps 1:1 to "Index/Feedback/Tooltip/*" tokens — see packages/tokens/tokens/components/feedback.json
 * in design_system (React reference repo, read only).
 */
class SocTooltip {
    position = input('top');
    variant = input('default');
    title = input();
    status = input('info');
    showIcon = input(true, { transform: booleanAttribute });
    arrowPositionClasses = arrowPositionClasses;
    tooltipId = nextUniqueId('soc-tooltip');
    visible = signal(false);
    resolvedPosition = signal('top');
    topPx = signal(0);
    leftPx = signal(0);
    hostRef = inject((ElementRef));
    bubbleRef = viewChild('bubble');
    appended = false;
    constructor() {
        effect(() => {
            // Re-run whenever visible/position change; reads both so both are tracked dependencies.
            const isVisible = this.visible();
            this.position();
            const bubbleEl = this.bubbleRef()?.nativeElement;
            if (!bubbleEl)
                return;
            if (!this.appended) {
                document.body.appendChild(bubbleEl);
                this.appended = true;
            }
            if (isVisible)
                this.reposition();
        });
        const onWindowChange = () => {
            if (this.visible())
                this.reposition();
        };
        window.addEventListener('resize', onWindowChange);
        window.addEventListener('scroll', onWindowChange, true);
        inject(DestroyRef).onDestroy(() => {
            window.removeEventListener('resize', onWindowChange);
            window.removeEventListener('scroll', onWindowChange, true);
            this.bubbleRef()?.nativeElement.remove();
        });
    }
    show() {
        this.visible.set(true);
    }
    hide() {
        this.visible.set(false);
    }
    reposition() {
        const bubbleEl = this.bubbleRef()?.nativeElement;
        if (!bubbleEl)
            return;
        const triggerRect = this.hostRef.nativeElement.getBoundingClientRect();
        const bubbleRect = bubbleEl.getBoundingClientRect();
        const resolved = flipIfNeeded(this.position(), triggerRect, bubbleRect);
        this.resolvedPosition.set(resolved);
        const { top, left } = computeFixedPosition(resolved, triggerRect, bubbleRect);
        this.topPx.set(top);
        this.leftPx.set(left);
    }
    arrowStyle = computed(() => {
        const key = {
            top: 'border-top-color',
            bottom: 'border-bottom-color',
            left: 'border-left-color',
            right: 'border-right-color',
        };
        const color = this.variant() === 'message' ? messageArrowColorVar[this.status()] : 'var(--index-feedback-tooltip-bg)';
        return `${key[this.resolvedPosition()]}: ${color}`;
    });
    bubbleClass = computed(() => {
        const base = 'pointer-events-none z-10 rounded-[var(--index-feedback-tooltip-radius)] px-[var(--index-feedback-tooltip-padding-h)] py-[var(--index-feedback-tooltip-padding-v)] text-[length:var(--index-feedback-tooltip-font-size)] [font-family:var(--index-feedback-tooltip-font-family)]';
        if (this.variant() === 'message') {
            return `${base} flex items-center gap-[var(--index-feedback-tooltip-msg-icon-gap)] whitespace-nowrap ${messageBgClasses[this.status()]} ${messageTextClasses[this.status()]}`;
        }
        if (this.variant() === 'extend') {
            return `${base} flex w-[220px] flex-col gap-[var(--index-feedback-tooltip-extend-gap)] bg-[var(--index-feedback-tooltip-bg)] text-[var(--index-feedback-tooltip-text-color)]`;
        }
        return `${base} whitespace-nowrap bg-[var(--index-feedback-tooltip-bg)] text-[var(--index-feedback-tooltip-text-color)] [font-weight:var(--index-feedback-tooltip-font-weight)]`;
    });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocTooltip, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocTooltip, isStandalone: true, selector: "soc-tooltip", inputs: { position: { classPropertyName: "position", publicName: "position", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, status: { classPropertyName: "status", publicName: "status", isSignal: true, isRequired: false, transformFunction: null }, showIcon: { classPropertyName: "showIcon", publicName: "showIcon", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "mouseenter": "show()", "mouseleave": "hide()", "focusin": "show()", "focusout": "hide()", "click": "hide()" }, properties: { "attr.aria-describedby": "visible() ? tooltipId : null" }, classAttribute: "relative inline-flex" }, viewQueries: [{ propertyName: "bubbleRef", first: true, predicate: ["bubble"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <ng-content />
    <span
      #bubble
      role="tooltip"
      [attr.id]="tooltipId"
      [style.position]="'fixed'"
      [style.top.px]="topPx()"
      [style.left.px]="leftPx()"
      [style.visibility]="visible() ? 'visible' : 'hidden'"
      [class]="bubbleClass()"
    >
      @if (variant() === 'extend') {
        <p class="w-full [font-weight:var(--index-feedback-tooltip-extend-title-weight)] text-[length:var(--index-feedback-tooltip-extend-title-size)] [font-family:var(--index-feedback-tooltip-extend-title-font)]">
          {{ title() }}
        </p>
        <div class="w-full font-normal">
          <ng-content select="[socTooltipContent]" />
        </div>
      } @else {
        @if (variant() === 'message' && showIcon()) {
          <span class="size-[var(--index-feedback-tooltip-msg-icon-size)] shrink-0">
            @switch (status()) {
              @case ('success') {
                <svg lucideCircleCheck class="size-full" [strokeWidth]="1.5"></svg>
              }
              @case ('error') {
                <svg lucideCircleX class="size-full" [strokeWidth]="1.5"></svg>
              }
              @case ('warning') {
                <svg lucideTriangleAlert class="size-full" [strokeWidth]="1.5"></svg>
              }
              @case ('info') {
                <svg lucideCircleAlert class="size-full" [strokeWidth]="1.5"></svg>
              }
            }
          </span>
        }
        <!-- Single instance of this selector for both "default" and "message" variants — Angular
             assigns each distinct ng-content selector to exactly one static slot bucket, so the
             same selector appearing in two different ng-content instances (one per variant branch)
             silently drops whichever one isn't the canonical slot, even though only one branch is
             ever active at a time. Verified this empirically: the "message" branch's copy worked,
             the "default" one silently rendered nothing. -->
        <ng-content select="[socTooltipLabel]" />
      }
      <span class="absolute size-0" [class]="arrowPositionClasses[resolvedPosition()]" [style]="arrowStyle()"></span>
    </span>
  `, isInline: true, dependencies: [{ kind: "component", type: LucideCircleAlert, selector: "svg[lucideCircleAlert], svg[lucideAlertCircle]" }, { kind: "component", type: LucideCircleCheck, selector: "svg[lucideCircleCheck], svg[lucideCheckCircle2]" }, { kind: "component", type: LucideCircleX, selector: "svg[lucideCircleX], svg[lucideXCircle]" }, { kind: "component", type: LucideTriangleAlert, selector: "svg[lucideTriangleAlert], svg[lucideAlertTriangle]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocTooltip, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-tooltip',
                    standalone: true,
                    imports: [LucideCircleAlert, LucideCircleCheck, LucideCircleX, LucideTriangleAlert],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        class: 'relative inline-flex',
                        '(mouseenter)': 'show()',
                        '(mouseleave)': 'hide()',
                        '(focusin)': 'show()',
                        '(focusout)': 'hide()',
                        '(click)': 'hide()',
                        '[attr.aria-describedby]': 'visible() ? tooltipId : null',
                    },
                    template: `
    <ng-content />
    <span
      #bubble
      role="tooltip"
      [attr.id]="tooltipId"
      [style.position]="'fixed'"
      [style.top.px]="topPx()"
      [style.left.px]="leftPx()"
      [style.visibility]="visible() ? 'visible' : 'hidden'"
      [class]="bubbleClass()"
    >
      @if (variant() === 'extend') {
        <p class="w-full [font-weight:var(--index-feedback-tooltip-extend-title-weight)] text-[length:var(--index-feedback-tooltip-extend-title-size)] [font-family:var(--index-feedback-tooltip-extend-title-font)]">
          {{ title() }}
        </p>
        <div class="w-full font-normal">
          <ng-content select="[socTooltipContent]" />
        </div>
      } @else {
        @if (variant() === 'message' && showIcon()) {
          <span class="size-[var(--index-feedback-tooltip-msg-icon-size)] shrink-0">
            @switch (status()) {
              @case ('success') {
                <svg lucideCircleCheck class="size-full" [strokeWidth]="1.5"></svg>
              }
              @case ('error') {
                <svg lucideCircleX class="size-full" [strokeWidth]="1.5"></svg>
              }
              @case ('warning') {
                <svg lucideTriangleAlert class="size-full" [strokeWidth]="1.5"></svg>
              }
              @case ('info') {
                <svg lucideCircleAlert class="size-full" [strokeWidth]="1.5"></svg>
              }
            }
          </span>
        }
        <!-- Single instance of this selector for both "default" and "message" variants — Angular
             assigns each distinct ng-content selector to exactly one static slot bucket, so the
             same selector appearing in two different ng-content instances (one per variant branch)
             silently drops whichever one isn't the canonical slot, even though only one branch is
             ever active at a time. Verified this empirically: the "message" branch's copy worked,
             the "default" one silently rendered nothing. -->
        <ng-content select="[socTooltipLabel]" />
      }
      <span class="absolute size-0" [class]="arrowPositionClasses[resolvedPosition()]" [style]="arrowStyle()"></span>
    </span>
  `,
                }]
        }], ctorParameters: () => [] });

/** React `MenuItem`'s `icon?: ReactNode` — only rendered when `mode === 'icon'`. */
class SocMenuItemIcon {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocMenuItemIcon, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocMenuItemIcon, isStandalone: true, selector: "[socMenuItemIcon]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocMenuItemIcon, decorators: [{
            type: Directive,
            args: [{ selector: '[socMenuItemIcon]', standalone: true }]
        }] });
const LEVEL_PADDING = {
    1: 'pl-[var(--index-conteneur-menu-item-pad-h)]',
    2: 'pl-[var(--index-conteneur-menu-level2-indent)]',
    3: 'pl-[var(--index-conteneur-menu-level3-indent)]',
};
/**
 * Attribute selector on a real `<button>` (`button[socMenuItem]`) — React's `MenuItem` root IS a
 * single `<button type="button">`, same shape as `Button` itself, so `(click)` (React `onClick`),
 * `disabled`, `aria-*` etc. are just the native ones. Maps 1:1 to "Index/Conteneur/Menu/*" tokens —
 * see packages/tokens/tokens/components/conteneur.json in design_system (React reference repo,
 * read only). `icon` -> named content slot (`socMenuItemIcon`).
 *
 * `checked` is optional here exactly like in React: undefined leaves the inner `Checkbox`
 * uncontrolled (it keeps its own state), a value drives it. One known difference, only reachable by
 * passing `checked` without ever updating it on click: React's controlled `Checkbox` then ignores
 * the click, whereas `soc-checkbox`'s `model()` flips its own value locally until the bound value
 * next changes. Normal usage (parent toggles `checked` in its own `(click)` handler) is identical.
 */
class SocMenuItem {
    label = input.required();
    level = input(1);
    mode = input('icon');
    checked = input();
    iconContent = contentChild(SocMenuItemIcon);
    hasIcon = computed(() => !!this.iconContent());
    hostClasses = computed(() => `flex w-full min-w-[160px] items-center gap-[var(--index-conteneur-menu-item-gap)] py-[var(--index-conteneur-menu-item-pad-v)] pr-[var(--index-conteneur-menu-item-pad-h)] text-left hover:bg-[var(--index-conteneur-menu-item-bg-hover)] active:bg-[var(--index-conteneur-menu-item-bg-pressed)] focus-visible:outline-none focus-visible:border-[length:var(--index-conteneur-menu-item-border-width)] focus-visible:border-[var(--index-conteneur-menu-item-border-focus)] ${LEVEL_PADDING[this.level()]}`);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocMenuItem, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocMenuItem, isStandalone: true, selector: "button[socMenuItem]", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, level: { classPropertyName: "level", publicName: "level", isSignal: true, isRequired: false, transformFunction: null }, mode: { classPropertyName: "mode", publicName: "mode", isSignal: true, isRequired: false, transformFunction: null }, checked: { classPropertyName: "checked", publicName: "checked", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "type": "button" }, properties: { "class": "hostClasses()" } }, queries: [{ propertyName: "iconContent", first: true, predicate: SocMenuItemIcon, descendants: true, isSignal: true }], ngImport: i0, template: `
    @if (mode() === 'icon' && hasIcon()) {
      <span class="size-[var(--index-conteneur-menu-item-icon-size)] shrink-0 text-[var(--index-conteneur-menu-item-icon-color)]">
        <ng-content select="[socMenuItemIcon]" />
      </span>
    }
    @if (mode() === 'checkbox') {
      <soc-checkbox [checked]="checked() ?? false" />
    }
    @if (mode() === 'radio') {
      <soc-radio-button [selected]="checked() ?? false" />
    }
    <span class="flex-1 text-[length:var(--index-conteneur-menu-item-text-size)] text-[var(--index-conteneur-menu-item-text-color)] [font-family:var(--index-conteneur-menu-item-text-font)] [font-weight:var(--index-conteneur-menu-item-text-weight)]">
      {{ label() }}
    </span>
  `, isInline: true, dependencies: [{ kind: "component", type: SocCheckbox, selector: "soc-checkbox", inputs: ["checked", "label", "id"], outputs: ["checkedChange"] }, { kind: "component", type: SocRadioButton, selector: "soc-radio-button", inputs: ["selected", "disabled", "label", "name", "id", "value"], outputs: ["selectedChange", "select"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocMenuItem, decorators: [{
            type: Component,
            args: [{
                    selector: 'button[socMenuItem]',
                    standalone: true,
                    imports: [SocCheckbox, SocRadioButton],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        type: 'button',
                        '[class]': 'hostClasses()',
                    },
                    template: `
    @if (mode() === 'icon' && hasIcon()) {
      <span class="size-[var(--index-conteneur-menu-item-icon-size)] shrink-0 text-[var(--index-conteneur-menu-item-icon-color)]">
        <ng-content select="[socMenuItemIcon]" />
      </span>
    }
    @if (mode() === 'checkbox') {
      <soc-checkbox [checked]="checked() ?? false" />
    }
    @if (mode() === 'radio') {
      <soc-radio-button [selected]="checked() ?? false" />
    }
    <span class="flex-1 text-[length:var(--index-conteneur-menu-item-text-size)] text-[var(--index-conteneur-menu-item-text-color)] [font-family:var(--index-conteneur-menu-item-text-font)] [font-weight:var(--index-conteneur-menu-item-text-weight)]">
      {{ label() }}
    </span>
  `,
                }]
        }] });
/**
 * No native HTML equivalent — plain wrapper (`soc-menu`). A list of `button[socMenuItem]`, meant to
 * be the projected content of a `soc-popover`. React's `className` merge needs no input here: a
 * literal `class="..."` on `<soc-menu>` composes with this host's own classes natively.
 */
class SocMenu {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocMenu, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.25", type: SocMenu, isStandalone: true, selector: "soc-menu", host: { classAttribute: "flex w-full flex-col items-start gap-[var(--index-conteneur-menu-items-gap)]" }, ngImport: i0, template: `<ng-content />`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocMenu, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-menu',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: { class: 'flex w-full flex-col items-start gap-[var(--index-conteneur-menu-items-gap)]' },
                    template: `<ng-content />`,
                }]
        }] });

/**
 * Contenu du menu déroulant ouvert au clic sur l'avatar dans `HeaderApp` — à passer à sa prop
 * `avatarMenu` (rendu dans un `Popover` ancré à l'AvatarZone). Ne s'utilise jamais seul en dehors de
 * ce contexte : ce n'est qu'un panneau de contenu, pas un composant de déclenchement. Plain wrapper
 * (`soc-avatar-menu`); React's root `<div className>` is this host, so a literal `class` on
 * `<soc-avatar-menu>` replaces React's `className` prop.
 *
 * Maps 1:1 to Figma's "AvatarMenu" (node 630:2682) — reuses the popover surface tokens of
 * `Menu`/`Popover` (`Index/Conteneur/Menu/popover-*`), no distinct token set exists for this panel.
 *
 * GAP-DECISION (flagged, not decided silently): React shows the "Voir profil" / "Modifier avatar"
 * ghost buttons only when the matching `onViewProfile` / `onEditAvatar` prop is *passed* ("Omit to
 * hide"). An Angular `output()` has no public way to ask whether anyone subscribed, so that
 * presence-of-handler signal can't be reproduced. Mirrored with two explicit boolean inputs,
 * `showViewProfile` / `showEditAvatar` (both false by default, i.e. hidden — same default as
 * "handler omitted" in React), next to the `viewProfile` / `editAvatar` outputs. `disconnect` is
 * always rendered, like React's required `onDisconnect`.
 */
class SocAvatarMenu {
    userName = input.required();
    userEmail = input.required();
    /** Initials shown in the profile circle — 2 characters max, forwarded to `Avatar`. */
    avatarLabel = input.required();
    showViewProfile = input(false, { transform: booleanAttribute });
    showEditAvatar = input(false, { transform: booleanAttribute });
    viewProfile = output();
    editAvatar = output();
    disconnect = output();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAvatarMenu, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocAvatarMenu, isStandalone: true, selector: "soc-avatar-menu", inputs: { userName: { classPropertyName: "userName", publicName: "userName", isSignal: true, isRequired: true, transformFunction: null }, userEmail: { classPropertyName: "userEmail", publicName: "userEmail", isSignal: true, isRequired: true, transformFunction: null }, avatarLabel: { classPropertyName: "avatarLabel", publicName: "avatarLabel", isSignal: true, isRequired: true, transformFunction: null }, showViewProfile: { classPropertyName: "showViewProfile", publicName: "showViewProfile", isSignal: true, isRequired: false, transformFunction: null }, showEditAvatar: { classPropertyName: "showEditAvatar", publicName: "showEditAvatar", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { viewProfile: "viewProfile", editAvatar: "editAvatar", disconnect: "disconnect" }, host: { classAttribute: "flex w-[231px] flex-col items-start gap-[3px] rounded-[var(--index-conteneur-menu-popover-radius)] bg-[var(--index-conteneur-menu-popover-bg)] py-[var(--index-conteneur-menu-popover-pad)] drop-shadow-[0px_var(--index-conteneur-menu-popover-shadow-y)_var(--index-conteneur-menu-popover-shadow-blur)_rgba(68,84,111,var(--index-conteneur-menu-popover-shadow-opacity))]" }, ngImport: i0, template: `
    <div class="flex w-full flex-col gap-3 p-3">
      <soc-avatar class="w-full" [label]="avatarLabel()" [name]="userName()" [subtitle]="userEmail()" size="lg" namePosition="right" />
      @if (showViewProfile() || showEditAvatar()) {
        <div class="flex items-start gap-2">
          @if (showViewProfile()) {
            <button socButton variant="ghost" size="sm" (click)="viewProfile.emit()">Voir profil</button>
          }
          @if (showEditAvatar()) {
            <button socButton variant="ghost" size="sm" (click)="editAvatar.emit()">Modifier avatar</button>
          }
        </div>
      }
    </div>
    <div class="h-px w-full bg-[var(--index-conteneur-dialog-separator-color)]"></div>
    <soc-menu>
      <button socMenuItem label="Déconnexion" (click)="disconnect.emit()">
        <svg lucideLogOut socMenuItemIcon class="size-full" [strokeWidth]="1.5"></svg>
      </button>
    </soc-menu>
  `, isInline: true, dependencies: [{ kind: "component", type: SocAvatar, selector: "soc-avatar", inputs: ["label", "color", "size", "mode", "name", "subtitle", "namePosition"] }, { kind: "component", type: SocButton, selector: "button[socButton]", inputs: ["variant", "size"] }, { kind: "component", type: SocMenu, selector: "soc-menu" }, { kind: "component", type: SocMenuItem, selector: "button[socMenuItem]", inputs: ["label", "level", "mode", "checked"] }, { kind: "directive", type: SocMenuItemIcon, selector: "[socMenuItemIcon]" }, { kind: "component", type: LucideLogOut, selector: "svg[lucideLogOut]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAvatarMenu, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-avatar-menu',
                    standalone: true,
                    imports: [SocAvatar, SocButton, SocMenu, SocMenuItem, SocMenuItemIcon, LucideLogOut],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        class: 'flex w-[231px] flex-col items-start gap-[3px] rounded-[var(--index-conteneur-menu-popover-radius)] bg-[var(--index-conteneur-menu-popover-bg)] py-[var(--index-conteneur-menu-popover-pad)] drop-shadow-[0px_var(--index-conteneur-menu-popover-shadow-y)_var(--index-conteneur-menu-popover-shadow-blur)_rgba(68,84,111,var(--index-conteneur-menu-popover-shadow-opacity))]',
                    },
                    template: `
    <div class="flex w-full flex-col gap-3 p-3">
      <soc-avatar class="w-full" [label]="avatarLabel()" [name]="userName()" [subtitle]="userEmail()" size="lg" namePosition="right" />
      @if (showViewProfile() || showEditAvatar()) {
        <div class="flex items-start gap-2">
          @if (showViewProfile()) {
            <button socButton variant="ghost" size="sm" (click)="viewProfile.emit()">Voir profil</button>
          }
          @if (showEditAvatar()) {
            <button socButton variant="ghost" size="sm" (click)="editAvatar.emit()">Modifier avatar</button>
          }
        </div>
      }
    </div>
    <div class="h-px w-full bg-[var(--index-conteneur-dialog-separator-color)]"></div>
    <soc-menu>
      <button socMenuItem label="Déconnexion" (click)="disconnect.emit()">
        <svg lucideLogOut socMenuItemIcon class="size-full" [strokeWidth]="1.5"></svg>
      </button>
    </soc-menu>
  `,
                }]
        }] });

const GAP_CLASSES = {
    sm: 'gap-[var(--index-conteneur-cardgrid-gap-sm)]',
    md: 'gap-[var(--index-conteneur-cardgrid-gap-md)]',
    lg: 'gap-[var(--index-conteneur-cardgrid-gap-lg)]',
};
/**
 * Shared CSS Grid primitive behind both `DataTable`'s `mode="card"` and any bento-style card grid
 * (e.g. a `PageHome` content section) — the single place grid-column/breakpoint/gap logic lives.
 * No Figma source (code-only primitive), no masonry library — native CSS Grid only,
 * `grid-auto-flow: dense` does all the gap-backfilling in `mode="bento"`. Plain wrapper
 * (`soc-card-grid`); its children are `soc-card`s.
 *
 * - `mode` "fixed": every card is forced to span exactly 1 column × 1 row, regardless of any
 *   `colSpan`/`rowSpan` it was given. "bento": each card's own `colSpan` (1, 2 or 3) / `rowSpan` (1
 *   or 2) is respected — `colSpan` clamped to never exceed 75% of the row's active column count.
 * - `rowHeight`: fixed height (px) for every grid row (`grid-auto-rows`) — a `rowSpan={2}` card
 *   still gets exactly 2× this plus the gap. `'auto'` (default): rows size to their own content.
 * - `columns`: forces this exact column count, bypassing the container-query breakpoints below.
 *   The same 75% ceiling then runs once, against that fixed number.
 *
 * Columns respond to this grid's own rendered width via a CSS container query (`@container` on the
 * host, `@min-[…]:grid-cols-*` on the grid nested one level inside it — a container query element
 * can't measure itself, only an ancestor's container-type), deliberately not a viewport media
 * query. 2 columns below 600px, 3 from 600px, 4 from 900px — measured against *this component's own
 * box*, calibrated (see React `CardGrid.tsx`'s docstring for the measurements) so a ≥1280px desktop
 * window inside an `AppShell` reaches 4 columns. `class` on `<soc-card-grid>` lands on the outer
 * wrapper (React: `className`), so a consumer's padding/margin doesn't throw off the container
 * query's own width measurement of the grid inside it.
 *
 *   effectiveColSpan = max(1, min(requestedColSpan, floor(activeColumns * 0.75)))
 *
 * i.e. ceiling 1 column (2 active), 2 (3 active), 3 (4 active) — never a full-width row.
 *
 * React applies all of this by `cloneElement`-ing each child `Card` with overridden `colSpan` and
 * `className`. Angular can't rewrite another component's inputs, so this component only *exposes*
 * `mode`/`columns` through `CARD_GRID_CONTEXT` and each `soc-card` resolves its own effective span
 * from it (see `SocCard`'s `placement`). Same rules, same classes, applied on the receiving side.
 */
class SocCardGrid {
    mode = input('fixed');
    gap = input('md');
    /** A plain `number` (px), not a Tailwind class, because it's an arbitrary continuous value the
     * static class scanner can't pick up — applied as an inline style instead. */
    rowHeight = input('auto');
    columns = input();
    gridTemplateColumns = computed(() => {
        const columns = this.columns();
        return columns != null ? `repeat(${columns}, minmax(0, 1fr))` : null;
    });
    gridAutoRows = computed(() => {
        const rowHeight = this.rowHeight();
        return rowHeight !== 'auto' ? `${rowHeight}px` : null;
    });
    gridClass = computed(() => `grid ${this.columns() == null ? 'grid-cols-2 @min-[600px]:grid-cols-3 @min-[900px]:grid-cols-4' : ''} ${this.mode() === 'bento' ? 'grid-flow-dense' : ''} ${GAP_CLASSES[this.gap()]}`);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocCardGrid, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.25", type: SocCardGrid, isStandalone: true, selector: "soc-card-grid", inputs: { mode: { classPropertyName: "mode", publicName: "mode", isSignal: true, isRequired: false, transformFunction: null }, gap: { classPropertyName: "gap", publicName: "gap", isSignal: true, isRequired: false, transformFunction: null }, rowHeight: { classPropertyName: "rowHeight", publicName: "rowHeight", isSignal: true, isRequired: false, transformFunction: null }, columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "@container block w-full" }, providers: [{ provide: CARD_GRID_CONTEXT, useExisting: SocCardGrid }], ngImport: i0, template: `
    <div [class]="gridClass()" [style.grid-template-columns]="gridTemplateColumns()" [style.grid-auto-rows]="gridAutoRows()">
      <ng-content />
    </div>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocCardGrid, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-card-grid',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    providers: [{ provide: CARD_GRID_CONTEXT, useExisting: SocCardGrid }],
                    host: { class: '@container block w-full' },
                    template: `
    <div [class]="gridClass()" [style.grid-template-columns]="gridTemplateColumns()" [style.grid-auto-rows]="gridAutoRows()">
      <ng-content />
    </div>
  `,
                }]
        }] });

/** React `badge` — consumer-supplied Badge next to `title` (`table`/`card` mode), typically an
 * instance count when several objects of the same type are listed on one page. */
class SocDataTableBadge {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocDataTableBadge, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocDataTableBadge, isStandalone: true, selector: "[socDataTableBadge]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocDataTableBadge, decorators: [{
            type: Directive,
            args: [{ selector: '[socDataTableBadge]', standalone: true }]
        }] });
/** React `filters` — extra controls rendered next to the search bar — Selects, filters, etc. */
class SocDataTableFilters {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocDataTableFilters, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocDataTableFilters, isStandalone: true, selector: "[socDataTableFilters]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocDataTableFilters, decorators: [{
            type: Directive,
            args: [{ selector: '[socDataTableFilters]', standalone: true }]
        }] });
/** React `actions` — buttons rendered on the right of the action line, typically Button (icon-only
 * + primary). The right-hand wrapper only renders when something is projected here. */
class SocDataTableActions {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocDataTableActions, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocDataTableActions, isStandalone: true, selector: "[socDataTableActions]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocDataTableActions, decorators: [{
            type: Directive,
            args: [{ selector: '[socDataTableActions]', standalone: true }]
        }] });
const ROW_ACTION_BUTTON_CLASS = 'inline-flex size-[var(--index-données-datatable-action-icon-size)] cursor-pointer items-center justify-center text-[var(--index-données-datatable-action-icon-color)] hover:text-[var(--index-données-datatable-action-icon-hover)]';
const CARD_ACTION_BUTTON_CLASS = 'flex size-[24px] shrink-0 items-center justify-center rounded-[var(--index-conteneur-card-action-radius)] px-[var(--index-conteneur-card-action-pad-h)] py-[var(--index-conteneur-card-action-pad-v)] hover:bg-[var(--index-conteneur-card-action-bg-hover)]';
/**
 * Maps 1:1 to "Index/Données/DataTable/*" tokens — see packages/tokens/tokens/components/données.json
 * in design_system (React reference repo, read only). Composes `soc-search-bar`, `soc-checkbox`,
 * `soc-pagination`, `soc-popover`/`soc-tooltip` and (card mode) `soc-card-grid`/`soc-card`, same as
 * React. Plain generic wrapper (`soc-data-table`, `<T>` = the row type).
 *
 * `mode`: "table" (Figma "Data Table 1", default) — full grid with search/actions/pagination.
 * "detail" ("Data Table 2") — a single record as a label/value list: columns become row labels,
 * `rows[0]` is the record. "card" (code-only mode) — the title/subtitle/search/filters/actions zone
 * is identical to "table"; only the row grid becomes a `soc-card-grid` of `soc-card`s, one per row
 * (`cardContent` builds each). Multi-select and sorting don't apply to card mode (see React's own
 * `DataTable.tsx` docstring for why; `DataTable` has never implemented sorting in any mode).
 *
 * ## Contraintes de composition (unchanged from React)
 * - `rowActions` (action unique, `(rowAction)`) ou `rowActionsMenu` (plusieurs actions
 *   conditionnelles) pour toute action de ligne — jamais de bouton d'action personnalisé en plus.
 * - `rowActionsMenu` pour toute liste d'actions conditionnelles par ligne — jamais une `Dialog`,
 *   toujours un menu contextuel (`soc-popover position="bottom-end"`, croît vers la gauche, jamais
 *   coupé par un tableau scrollable horizontalement).
 * - Le retrait gauche (première colonne — checkbox si `selectable`, sinon première colonne de
 *   données) est toujours `title-zone-pad-h`, jamais `header-pad-h`/`cell-pad-h`; l'écart checkbox →
 *   première colonne est le token dédié `checkbox-col-pad-right`.
 * - Le placeholder ("Rechercher ici...") et la largeur (260px) de la barre de recherche sont fixes
 *   au niveau du composant, jamais une prop.
 * - `mode="card"` réutilise `rowClick`/`rowAction`/`rowActionsMenu` tels quels; la grille est un
 *   `soc-card-grid` en `mode="fixed"`.
 *
 * ## GAP-DECISIONS (flagged, not decided silently) — React idioms with no Angular equivalent
 * 1. **Presence of a callback prop.** React turns features on by passing the handler: `onSearch`
 *    shows the search bar, `onRowClick` makes rows clickable/hoverable, `onRowAction` adds the
 *    "•••" column. An Angular `output()` can't be asked "does anyone listen?", so each is an
 *    explicit boolean input next to its output: `searchable`/`(search)`, `rowClickable`/
 *    `(rowClick)`, `rowActions`/`(rowAction)`. All default to false (= "handler omitted").
 *    `rowActionsMenu` is a template *input*, so its presence is directly detectable and also adds
 *    the "•••" column on its own, as in React.
 * 2. **`ReactNode`-returning functions.** `columns[].render`, `cardContent().body/footer` and
 *    `rowActionsMenu` return rich JSX in React; here they are `TemplateRef`s the consumer declares
 *    (`<ng-template let-row>`), with the row (and `close` for the menu) as context. `render` also
 *    accepts a plain `(row) => string` for text cells.
 * 3. **`ReactNode` slots** (`badge`, `filters`, `actions`) -> marker-directive content slots.
 * 4. **`selectedKeys`/`onSelectedKeysChange`** -> `selectedKeys` input + `selectedKeysChange`
 *    output (so `[(selectedKeys)]` works). **`pagination`'s callbacks** -> `pageChange`/
 *    `pageSizeChange` outputs on this component.
 */
class SocDataTable {
    mode = input('table');
    title = input();
    subtitle = input();
    columns = input.required();
    cardContent = input();
    rows = input.required();
    rowKey = input.required();
    selectable = input(false, { transform: booleanAttribute });
    selectedKeys = input();
    selectedKeysChange = output();
    searchable = input(false, { transform: booleanAttribute });
    search = output();
    rowClickable = input(false, { transform: booleanAttribute });
    rowClick = output();
    rowActions = input(false, { transform: booleanAttribute });
    rowAction = output();
    rowActionsMenu = input();
    pagination = input();
    pageChange = output();
    pageSizeChange = output();
    actionsContent = contentChild(SocDataTableActions);
    hasActions = computed(() => !!this.actionsContent());
    hasRowActions = computed(() => this.rowActions() || !!this.rowActionsMenu());
    rowActionButtonClass = ROW_ACTION_BUTTON_CLASS;
    cardActionButtonClass = CARD_ACTION_BUTTON_CLASS;
    cardActionIconThickness = 'var(--index-conteneur-card-action-icon-thickness)';
    record = computed(() => this.rows()[0]);
    openActionsKey = signal(null);
    setActionsOpen(key, open) {
        this.openActionsKey.set(open ? key : null);
    }
    closeActions = () => this.openActionsKey.set(null);
    templateOf(column) {
        return column.render instanceof TemplateRef ? column.render : null;
    }
    textOf(column, row) {
        return typeof column.render === 'function' ? column.render(row) : '';
    }
    allKeys = computed(() => this.rows().map(this.rowKey()));
    allSelected = computed(() => this.selectable() && this.allKeys().length > 0 && this.allKeys().every((key) => this.selectedKeys()?.has(key)));
    isSelected(key) {
        return this.selectedKeys()?.has(key) ?? false;
    }
    toggleAll() {
        this.selectedKeysChange.emit(this.allSelected() ? new Set() : new Set(this.allKeys()));
    }
    toggleRow(key) {
        const next = new Set(this.selectedKeys());
        if (next.has(key))
            next.delete(key);
        else
            next.add(key);
        this.selectedKeysChange.emit(next);
    }
    onRowClick(row) {
        if (this.rowClickable())
            this.rowClick.emit(row);
    }
    // Card's own "•••" button: only wired to `rowAction` when no `rowActionsMenu` replaces it
    // (React: `onAction={!rowActionsMenu && onRowAction ? ... : undefined}`).
    onCardAction(row) {
        if (!this.rowActionsMenu() && this.rowActions())
            this.rowAction.emit(row);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocDataTable, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocDataTable, isStandalone: true, selector: "soc-data-table", inputs: { mode: { classPropertyName: "mode", publicName: "mode", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, subtitle: { classPropertyName: "subtitle", publicName: "subtitle", isSignal: true, isRequired: false, transformFunction: null }, columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: true, transformFunction: null }, cardContent: { classPropertyName: "cardContent", publicName: "cardContent", isSignal: true, isRequired: false, transformFunction: null }, rows: { classPropertyName: "rows", publicName: "rows", isSignal: true, isRequired: true, transformFunction: null }, rowKey: { classPropertyName: "rowKey", publicName: "rowKey", isSignal: true, isRequired: true, transformFunction: null }, selectable: { classPropertyName: "selectable", publicName: "selectable", isSignal: true, isRequired: false, transformFunction: null }, selectedKeys: { classPropertyName: "selectedKeys", publicName: "selectedKeys", isSignal: true, isRequired: false, transformFunction: null }, searchable: { classPropertyName: "searchable", publicName: "searchable", isSignal: true, isRequired: false, transformFunction: null }, rowClickable: { classPropertyName: "rowClickable", publicName: "rowClickable", isSignal: true, isRequired: false, transformFunction: null }, rowActions: { classPropertyName: "rowActions", publicName: "rowActions", isSignal: true, isRequired: false, transformFunction: null }, rowActionsMenu: { classPropertyName: "rowActionsMenu", publicName: "rowActionsMenu", isSignal: true, isRequired: false, transformFunction: null }, pagination: { classPropertyName: "pagination", publicName: "pagination", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selectedKeysChange: "selectedKeysChange", search: "search", rowClick: "rowClick", rowAction: "rowAction", pageChange: "pageChange", pageSizeChange: "pageSizeChange" }, host: { classAttribute: "flex w-full flex-col items-start overflow-hidden rounded-[var(--index-donn\u00E9es-datatable-radius)] bg-[var(--index-donn\u00E9es-datatable-bg)]" }, queries: [{ propertyName: "actionsContent", first: true, predicate: SocDataTableActions, descendants: true, isSignal: true }], ngImport: i0, template: `
    @if (mode() === 'detail') {
      @if (title() || subtitle()) {
        <div class="flex w-full flex-col gap-[var(--index-données-datatable-title-zone-gap)] px-[var(--index-données-datatable-title-zone-pad-h)] py-[var(--index-données-datatable-title-zone-pad-v)]">
          @if (title()) {
            <p class="w-full text-[length:var(--index-données-datatable-title-size)] text-[var(--index-données-datatable-title-color)] [font-family:var(--index-données-datatable-title-font)] [font-weight:var(--index-données-datatable-title-weight)]">
              {{ title() }}
            </p>
          }
          @if (subtitle()) {
            <p class="w-full text-[length:var(--index-données-datatable-subtitle-size)] text-[var(--index-données-datatable-subtitle-color)] [font-family:var(--index-données-datatable-subtitle-font)] [font-weight:var(--index-données-datatable-subtitle-weight)]">
              {{ subtitle() }}
            </p>
          }
          <div class="h-px w-full bg-[var(--index-données-datatable-cell-border)]"></div>
        </div>
      }
      <div class="flex w-full flex-col items-start">
        @for (column of columns(); track column.key; let last = $last) {
          <div
            [class]="'flex w-full items-center gap-4 px-[var(--index-données-datatable-title-zone-pad-h)] py-[var(--index-données-datatable-cell-pad-v)] ' + (last ? '' : 'border-b-[length:var(--index-données-datatable-cell-border-width)] border-[var(--index-données-datatable-cell-border)]')"
          >
            <span class="w-[200px] shrink-0 text-[length:var(--index-données-datatable-cell-size)] text-[var(--bridges-color-text-secondary)] [font-family:var(--index-données-datatable-cell-font)]">
              {{ column.header }}
            </span>
            <span class="min-w-0 flex-1 text-[length:var(--index-données-datatable-cell-size)] text-[var(--bridges-color-text-primary)] [font-family:var(--index-données-datatable-cell-font)] [font-weight:var(--index-données-datatable-header-weight)]">
              @if (record(); as rec) {
                @if (templateOf(column); as tpl) {
                  <ng-container [ngTemplateOutlet]="tpl" [ngTemplateOutletContext]="{ $implicit: rec, row: rec }" />
                } @else {
                  {{ textOf(column, rec) }}
                }
              }
            </span>
          </div>
        }
      </div>
    } @else {
      @if (title() || subtitle()) {
        <div class="flex w-full flex-col gap-[var(--index-données-datatable-title-zone-gap)] bg-[var(--index-données-datatable-bg-title)] pr-[var(--index-données-datatable-title-zone-pad-h)] py-[var(--index-données-datatable-title-zone-pad-v)]">
          @if (title()) {
            <div class="flex w-full items-center gap-[var(--index-données-datatable-title-row-gap)]">
              <p class="text-[length:var(--index-données-datatable-title-size)] text-[var(--index-données-datatable-title-color)] [font-family:var(--index-données-datatable-title-font)] [font-weight:var(--index-données-datatable-title-weight)]">
                {{ title() }}
              </p>
              <ng-content select="[socDataTableBadge]" />
            </div>
          }
          @if (subtitle()) {
            <p class="w-full text-[length:var(--index-données-datatable-subtitle-size)] text-[var(--index-données-datatable-subtitle-color)] [font-family:var(--index-données-datatable-subtitle-font)] [font-weight:var(--index-données-datatable-subtitle-weight)]">
              {{ subtitle() }}
            </p>
          }
        </div>
      }
      <div class="flex w-full items-center justify-between gap-[var(--index-données-datatable-action-gap-zones)] bg-[var(--index-données-datatable-bg-action)] pr-[var(--index-données-datatable-action-pad-h)] py-[var(--index-données-datatable-action-pad-v)]">
        <div class="flex items-center gap-[var(--index-données-datatable-action-gap)]">
          @if (searchable()) {
            <soc-search-bar placeholder="Rechercher ici..." (valueChange)="search.emit($event)" class="w-[260px] h-[var(--index-input-searchbar-field-height)]" />
          }
          <ng-content select="[socDataTableFilters]" />
        </div>
        @if (hasActions()) {
          <div class="flex items-center gap-[var(--index-données-datatable-action-gap)]">
            <ng-content select="[socDataTableActions]" />
          </div>
        }
      </div>
      @if (mode() === 'table') {
        <div class="w-full overflow-x-auto">
          <table class="w-full min-w-max border-collapse">
            <thead>
              <tr>
                @if (selectable()) {
                  <th class="border-b-[length:var(--index-données-datatable-cell-border-width)] border-[var(--index-données-datatable-cell-border)] bg-[var(--index-données-datatable-header-bg)] py-[var(--index-données-datatable-header-pad-v)] pl-[var(--index-données-datatable-title-zone-pad-h)] pr-[var(--index-données-datatable-checkbox-col-pad-right)] text-left">
                    <soc-checkbox [checked]="allSelected()" (checkedChange)="toggleAll()" />
                  </th>
                }
                @for (column of columns(); track column.key; let index = $index) {
                  <th
                    [class]="'border-b-[length:var(--index-données-datatable-cell-border-width)] border-[var(--index-données-datatable-cell-border)] bg-[var(--index-données-datatable-header-bg)] py-[var(--index-données-datatable-header-pad-v)] pr-[var(--index-données-datatable-header-pad-h)] text-left text-[length:var(--index-données-datatable-header-size)] text-[var(--index-données-datatable-header-color)] [font-family:var(--index-données-datatable-header-font)] [font-weight:var(--index-données-datatable-header-weight)] ' + (index === 0 && !selectable() ? 'pl-[var(--index-données-datatable-title-zone-pad-h)]' : 'pl-[var(--index-données-datatable-header-pad-h)]')"
                  >
                    {{ column.header }}
                  </th>
                }
                @if (hasRowActions()) {
                  <th class="border-b-[length:var(--index-données-datatable-cell-border-width)] border-[var(--index-données-datatable-cell-border)] bg-[var(--index-données-datatable-header-bg)] w-[62px]"></th>
                }
              </tr>
            </thead>
            <tbody>
              @for (row of rows(); track rowKey()(row)) {
                @let key = rowKey()(row);
                <tr (click)="onRowClick(row)" [class]="'group ' + (rowClickable() ? 'cursor-pointer' : '')">
                  @if (selectable()) {
                    <td
                      (click)="$event.stopPropagation()"
                      class="border-b-[length:var(--index-données-datatable-cell-border-width)] border-[var(--index-données-datatable-cell-border)] bg-[var(--index-données-datatable-cell-bg)] py-[var(--index-données-datatable-cell-pad-v)] pl-[var(--index-données-datatable-title-zone-pad-h)] pr-[var(--index-données-datatable-checkbox-col-pad-right)] group-hover:bg-[var(--index-données-datatable-cell-bg-hover)]"
                    >
                      <soc-checkbox [checked]="isSelected(key)" (checkedChange)="toggleRow(key)" />
                    </td>
                  }
                  @for (column of columns(); track column.key; let index = $index) {
                    <td
                      [class]="'border-b-[length:var(--index-données-datatable-cell-border-width)] border-[var(--index-données-datatable-cell-border)] bg-[var(--index-données-datatable-cell-bg)] py-[var(--index-données-datatable-cell-pad-v)] pr-[var(--index-données-datatable-cell-pad-h)] text-[length:var(--index-données-datatable-cell-size)] text-[var(--index-données-datatable-cell-color)] [font-family:var(--index-données-datatable-cell-font)] [font-weight:var(--index-données-datatable-cell-weight)] group-hover:bg-[var(--index-données-datatable-cell-bg-hover)] ' + (index === 0 && !selectable() ? 'pl-[var(--index-données-datatable-title-zone-pad-h)]' : 'pl-[var(--index-données-datatable-cell-pad-h)]')"
                    >
                      @if (templateOf(column); as tpl) {
                        <ng-container [ngTemplateOutlet]="tpl" [ngTemplateOutletContext]="{ $implicit: row, row: row }" />
                      } @else {
                        {{ textOf(column, row) }}
                      }
                    </td>
                  }
                  @if (hasRowActions()) {
                    <td
                      (click)="$event.stopPropagation()"
                      class="border-b-[length:var(--index-données-datatable-cell-border-width)] border-[var(--index-données-datatable-cell-border)] bg-[var(--index-données-datatable-cell-bg)] px-[var(--index-données-datatable-cell-pad-h)] py-[var(--index-données-datatable-cell-pad-v)] text-center group-hover:bg-[var(--index-données-datatable-cell-bg-hover)]"
                    >
                      @if (rowActionsMenu(); as menu) {
                        <soc-popover position="bottom-end" [open]="openActionsKey() === key" (openChange)="setActionsOpen(key, $event)">
                          <soc-tooltip socPopoverTrigger>
                            <button type="button" aria-label="Actions" [class]="rowActionButtonClass">
                              <svg lucideMoreHorizontal class="size-full" [strokeWidth]="1.5"></svg>
                            </button>
                            <span socTooltipLabel>Actions</span>
                          </soc-tooltip>
                          <ng-container [ngTemplateOutlet]="menu" [ngTemplateOutletContext]="{ $implicit: row, row: row, close: closeActions }" />
                        </soc-popover>
                      } @else {
                        <soc-tooltip>
                          <button type="button" (click)="rowAction.emit(row)" aria-label="Actions" [class]="rowActionButtonClass">
                            <svg lucideMoreHorizontal class="size-full" [strokeWidth]="1.5"></svg>
                          </button>
                          <span socTooltipLabel>Actions</span>
                        </soc-tooltip>
                      }
                    </td>
                  }
                </tr>
              }
            </tbody>
          </table>
        </div>
      }
      @if (mode() === 'card') {
        <soc-card-grid mode="fixed" gap="md" class="pr-[var(--index-données-datatable-title-zone-pad-h)] py-[var(--index-données-datatable-cell-pad-v)]">
          @for (row of rows(); track rowKey()(row)) {
            @let key = rowKey()(row);
            @let content = cardContent()?.(row);
            @if (content) {
              <soc-card
                [title]="content.title"
                [subtitle]="content.subtitle"
                [type]="rowClickable() ? 'selectable' : 'default'"
                (cardClick)="rowClick.emit(row)"
                (action)="onCardAction(row)"
              >
                @if (rowActionsMenu(); as menu) {
                  <!-- stopPropagation on this wrapper, not the trigger button: same reason as the
                       table-row version stopping propagation on the wrapping td. -->
                  <span socCardActionSlot (click)="$event.stopPropagation()">
                    <soc-popover position="bottom-end" [open]="openActionsKey() === key" (openChange)="setActionsOpen(key, $event)">
                      <soc-tooltip socPopoverTrigger>
                        <button type="button" aria-label="Actions" [class]="cardActionButtonClass">
                          <svg lucideMoreHorizontal class="size-[var(--index-conteneur-card-action-icon-size)] text-[var(--index-conteneur-card-action-icon-color)]" [strokeWidth]="cardActionIconThickness"></svg>
                        </button>
                        <span socTooltipLabel>Actions</span>
                      </soc-tooltip>
                      <ng-container [ngTemplateOutlet]="menu" [ngTemplateOutletContext]="{ $implicit: row, row: row, close: closeActions }" />
                    </soc-popover>
                  </span>
                }
                @if (content.body; as body) {
                  <ng-container [ngTemplateOutlet]="body" [ngTemplateOutletContext]="{ $implicit: row, row: row }" />
                }
                @if (content.footer; as footer) {
                  <div socCardFooter>
                    <ng-container [ngTemplateOutlet]="footer" [ngTemplateOutletContext]="{ $implicit: row, row: row }" />
                  </div>
                }
              </soc-card>
            }
          }
        </soc-card-grid>
      }
      @if (pagination(); as pager) {
        <div class="flex w-full items-center justify-center bg-[var(--index-données-datatable-bg-pagination)] px-[var(--index-données-datatable-pagination-pad-h)] py-[var(--index-données-datatable-pagination-pad-v)]">
          <soc-pagination
            class="w-full"
            [currentPage]="pager.currentPage"
            [totalPages]="pager.totalPages"
            [totalEntries]="pager.totalEntries"
            [pageSize]="pager.pageSize"
            (pageChange)="pageChange.emit($event)"
            (pageSizeChange)="pageSizeChange.emit($event)"
          />
        </div>
      }
    }
  `, isInline: true, dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: SocCard, selector: "soc-card", inputs: ["title", "subtitle", "type", "colSpan", "rowSpan"], outputs: ["action", "cardClick"] }, { kind: "directive", type: SocCardActionSlot, selector: "[socCardActionSlot]" }, { kind: "directive", type: SocCardFooter, selector: "[socCardFooter]" }, { kind: "component", type: SocCardGrid, selector: "soc-card-grid", inputs: ["mode", "gap", "rowHeight", "columns"] }, { kind: "component", type: SocCheckbox, selector: "soc-checkbox", inputs: ["checked", "label", "id"], outputs: ["checkedChange"] }, { kind: "component", type: SocPagination, selector: "soc-pagination", inputs: ["currentPage", "totalPages", "variant", "hasFirstLast", "totalEntries", "pageSize", "pageSizeOptions"], outputs: ["pageChange", "pageSizeChange"] }, { kind: "component", type: SocPopover, selector: "soc-popover", inputs: ["position", "open", "matchTriggerWidth", "panelClass"], outputs: ["openChange"] }, { kind: "directive", type: SocPopoverTrigger, selector: "[socPopoverTrigger]" }, { kind: "component", type: SocSearchBar, selector: "soc-search-bar", inputs: ["placeholder", "value"], outputs: ["valueChange", "clear"] }, { kind: "component", type: SocTooltip, selector: "soc-tooltip", inputs: ["position", "variant", "title", "status", "showIcon"] }, { kind: "directive", type: SocTooltipLabel, selector: "[socTooltipLabel]" }, { kind: "component", type: LucideMoreHorizontal, selector: "svg[lucideEllipsis], svg[lucideMoreHorizontal]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocDataTable, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-data-table',
                    standalone: true,
                    imports: [
                        NgTemplateOutlet,
                        SocCard,
                        SocCardActionSlot,
                        SocCardFooter,
                        SocCardGrid,
                        SocCheckbox,
                        SocPagination,
                        SocPopover,
                        SocPopoverTrigger,
                        SocSearchBar,
                        SocTooltip,
                        SocTooltipLabel,
                        LucideMoreHorizontal,
                    ],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        class: 'flex w-full flex-col items-start overflow-hidden rounded-[var(--index-données-datatable-radius)] bg-[var(--index-données-datatable-bg)]',
                    },
                    template: `
    @if (mode() === 'detail') {
      @if (title() || subtitle()) {
        <div class="flex w-full flex-col gap-[var(--index-données-datatable-title-zone-gap)] px-[var(--index-données-datatable-title-zone-pad-h)] py-[var(--index-données-datatable-title-zone-pad-v)]">
          @if (title()) {
            <p class="w-full text-[length:var(--index-données-datatable-title-size)] text-[var(--index-données-datatable-title-color)] [font-family:var(--index-données-datatable-title-font)] [font-weight:var(--index-données-datatable-title-weight)]">
              {{ title() }}
            </p>
          }
          @if (subtitle()) {
            <p class="w-full text-[length:var(--index-données-datatable-subtitle-size)] text-[var(--index-données-datatable-subtitle-color)] [font-family:var(--index-données-datatable-subtitle-font)] [font-weight:var(--index-données-datatable-subtitle-weight)]">
              {{ subtitle() }}
            </p>
          }
          <div class="h-px w-full bg-[var(--index-données-datatable-cell-border)]"></div>
        </div>
      }
      <div class="flex w-full flex-col items-start">
        @for (column of columns(); track column.key; let last = $last) {
          <div
            [class]="'flex w-full items-center gap-4 px-[var(--index-données-datatable-title-zone-pad-h)] py-[var(--index-données-datatable-cell-pad-v)] ' + (last ? '' : 'border-b-[length:var(--index-données-datatable-cell-border-width)] border-[var(--index-données-datatable-cell-border)]')"
          >
            <span class="w-[200px] shrink-0 text-[length:var(--index-données-datatable-cell-size)] text-[var(--bridges-color-text-secondary)] [font-family:var(--index-données-datatable-cell-font)]">
              {{ column.header }}
            </span>
            <span class="min-w-0 flex-1 text-[length:var(--index-données-datatable-cell-size)] text-[var(--bridges-color-text-primary)] [font-family:var(--index-données-datatable-cell-font)] [font-weight:var(--index-données-datatable-header-weight)]">
              @if (record(); as rec) {
                @if (templateOf(column); as tpl) {
                  <ng-container [ngTemplateOutlet]="tpl" [ngTemplateOutletContext]="{ $implicit: rec, row: rec }" />
                } @else {
                  {{ textOf(column, rec) }}
                }
              }
            </span>
          </div>
        }
      </div>
    } @else {
      @if (title() || subtitle()) {
        <div class="flex w-full flex-col gap-[var(--index-données-datatable-title-zone-gap)] bg-[var(--index-données-datatable-bg-title)] pr-[var(--index-données-datatable-title-zone-pad-h)] py-[var(--index-données-datatable-title-zone-pad-v)]">
          @if (title()) {
            <div class="flex w-full items-center gap-[var(--index-données-datatable-title-row-gap)]">
              <p class="text-[length:var(--index-données-datatable-title-size)] text-[var(--index-données-datatable-title-color)] [font-family:var(--index-données-datatable-title-font)] [font-weight:var(--index-données-datatable-title-weight)]">
                {{ title() }}
              </p>
              <ng-content select="[socDataTableBadge]" />
            </div>
          }
          @if (subtitle()) {
            <p class="w-full text-[length:var(--index-données-datatable-subtitle-size)] text-[var(--index-données-datatable-subtitle-color)] [font-family:var(--index-données-datatable-subtitle-font)] [font-weight:var(--index-données-datatable-subtitle-weight)]">
              {{ subtitle() }}
            </p>
          }
        </div>
      }
      <div class="flex w-full items-center justify-between gap-[var(--index-données-datatable-action-gap-zones)] bg-[var(--index-données-datatable-bg-action)] pr-[var(--index-données-datatable-action-pad-h)] py-[var(--index-données-datatable-action-pad-v)]">
        <div class="flex items-center gap-[var(--index-données-datatable-action-gap)]">
          @if (searchable()) {
            <soc-search-bar placeholder="Rechercher ici..." (valueChange)="search.emit($event)" class="w-[260px] h-[var(--index-input-searchbar-field-height)]" />
          }
          <ng-content select="[socDataTableFilters]" />
        </div>
        @if (hasActions()) {
          <div class="flex items-center gap-[var(--index-données-datatable-action-gap)]">
            <ng-content select="[socDataTableActions]" />
          </div>
        }
      </div>
      @if (mode() === 'table') {
        <div class="w-full overflow-x-auto">
          <table class="w-full min-w-max border-collapse">
            <thead>
              <tr>
                @if (selectable()) {
                  <th class="border-b-[length:var(--index-données-datatable-cell-border-width)] border-[var(--index-données-datatable-cell-border)] bg-[var(--index-données-datatable-header-bg)] py-[var(--index-données-datatable-header-pad-v)] pl-[var(--index-données-datatable-title-zone-pad-h)] pr-[var(--index-données-datatable-checkbox-col-pad-right)] text-left">
                    <soc-checkbox [checked]="allSelected()" (checkedChange)="toggleAll()" />
                  </th>
                }
                @for (column of columns(); track column.key; let index = $index) {
                  <th
                    [class]="'border-b-[length:var(--index-données-datatable-cell-border-width)] border-[var(--index-données-datatable-cell-border)] bg-[var(--index-données-datatable-header-bg)] py-[var(--index-données-datatable-header-pad-v)] pr-[var(--index-données-datatable-header-pad-h)] text-left text-[length:var(--index-données-datatable-header-size)] text-[var(--index-données-datatable-header-color)] [font-family:var(--index-données-datatable-header-font)] [font-weight:var(--index-données-datatable-header-weight)] ' + (index === 0 && !selectable() ? 'pl-[var(--index-données-datatable-title-zone-pad-h)]' : 'pl-[var(--index-données-datatable-header-pad-h)]')"
                  >
                    {{ column.header }}
                  </th>
                }
                @if (hasRowActions()) {
                  <th class="border-b-[length:var(--index-données-datatable-cell-border-width)] border-[var(--index-données-datatable-cell-border)] bg-[var(--index-données-datatable-header-bg)] w-[62px]"></th>
                }
              </tr>
            </thead>
            <tbody>
              @for (row of rows(); track rowKey()(row)) {
                @let key = rowKey()(row);
                <tr (click)="onRowClick(row)" [class]="'group ' + (rowClickable() ? 'cursor-pointer' : '')">
                  @if (selectable()) {
                    <td
                      (click)="$event.stopPropagation()"
                      class="border-b-[length:var(--index-données-datatable-cell-border-width)] border-[var(--index-données-datatable-cell-border)] bg-[var(--index-données-datatable-cell-bg)] py-[var(--index-données-datatable-cell-pad-v)] pl-[var(--index-données-datatable-title-zone-pad-h)] pr-[var(--index-données-datatable-checkbox-col-pad-right)] group-hover:bg-[var(--index-données-datatable-cell-bg-hover)]"
                    >
                      <soc-checkbox [checked]="isSelected(key)" (checkedChange)="toggleRow(key)" />
                    </td>
                  }
                  @for (column of columns(); track column.key; let index = $index) {
                    <td
                      [class]="'border-b-[length:var(--index-données-datatable-cell-border-width)] border-[var(--index-données-datatable-cell-border)] bg-[var(--index-données-datatable-cell-bg)] py-[var(--index-données-datatable-cell-pad-v)] pr-[var(--index-données-datatable-cell-pad-h)] text-[length:var(--index-données-datatable-cell-size)] text-[var(--index-données-datatable-cell-color)] [font-family:var(--index-données-datatable-cell-font)] [font-weight:var(--index-données-datatable-cell-weight)] group-hover:bg-[var(--index-données-datatable-cell-bg-hover)] ' + (index === 0 && !selectable() ? 'pl-[var(--index-données-datatable-title-zone-pad-h)]' : 'pl-[var(--index-données-datatable-cell-pad-h)]')"
                    >
                      @if (templateOf(column); as tpl) {
                        <ng-container [ngTemplateOutlet]="tpl" [ngTemplateOutletContext]="{ $implicit: row, row: row }" />
                      } @else {
                        {{ textOf(column, row) }}
                      }
                    </td>
                  }
                  @if (hasRowActions()) {
                    <td
                      (click)="$event.stopPropagation()"
                      class="border-b-[length:var(--index-données-datatable-cell-border-width)] border-[var(--index-données-datatable-cell-border)] bg-[var(--index-données-datatable-cell-bg)] px-[var(--index-données-datatable-cell-pad-h)] py-[var(--index-données-datatable-cell-pad-v)] text-center group-hover:bg-[var(--index-données-datatable-cell-bg-hover)]"
                    >
                      @if (rowActionsMenu(); as menu) {
                        <soc-popover position="bottom-end" [open]="openActionsKey() === key" (openChange)="setActionsOpen(key, $event)">
                          <soc-tooltip socPopoverTrigger>
                            <button type="button" aria-label="Actions" [class]="rowActionButtonClass">
                              <svg lucideMoreHorizontal class="size-full" [strokeWidth]="1.5"></svg>
                            </button>
                            <span socTooltipLabel>Actions</span>
                          </soc-tooltip>
                          <ng-container [ngTemplateOutlet]="menu" [ngTemplateOutletContext]="{ $implicit: row, row: row, close: closeActions }" />
                        </soc-popover>
                      } @else {
                        <soc-tooltip>
                          <button type="button" (click)="rowAction.emit(row)" aria-label="Actions" [class]="rowActionButtonClass">
                            <svg lucideMoreHorizontal class="size-full" [strokeWidth]="1.5"></svg>
                          </button>
                          <span socTooltipLabel>Actions</span>
                        </soc-tooltip>
                      }
                    </td>
                  }
                </tr>
              }
            </tbody>
          </table>
        </div>
      }
      @if (mode() === 'card') {
        <soc-card-grid mode="fixed" gap="md" class="pr-[var(--index-données-datatable-title-zone-pad-h)] py-[var(--index-données-datatable-cell-pad-v)]">
          @for (row of rows(); track rowKey()(row)) {
            @let key = rowKey()(row);
            @let content = cardContent()?.(row);
            @if (content) {
              <soc-card
                [title]="content.title"
                [subtitle]="content.subtitle"
                [type]="rowClickable() ? 'selectable' : 'default'"
                (cardClick)="rowClick.emit(row)"
                (action)="onCardAction(row)"
              >
                @if (rowActionsMenu(); as menu) {
                  <!-- stopPropagation on this wrapper, not the trigger button: same reason as the
                       table-row version stopping propagation on the wrapping td. -->
                  <span socCardActionSlot (click)="$event.stopPropagation()">
                    <soc-popover position="bottom-end" [open]="openActionsKey() === key" (openChange)="setActionsOpen(key, $event)">
                      <soc-tooltip socPopoverTrigger>
                        <button type="button" aria-label="Actions" [class]="cardActionButtonClass">
                          <svg lucideMoreHorizontal class="size-[var(--index-conteneur-card-action-icon-size)] text-[var(--index-conteneur-card-action-icon-color)]" [strokeWidth]="cardActionIconThickness"></svg>
                        </button>
                        <span socTooltipLabel>Actions</span>
                      </soc-tooltip>
                      <ng-container [ngTemplateOutlet]="menu" [ngTemplateOutletContext]="{ $implicit: row, row: row, close: closeActions }" />
                    </soc-popover>
                  </span>
                }
                @if (content.body; as body) {
                  <ng-container [ngTemplateOutlet]="body" [ngTemplateOutletContext]="{ $implicit: row, row: row }" />
                }
                @if (content.footer; as footer) {
                  <div socCardFooter>
                    <ng-container [ngTemplateOutlet]="footer" [ngTemplateOutletContext]="{ $implicit: row, row: row }" />
                  </div>
                }
              </soc-card>
            }
          }
        </soc-card-grid>
      }
      @if (pagination(); as pager) {
        <div class="flex w-full items-center justify-center bg-[var(--index-données-datatable-bg-pagination)] px-[var(--index-données-datatable-pagination-pad-h)] py-[var(--index-données-datatable-pagination-pad-v)]">
          <soc-pagination
            class="w-full"
            [currentPage]="pager.currentPage"
            [totalPages]="pager.totalPages"
            [totalEntries]="pager.totalEntries"
            [pageSize]="pager.pageSize"
            (pageChange)="pageChange.emit($event)"
            (pageSizeChange)="pageSizeChange.emit($event)"
          />
        </div>
      }
    }
  `,
                }]
        }] });

/**
 * ## Rôle
 * Fenêtre modale bloquante, superposée au contenu de la page, pour une action ou une information
 * qui exige l'attention exclusive de l'utilisateur avant qu'il puisse continuer.
 *
 * ## Quand l'utiliser
 * - Toute action nécessitant une confirmation explicite avant exécution (suppression, annulation
 *   d'un processus en cours, désactivation, etc.).
 * - Saisie ou consultation ponctuelle qui ne justifie pas une page dédiée.
 *
 * ## Contraintes de composition
 * - Toute action nécessitant une confirmation de l'utilisateur (suppression, annulation, etc.) doit
 *   systématiquement passer par une instance de `soc-dialog` avec `[open]="true"` — jamais une
 *   confirmation inline (`window.confirm`, un simple changement d'état de bouton, une modification
 *   silencieuse sans dialogue) ne remplace ce composant.
 * - Un seul `soc-dialog` ouvert à la fois — ne jamais en empiler plusieurs.
 *
 * Maps 1:1 to "Index/Conteneur/Dialog/*" tokens — see packages/tokens/tokens/components/conteneur.json
 * in design_system (React reference repo, read only). Plain wrapper (`soc-dialog`). `onClose` ->
 * `close` output; `open` stays purely controlled (React has no internal fallback): plain `input()`.
 * `primaryAction`/`secondaryAction` keep React's `{ label, onClick? }` data shape (per-item
 * callbacks, like `Breadcrumb`'s items) — their *presence* decides whether the footer renders.
 *
 * Portaled to `document.body` via a direct `appendChild` while open, same technique as `Popover`/
 * `Tooltip` (React: `createPortal`). Unlike React, projected content is created once with the parent
 * (Angular content projection can't be unmounted/remounted by the child) — only its placement
 * follows `open`.
 */
class SocDialog {
    open = input(false, { transform: booleanAttribute });
    title = input.required();
    primaryAction = input();
    secondaryAction = input();
    close = output();
    closeIconThickness = 'var(--index-conteneur-dialog-close-icon-thickness)';
    overlayRef = viewChild('overlay');
    constructor() {
        effect(() => {
            const el = this.overlayRef()?.nativeElement;
            if (el && el.parentElement !== document.body)
                document.body.appendChild(el);
        });
        const onKeyDown = (e) => {
            if (this.open() && e.key === 'Escape')
                this.close.emit();
        };
        document.addEventListener('keydown', onKeyDown);
        inject(DestroyRef).onDestroy(() => {
            document.removeEventListener('keydown', onKeyDown);
            this.overlayRef()?.nativeElement.remove();
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocDialog, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocDialog, isStandalone: true, selector: "soc-dialog", inputs: { open: { classPropertyName: "open", publicName: "open", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, primaryAction: { classPropertyName: "primaryAction", publicName: "primaryAction", isSignal: true, isRequired: false, transformFunction: null }, secondaryAction: { classPropertyName: "secondaryAction", publicName: "secondaryAction", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { close: "close" }, viewQueries: [{ propertyName: "overlayRef", first: true, predicate: ["overlay"], descendants: true, isSignal: true }], ngImport: i0, template: `
    @if (open()) {
      <div #overlay class="fixed inset-0 z-50 flex items-center justify-center bg-[var(--index-conteneur-dialog-overlay-color)]" (click)="close.emit()">
        <div
          role="dialog"
          aria-modal="true"
          (click)="$event.stopPropagation()"
          class="flex w-[560px] max-w-[90vw] flex-col items-start rounded-[var(--index-conteneur-dialog-radius)] border-[length:var(--index-conteneur-dialog-border-width)] border-[var(--index-conteneur-dialog-border)] bg-[var(--index-conteneur-dialog-bg)]"
        >
          <div class="flex w-full items-center py-[var(--index-conteneur-dialog-header-pad-v)] px-[var(--index-conteneur-dialog-header-pad-h-right)]">
            <p class="flex-1 text-[length:var(--index-conteneur-dialog-title-size)] text-[var(--index-conteneur-dialog-title-color)] [font-family:var(--index-conteneur-dialog-title-font)] [font-weight:var(--index-conteneur-dialog-title-weight)]">
              {{ title() }}
            </p>
            <button
              type="button"
              (click)="close.emit()"
              aria-label="Fermer"
              class="size-[var(--index-conteneur-dialog-close-icon-size)] shrink-0 text-[var(--index-conteneur-dialog-close-icon-color)]"
            >
              <svg lucideX class="size-full" [strokeWidth]="closeIconThickness"></svg>
            </button>
          </div>
          <div class="h-[length:var(--index-conteneur-dialog-separator-height)] w-full bg-[var(--index-conteneur-dialog-separator-color)]"></div>
          <!-- No items-start: direct children default to 100% width (flex's stretch is the default
               align-items) — a child that wants its own width sets self-start/an explicit width
               itself, which still overrides this via align-self. -->
          <div
            class="flex w-full flex-col px-[var(--index-conteneur-dialog-content-pad-h)] py-[var(--index-conteneur-dialog-content-pad-v)]"
            style="min-height: var(--index-conteneur-dialog-slot-min-height)"
          >
            <ng-content />
          </div>
          @if (primaryAction() || secondaryAction()) {
            <div class="h-[length:var(--index-conteneur-dialog-separator-height)] w-full bg-[var(--index-conteneur-dialog-separator-color)]"></div>
            <div class="flex w-full items-center justify-end gap-[var(--index-conteneur-dialog-button-gap)] px-[var(--index-conteneur-dialog-footer-pad-h)] py-[var(--index-conteneur-dialog-footer-pad-v)]">
              @if (secondaryAction(); as secondary) {
                <button socButton variant="secondary" (click)="secondary.onClick?.()">{{ secondary.label }}</button>
              }
              @if (primaryAction(); as primary) {
                <button socButton variant="primary" (click)="primary.onClick?.()">{{ primary.label }}</button>
              }
            </div>
          }
        </div>
      </div>
    }
  `, isInline: true, dependencies: [{ kind: "component", type: SocButton, selector: "button[socButton]", inputs: ["variant", "size"] }, { kind: "component", type: LucideX, selector: "svg[lucideX]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocDialog, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-dialog',
                    standalone: true,
                    imports: [SocButton, LucideX],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    template: `
    @if (open()) {
      <div #overlay class="fixed inset-0 z-50 flex items-center justify-center bg-[var(--index-conteneur-dialog-overlay-color)]" (click)="close.emit()">
        <div
          role="dialog"
          aria-modal="true"
          (click)="$event.stopPropagation()"
          class="flex w-[560px] max-w-[90vw] flex-col items-start rounded-[var(--index-conteneur-dialog-radius)] border-[length:var(--index-conteneur-dialog-border-width)] border-[var(--index-conteneur-dialog-border)] bg-[var(--index-conteneur-dialog-bg)]"
        >
          <div class="flex w-full items-center py-[var(--index-conteneur-dialog-header-pad-v)] px-[var(--index-conteneur-dialog-header-pad-h-right)]">
            <p class="flex-1 text-[length:var(--index-conteneur-dialog-title-size)] text-[var(--index-conteneur-dialog-title-color)] [font-family:var(--index-conteneur-dialog-title-font)] [font-weight:var(--index-conteneur-dialog-title-weight)]">
              {{ title() }}
            </p>
            <button
              type="button"
              (click)="close.emit()"
              aria-label="Fermer"
              class="size-[var(--index-conteneur-dialog-close-icon-size)] shrink-0 text-[var(--index-conteneur-dialog-close-icon-color)]"
            >
              <svg lucideX class="size-full" [strokeWidth]="closeIconThickness"></svg>
            </button>
          </div>
          <div class="h-[length:var(--index-conteneur-dialog-separator-height)] w-full bg-[var(--index-conteneur-dialog-separator-color)]"></div>
          <!-- No items-start: direct children default to 100% width (flex's stretch is the default
               align-items) — a child that wants its own width sets self-start/an explicit width
               itself, which still overrides this via align-self. -->
          <div
            class="flex w-full flex-col px-[var(--index-conteneur-dialog-content-pad-h)] py-[var(--index-conteneur-dialog-content-pad-v)]"
            style="min-height: var(--index-conteneur-dialog-slot-min-height)"
          >
            <ng-content />
          </div>
          @if (primaryAction() || secondaryAction()) {
            <div class="h-[length:var(--index-conteneur-dialog-separator-height)] w-full bg-[var(--index-conteneur-dialog-separator-color)]"></div>
            <div class="flex w-full items-center justify-end gap-[var(--index-conteneur-dialog-button-gap)] px-[var(--index-conteneur-dialog-footer-pad-h)] py-[var(--index-conteneur-dialog-footer-pad-v)]">
              @if (secondaryAction(); as secondary) {
                <button socButton variant="secondary" (click)="secondary.onClick?.()">{{ secondary.label }}</button>
              }
              @if (primaryAction(); as primary) {
                <button socButton variant="primary" (click)="primary.onClick?.()">{{ primary.label }}</button>
              }
            </div>
          }
        </div>
      </div>
    }
  `,
                }]
        }], ctorParameters: () => [] });

const ANCHOR_CLASSES = {
    left: 'inset-y-0 left-0 h-full w-[480px] max-w-[90vw]',
    right: 'inset-y-0 right-0 h-full w-[480px] max-w-[90vw]',
    bottom: 'inset-x-0 bottom-0 w-full max-h-[90vh]',
};
/**
 * Maps 1:1 to "Index/Conteneur/Drawer/*" tokens — see packages/tokens/tokens/components/conteneur.json
 * in design_system (React reference repo, read only). Plain wrapper (`soc-drawer`), same
 * open/close/portal/actions conventions as `SocDialog` (see its doc, not repeated here).
 */
class SocDrawer {
    open = input(false, { transform: booleanAttribute });
    title = input.required();
    topline = input();
    subtitle = input();
    anchor = input('right');
    sectionTitle = input();
    sectionSubtitle = input();
    primaryAction = input();
    secondaryAction = input();
    close = output();
    closeIconThickness = 'var(--index-conteneur-drawer-close-icon-thickness)';
    panelClass = computed(() => `absolute flex flex-col items-start overflow-hidden border-[length:var(--index-conteneur-drawer-border-width)] border-[var(--index-conteneur-drawer-border)] bg-[var(--index-conteneur-drawer-bg)] shadow-[0_0_var(--index-conteneur-drawer-shadow-blur)_rgba(0,0,0,0.15)] ${this.anchor() === 'bottom' ? 'rounded-t-[var(--index-conteneur-drawer-radius)]' : 'rounded-[var(--index-conteneur-drawer-radius)]'} ${ANCHOR_CLASSES[this.anchor()]}`);
    overlayRef = viewChild('overlay');
    constructor() {
        effect(() => {
            const el = this.overlayRef()?.nativeElement;
            if (el && el.parentElement !== document.body)
                document.body.appendChild(el);
        });
        const onKeyDown = (e) => {
            if (this.open() && e.key === 'Escape')
                this.close.emit();
        };
        document.addEventListener('keydown', onKeyDown);
        inject(DestroyRef).onDestroy(() => {
            document.removeEventListener('keydown', onKeyDown);
            this.overlayRef()?.nativeElement.remove();
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocDrawer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocDrawer, isStandalone: true, selector: "soc-drawer", inputs: { open: { classPropertyName: "open", publicName: "open", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, topline: { classPropertyName: "topline", publicName: "topline", isSignal: true, isRequired: false, transformFunction: null }, subtitle: { classPropertyName: "subtitle", publicName: "subtitle", isSignal: true, isRequired: false, transformFunction: null }, anchor: { classPropertyName: "anchor", publicName: "anchor", isSignal: true, isRequired: false, transformFunction: null }, sectionTitle: { classPropertyName: "sectionTitle", publicName: "sectionTitle", isSignal: true, isRequired: false, transformFunction: null }, sectionSubtitle: { classPropertyName: "sectionSubtitle", publicName: "sectionSubtitle", isSignal: true, isRequired: false, transformFunction: null }, primaryAction: { classPropertyName: "primaryAction", publicName: "primaryAction", isSignal: true, isRequired: false, transformFunction: null }, secondaryAction: { classPropertyName: "secondaryAction", publicName: "secondaryAction", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { close: "close" }, viewQueries: [{ propertyName: "overlayRef", first: true, predicate: ["overlay"], descendants: true, isSignal: true }], ngImport: i0, template: `
    @if (open()) {
      <div #overlay class="fixed inset-0 z-50 bg-black/20" (click)="close.emit()">
        <div role="dialog" aria-modal="true" (click)="$event.stopPropagation()" [class]="panelClass()">
          <div class="flex w-full items-start gap-3 py-[var(--index-conteneur-drawer-header-pad-v)] pl-[var(--index-conteneur-drawer-header-pad-h)] pr-[var(--index-conteneur-drawer-header-pad-h-right)]">
            <div class="flex min-w-0 flex-1 flex-col gap-[var(--index-conteneur-drawer-header-gap)]">
              @if (topline()) {
                <p class="w-full text-[length:var(--index-conteneur-drawer-subtitle-size)] text-[var(--index-conteneur-drawer-topline-color)]">{{ topline() }}</p>
              }
              <p class="w-full text-[length:var(--index-conteneur-drawer-title-size)] text-[var(--index-conteneur-drawer-title-color)] [font-family:var(--index-conteneur-drawer-title-font)] [font-weight:var(--index-conteneur-drawer-title-weight)]">
                {{ title() }}
              </p>
              @if (subtitle()) {
                <p class="w-full text-[length:var(--index-conteneur-drawer-subtitle-size)] text-[var(--index-conteneur-drawer-subtitle-color)]">{{ subtitle() }}</p>
              }
            </div>
            <button
              type="button"
              (click)="close.emit()"
              aria-label="Fermer"
              class="size-[var(--index-conteneur-drawer-close-icon-size)] shrink-0 text-[var(--index-conteneur-drawer-close-icon-color)]"
            >
              <svg lucideX class="size-full" [strokeWidth]="closeIconThickness"></svg>
            </button>
          </div>
          <div class="h-[length:var(--index-conteneur-drawer-separator-height)] w-full bg-[var(--index-conteneur-drawer-separator-color)]"></div>
          <div class="flex w-full flex-1 flex-col gap-[var(--index-conteneur-drawer-section-inner-gap)] overflow-y-auto px-[var(--index-conteneur-drawer-content-pad-h)] py-[var(--index-conteneur-drawer-content-pad-v)]">
            @if (sectionTitle() || sectionSubtitle()) {
              <div class="flex w-full flex-col gap-[var(--index-conteneur-drawer-section-title-gap)]">
                @if (sectionTitle()) {
                  <p class="w-full text-[length:var(--index-conteneur-drawer-section-title-size)] text-[var(--index-conteneur-drawer-section-title-color)] [font-family:var(--index-conteneur-drawer-section-title-font)] [font-weight:var(--index-conteneur-drawer-section-title-weight)]">
                    {{ sectionTitle() }}
                  </p>
                }
                @if (sectionSubtitle()) {
                  <p class="w-full text-[length:var(--index-conteneur-drawer-section-subtitle-size)] text-[var(--index-conteneur-drawer-section-subtitle-color)]">{{ sectionSubtitle() }}</p>
                }
              </div>
            }
            <ng-content />
          </div>
          @if (primaryAction() || secondaryAction()) {
            <div class="h-[length:var(--index-conteneur-drawer-separator-height)] w-full bg-[var(--index-conteneur-drawer-separator-color)]"></div>
            <div class="flex w-full items-center justify-end gap-[var(--index-conteneur-drawer-button-gap)] px-[var(--index-conteneur-drawer-footer-pad-h)] py-[var(--index-conteneur-drawer-footer-pad-v)]">
              @if (secondaryAction(); as secondary) {
                <button socButton variant="secondary" (click)="secondary.onClick?.()">{{ secondary.label }}</button>
              }
              @if (primaryAction(); as primary) {
                <button socButton variant="primary" (click)="primary.onClick?.()">{{ primary.label }}</button>
              }
            </div>
          }
        </div>
      </div>
    }
  `, isInline: true, dependencies: [{ kind: "component", type: SocButton, selector: "button[socButton]", inputs: ["variant", "size"] }, { kind: "component", type: LucideX, selector: "svg[lucideX]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocDrawer, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-drawer',
                    standalone: true,
                    imports: [SocButton, LucideX],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    template: `
    @if (open()) {
      <div #overlay class="fixed inset-0 z-50 bg-black/20" (click)="close.emit()">
        <div role="dialog" aria-modal="true" (click)="$event.stopPropagation()" [class]="panelClass()">
          <div class="flex w-full items-start gap-3 py-[var(--index-conteneur-drawer-header-pad-v)] pl-[var(--index-conteneur-drawer-header-pad-h)] pr-[var(--index-conteneur-drawer-header-pad-h-right)]">
            <div class="flex min-w-0 flex-1 flex-col gap-[var(--index-conteneur-drawer-header-gap)]">
              @if (topline()) {
                <p class="w-full text-[length:var(--index-conteneur-drawer-subtitle-size)] text-[var(--index-conteneur-drawer-topline-color)]">{{ topline() }}</p>
              }
              <p class="w-full text-[length:var(--index-conteneur-drawer-title-size)] text-[var(--index-conteneur-drawer-title-color)] [font-family:var(--index-conteneur-drawer-title-font)] [font-weight:var(--index-conteneur-drawer-title-weight)]">
                {{ title() }}
              </p>
              @if (subtitle()) {
                <p class="w-full text-[length:var(--index-conteneur-drawer-subtitle-size)] text-[var(--index-conteneur-drawer-subtitle-color)]">{{ subtitle() }}</p>
              }
            </div>
            <button
              type="button"
              (click)="close.emit()"
              aria-label="Fermer"
              class="size-[var(--index-conteneur-drawer-close-icon-size)] shrink-0 text-[var(--index-conteneur-drawer-close-icon-color)]"
            >
              <svg lucideX class="size-full" [strokeWidth]="closeIconThickness"></svg>
            </button>
          </div>
          <div class="h-[length:var(--index-conteneur-drawer-separator-height)] w-full bg-[var(--index-conteneur-drawer-separator-color)]"></div>
          <div class="flex w-full flex-1 flex-col gap-[var(--index-conteneur-drawer-section-inner-gap)] overflow-y-auto px-[var(--index-conteneur-drawer-content-pad-h)] py-[var(--index-conteneur-drawer-content-pad-v)]">
            @if (sectionTitle() || sectionSubtitle()) {
              <div class="flex w-full flex-col gap-[var(--index-conteneur-drawer-section-title-gap)]">
                @if (sectionTitle()) {
                  <p class="w-full text-[length:var(--index-conteneur-drawer-section-title-size)] text-[var(--index-conteneur-drawer-section-title-color)] [font-family:var(--index-conteneur-drawer-section-title-font)] [font-weight:var(--index-conteneur-drawer-section-title-weight)]">
                    {{ sectionTitle() }}
                  </p>
                }
                @if (sectionSubtitle()) {
                  <p class="w-full text-[length:var(--index-conteneur-drawer-section-subtitle-size)] text-[var(--index-conteneur-drawer-section-subtitle-color)]">{{ sectionSubtitle() }}</p>
                }
              </div>
            }
            <ng-content />
          </div>
          @if (primaryAction() || secondaryAction()) {
            <div class="h-[length:var(--index-conteneur-drawer-separator-height)] w-full bg-[var(--index-conteneur-drawer-separator-color)]"></div>
            <div class="flex w-full items-center justify-end gap-[var(--index-conteneur-drawer-button-gap)] px-[var(--index-conteneur-drawer-footer-pad-h)] py-[var(--index-conteneur-drawer-footer-pad-v)]">
              @if (secondaryAction(); as secondary) {
                <button socButton variant="secondary" (click)="secondary.onClick?.()">{{ secondary.label }}</button>
              }
              @if (primaryAction(); as primary) {
                <button socButton variant="primary" (click)="primary.onClick?.()">{{ primary.label }}</button>
              }
            </div>
          }
        </div>
      </div>
    }
  `,
                }]
        }], ctorParameters: () => [] });
/** A label/value row matching Figma's Drawer "Détail" mode — see Index/Conteneur/Drawer/detail-*. */
class SocDrawerDetailItem {
    label = input.required();
    value = input.required();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocDrawerDetailItem, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.25", type: SocDrawerDetailItem, isStandalone: true, selector: "soc-drawer-detail-item", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: true, transformFunction: null } }, host: { classAttribute: "flex w-full flex-col gap-[var(--index-conteneur-drawer-detail-item-gap)]" }, ngImport: i0, template: `
    <p class="w-full text-[length:var(--index-conteneur-drawer-detail-item-size)] text-[var(--index-conteneur-drawer-detail-label-color)] [font-family:var(--index-conteneur-drawer-detail-item-font)] [font-weight:var(--index-conteneur-drawer-detail-item-weight)]">
      {{ label() }}
    </p>
    <p class="w-full text-[length:var(--index-conteneur-drawer-detail-item-size)] text-[var(--index-conteneur-drawer-detail-value-color)] [font-family:var(--index-conteneur-drawer-detail-item-font)] [font-weight:var(--index-conteneur-drawer-detail-item-weight)]">
      {{ value() }}
    </p>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocDrawerDetailItem, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-drawer-detail-item',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: { class: 'flex w-full flex-col gap-[var(--index-conteneur-drawer-detail-item-gap)]' },
                    template: `
    <p class="w-full text-[length:var(--index-conteneur-drawer-detail-item-size)] text-[var(--index-conteneur-drawer-detail-label-color)] [font-family:var(--index-conteneur-drawer-detail-item-font)] [font-weight:var(--index-conteneur-drawer-detail-item-weight)]">
      {{ label() }}
    </p>
    <p class="w-full text-[length:var(--index-conteneur-drawer-detail-item-size)] text-[var(--index-conteneur-drawer-detail-value-color)] [font-family:var(--index-conteneur-drawer-detail-item-font)] [font-weight:var(--index-conteneur-drawer-detail-item-weight)]">
      {{ value() }}
    </p>
  `,
                }]
        }] });

/**
 * Maps 1:1 to "Index/Selection/Select/enterprise-*" tokens — a distinct always-dark trigger for
 * switching between companies/subsidiaries (used in HeaderApp), not a form field. Plain wrapper
 * (`soc-enterprise-select`) built on `soc-popover` + `soc-menu`, same as React. `value`/
 * `defaultValue`/`onChange` -> one `model()` (see `LanguageSelect`); React's `className` targets
 * the trigger button, exposed as `triggerClass` for the same reason (no root element of its own).
 */
class SocEnterpriseSelect {
    options = input.required();
    value = model();
    defaultValue = input();
    triggerClass = input();
    open = signal(false);
    currentValue = computed(() => this.value() ?? this.defaultValue() ?? this.options()[0]?.value);
    current = computed(() => this.options().find((option) => option.value === this.currentValue()) ?? this.options()[0]);
    triggerClasses = computed(() => `flex w-[400px] items-center justify-between rounded-[var(--index-selection-select-enterprise-radius)] bg-[var(--index-selection-select-enterprise-bg)] px-[var(--index-selection-select-enterprise-pad-h)] py-[var(--index-selection-select-enterprise-pad-v)] text-left text-[length:var(--index-selection-select-enterprise-size)] [font-family:var(--index-selection-select-enterprise-font)] [font-weight:var(--index-selection-select-enterprise-weight)] ${this.triggerClass() ?? ''}`);
    selectOption(next) {
        this.value.set(next);
        this.open.set(false);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocEnterpriseSelect, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocEnterpriseSelect, isStandalone: true, selector: "soc-enterprise-select", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, defaultValue: { classPropertyName: "defaultValue", publicName: "defaultValue", isSignal: true, isRequired: false, transformFunction: null }, triggerClass: { classPropertyName: "triggerClass", publicName: "triggerClass", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, host: { classAttribute: "contents" }, ngImport: i0, template: `
    <soc-popover [(open)]="open" panelClass="w-[400px]">
      <!-- justify-between: the chevron must stay flush with the button's right edge and the
           ValueGroup flush with its left edge — a fixed gap would leave slack after the chevron
           whenever the content is narrower than the button's fixed width (matches the current
           Figma spec — see HeaderApp node 439:1253). -->
      <button socPopoverTrigger type="button" [class]="triggerClasses()">
        <span class="flex items-center gap-[var(--index-selection-select-enterprise-gap)] whitespace-nowrap">
          <!-- enterprise-text-color is bound to Bridges/Color/Text/primary in Figma — a
               theme-following (dark-on-light) role — but this trigger's background is always dark,
               and the canvas actually renders it with the mode-invariant "on-primary" light text,
               the same role SideNavigation already uses for its own always-dark chrome. Using
               that here instead of the literal (mismatched) token. -->
          <span class="text-[var(--bridges-color-text-on-primary)]">{{ current()?.company }} - {{ current()?.subsidiary }}</span>
          @if (current()?.count) {
            <span class="text-[var(--index-selection-select-enterprise-meta-color)]">{{ current()?.count }}</span>
          }
        </span>
        <span class="size-4 shrink-0 text-[var(--index-selection-select-enterprise-chevron-color)]">
          <svg lucideChevronDown class="size-full" [strokeWidth]="1.5"></svg>
        </span>
      </button>
      <soc-menu>
        @for (option of options(); track option.value) {
          <button socMenuItem [label]="option.company + ' - ' + option.subsidiary" (click)="selectOption(option.value)"></button>
        }
      </soc-menu>
    </soc-popover>
  `, isInline: true, dependencies: [{ kind: "component", type: SocPopover, selector: "soc-popover", inputs: ["position", "open", "matchTriggerWidth", "panelClass"], outputs: ["openChange"] }, { kind: "directive", type: SocPopoverTrigger, selector: "[socPopoverTrigger]" }, { kind: "component", type: SocMenu, selector: "soc-menu" }, { kind: "component", type: SocMenuItem, selector: "button[socMenuItem]", inputs: ["label", "level", "mode", "checked"] }, { kind: "component", type: LucideChevronDown, selector: "svg[lucideChevronDown]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocEnterpriseSelect, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-enterprise-select',
                    standalone: true,
                    imports: [SocPopover, SocPopoverTrigger, SocMenu, SocMenuItem, LucideChevronDown],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: { class: 'contents' },
                    template: `
    <soc-popover [(open)]="open" panelClass="w-[400px]">
      <!-- justify-between: the chevron must stay flush with the button's right edge and the
           ValueGroup flush with its left edge — a fixed gap would leave slack after the chevron
           whenever the content is narrower than the button's fixed width (matches the current
           Figma spec — see HeaderApp node 439:1253). -->
      <button socPopoverTrigger type="button" [class]="triggerClasses()">
        <span class="flex items-center gap-[var(--index-selection-select-enterprise-gap)] whitespace-nowrap">
          <!-- enterprise-text-color is bound to Bridges/Color/Text/primary in Figma — a
               theme-following (dark-on-light) role — but this trigger's background is always dark,
               and the canvas actually renders it with the mode-invariant "on-primary" light text,
               the same role SideNavigation already uses for its own always-dark chrome. Using
               that here instead of the literal (mismatched) token. -->
          <span class="text-[var(--bridges-color-text-on-primary)]">{{ current()?.company }} - {{ current()?.subsidiary }}</span>
          @if (current()?.count) {
            <span class="text-[var(--index-selection-select-enterprise-meta-color)]">{{ current()?.count }}</span>
          }
        </span>
        <span class="size-4 shrink-0 text-[var(--index-selection-select-enterprise-chevron-color)]">
          <svg lucideChevronDown class="size-full" [strokeWidth]="1.5"></svg>
        </span>
      </button>
      <soc-menu>
        @for (option of options(); track option.value) {
          <button socMenuItem [label]="option.company + ' - ' + option.subsidiary" (click)="selectOption(option.value)"></button>
        }
      </soc-menu>
    </soc-popover>
  `,
                }]
        }] });

/** React `HeaderApp`'s `left: ReactNode` — typically an EnterpriseSelect or a Logo. */
class SocHeaderAppLeft {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocHeaderAppLeft, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocHeaderAppLeft, isStandalone: true, selector: "[socHeaderAppLeft]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocHeaderAppLeft, decorators: [{
            type: Directive,
            args: [{ selector: '[socHeaderAppLeft]', standalone: true }]
        }] });
/** React `avatar: ReactNode` — typically a `soc-avatar` (size="md", mode="solid"). */
class SocHeaderAppAvatar {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocHeaderAppAvatar, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocHeaderAppAvatar, isStandalone: true, selector: "[socHeaderAppAvatar]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocHeaderAppAvatar, decorators: [{
            type: Directive,
            args: [{ selector: '[socHeaderAppAvatar]', standalone: true }]
        }] });
/** React `avatarMenu?: ReactNode` — content of the dropdown opened by clicking the AvatarZone,
 * typically a `soc-avatar-menu`. Omit it to keep the AvatarZone a plain, non-interactive display
 * (no hover state, no click handler): the AvatarZone only becomes a button once this is present. */
class SocHeaderAppAvatarMenu {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocHeaderAppAvatarMenu, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocHeaderAppAvatarMenu, isStandalone: true, selector: "[socHeaderAppAvatarMenu]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocHeaderAppAvatarMenu, decorators: [{
            type: Directive,
            args: [{ selector: '[socHeaderAppAvatarMenu]', standalone: true }]
        }] });
/** React `languageSelect?: ReactNode` — rendered between the notification icon and the separator,
 * typically a `soc-language-select`. Omit to not show a language control at all. */
class SocHeaderAppLanguageSelect {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocHeaderAppLanguageSelect, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocHeaderAppLanguageSelect, isStandalone: true, selector: "[socHeaderAppLanguageSelect]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocHeaderAppLanguageSelect, decorators: [{
            type: Directive,
            args: [{ selector: '[socHeaderAppLanguageSelect]', standalone: true }]
        }] });
/**
 * Maps 1:1 to "Index/Navigation/HeaderApp/*" tokens — see
 * packages/tokens/tokens/components/navigation.json in design_system (React reference repo, read
 * only). Plain wrapper (`soc-header-app`, `role="banner"` to keep the landmark React's `<header>`
 * gives for free); React's `className` is a literal `class` on the host. The help/notification
 * icons are Lucide's `CircleHelp`/`Bell` (Figma names its icon instances after Lucide slugs).
 *
 * Every `ReactNode` prop -> named content slot with a marker directive. `avatar` is needed in two
 * mutually exclusive places (inside the AvatarZone button when `avatarMenu` is present, bare
 * otherwise) — Angular only reliably honours ONE physical `<ng-content>` per selector, so the
 * AvatarZone lives in a single `<ng-template>` rendered from either branch (same fix as `Message`/
 * `Tooltip`). `onHelpClick`/`onNotificationsClick` -> `helpClick`/`notificationsClick` outputs.
 *
 * No left padding on purpose — `left` (typically an EnterpriseSelect) must sit flush with
 * HeaderApp's own left edge, so it lines up with SideNavigation's left border below it in the
 * "Full Page" composition. `pad-h` still applies on the right, ahead of the icons/AvatarZone.
 */
class SocHeaderApp {
    /** The signed-in user's display name, rendered inside HeaderApp's own AvatarZone next to the
     * `avatar` slot — not a free-form slot: the gap and typography between the two come from
     * `Index/Navigation/HeaderApp/avatar-*` tokens, matching Figma's AvatarZone exactly. */
    userName = input.required();
    helpClick = output();
    notificationsClick = output();
    iconThickness = 'var(--index-navigation-headerapp-icon-thickness)';
    avatarMenuOpen = signal(false);
    avatarMenuContent = contentChild(SocHeaderAppAvatarMenu);
    hasAvatarMenu = computed(() => !!this.avatarMenuContent());
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocHeaderApp, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocHeaderApp, isStandalone: true, selector: "soc-header-app", inputs: { userName: { classPropertyName: "userName", publicName: "userName", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { helpClick: "helpClick", notificationsClick: "notificationsClick" }, host: { attributes: { "role": "banner" }, classAttribute: "flex w-full items-center justify-between bg-[var(--index-navigation-headerapp-bg)] pr-[var(--index-navigation-headerapp-pad-h)] py-[var(--index-navigation-headerapp-pad-v)]" }, queries: [{ propertyName: "avatarMenuContent", first: true, predicate: SocHeaderAppAvatarMenu, descendants: true, isSignal: true }], ngImport: i0, template: `
    <div><ng-content select="[socHeaderAppLeft]" /></div>
    <div class="flex items-center gap-[var(--index-navigation-headerapp-gap)]">
      <soc-tooltip>
        <button
          type="button"
          (click)="helpClick.emit()"
          aria-label="Aide"
          class="inline-flex size-[var(--index-navigation-headerapp-icon-size)] items-center justify-center text-[var(--index-navigation-headerapp-icon-color)]"
        >
          <svg lucideCircleHelp class="size-full" [strokeWidth]="iconThickness"></svg>
        </button>
        <span socTooltipLabel>Aide</span>
      </soc-tooltip>
      <soc-tooltip>
        <button
          type="button"
          (click)="notificationsClick.emit()"
          aria-label="Notifications"
          class="inline-flex size-[var(--index-navigation-headerapp-icon-size)] items-center justify-center text-[var(--index-navigation-headerapp-icon-color)]"
        >
          <svg lucideBell class="size-full" [strokeWidth]="iconThickness"></svg>
        </button>
        <span socTooltipLabel>Notifications</span>
      </soc-tooltip>
      <ng-content select="[socHeaderAppLanguageSelect]" />
      <span aria-hidden="true" class="w-px self-stretch bg-[var(--index-navigation-headerapp-separator-color)]"></span>
      @if (hasAvatarMenu()) {
        <soc-popover position="bottom-end" [(open)]="avatarMenuOpen">
          <button
            socPopoverTrigger
            type="button"
            class="rounded-[var(--index-navigation-headerapp-avatarzone-radius)] px-[var(--index-navigation-headerapp-avatarzone-pad-h)] py-[var(--index-navigation-headerapp-avatarzone-pad-v)] hover:bg-[var(--index-navigation-headerapp-avatarzone-bg-hover)]"
          >
            <ng-container [ngTemplateOutlet]="avatarZone" />
          </button>
          <ng-content select="[socHeaderAppAvatarMenu]" />
        </soc-popover>
      } @else {
        <ng-container [ngTemplateOutlet]="avatarZone" />
      }
    </div>

    <ng-template #avatarZone>
      <div class="flex items-center gap-[var(--index-navigation-headerapp-avatar-zone-gap)]">
        <span class="whitespace-nowrap text-[length:var(--index-navigation-headerapp-avatar-title-size)] text-[var(--index-navigation-headerapp-label-headerapp-color)] [font-family:var(--index-navigation-headerapp-avatar-title-font)] [font-weight:var(--index-navigation-headerapp-avatar-title-weight)]">
          {{ userName() }}
        </span>
        <ng-content select="[socHeaderAppAvatar]" />
      </div>
    </ng-template>
  `, isInline: true, dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: SocPopover, selector: "soc-popover", inputs: ["position", "open", "matchTriggerWidth", "panelClass"], outputs: ["openChange"] }, { kind: "directive", type: SocPopoverTrigger, selector: "[socPopoverTrigger]" }, { kind: "component", type: SocTooltip, selector: "soc-tooltip", inputs: ["position", "variant", "title", "status", "showIcon"] }, { kind: "directive", type: SocTooltipLabel, selector: "[socTooltipLabel]" }, { kind: "component", type: LucideBell, selector: "svg[lucideBell]" }, { kind: "component", type: LucideCircleHelp, selector: "svg[lucideCircleQuestionMark], svg[lucideHelpCircle], svg[lucideCircleHelp]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocHeaderApp, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-header-app',
                    standalone: true,
                    imports: [NgTemplateOutlet, SocPopover, SocPopoverTrigger, SocTooltip, SocTooltipLabel, LucideBell, LucideCircleHelp],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        role: 'banner',
                        class: 'flex w-full items-center justify-between bg-[var(--index-navigation-headerapp-bg)] pr-[var(--index-navigation-headerapp-pad-h)] py-[var(--index-navigation-headerapp-pad-v)]',
                    },
                    template: `
    <div><ng-content select="[socHeaderAppLeft]" /></div>
    <div class="flex items-center gap-[var(--index-navigation-headerapp-gap)]">
      <soc-tooltip>
        <button
          type="button"
          (click)="helpClick.emit()"
          aria-label="Aide"
          class="inline-flex size-[var(--index-navigation-headerapp-icon-size)] items-center justify-center text-[var(--index-navigation-headerapp-icon-color)]"
        >
          <svg lucideCircleHelp class="size-full" [strokeWidth]="iconThickness"></svg>
        </button>
        <span socTooltipLabel>Aide</span>
      </soc-tooltip>
      <soc-tooltip>
        <button
          type="button"
          (click)="notificationsClick.emit()"
          aria-label="Notifications"
          class="inline-flex size-[var(--index-navigation-headerapp-icon-size)] items-center justify-center text-[var(--index-navigation-headerapp-icon-color)]"
        >
          <svg lucideBell class="size-full" [strokeWidth]="iconThickness"></svg>
        </button>
        <span socTooltipLabel>Notifications</span>
      </soc-tooltip>
      <ng-content select="[socHeaderAppLanguageSelect]" />
      <span aria-hidden="true" class="w-px self-stretch bg-[var(--index-navigation-headerapp-separator-color)]"></span>
      @if (hasAvatarMenu()) {
        <soc-popover position="bottom-end" [(open)]="avatarMenuOpen">
          <button
            socPopoverTrigger
            type="button"
            class="rounded-[var(--index-navigation-headerapp-avatarzone-radius)] px-[var(--index-navigation-headerapp-avatarzone-pad-h)] py-[var(--index-navigation-headerapp-avatarzone-pad-v)] hover:bg-[var(--index-navigation-headerapp-avatarzone-bg-hover)]"
          >
            <ng-container [ngTemplateOutlet]="avatarZone" />
          </button>
          <ng-content select="[socHeaderAppAvatarMenu]" />
        </soc-popover>
      } @else {
        <ng-container [ngTemplateOutlet]="avatarZone" />
      }
    </div>

    <ng-template #avatarZone>
      <div class="flex items-center gap-[var(--index-navigation-headerapp-avatar-zone-gap)]">
        <span class="whitespace-nowrap text-[length:var(--index-navigation-headerapp-avatar-title-size)] text-[var(--index-navigation-headerapp-label-headerapp-color)] [font-family:var(--index-navigation-headerapp-avatar-title-font)] [font-weight:var(--index-navigation-headerapp-avatar-title-weight)]">
          {{ userName() }}
        </span>
        <ng-content select="[socHeaderAppAvatar]" />
      </div>
    </ng-template>
  `,
                }]
        }] });

/**
 * Sélecteur de langue toujours affiché dans `HeaderApp` — un déclencheur compact (ex. "EN" +
 * chevron) qui ouvre un menu contextuel de choix. Plain wrapper (`soc-language-select`), built on
 * `soc-popover` + `soc-menu` like React. Uses `Index/Selection/Select/field-light-*` tokens (white
 * text/border) since it sits on HeaderApp's always-dark background.
 *
 * React's `value`/`defaultValue`/`onChange` collapse to one `model()` (`[(value)]`), same pattern
 * as `Select`; the fallback chain `defaultValue ?? options[0]` is kept. React's `className` targets
 * the *trigger button* (this component has no root element of its own — `Popover` is a fragment),
 * so it can't be a plain `class` on `<soc-language-select>`: exposed as `triggerClass` instead.
 */
class SocLanguageSelect {
    options = input.required();
    value = model();
    defaultValue = input();
    triggerClass = input();
    iconThickness = 'var(--index-selection-select-icon-thickness)';
    open = signal(false);
    currentValue = computed(() => this.value() ?? this.defaultValue() ?? this.options()[0]?.value);
    current = computed(() => this.options().find((option) => option.value === this.currentValue()) ?? this.options()[0]);
    triggerClasses = computed(() => `flex w-fit items-center gap-[var(--index-selection-select-icon-gap)] rounded-[var(--index-selection-select-field-radius)] border-[length:var(--index-selection-select-field-stroke-width)] border-[var(--index-selection-select-field-light-stroke)] px-[var(--index-selection-select-field-pad-h)] py-[var(--index-selection-select-field-pad-v)] text-left ${this.triggerClass() ?? ''}`);
    selectOption(next) {
        this.value.set(next);
        this.open.set(false);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLanguageSelect, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocLanguageSelect, isStandalone: true, selector: "soc-language-select", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, defaultValue: { classPropertyName: "defaultValue", publicName: "defaultValue", isSignal: true, isRequired: false, transformFunction: null }, triggerClass: { classPropertyName: "triggerClass", publicName: "triggerClass", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, host: { classAttribute: "contents" }, ngImport: i0, template: `
    <soc-popover [(open)]="open">
      <button socPopoverTrigger type="button" [class]="triggerClasses()">
        <!-- Grid stack: every option's label shares the same cell, so the track's intrinsic width
             is the widest option — not just the currently selected one. Sizes to content (no
             hardcoded width), never truncates, and picking a shorter/longer option never shifts
             the trigger's width since the reserved space already accounts for all of them. -->
        <span class="grid">
          @for (option of options(); track option.value) {
            <span
              [attr.aria-hidden]="option.value !== current()?.value"
              [class]="'[grid-area:1/1] whitespace-nowrap [font-family:var(--index-selection-select-value-font)] [font-weight:var(--index-selection-select-value-weight)] text-[length:var(--index-selection-select-value-size)] text-[var(--index-selection-select-value-light-color)] ' + (option.value === current()?.value ? '' : 'invisible')"
            >
              {{ option.label }}
            </span>
          }
        </span>
        <span class="size-[18px] shrink-0 text-[var(--index-selection-select-icon-light-chevron)]">
          <svg lucideChevronDown class="size-full" [strokeWidth]="iconThickness"></svg>
        </span>
      </button>
      <soc-menu>
        @for (option of options(); track option.value) {
          <button socMenuItem [label]="option.label" (click)="selectOption(option.value)"></button>
        }
      </soc-menu>
    </soc-popover>
  `, isInline: true, dependencies: [{ kind: "component", type: SocPopover, selector: "soc-popover", inputs: ["position", "open", "matchTriggerWidth", "panelClass"], outputs: ["openChange"] }, { kind: "directive", type: SocPopoverTrigger, selector: "[socPopoverTrigger]" }, { kind: "component", type: SocMenu, selector: "soc-menu" }, { kind: "component", type: SocMenuItem, selector: "button[socMenuItem]", inputs: ["label", "level", "mode", "checked"] }, { kind: "component", type: LucideChevronDown, selector: "svg[lucideChevronDown]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLanguageSelect, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-language-select',
                    standalone: true,
                    imports: [SocPopover, SocPopoverTrigger, SocMenu, SocMenuItem, LucideChevronDown],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: { class: 'contents' },
                    template: `
    <soc-popover [(open)]="open">
      <button socPopoverTrigger type="button" [class]="triggerClasses()">
        <!-- Grid stack: every option's label shares the same cell, so the track's intrinsic width
             is the widest option — not just the currently selected one. Sizes to content (no
             hardcoded width), never truncates, and picking a shorter/longer option never shifts
             the trigger's width since the reserved space already accounts for all of them. -->
        <span class="grid">
          @for (option of options(); track option.value) {
            <span
              [attr.aria-hidden]="option.value !== current()?.value"
              [class]="'[grid-area:1/1] whitespace-nowrap [font-family:var(--index-selection-select-value-font)] [font-weight:var(--index-selection-select-value-weight)] text-[length:var(--index-selection-select-value-size)] text-[var(--index-selection-select-value-light-color)] ' + (option.value === current()?.value ? '' : 'invisible')"
            >
              {{ option.label }}
            </span>
          }
        </span>
        <span class="size-[18px] shrink-0 text-[var(--index-selection-select-icon-light-chevron)]">
          <svg lucideChevronDown class="size-full" [strokeWidth]="iconThickness"></svg>
        </span>
      </button>
      <soc-menu>
        @for (option of options(); track option.value) {
          <button socMenuItem [label]="option.label" (click)="selectOption(option.value)"></button>
        }
      </soc-menu>
    </soc-popover>
  `,
                }]
        }] });

/**
 * Maps 1:1 to "Index/Selection/Select/*" tokens for the field box (Multi-select has no dedicated
 * field tokens of its own — its Figma dependency is Select + Chips) plus "Index/Selection/Chips/*"
 * (type=Input) for the selected-value tags — see packages/tokens/tokens/components/selection.json
 * in design_system (React reference repo, read only). Plain wrapper (`soc-multi-select`) built on
 * `soc-popover` + `soc-menu` (checkbox mode), same as React.
 *
 * `value`/`onChange` are both required in React (purely controlled). A `model()` here (`[(value)]`
 * or `[value]` + `(valueChange)`) so the component is also a form control (`formControl`,
 * `formControlName`, `ngModel`).
 */
class SocMultiSelect extends SocFormControl {
    label = input();
    required = input(false, { transform: booleanAttribute });
    error = input(false, { transform: booleanAttribute });
    warning = input(false, { transform: booleanAttribute });
    helperText = input();
    placeholder = input('Select options');
    options = input.required();
    value = model([]);
    id = input();
    valueModel = this.value;
    coerce(value) {
        return Array.isArray(value) ? value : [];
    }
    iconThickness = 'var(--index-selection-select-icon-thickness)';
    helpIconThickness = 'var(--index-selection-select-icon-help-thickness)';
    generatedId = nextUniqueId('soc-multi-select');
    get fieldId() {
        return this.id() ?? this.generatedId;
    }
    selectedOptions = computed(() => this.options().filter((option) => this.value().includes(option.value)));
    onOpenChange(open) {
        if (!open)
            this.onTouched();
    }
    toggle(optionValue) {
        const current = this.value();
        this.value.set(current.includes(optionValue) ? current.filter((v) => v !== optionValue) : [...current, optionValue]);
    }
    labelClass = computed(() => `[font-family:var(--index-selection-select-label-font)] [font-weight:var(--index-selection-select-label-weight)] text-[length:var(--index-selection-select-label-size)] ${this.isDisabled() ? 'text-[var(--index-selection-select-label-disabled)]' : 'text-[var(--index-selection-select-label-color)]'}`);
    fieldClass = computed(() => {
        const base = 'flex w-full flex-wrap items-center gap-1.5 rounded-[var(--index-selection-select-field-radius)] border-[length:var(--index-selection-select-field-stroke-width)] bg-[var(--index-selection-select-field-bg)] px-[var(--index-selection-select-field-pad-h)] py-[var(--index-selection-select-field-pad-v)] text-left disabled:cursor-not-allowed disabled:bg-[var(--index-selection-select-field-bg-disabled)]';
        const stroke = this.error()
            ? 'border-[var(--index-selection-select-field-stroke-error)]'
            : this.warning()
                ? 'border-[var(--index-selection-select-field-stroke-warning)]'
                : 'border-[var(--index-selection-select-field-stroke)] hover:border-[var(--index-selection-select-field-stroke-hover)] focus-visible:border-[var(--index-selection-select-field-stroke-focus)] disabled:border-[var(--index-selection-select-field-stroke-disabled)]';
        return `${base} ${stroke}`;
    });
    helperIconColorClass = computed(() => this.error()
        ? 'text-[var(--index-selection-select-icon-help-error)]'
        : this.warning()
            ? 'text-[var(--index-selection-select-icon-help-warning)]'
            : 'text-[var(--index-selection-select-icon-help)]');
    helperTextColorClass = computed(() => this.error()
        ? 'text-[var(--index-selection-select-help-color-error)]'
        : this.warning()
            ? 'text-[var(--index-selection-select-help-color-warning)]'
            : 'text-[var(--index-selection-select-help-color)]');
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocMultiSelect, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocMultiSelect, isStandalone: true, selector: "soc-multi-select", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, warning: { classPropertyName: "warning", publicName: "warning", isSignal: true, isRequired: false, transformFunction: null }, helperText: { classPropertyName: "helperText", publicName: "helperText", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, host: { properties: { "attr.id": "null" }, classAttribute: "flex w-full flex-col gap-[var(--index-selection-select-label-gap)]" }, providers: [provideFormControl(() => SocMultiSelect)], usesInheritance: true, ngImport: i0, template: `
    @if (label()) {
      <label [for]="fieldId" [class]="labelClass()">
        {{ label() }}
        @if (required()) {
          <span class="text-[var(--index-selection-select-required-color)]"> *</span>
        }
      </label>
    }
    <soc-popover [matchTriggerWidth]="true" (openChange)="onOpenChange($event)">
      <button socPopoverTrigger type="button" [id]="fieldId" [disabled]="isDisabled()" [class]="fieldClass()">
        @if (value().length === 0) {
          <span class="text-[length:var(--index-selection-select-value-size)] text-[var(--index-selection-select-placeholder-color)]">
            {{ placeholder() }}
          </span>
        }
        @for (option of selectedOptions(); track option.value) {
          <soc-input-chip [label]="option.label" [removable]="true" (remove)="toggle(option.value)" />
        }
        <span class="ml-auto size-[var(--index-selection-select-icon-field-size)] shrink-0 text-[var(--index-selection-select-icon-chevron)]">
          <svg lucideChevronDown class="size-full" [strokeWidth]="iconThickness"></svg>
        </span>
      </button>
      <soc-menu class="min-w-[var(--index-selection-select-field-radius)]">
        @for (option of options(); track option.value) {
          <button socMenuItem [label]="option.label" mode="checkbox" [checked]="value().includes(option.value)" (click)="toggle(option.value)"></button>
        }
      </soc-menu>
    </soc-popover>
    @if (helperText()) {
      <div class="flex items-center gap-[var(--index-selection-select-helper-gap)]">
        <span [class]="'size-[var(--index-selection-select-icon-help-size)] shrink-0 ' + helperIconColorClass()">
          <svg lucideInfo class="size-full" [strokeWidth]="helpIconThickness"></svg>
        </span>
        <span [class]="'[font-family:var(--index-selection-select-help-font)] [font-weight:var(--index-selection-select-help-weight)] text-[length:var(--index-selection-select-help-size)] ' + helperTextColorClass()">
          {{ helperText() }}
        </span>
      </div>
    }
  `, isInline: true, dependencies: [{ kind: "component", type: SocPopover, selector: "soc-popover", inputs: ["position", "open", "matchTriggerWidth", "panelClass"], outputs: ["openChange"] }, { kind: "directive", type: SocPopoverTrigger, selector: "[socPopoverTrigger]" }, { kind: "component", type: SocMenu, selector: "soc-menu" }, { kind: "component", type: SocMenuItem, selector: "button[socMenuItem]", inputs: ["label", "level", "mode", "checked"] }, { kind: "component", type: SocInputChip, selector: "soc-input-chip", inputs: ["label", "removable"], outputs: ["remove"] }, { kind: "component", type: LucideChevronDown, selector: "svg[lucideChevronDown]" }, { kind: "component", type: LucideInfo, selector: "svg[lucideInfo]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocMultiSelect, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-multi-select',
                    standalone: true,
                    imports: [SocPopover, SocPopoverTrigger, SocMenu, SocMenuItem, SocInputChip, LucideChevronDown, LucideInfo],
                    providers: [provideFormControl(() => SocMultiSelect)],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    // `id` is forwarded to the inner trigger button (label `for` target), like React — a static
                    // `id="..."` on <soc-*> would otherwise also land on this host element as a duplicate DOM id,
                    // and `<label for>` would resolve to the host (not labelable) instead of the button.
                    host: { class: 'flex w-full flex-col gap-[var(--index-selection-select-label-gap)]', '[attr.id]': 'null' },
                    template: `
    @if (label()) {
      <label [for]="fieldId" [class]="labelClass()">
        {{ label() }}
        @if (required()) {
          <span class="text-[var(--index-selection-select-required-color)]"> *</span>
        }
      </label>
    }
    <soc-popover [matchTriggerWidth]="true" (openChange)="onOpenChange($event)">
      <button socPopoverTrigger type="button" [id]="fieldId" [disabled]="isDisabled()" [class]="fieldClass()">
        @if (value().length === 0) {
          <span class="text-[length:var(--index-selection-select-value-size)] text-[var(--index-selection-select-placeholder-color)]">
            {{ placeholder() }}
          </span>
        }
        @for (option of selectedOptions(); track option.value) {
          <soc-input-chip [label]="option.label" [removable]="true" (remove)="toggle(option.value)" />
        }
        <span class="ml-auto size-[var(--index-selection-select-icon-field-size)] shrink-0 text-[var(--index-selection-select-icon-chevron)]">
          <svg lucideChevronDown class="size-full" [strokeWidth]="iconThickness"></svg>
        </span>
      </button>
      <soc-menu class="min-w-[var(--index-selection-select-field-radius)]">
        @for (option of options(); track option.value) {
          <button socMenuItem [label]="option.label" mode="checkbox" [checked]="value().includes(option.value)" (click)="toggle(option.value)"></button>
        }
      </soc-menu>
    </soc-popover>
    @if (helperText()) {
      <div class="flex items-center gap-[var(--index-selection-select-helper-gap)]">
        <span [class]="'size-[var(--index-selection-select-icon-help-size)] shrink-0 ' + helperIconColorClass()">
          <svg lucideInfo class="size-full" [strokeWidth]="helpIconThickness"></svg>
        </span>
        <span [class]="'[font-family:var(--index-selection-select-help-font)] [font-weight:var(--index-selection-select-help-weight)] text-[length:var(--index-selection-select-help-size)] ' + helperTextColorClass()">
          {{ helperText() }}
        </span>
      </div>
    }
  `,
                }]
        }] });

/**
 * Maps 1:1 to "Index/Données/ProfileLine/*" tokens — see packages/tokens/tokens/components/données.json
 * in design_system (React reference repo, read only). Plain wrapper (`soc-profile-line`); React's
 * root `<div className>` is this host, so a literal `class` on `<soc-profile-line>` replaces its
 * `className` prop. The avatar is always LG/solid per Figma's component notes. Meta fields not
 * passed are simply omitted from the dot-separated row rather than rendered empty.
 *
 * React's `id` prop is the displayed employee id (e.g. "#123456789"), not a DOM id — kept as `id`
 * for parity, with the host's own `id` attribute cleared so a static `id="..."` isn't also left on
 * the element as a stray DOM id.
 */
class SocProfileLine {
    /** Initials shown in the avatar circle — 2 characters max. */
    avatarLabel = input.required();
    avatarColor = input('blue');
    name = input.required();
    id = input();
    role = input();
    department = input();
    email = input();
    company = input();
    metaItems = computed(() => [this.id(), this.role(), this.department(), this.email(), this.company()].filter((item) => Boolean(item)));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocProfileLine, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocProfileLine, isStandalone: true, selector: "soc-profile-line", inputs: { avatarLabel: { classPropertyName: "avatarLabel", publicName: "avatarLabel", isSignal: true, isRequired: true, transformFunction: null }, avatarColor: { classPropertyName: "avatarColor", publicName: "avatarColor", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: true, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, role: { classPropertyName: "role", publicName: "role", isSignal: true, isRequired: false, transformFunction: null }, department: { classPropertyName: "department", publicName: "department", isSignal: true, isRequired: false, transformFunction: null }, email: { classPropertyName: "email", publicName: "email", isSignal: true, isRequired: false, transformFunction: null }, company: { classPropertyName: "company", publicName: "company", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.id": "null" }, classAttribute: "flex items-center gap-[var(--index-donn\u00E9es-profileline-gap)]" }, ngImport: i0, template: `
    <soc-avatar [label]="avatarLabel()" [color]="avatarColor()" size="lg" mode="solid" />
    <div class="flex flex-col items-start gap-[var(--index-données-profileline-text-gap)]">
      <p class="whitespace-nowrap text-[length:var(--index-données-profileline-name-size)] text-[var(--index-données-profileline-name-color)] [font-family:var(--index-données-profileline-name-font)] [font-weight:var(--index-données-profileline-name-weight)]">
        {{ name() }}
      </p>
      @if (metaItems().length > 0) {
        <div class="flex flex-wrap items-center gap-[var(--index-données-profileline-meta-gap)]">
          @for (item of metaItems(); track item; let index = $index) {
            <span class="flex items-center gap-[var(--index-données-profileline-meta-gap)]">
              @if (index > 0) {
                <span aria-hidden="true" class="inline-flex size-[var(--index-données-profileline-dot-size)] shrink-0 items-center justify-center">
                  <span class="size-1 rounded-full bg-[var(--index-données-profileline-dot-color)]"></span>
                </span>
              }
              <span class="whitespace-nowrap text-[length:var(--index-données-profileline-meta-size)] text-[var(--index-données-profileline-meta-color)] [font-family:var(--index-données-profileline-meta-font)] [font-weight:var(--index-données-profileline-meta-weight)]">
                {{ item }}
              </span>
            </span>
          }
        </div>
      }
    </div>
  `, isInline: true, dependencies: [{ kind: "component", type: SocAvatar, selector: "soc-avatar", inputs: ["label", "color", "size", "mode", "name", "subtitle", "namePosition"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocProfileLine, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-profile-line',
                    standalone: true,
                    imports: [SocAvatar],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: { class: 'flex items-center gap-[var(--index-données-profileline-gap)]', '[attr.id]': 'null' },
                    template: `
    <soc-avatar [label]="avatarLabel()" [color]="avatarColor()" size="lg" mode="solid" />
    <div class="flex flex-col items-start gap-[var(--index-données-profileline-text-gap)]">
      <p class="whitespace-nowrap text-[length:var(--index-données-profileline-name-size)] text-[var(--index-données-profileline-name-color)] [font-family:var(--index-données-profileline-name-font)] [font-weight:var(--index-données-profileline-name-weight)]">
        {{ name() }}
      </p>
      @if (metaItems().length > 0) {
        <div class="flex flex-wrap items-center gap-[var(--index-données-profileline-meta-gap)]">
          @for (item of metaItems(); track item; let index = $index) {
            <span class="flex items-center gap-[var(--index-données-profileline-meta-gap)]">
              @if (index > 0) {
                <span aria-hidden="true" class="inline-flex size-[var(--index-données-profileline-dot-size)] shrink-0 items-center justify-center">
                  <span class="size-1 rounded-full bg-[var(--index-données-profileline-dot-color)]"></span>
                </span>
              }
              <span class="whitespace-nowrap text-[length:var(--index-données-profileline-meta-size)] text-[var(--index-données-profileline-meta-color)] [font-family:var(--index-données-profileline-meta-font)] [font-weight:var(--index-données-profileline-meta-weight)]">
                {{ item }}
              </span>
            </span>
          }
        </div>
      }
    </div>
  `,
                }]
        }] });

const SELECT_DEFAULT_PLACEHOLDER = 'Select an option';
/**
 * No native HTML equivalent (label + custom trigger + popover list + helper row) — plain wrapper
 * (`soc-select`). Maps 1:1 to "Index/Selection/Select/*" tokens — see
 * packages/tokens/tokens/components/selection.json in design_system (React reference repo, read
 * only). Built on `soc-popover` + `soc-menu`, same as React.
 *
 * "formulaire" (default): label above the field. "labelHeader": no label above — `label` renders as
 * a small uppercase title inside the field, stacked above the value (compact inline filters).
 *
 * React's `value` (controlled) / `defaultValue` (uncontrolled) / `onChange` collapse to one `model()`
 * (`[(value)]`), same pattern as `Checkbox`/`Switch`; `defaultValue` is kept as its own input and
 * only used while `value` is still undefined, so an uncontrolled `defaultValue` behaves as in React
 * (first selection takes over).
 */
class SocSelect extends SocFormControl {
    label = input();
    mode = input('formulaire');
    required = input(false, { transform: booleanAttribute });
    error = input(false, { transform: booleanAttribute });
    warning = input(false, { transform: booleanAttribute });
    helperText = input();
    placeholder = input(SELECT_DEFAULT_PLACEHOLDER);
    options = input.required();
    value = model();
    valueModel = this.value;
    coerce(value) {
        return value == null || value === '' ? undefined : String(value);
    }
    defaultValue = input();
    id = input();
    iconThickness = 'var(--index-selection-select-icon-thickness)';
    helpIconThickness = 'var(--index-selection-select-icon-help-thickness)';
    generatedId = nextUniqueId('soc-select');
    get selectId() {
        return this.id() ?? this.generatedId;
    }
    open = signal(false);
    isOpen = computed(() => this.open() && !this.isDisabled());
    currentValue = computed(() => this.value() ?? this.defaultValue());
    selectedOption = computed(() => this.options().find((option) => option.value === this.currentValue()));
    helperIsError = computed(() => this.error());
    helperIsWarning = computed(() => !this.error() && this.warning());
    onOpenChange(open) {
        this.open.set(open);
        if (!open)
            this.onTouched();
    }
    selectOption(optionValue) {
        this.value.set(optionValue);
        this.open.set(false);
    }
    labelClass = computed(() => `[font-family:var(--index-selection-select-label-font)] [font-weight:var(--index-selection-select-label-weight)] text-[length:var(--index-selection-select-label-size)] ${this.isDisabled() ? 'text-[var(--index-selection-select-label-disabled)]' : 'text-[var(--index-selection-select-label-color)]'}`);
    fieldClass = computed(() => {
        const base = 'flex w-full items-center gap-[var(--index-selection-select-icon-gap)] rounded-[var(--index-selection-select-field-radius)] border-[length:var(--index-selection-select-field-stroke-width)] bg-[var(--index-selection-select-field-bg)] px-[var(--index-selection-select-field-pad-h)] text-left disabled:cursor-not-allowed disabled:bg-[var(--index-selection-select-field-bg-disabled)]';
        // "labelHeader" stacks two text lines (title + value) — Figma fixes that field to a flat height
        // (matching TableFilterSelect to SearchBar in a DataTable filter row) instead of letting
        // padding + the two lines' natural line-height determine it.
        const height = this.mode() === 'labelHeader' ? 'h-[var(--index-selection-select-field-height-label-header)]' : 'py-[var(--index-selection-select-field-pad-v)]';
        const stroke = this.error()
            ? 'border-[var(--index-selection-select-field-stroke-error)]'
            : this.warning()
                ? 'border-[var(--index-selection-select-field-stroke-warning)]'
                : 'border-[var(--index-selection-select-field-stroke)] hover:border-[var(--index-selection-select-field-stroke-hover)] focus-visible:border-[var(--index-selection-select-field-stroke-focus)] disabled:border-[var(--index-selection-select-field-stroke-disabled)]';
        return `${base} ${height} ${stroke}`;
    });
    // React uses a different "has value" color in labelHeader mode (label-color) than in formulaire
    // mode (value-color) — preserved as-is.
    valueColorClass(labelHeader) {
        if (this.selectedOption()) {
            return labelHeader ? 'text-[var(--index-selection-select-label-color)]' : 'text-[var(--index-selection-select-value-color)]';
        }
        return this.isDisabled() ? 'text-[var(--index-selection-select-placeholder-color-disabled)]' : 'text-[var(--index-selection-select-placeholder-color)]';
    }
    helperIconColorClass = computed(() => this.helperIsError()
        ? 'text-[var(--index-selection-select-icon-help-error)]'
        : this.helperIsWarning()
            ? 'text-[var(--index-selection-select-icon-help-warning)]'
            : 'text-[var(--index-selection-select-icon-help)]');
    helperTextColorClass = computed(() => this.helperIsError()
        ? 'text-[var(--index-selection-select-help-color-error)]'
        : this.helperIsWarning()
            ? 'text-[var(--index-selection-select-help-color-warning)]'
            : 'text-[var(--index-selection-select-help-color)]');
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocSelect, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocSelect, isStandalone: true, selector: "soc-select", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, mode: { classPropertyName: "mode", publicName: "mode", isSignal: true, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, warning: { classPropertyName: "warning", publicName: "warning", isSignal: true, isRequired: false, transformFunction: null }, helperText: { classPropertyName: "helperText", publicName: "helperText", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, defaultValue: { classPropertyName: "defaultValue", publicName: "defaultValue", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, host: { properties: { "attr.id": "null" }, classAttribute: "flex w-full flex-col gap-[var(--index-selection-select-label-gap)]" }, providers: [provideFormControl(() => SocSelect)], usesInheritance: true, ngImport: i0, template: `
    @if (mode() === 'formulaire' && label()) {
      <label [for]="selectId" [class]="labelClass()">
        {{ label() }}
        @if (required()) {
          <span class="text-[var(--index-selection-select-required-color)]"> *</span>
        }
      </label>
    }
    <soc-popover [matchTriggerWidth]="true" [open]="isOpen()" (openChange)="onOpenChange($event)">
      <button socPopoverTrigger type="button" [id]="selectId" [disabled]="isDisabled()" [class]="fieldClass()">
        @if (mode() === 'labelHeader') {
          <span class="flex min-w-0 flex-1 flex-col items-start">
            @if (label()) {
              <span class="w-full truncate uppercase [font-family:var(--index-selection-select-title-header-font)] [font-weight:var(--index-selection-select-title-header-weight)] text-[length:var(--index-selection-select-title-header-size)] text-[var(--index-selection-select-title-header-color)]">
                {{ label() }}
                @if (required()) {
                  <span class="text-[var(--index-selection-select-required-color)]"> *</span>
                }
              </span>
            }
            <span [class]="'w-full truncate [font-family:var(--index-selection-select-value-font)] [font-weight:var(--index-selection-select-value-weight)] text-[length:var(--index-selection-select-value-size)] ' + valueColorClass(true)">
              {{ selectedOption()?.label ?? placeholder() }}
            </span>
          </span>
        } @else {
          <span [class]="'min-w-0 flex-1 truncate [font-family:var(--index-selection-select-value-font)] [font-weight:var(--index-selection-select-value-weight)] text-[length:var(--index-selection-select-value-size)] ' + valueColorClass(false)">
            {{ selectedOption()?.label ?? placeholder() }}
          </span>
        }
        <span [class]="'size-[var(--index-selection-select-icon-field-size)] shrink-0 ' + (isDisabled() ? 'text-[var(--index-selection-select-icon-chevron-disabled)]' : 'text-[var(--index-selection-select-icon-chevron)]')">
          <svg lucideChevronDown class="size-full" [strokeWidth]="iconThickness"></svg>
        </span>
      </button>
      <soc-menu>
        @for (option of options(); track option.value) {
          <button socMenuItem [label]="option.label" (click)="selectOption(option.value)">
            @if (option.value === currentValue()) {
              <svg lucideCheck socMenuItemIcon class="size-full" [strokeWidth]="iconThickness"></svg>
            } @else {
              <span socMenuItemIcon aria-hidden="true" class="block size-full"></span>
            }
          </button>
        }
      </soc-menu>
    </soc-popover>
    @if (helperText()) {
      <div class="flex items-center gap-[var(--index-selection-select-helper-gap)]">
        <span [class]="'size-[var(--index-selection-select-icon-help-size)] shrink-0 ' + helperIconColorClass()">
          <svg lucideInfo class="size-full" [strokeWidth]="helpIconThickness"></svg>
        </span>
        <span [class]="'[font-family:var(--index-selection-select-help-font)] [font-weight:var(--index-selection-select-help-weight)] text-[length:var(--index-selection-select-help-size)] ' + helperTextColorClass()">
          {{ helperText() }}
        </span>
      </div>
    }
  `, isInline: true, dependencies: [{ kind: "component", type: SocPopover, selector: "soc-popover", inputs: ["position", "open", "matchTriggerWidth", "panelClass"], outputs: ["openChange"] }, { kind: "directive", type: SocPopoverTrigger, selector: "[socPopoverTrigger]" }, { kind: "component", type: SocMenu, selector: "soc-menu" }, { kind: "component", type: SocMenuItem, selector: "button[socMenuItem]", inputs: ["label", "level", "mode", "checked"] }, { kind: "directive", type: SocMenuItemIcon, selector: "[socMenuItemIcon]" }, { kind: "component", type: LucideCheck, selector: "svg[lucideCheck]" }, { kind: "component", type: LucideChevronDown, selector: "svg[lucideChevronDown]" }, { kind: "component", type: LucideInfo, selector: "svg[lucideInfo]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocSelect, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-select',
                    standalone: true,
                    imports: [SocPopover, SocPopoverTrigger, SocMenu, SocMenuItem, SocMenuItemIcon, LucideCheck, LucideChevronDown, LucideInfo],
                    providers: [provideFormControl(() => SocSelect)],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    // `id` is forwarded to the inner trigger button (label `for` target), like React — a static
                    // `id="..."` on <soc-*> would otherwise also land on this host element as a duplicate DOM id,
                    // and `<label for>` would resolve to the host (not labelable) instead of the button.
                    host: { class: 'flex w-full flex-col gap-[var(--index-selection-select-label-gap)]', '[attr.id]': 'null' },
                    template: `
    @if (mode() === 'formulaire' && label()) {
      <label [for]="selectId" [class]="labelClass()">
        {{ label() }}
        @if (required()) {
          <span class="text-[var(--index-selection-select-required-color)]"> *</span>
        }
      </label>
    }
    <soc-popover [matchTriggerWidth]="true" [open]="isOpen()" (openChange)="onOpenChange($event)">
      <button socPopoverTrigger type="button" [id]="selectId" [disabled]="isDisabled()" [class]="fieldClass()">
        @if (mode() === 'labelHeader') {
          <span class="flex min-w-0 flex-1 flex-col items-start">
            @if (label()) {
              <span class="w-full truncate uppercase [font-family:var(--index-selection-select-title-header-font)] [font-weight:var(--index-selection-select-title-header-weight)] text-[length:var(--index-selection-select-title-header-size)] text-[var(--index-selection-select-title-header-color)]">
                {{ label() }}
                @if (required()) {
                  <span class="text-[var(--index-selection-select-required-color)]"> *</span>
                }
              </span>
            }
            <span [class]="'w-full truncate [font-family:var(--index-selection-select-value-font)] [font-weight:var(--index-selection-select-value-weight)] text-[length:var(--index-selection-select-value-size)] ' + valueColorClass(true)">
              {{ selectedOption()?.label ?? placeholder() }}
            </span>
          </span>
        } @else {
          <span [class]="'min-w-0 flex-1 truncate [font-family:var(--index-selection-select-value-font)] [font-weight:var(--index-selection-select-value-weight)] text-[length:var(--index-selection-select-value-size)] ' + valueColorClass(false)">
            {{ selectedOption()?.label ?? placeholder() }}
          </span>
        }
        <span [class]="'size-[var(--index-selection-select-icon-field-size)] shrink-0 ' + (isDisabled() ? 'text-[var(--index-selection-select-icon-chevron-disabled)]' : 'text-[var(--index-selection-select-icon-chevron)]')">
          <svg lucideChevronDown class="size-full" [strokeWidth]="iconThickness"></svg>
        </span>
      </button>
      <soc-menu>
        @for (option of options(); track option.value) {
          <button socMenuItem [label]="option.label" (click)="selectOption(option.value)">
            @if (option.value === currentValue()) {
              <svg lucideCheck socMenuItemIcon class="size-full" [strokeWidth]="iconThickness"></svg>
            } @else {
              <span socMenuItemIcon aria-hidden="true" class="block size-full"></span>
            }
          </button>
        }
      </soc-menu>
    </soc-popover>
    @if (helperText()) {
      <div class="flex items-center gap-[var(--index-selection-select-helper-gap)]">
        <span [class]="'size-[var(--index-selection-select-icon-help-size)] shrink-0 ' + helperIconColorClass()">
          <svg lucideInfo class="size-full" [strokeWidth]="helpIconThickness"></svg>
        </span>
        <span [class]="'[font-family:var(--index-selection-select-help-font)] [font-weight:var(--index-selection-select-help-weight)] text-[length:var(--index-selection-select-help-size)] ' + helperTextColorClass()">
          {{ helperText() }}
        </span>
      </div>
    }
  `,
                }]
        }] });

/**
 * `soc-select` locked to `mode="labelHeader"` — the compact filter style (title stacked above the
 * value inside the field, no separate label row) used for filters above a `DataTable`/`PageList`.
 * `mode` isn't exposed here on purpose, same reasoning as React: use `soc-table-filter-select` for
 * every table filter and that choice is made once, here, not re-decided at each call site.
 *
 * Same inputs as `SocSelect` otherwise (React: `Omit<SelectProps, 'mode'>`), forwarded one by one —
 * Angular has no "spread the props" equivalent for a component. Like React (which returns `Select`
 * directly), no root element of its own: host is `display: contents`.
 */
class SocTableFilterSelect extends SocFormControl {
    label = input();
    required = input(false, { transform: booleanAttribute });
    error = input(false, { transform: booleanAttribute });
    warning = input(false, { transform: booleanAttribute });
    helperText = input();
    placeholder = input(SELECT_DEFAULT_PLACEHOLDER);
    options = input.required();
    value = model();
    defaultValue = input();
    valueModel = this.value;
    coerce(value) {
        return value == null || value === '' ? undefined : String(value);
    }
    id = input();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocTableFilterSelect, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.25", type: SocTableFilterSelect, isStandalone: true, selector: "soc-table-filter-select", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, warning: { classPropertyName: "warning", publicName: "warning", isSignal: true, isRequired: false, transformFunction: null }, helperText: { classPropertyName: "helperText", publicName: "helperText", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, defaultValue: { classPropertyName: "defaultValue", publicName: "defaultValue", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, host: { properties: { "attr.id": "null" }, classAttribute: "contents" }, providers: [provideFormControl(() => SocTableFilterSelect)], usesInheritance: true, ngImport: i0, template: `
    <soc-select
      mode="labelHeader"
      [label]="label()"
      [required]="required()"
      [error]="error()"
      [warning]="warning()"
      [helperText]="helperText()"
      [placeholder]="placeholder()"
      [options]="options()"
      [(value)]="value"
      [defaultValue]="defaultValue()"
      [disabled]="isDisabled()"
      [id]="id()"
    />
  `, isInline: true, dependencies: [{ kind: "component", type: SocSelect, selector: "soc-select", inputs: ["label", "mode", "required", "error", "warning", "helperText", "placeholder", "options", "value", "defaultValue", "id"], outputs: ["valueChange"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocTableFilterSelect, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-table-filter-select',
                    standalone: true,
                    imports: [SocSelect],
                    providers: [provideFormControl(() => SocTableFilterSelect)],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    // `id` is forwarded to the inner soc-select (see SocSelect) — don't also leave it on this host.
                    host: { class: 'contents', '[attr.id]': 'null' },
                    template: `
    <soc-select
      mode="labelHeader"
      [label]="label()"
      [required]="required()"
      [error]="error()"
      [warning]="warning()"
      [helperText]="helperText()"
      [placeholder]="placeholder()"
      [options]="options()"
      [(value)]="value"
      [defaultValue]="defaultValue()"
      [disabled]="isDisabled()"
      [id]="id()"
    />
  `,
                }]
        }] });

/**
 * Maps 1:1 to "Index/Input/UploadFile/*" tokens — see packages/tokens/tokens/components/input.json
 * in design_system (React reference repo, read only). Plain wrapper (`soc-upload-file`): a drop zone
 * (div) + a `soc-button`-styled trigger + a hidden native `<input type="file">`, not one native
 * element. `onFilesSelected` -> `filesSelected` output (carries the `FileList`, same as React);
 * `accept`/`multiple`/`disabled` are forwarded to the hidden input.
 *
 * Also a form control (`formControl`, `formControlName`, `ngModel`) whose value is the selected
 * `File[]` (a `FileList` can't be assigned, so the form works with a plain array; `null` after
 * `reset()` empties it). React's component doesn't list the chosen files — neither does this one; the
 * consumer displays them from `(filesSelected)` or the form value.
 */
class SocUploadFile extends SocFormControl {
    error = input(false, { transform: booleanAttribute });
    warning = input(false, { transform: booleanAttribute });
    helperText = input();
    accept = input();
    multiple = input(false, { transform: booleanAttribute });
    filesSelected = output();
    files = model([]);
    valueModel = this.files;
    fileInput = viewChild('fileInput');
    coerce(value) {
        const files = Array.isArray(value) ? value : [];
        if (files.length === 0 && this.fileInput())
            this.fileInput().nativeElement.value = '';
        return files;
    }
    dragging = signal(false);
    onDragOver(e) {
        e.preventDefault();
        if (!this.isDisabled())
            this.dragging.set(true);
    }
    onDrop(e) {
        e.preventDefault();
        this.dragging.set(false);
        if (this.isDisabled())
            return;
        const files = e.dataTransfer?.files;
        if (files && files.length > 0)
            this.select(files);
    }
    onChange(e) {
        const files = e.target.files;
        if (files)
            this.select(files);
    }
    select(files) {
        this.files.set(Array.from(files));
        this.filesSelected.emit(files);
        this.onTouched();
    }
    zoneClass = computed(() => {
        const border = this.error()
            ? 'border-[var(--index-input-uploadfile-zone-border-error)]'
            : this.warning()
                ? 'border-[var(--index-input-uploadfile-zone-border-warning)]'
                : this.dragging()
                    ? 'border-[var(--index-input-uploadfile-zone-border-drag)]'
                    : 'border-[var(--index-input-uploadfile-zone-border-default)]';
        return `flex w-full flex-col items-center justify-center gap-[var(--index-input-uploadfile-zone-gap)] rounded-[var(--index-input-uploadfile-zone-radius)] border-[length:var(--index-input-uploadfile-zone-border-width)] border-dashed bg-[var(--index-input-uploadfile-zone-bg)] px-[var(--index-input-uploadfile-zone-pad-h)] py-[var(--index-input-uploadfile-zone-pad-v)] ${border} ${this.isDisabled() ? 'opacity-50' : ''}`;
    });
    helperClass = computed(() => `text-[length:var(--index-input-uploadfile-zone-text-size)] ${this.error()
        ? 'text-[var(--index-input-uploadfile-zone-error-text)]'
        : this.warning()
            ? 'text-[var(--index-input-uploadfile-zone-warning-text)]'
            : 'text-[var(--index-input-uploadfile-zone-text-color)]'}`);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocUploadFile, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocUploadFile, isStandalone: true, selector: "soc-upload-file", inputs: { error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, warning: { classPropertyName: "warning", publicName: "warning", isSignal: true, isRequired: false, transformFunction: null }, helperText: { classPropertyName: "helperText", publicName: "helperText", isSignal: true, isRequired: false, transformFunction: null }, accept: { classPropertyName: "accept", publicName: "accept", isSignal: true, isRequired: false, transformFunction: null }, multiple: { classPropertyName: "multiple", publicName: "multiple", isSignal: true, isRequired: false, transformFunction: null }, files: { classPropertyName: "files", publicName: "files", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { filesSelected: "filesSelected", files: "filesChange" }, host: { classAttribute: "flex w-full flex-col gap-2" }, providers: [provideFormControl(() => SocUploadFile)], viewQueries: [{ propertyName: "fileInput", first: true, predicate: ["fileInput"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: `
    <div (dragover)="onDragOver($event)" (dragleave)="dragging.set(false)" (drop)="onDrop($event)" [class]="zoneClass()">
      <svg lucideUploadCloud class="size-[var(--index-input-uploadfile-zone-icon-size)] text-[var(--index-input-uploadfile-zone-icon-color)]" [strokeWidth]="1.5"></svg>
      <p class="text-[length:var(--index-input-uploadfile-zone-text-size)] text-[var(--index-input-uploadfile-zone-text-color)] [font-family:var(--index-input-uploadfile-zone-text-font)] [font-weight:var(--index-input-uploadfile-zone-text-weight)]">
        Drag &amp; drop your files here
      </p>
      <p class="text-[length:var(--index-input-uploadfile-zone-text-size)] text-[var(--index-input-uploadfile-zone-separator-color)]">ou</p>
      <button socButton variant="tertiary" [disabled]="isDisabled()" (click)="fileInput.click()">Upload file</button>
      <input #fileInput type="file" [accept]="accept() ?? ''" [multiple]="multiple()" [disabled]="isDisabled()" class="hidden" (change)="onChange($event)" (blur)="onTouched()" />
    </div>
    @if (helperText()) {
      <p [class]="helperClass()">{{ helperText() }}</p>
    }
  `, isInline: true, dependencies: [{ kind: "component", type: SocButton, selector: "button[socButton]", inputs: ["variant", "size"] }, { kind: "component", type: LucideUploadCloud, selector: "svg[lucideCloudUpload], svg[lucideUploadCloud]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocUploadFile, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-upload-file',
                    standalone: true,
                    imports: [SocButton, LucideUploadCloud],
                    providers: [provideFormControl(() => SocUploadFile)],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: { class: 'flex w-full flex-col gap-2' },
                    template: `
    <div (dragover)="onDragOver($event)" (dragleave)="dragging.set(false)" (drop)="onDrop($event)" [class]="zoneClass()">
      <svg lucideUploadCloud class="size-[var(--index-input-uploadfile-zone-icon-size)] text-[var(--index-input-uploadfile-zone-icon-color)]" [strokeWidth]="1.5"></svg>
      <p class="text-[length:var(--index-input-uploadfile-zone-text-size)] text-[var(--index-input-uploadfile-zone-text-color)] [font-family:var(--index-input-uploadfile-zone-text-font)] [font-weight:var(--index-input-uploadfile-zone-text-weight)]">
        Drag &amp; drop your files here
      </p>
      <p class="text-[length:var(--index-input-uploadfile-zone-text-size)] text-[var(--index-input-uploadfile-zone-separator-color)]">ou</p>
      <button socButton variant="tertiary" [disabled]="isDisabled()" (click)="fileInput.click()">Upload file</button>
      <input #fileInput type="file" [accept]="accept() ?? ''" [multiple]="multiple()" [disabled]="isDisabled()" class="hidden" (change)="onChange($event)" (blur)="onTouched()" />
    </div>
    @if (helperText()) {
      <p [class]="helperClass()">{{ helperText() }}</p>
    }
  `,
                }]
        }] });

/**
 * Content-slot markers shared by the page templates (`PageList`, `PageDetails`, `PageForm`,
 * `PageProfile`, `PageHome`) — React's `ReactNode` props (`breadcrumb`, `badge`, `actions`, `tabs`, …)
 * become named `<ng-content>` slots, selected by these attributes. One set for all templates: the same
 * slot reads the same everywhere (`<soc-breadcrumb socPageBreadcrumb>`, `<div socPageActions>`), and
 * each template simply ignores the markers it has no slot for. The default (unnamed) slot is always
 * React's `children`.
 */
class SocPageBreadcrumb {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageBreadcrumb, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocPageBreadcrumb, isStandalone: true, selector: "[socPageBreadcrumb]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageBreadcrumb, decorators: [{
            type: Directive,
            args: [{ selector: '[socPageBreadcrumb]', standalone: true }]
        }] });
/** Secondary tab row above the page header (`PageList`) — typically a pill `soc-tabs`. */
class SocPageSecondaryTabs {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageSecondaryTabs, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocPageSecondaryTabs, isStandalone: true, selector: "[socPageSecondaryTabs]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageSecondaryTabs, decorators: [{
            type: Directive,
            args: [{ selector: '[socPageSecondaryTabs]', standalone: true }]
        }] });
/** Badge next to the title (`PageList`, `PageDetails`). */
class SocPageBadge {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageBadge, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocPageBadge, isStandalone: true, selector: "[socPageBadge]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageBadge, decorators: [{
            type: Directive,
            args: [{ selector: '[socPageBadge]', standalone: true }]
        }] });
/** Tag next to the title (`PageDetails`, `PageProfile`). */
class SocPageTag {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageTag, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocPageTag, isStandalone: true, selector: "[socPageTag]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageTag, decorators: [{
            type: Directive,
            args: [{ selector: '[socPageTag]', standalone: true }]
        }] });
/** Buttons rendered top-right of the header (`PageList`, `PageDetails`) or under the form (`PageForm`). */
class SocPageActions {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageActions, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocPageActions, isStandalone: true, selector: "[socPageActions]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageActions, decorators: [{
            type: Directive,
            args: [{ selector: '[socPageActions]', standalone: true }]
        }] });
/** Tab row below the header — typically a `soc-tabs`. */
class SocPageTabs {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageTabs, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocPageTabs, isStandalone: true, selector: "[socPageTabs]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageTabs, decorators: [{
            type: Directive,
            args: [{ selector: '[socPageTabs]', standalone: true }]
        }] });
/** Identity block (`PageProfile`) — typically a `soc-profile-line`. */
class SocPageHeader {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageHeader, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocPageHeader, isStandalone: true, selector: "[socPageHeader]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageHeader, decorators: [{
            type: Directive,
            args: [{ selector: '[socPageHeader]', standalone: true }]
        }] });
/** Stepper zone (`PageForm`). */
class SocPageStepper {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageStepper, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocPageStepper, isStandalone: true, selector: "[socPageStepper]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageStepper, decorators: [{
            type: Directive,
            args: [{ selector: '[socPageStepper]', standalone: true }]
        }] });
/** Message zone (`PageForm`, `PageProfile`) — typically a `soc-message`. */
class SocPageMessage {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageMessage, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocPageMessage, isStandalone: true, selector: "[socPageMessage]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageMessage, decorators: [{
            type: Directive,
            args: [{ selector: '[socPageMessage]', standalone: true }]
        }] });
/** Second content block with its own section title (`PageForm`). */
class SocPageSecondContent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageSecondContent, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocPageSecondContent, isStandalone: true, selector: "[socPageSecondContent]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageSecondContent, decorators: [{
            type: Directive,
            args: [{ selector: '[socPageSecondContent]', standalone: true }]
        }] });
/** Buttons next to the section title (`PageHome`). */
class SocPageSectionActions {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageSectionActions, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocPageSectionActions, isStandalone: true, selector: "[socPageSectionActions]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageSectionActions, decorators: [{
            type: Directive,
            args: [{ selector: '[socPageSectionActions]', standalone: true }]
        }] });

/** HeaderApp's `left` slot — typically a `soc-enterprise-select`. Never a fixed generic instance: its
 * content depends on the signed-in user/enterprise context, which only the consumer has. */
class SocAppShellHeaderLeft {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAppShellHeaderLeft, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocAppShellHeaderLeft, isStandalone: true, selector: "[socAppShellHeaderLeft]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAppShellHeaderLeft, decorators: [{
            type: Directive,
            args: [{ selector: '[socAppShellHeaderLeft]', standalone: true }]
        }] });
/** HeaderApp's `avatar` slot — typically a `soc-avatar` (size="md", mode="solid"). */
class SocAppShellHeaderAvatar {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAppShellHeaderAvatar, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocAppShellHeaderAvatar, isStandalone: true, selector: "[socAppShellHeaderAvatar]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAppShellHeaderAvatar, decorators: [{
            type: Directive,
            args: [{ selector: '[socAppShellHeaderAvatar]', standalone: true }]
        }] });
/** Advanced/custom escape hatch — full control over the avatar menu's content, for cases `user` +
 * `showViewProfile`/`showEditAvatar`/`(disconnect)` can't express. Wins over `user` if both are given. */
class SocAppShellHeaderAvatarMenu {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAppShellHeaderAvatarMenu, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocAppShellHeaderAvatarMenu, isStandalone: true, selector: "[socAppShellHeaderAvatarMenu]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAppShellHeaderAvatarMenu, decorators: [{
            type: Directive,
            args: [{ selector: '[socAppShellHeaderAvatarMenu]', standalone: true }]
        }] });
/** Advanced/custom escape hatch for the language control — same idea; wins over `languages`. */
class SocAppShellHeaderLanguageSelect {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAppShellHeaderLanguageSelect, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocAppShellHeaderLanguageSelect, isStandalone: true, selector: "[socAppShellHeaderLanguageSelect]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAppShellHeaderLanguageSelect, decorators: [{
            type: Directive,
            args: [{ selector: '[socAppShellHeaderLanguageSelect]', standalone: true }]
        }] });
/**
 * ## Rôle
 * Conteneur racine de toute page applicative du Design System: assemble AppSwitch, HeaderApp,
 * SideNavigation et la Content Zone dans une seule structure fixe, identique quel que soit le produit ou
 * l'écran. À utiliser systématiquement comme racine d'une page applicative (jamais deux imbriqués, jamais
 * pour un écran hors-application: connexion, erreur plein écran).
 *
 * ## Cas particuliers
 * - `product` pilote à la fois AppSwitch (icône sélectionnée) et SideNavigation (contenu du menu): les
 *   deux ne doivent jamais être synchronisés manuellement ni diverger.
 * - SideNavigation reste scrollable indépendamment de la Content Zone.
 * - Espacements internes verrouillés (tokens du DS): aucune surcharge `style`/`class`/gap/padding.
 *
 * ## Menu avatar et sélecteur de langue
 * Usage recommandé: `[user]="{ name, email, avatarLabel }"` + `(disconnect)` (+ `showViewProfile`/
 * `showEditAvatar`) et `[languages]` + `[(language)]` — AppShell construit et câble lui-même
 * `soc-avatar-menu`/`soc-language-select`. `socAppShellHeaderAvatarMenu`/`socAppShellHeaderLanguageSelect`
 * restent en secours pour un contenu totalement custom (ils gagnent si les deux sont fournis).
 *
 * ## Différences avec React (décisions signalées)
 * 1. `product`, `navSelectedId`, `navCollapsed`, `language` sont des `model()` (`[(product)]`…): AppShell
 *    suit le clic tout seul, là où React exige que le parent mette à jour `navSelectedId`/`navCollapsed`
 *    depuis `onNavSelect`/`onNavToggleCollapse` (sinon l'item actif ne bouge pas et le bouton de repli ne
 *    fait rien). Les sorties `productChange`/`navSelectedIdChange`/`navCollapsedChange`/`languageChange`
 *    jouent le rôle des callbacks React; le routage de la page affichée reste au consommateur.
 * 2. `onViewProfile`/`onEditAvatar` (leur présence affichait les boutons) -> `showViewProfile`/
 *    `showEditAvatar` + sorties (même décision que `soc-avatar-menu`).
 * 3. Slots `ReactNode` (`headerLeft`, `headerAvatar`, `headerAvatarMenu`, `headerLanguageSelect`) ->
 *    marqueurs `socAppShellHeader*`. Chacun est ré-exposé à HeaderApp via un wrapper `display: contents`
 *    déclaré ici: un `<ng-content>` transmis tel quel ne porterait pas les marqueurs de HeaderApp, et les
 *    requêtes de contenu de HeaderApp ne voient que les nœuds déclarés dans CE template.
 * 4. `children` = la page (`soc-page-list`/`details`/`form`/`profile`/`home`) dans la Content Zone.
 *
 * Maps 1:1 to "Index/Template/AppShell/*" tokens — see packages/tokens/tokens/components/template.json.
 */
class SocAppShell {
    /** Which app is active — drives AppSwitch's selected icon and SideNavigation's preset content at
     * once. AppShell has no meaningful "no product" state, so this is required. */
    product = model.required();
    /** Forwarded to HeaderApp's `userName` — rendered in its AvatarZone next to the avatar slot. */
    headerUserName = input.required();
    helpClick = output();
    notificationsClick = output();
    /** Signed-in user shown in the avatar menu — standard way to get a clickable avatar menu. */
    user = input();
    showViewProfile = input(false, { transform: booleanAttribute });
    showEditAvatar = input(false, { transform: booleanAttribute });
    viewProfile = output();
    editAvatar = output();
    disconnect = output();
    /** Standard way to get a language control next to the notification icon. */
    languages = input();
    language = model();
    /** Which item is highlighted within the product's preset menu. Kept in sync with the clicked item;
     * the consumer reacts to `navSelectedIdChange` to show the matching page. */
    navSelectedId = model();
    navCollapsed = model(false);
    customAvatarMenu = contentChild(SocAppShellHeaderAvatarMenu);
    customLanguageSelect = contentChild(SocAppShellHeaderLanguageSelect);
    hasCustomAvatarMenu = computed(() => !!this.customAvatarMenu());
    hasCustomLanguageSelect = computed(() => !!this.customLanguageSelect());
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAppShell, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocAppShell, isStandalone: true, selector: "soc-app-shell", inputs: { product: { classPropertyName: "product", publicName: "product", isSignal: true, isRequired: true, transformFunction: null }, headerUserName: { classPropertyName: "headerUserName", publicName: "headerUserName", isSignal: true, isRequired: true, transformFunction: null }, user: { classPropertyName: "user", publicName: "user", isSignal: true, isRequired: false, transformFunction: null }, showViewProfile: { classPropertyName: "showViewProfile", publicName: "showViewProfile", isSignal: true, isRequired: false, transformFunction: null }, showEditAvatar: { classPropertyName: "showEditAvatar", publicName: "showEditAvatar", isSignal: true, isRequired: false, transformFunction: null }, languages: { classPropertyName: "languages", publicName: "languages", isSignal: true, isRequired: false, transformFunction: null }, language: { classPropertyName: "language", publicName: "language", isSignal: true, isRequired: false, transformFunction: null }, navSelectedId: { classPropertyName: "navSelectedId", publicName: "navSelectedId", isSignal: true, isRequired: false, transformFunction: null }, navCollapsed: { classPropertyName: "navCollapsed", publicName: "navCollapsed", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { product: "productChange", helpClick: "helpClick", notificationsClick: "notificationsClick", viewProfile: "viewProfile", editAvatar: "editAvatar", disconnect: "disconnect", language: "languageChange", navSelectedId: "navSelectedIdChange", navCollapsed: "navCollapsedChange" }, host: { classAttribute: "flex h-screen w-full gap-0 bg-[var(--index-template-appshell-page-bg)]" }, queries: [{ propertyName: "customAvatarMenu", first: true, predicate: SocAppShellHeaderAvatarMenu, descendants: true, isSignal: true }, { propertyName: "customLanguageSelect", first: true, predicate: SocAppShellHeaderLanguageSelect, descendants: true, isSignal: true }], ngImport: i0, template: `
    <soc-app-switch [product]="product()" (select)="product.set($any($event))">
      <soc-switch-logo socAppSwitchLogo />
    </soc-app-switch>

    <div class="flex min-w-0 flex-1 flex-col gap-0">
      <soc-header-app [userName]="headerUserName()" (helpClick)="helpClick.emit()" (notificationsClick)="notificationsClick.emit()">
        <div socHeaderAppLeft class="contents"><ng-content select="[socAppShellHeaderLeft]" /></div>
        <div socHeaderAppAvatar class="contents"><ng-content select="[socAppShellHeaderAvatar]" /></div>
        @if (hasCustomLanguageSelect()) {
          <div socHeaderAppLanguageSelect class="contents"><ng-content select="[socAppShellHeaderLanguageSelect]" /></div>
        } @else if (languages()) {
          <soc-language-select socHeaderAppLanguageSelect [options]="languages()!" [(value)]="language" />
        }
        @if (hasCustomAvatarMenu()) {
          <div socHeaderAppAvatarMenu class="contents"><ng-content select="[socAppShellHeaderAvatarMenu]" /></div>
        } @else if (user()) {
          <soc-avatar-menu
            socHeaderAppAvatarMenu
            [userName]="user()!.name"
            [userEmail]="user()!.email"
            [avatarLabel]="user()!.avatarLabel"
            [showViewProfile]="showViewProfile()"
            [showEditAvatar]="showEditAvatar()"
            (viewProfile)="viewProfile.emit()"
            (editAvatar)="editAvatar.emit()"
            (disconnect)="disconnect.emit()"
          />
        }
      </soc-header-app>

      <div class="flex min-h-0 flex-1 gap-0">
        <soc-side-navigation
          [product]="product()"
          [selectedId]="navSelectedId()"
          (select)="navSelectedId.set($event)"
          [collapsed]="navCollapsed()"
          (toggleCollapse)="navCollapsed.set(!navCollapsed())"
        />

        <div class="scrollbar-hide min-w-0 flex-1 overflow-y-auto pl-[var(--index-template-appshell-content-zone-pad-left)]">
          <ng-content />
        </div>
      </div>
    </div>
  `, isInline: true, dependencies: [{ kind: "component", type: SocAppSwitch, selector: "soc-app-switch", inputs: ["product", "items", "selectedId"], outputs: ["select"] }, { kind: "directive", type: SocAppSwitchLogo, selector: "[socAppSwitchLogo]" }, { kind: "component", type: SocSwitchLogo, selector: "soc-switch-logo" }, { kind: "component", type: SocHeaderApp, selector: "soc-header-app", inputs: ["userName"], outputs: ["helpClick", "notificationsClick"] }, { kind: "directive", type: SocHeaderAppLeft, selector: "[socHeaderAppLeft]" }, { kind: "directive", type: SocHeaderAppAvatar, selector: "[socHeaderAppAvatar]" }, { kind: "directive", type: SocHeaderAppAvatarMenu, selector: "[socHeaderAppAvatarMenu]" }, { kind: "directive", type: SocHeaderAppLanguageSelect, selector: "[socHeaderAppLanguageSelect]" }, { kind: "component", type: SocAvatarMenu, selector: "soc-avatar-menu", inputs: ["userName", "userEmail", "avatarLabel", "showViewProfile", "showEditAvatar"], outputs: ["viewProfile", "editAvatar", "disconnect"] }, { kind: "component", type: SocLanguageSelect, selector: "soc-language-select", inputs: ["options", "value", "defaultValue", "triggerClass"], outputs: ["valueChange"] }, { kind: "component", type: SocSideNavigation, selector: "soc-side-navigation", inputs: ["product", "title", "sections", "actionSection", "selectedId", "collapsed"], outputs: ["select", "toggleCollapse"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocAppShell, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-app-shell',
                    standalone: true,
                    imports: [
                        SocAppSwitch,
                        SocAppSwitchLogo,
                        SocSwitchLogo,
                        SocHeaderApp,
                        SocHeaderAppLeft,
                        SocHeaderAppAvatar,
                        SocHeaderAppAvatarMenu,
                        SocHeaderAppLanguageSelect,
                        SocAvatarMenu,
                        SocLanguageSelect,
                        SocSideNavigation,
                    ],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: { class: 'flex h-screen w-full gap-0 bg-[var(--index-template-appshell-page-bg)]' },
                    template: `
    <soc-app-switch [product]="product()" (select)="product.set($any($event))">
      <soc-switch-logo socAppSwitchLogo />
    </soc-app-switch>

    <div class="flex min-w-0 flex-1 flex-col gap-0">
      <soc-header-app [userName]="headerUserName()" (helpClick)="helpClick.emit()" (notificationsClick)="notificationsClick.emit()">
        <div socHeaderAppLeft class="contents"><ng-content select="[socAppShellHeaderLeft]" /></div>
        <div socHeaderAppAvatar class="contents"><ng-content select="[socAppShellHeaderAvatar]" /></div>
        @if (hasCustomLanguageSelect()) {
          <div socHeaderAppLanguageSelect class="contents"><ng-content select="[socAppShellHeaderLanguageSelect]" /></div>
        } @else if (languages()) {
          <soc-language-select socHeaderAppLanguageSelect [options]="languages()!" [(value)]="language" />
        }
        @if (hasCustomAvatarMenu()) {
          <div socHeaderAppAvatarMenu class="contents"><ng-content select="[socAppShellHeaderAvatarMenu]" /></div>
        } @else if (user()) {
          <soc-avatar-menu
            socHeaderAppAvatarMenu
            [userName]="user()!.name"
            [userEmail]="user()!.email"
            [avatarLabel]="user()!.avatarLabel"
            [showViewProfile]="showViewProfile()"
            [showEditAvatar]="showEditAvatar()"
            (viewProfile)="viewProfile.emit()"
            (editAvatar)="editAvatar.emit()"
            (disconnect)="disconnect.emit()"
          />
        }
      </soc-header-app>

      <div class="flex min-h-0 flex-1 gap-0">
        <soc-side-navigation
          [product]="product()"
          [selectedId]="navSelectedId()"
          (select)="navSelectedId.set($event)"
          [collapsed]="navCollapsed()"
          (toggleCollapse)="navCollapsed.set(!navCollapsed())"
        />

        <div class="scrollbar-hide min-w-0 flex-1 overflow-y-auto pl-[var(--index-template-appshell-content-zone-pad-left)]">
          <ng-content />
        </div>
      </div>
    </div>
  `,
                }]
        }] });

/**
 * ## Rôle
 * Présenter en lecture les informations complètes d'un seul objet métier (non-personne), organisées en
 * sections, avec des actions contextuelles (modifier, supprimer, valider…). Pour une personne →
 * `soc-page-profile`; créer/modifier → `soc-page-form`; une liste → `soc-page-list`.
 *
 * ## Contraintes de composition (inchangées par rapport à React)
 * - Seul le Breadcrumb a son propre padding vertical; l'espacement entre zones vient du `content-gap`
 *   du conteneur scrollable. Padding-bottom fixe de 120px non exposé. Aucune surcharge de style.
 * - Les boutons de `socPageActions` sont toujours en variante `tertiary`, icône seule (`aria-label`),
 *   chacun enveloppé dans `<soc-tooltip>` (même texte) pour que son nom soit visible au survol — c'est
 *   au consommateur de le faire, `socPageActions` est un slot libre.
 *
 * `onBack` (React: sa présence affiche le bouton "Retour") -> `showBack` + sortie `back`, même décision
 * que partout dans le kit (un `output()` ne peut pas dire s'il a un abonné). Slots: `socPageBreadcrumb`,
 * `socPageBadge`, `socPageTag`, `socPageActions`, `socPageTabs`; contenu par défaut = `children`, empilé
 * avec un gap constant.
 *
 * Maps 1:1 to "Index/Template/PageDetails/*" tokens — see packages/tokens/tokens/components/template.json.
 */
class SocPageDetails {
    showBack = input(false, { transform: booleanAttribute });
    backLabel = input('Retour');
    /** Small label above the title. */
    topStatusLabel = input();
    title = input.required();
    statusLabel = input();
    description = input();
    back = output();
    actionsContent = contentChild(SocPageActions);
    tabsContent = contentChild(SocPageTabs);
    hasActions = computed(() => !!this.actionsContent());
    hasTabs = computed(() => !!this.tabsContent());
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageDetails, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocPageDetails, isStandalone: true, selector: "soc-page-details", inputs: { showBack: { classPropertyName: "showBack", publicName: "showBack", isSignal: true, isRequired: false, transformFunction: null }, backLabel: { classPropertyName: "backLabel", publicName: "backLabel", isSignal: true, isRequired: false, transformFunction: null }, topStatusLabel: { classPropertyName: "topStatusLabel", publicName: "topStatusLabel", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, statusLabel: { classPropertyName: "statusLabel", publicName: "statusLabel", isSignal: true, isRequired: false, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { back: "back" }, host: { classAttribute: "flex size-full flex-col items-start" }, queries: [{ propertyName: "actionsContent", first: true, predicate: SocPageActions, descendants: true, isSignal: true }, { propertyName: "tabsContent", first: true, predicate: SocPageTabs, descendants: true, isSignal: true }], ngImport: i0, template: `
    <div class="flex w-full min-h-px flex-[1_0_0] flex-col items-center overflow-clip rounded-tl-[var(--bridges-shape-figure-radius-xl)] bg-[var(--index-template-pagedetails-fourth-bg)]">
      <div class="w-full shrink-0 px-[var(--index-template-pagedetails-breadcrumb-pad-h)] py-[var(--index-template-pagedetails-breadcrumb-pad-v)]">
        <ng-content select="[socPageBreadcrumb]" />
      </div>

      <div class="scrollbar-hide flex w-full min-h-0 flex-1 flex-col gap-[var(--index-template-pagedetails-content-gap)] overflow-y-auto pb-[120px]">
        @if (showBack()) {
          <div class="pl-[var(--index-template-pagedetails-back-zone-pad-left)] pr-[var(--index-template-pagedetails-back-zone-pad-right)]">
            <button socButton variant="secondary" (click)="back.emit()">
              <svg lucideArrowLeft socButtonLeftIcon class="size-full" [strokeWidth]="1.5"></svg>
              {{ backLabel() }}
            </button>
          </div>
        }

        <div class="flex w-full items-start justify-between px-[var(--index-template-pagedetails-pageheader-pad-h)]">
          <div class="flex min-w-0 flex-col gap-[var(--index-template-pagedetails-title-block-gap)]">
            @if (topStatusLabel()) {
              <span class="text-[length:var(--index-template-pagedetails-status-label-size)] text-[var(--index-template-pagedetails-status-label-color)] [font-family:var(--index-template-pagedetails-status-label-font)] [font-weight:var(--index-template-pagedetails-status-label-weight)]">
                {{ topStatusLabel() }}
              </span>
            }
            <div class="flex items-center gap-[var(--index-template-pagedetails-title-row-gap)]">
              <h1 class="text-[length:var(--index-template-pagedetails-page-title-size)] text-[var(--index-template-pagedetails-page-title-color)] [font-family:var(--index-template-pagedetails-page-title-font)] [font-weight:var(--index-template-pagedetails-page-title-weight)]">
                {{ title() }}
              </h1>
              <ng-content select="[socPageBadge]" />
              <ng-content select="[socPageTag]" />
              @if (statusLabel()) {
                <span class="text-[length:var(--index-template-pagedetails-status-label-size)] text-[var(--index-template-pagedetails-status-label-color)] [font-family:var(--index-template-pagedetails-status-label-font)] [font-weight:var(--index-template-pagedetails-status-label-weight)]">
                  {{ statusLabel() }}
                </span>
              }
            </div>
            @if (description()) {
              <p class="text-[length:var(--index-template-pagedetails-page-description-size)] text-[var(--index-template-pagedetails-page-description-color)] [font-family:var(--index-template-pagedetails-page-description-font)] [font-weight:var(--index-template-pagedetails-page-description-weight)]">
                {{ description() }}
              </p>
            }
          </div>
          @if (hasActions()) {
            <div class="flex shrink-0 gap-[var(--index-template-pagedetails-actions-gap)] pt-[var(--index-template-pagedetails-actions-pad-top)]">
              <ng-content select="[socPageActions]" />
            </div>
          }
        </div>

        <div class="h-px w-full bg-[var(--bridges-color-border-subtle)]"></div>

        @if (hasTabs()) {
          <div class="w-full px-[var(--index-template-pagedetails-pageheader-pad-h)]">
            <ng-content select="[socPageTabs]" />
          </div>
        }

        <div class="flex w-full flex-col gap-[var(--index-template-pagedetails-content-gap)] px-[var(--index-template-pagedetails-pageheader-pad-h)]">
          <ng-content />
        </div>
      </div>
    </div>
  `, isInline: true, dependencies: [{ kind: "component", type: SocButton, selector: "button[socButton]", inputs: ["variant", "size"] }, { kind: "directive", type: SocButtonLeftIcon, selector: "[socButtonLeftIcon]" }, { kind: "component", type: LucideArrowLeft, selector: "svg[lucideArrowLeft]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageDetails, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-page-details',
                    standalone: true,
                    imports: [SocButton, SocButtonLeftIcon, LucideArrowLeft],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: { class: 'flex size-full flex-col items-start' },
                    template: `
    <div class="flex w-full min-h-px flex-[1_0_0] flex-col items-center overflow-clip rounded-tl-[var(--bridges-shape-figure-radius-xl)] bg-[var(--index-template-pagedetails-fourth-bg)]">
      <div class="w-full shrink-0 px-[var(--index-template-pagedetails-breadcrumb-pad-h)] py-[var(--index-template-pagedetails-breadcrumb-pad-v)]">
        <ng-content select="[socPageBreadcrumb]" />
      </div>

      <div class="scrollbar-hide flex w-full min-h-0 flex-1 flex-col gap-[var(--index-template-pagedetails-content-gap)] overflow-y-auto pb-[120px]">
        @if (showBack()) {
          <div class="pl-[var(--index-template-pagedetails-back-zone-pad-left)] pr-[var(--index-template-pagedetails-back-zone-pad-right)]">
            <button socButton variant="secondary" (click)="back.emit()">
              <svg lucideArrowLeft socButtonLeftIcon class="size-full" [strokeWidth]="1.5"></svg>
              {{ backLabel() }}
            </button>
          </div>
        }

        <div class="flex w-full items-start justify-between px-[var(--index-template-pagedetails-pageheader-pad-h)]">
          <div class="flex min-w-0 flex-col gap-[var(--index-template-pagedetails-title-block-gap)]">
            @if (topStatusLabel()) {
              <span class="text-[length:var(--index-template-pagedetails-status-label-size)] text-[var(--index-template-pagedetails-status-label-color)] [font-family:var(--index-template-pagedetails-status-label-font)] [font-weight:var(--index-template-pagedetails-status-label-weight)]">
                {{ topStatusLabel() }}
              </span>
            }
            <div class="flex items-center gap-[var(--index-template-pagedetails-title-row-gap)]">
              <h1 class="text-[length:var(--index-template-pagedetails-page-title-size)] text-[var(--index-template-pagedetails-page-title-color)] [font-family:var(--index-template-pagedetails-page-title-font)] [font-weight:var(--index-template-pagedetails-page-title-weight)]">
                {{ title() }}
              </h1>
              <ng-content select="[socPageBadge]" />
              <ng-content select="[socPageTag]" />
              @if (statusLabel()) {
                <span class="text-[length:var(--index-template-pagedetails-status-label-size)] text-[var(--index-template-pagedetails-status-label-color)] [font-family:var(--index-template-pagedetails-status-label-font)] [font-weight:var(--index-template-pagedetails-status-label-weight)]">
                  {{ statusLabel() }}
                </span>
              }
            </div>
            @if (description()) {
              <p class="text-[length:var(--index-template-pagedetails-page-description-size)] text-[var(--index-template-pagedetails-page-description-color)] [font-family:var(--index-template-pagedetails-page-description-font)] [font-weight:var(--index-template-pagedetails-page-description-weight)]">
                {{ description() }}
              </p>
            }
          </div>
          @if (hasActions()) {
            <div class="flex shrink-0 gap-[var(--index-template-pagedetails-actions-gap)] pt-[var(--index-template-pagedetails-actions-pad-top)]">
              <ng-content select="[socPageActions]" />
            </div>
          }
        </div>

        <div class="h-px w-full bg-[var(--bridges-color-border-subtle)]"></div>

        @if (hasTabs()) {
          <div class="w-full px-[var(--index-template-pagedetails-pageheader-pad-h)]">
            <ng-content select="[socPageTabs]" />
          </div>
        }

        <div class="flex w-full flex-col gap-[var(--index-template-pagedetails-content-gap)] px-[var(--index-template-pagedetails-pageheader-pad-h)]">
          <ng-content />
        </div>
      </div>
    </div>
  `,
                }]
        }] });

/**
 * Page de création/modification d'un objet: titre, stepper et message optionnels, une section de
 * formulaire (`children`, colonne de 595px) avec ses actions alignées à droite, puis un second bloc
 * optionnel (`socPageSecondContent`) avec son propre titre de section.
 *
 * `onBack` -> `showBack` + sortie `back` (voir `soc-page-details`). Slots: `socPageBreadcrumb`,
 * `socPageStepper`, `socPageMessage`, `socPageActions`, `socPageSecondContent`. Padding-bottom fixe de
 * 120px, comme `soc-page-list`. Les champs placés dans le slot par défaut sont typiquement des
 * `soc-input-text`… liés à un `FormGroup` (voir Guides/Formulaires).
 *
 * Maps 1:1 to "Index/Template/PageForm/*" tokens — see packages/tokens/tokens/components/template.json
 * in design_system (React reference repo, read only).
 */
class SocPageForm {
    showBack = input(false, { transform: booleanAttribute });
    backLabel = input('Retour');
    title = input.required();
    description = input();
    sectionTitle = input();
    sectionSubtitle = input();
    secondSectionTitle = input();
    secondSectionSubtitle = input();
    back = output();
    stepperContent = contentChild(SocPageStepper);
    messageContent = contentChild(SocPageMessage);
    actionsContent = contentChild(SocPageActions);
    secondContent = contentChild(SocPageSecondContent);
    hasStepper = computed(() => !!this.stepperContent());
    hasMessage = computed(() => !!this.messageContent());
    hasActions = computed(() => !!this.actionsContent());
    hasSecondContent = computed(() => !!this.secondContent());
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageForm, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocPageForm, isStandalone: true, selector: "soc-page-form", inputs: { showBack: { classPropertyName: "showBack", publicName: "showBack", isSignal: true, isRequired: false, transformFunction: null }, backLabel: { classPropertyName: "backLabel", publicName: "backLabel", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null }, sectionTitle: { classPropertyName: "sectionTitle", publicName: "sectionTitle", isSignal: true, isRequired: false, transformFunction: null }, sectionSubtitle: { classPropertyName: "sectionSubtitle", publicName: "sectionSubtitle", isSignal: true, isRequired: false, transformFunction: null }, secondSectionTitle: { classPropertyName: "secondSectionTitle", publicName: "secondSectionTitle", isSignal: true, isRequired: false, transformFunction: null }, secondSectionSubtitle: { classPropertyName: "secondSectionSubtitle", publicName: "secondSectionSubtitle", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { back: "back" }, host: { classAttribute: "flex size-full flex-col items-start" }, queries: [{ propertyName: "stepperContent", first: true, predicate: SocPageStepper, descendants: true, isSignal: true }, { propertyName: "messageContent", first: true, predicate: SocPageMessage, descendants: true, isSignal: true }, { propertyName: "actionsContent", first: true, predicate: SocPageActions, descendants: true, isSignal: true }, { propertyName: "secondContent", first: true, predicate: SocPageSecondContent, descendants: true, isSignal: true }], ngImport: i0, template: `
    <div class="flex w-full min-h-px flex-[1_0_0] flex-col items-center overflow-clip rounded-tl-[var(--bridges-shape-figure-radius-xl)] bg-[var(--index-template-pageform-fourth-bg)]">
      <div class="w-full shrink-0 px-[var(--index-template-pageform-breadcrumb-pad-h)] py-[var(--index-template-pageform-breadcrumb-pad-v)]">
        <ng-content select="[socPageBreadcrumb]" />
      </div>

      <div class="scrollbar-hide flex w-full min-h-0 flex-1 flex-col gap-[var(--index-template-pageform-content-gap)] overflow-y-auto pb-[120px]">
        @if (showBack()) {
          <div class="pl-[var(--index-template-pageform-back-zone-pad-left)] pr-[var(--index-template-pageform-back-zone-pad-right)]">
            <button socButton variant="secondary" (click)="back.emit()">
              <svg lucideArrowLeft socButtonLeftIcon class="size-full" [strokeWidth]="1.5"></svg>
              {{ backLabel() }}
            </button>
          </div>
        }

        <div class="flex w-full flex-col gap-[var(--index-template-pageform-title-block-gap)] px-[var(--index-template-pageform-pageheader-pad-h)]">
          <h1 class="text-[length:var(--index-template-pageform-page-title-size)] text-[var(--index-template-pageform-page-title-color)] [font-family:var(--index-template-pageform-page-title-font)] [font-weight:var(--index-template-pageform-page-title-weight)]">
            {{ title() }}
          </h1>
          @if (description()) {
            <p class="text-[length:var(--index-template-pageform-page-description-size)] text-[var(--index-template-pageform-page-description-color)] [font-family:var(--index-template-pageform-page-description-font)] [font-weight:var(--index-template-pageform-page-description-weight)]">
              {{ description() }}
            </p>
          }
        </div>

        <div class="h-px w-full bg-[var(--bridges-color-border-subtle)]"></div>

        @if (hasStepper()) {
          <div class="w-full px-[var(--index-template-pageform-stepper-zone-pad-h)]">
            <ng-content select="[socPageStepper]" />
          </div>
        }

        @if (hasMessage()) {
          <div class="w-full px-[var(--index-template-pageform-message-zone-pad-h)]">
            <ng-content select="[socPageMessage]" />
          </div>
        }

        <div class="flex w-full flex-col gap-[var(--index-template-pageform-section-zone-gap)] px-[var(--index-template-pageform-section-zone-pad-h)]">
          @if (sectionTitle() || sectionSubtitle()) {
            <div class="flex flex-col gap-[var(--index-template-pageform-titlesection-gap)]">
              @if (sectionTitle()) {
                <p class="text-[length:var(--index-template-pageform-section-title-size)] text-[var(--index-template-pageform-section-title-color)] [font-family:var(--index-template-pageform-section-title-font)] [font-weight:var(--index-template-pageform-section-title-weight)]">
                  {{ sectionTitle() }}
                </p>
              }
              @if (sectionSubtitle()) {
                <p class="text-[length:var(--index-template-pageform-section-subtitle-size)] text-[var(--index-template-pageform-section-subtitle-color)] [font-family:var(--index-template-pageform-section-subtitle-font)] [font-weight:var(--index-template-pageform-section-subtitle-weight)]">
                  {{ sectionSubtitle() }}
                </p>
              }
            </div>
          }
          <!-- The form column hugs its own width (595px, from the field slot) rather than stretching
               full-width — its left edge lines up with the section title above, but the actions are
               right-aligned within that same 595px column, flush with its right edge (Figma form_zone,
               items-end). -->
          <div class="flex w-fit flex-col items-end gap-[var(--index-template-pageform-form-zone-gap)]">
            <div class="flex w-[595px] max-w-full flex-col gap-[var(--bridges-position-gap-md)]">
              <ng-content />
            </div>
            @if (hasActions()) {
              <div class="flex items-center gap-[var(--index-template-pageform-actions-gap)] pt-[var(--index-template-pageform-actions-pad-top)]">
                <ng-content select="[socPageActions]" />
              </div>
            }
          </div>
        </div>

        @if (hasSecondContent()) {
          <div class="flex w-full flex-col gap-[var(--index-template-pageform-section-zone-gap)] px-[var(--index-template-pageform-section-zone-pad-h)]">
            @if (secondSectionTitle() || secondSectionSubtitle()) {
              <div class="flex flex-col gap-[var(--index-template-pageform-titlesection-gap)]">
                @if (secondSectionTitle()) {
                  <p class="text-[length:var(--index-template-pageform-section-title-size)] text-[var(--index-template-pageform-section-title-color)] [font-family:var(--index-template-pageform-section-title-font)] [font-weight:var(--index-template-pageform-section-title-weight)]">
                    {{ secondSectionTitle() }}
                  </p>
                }
                @if (secondSectionSubtitle()) {
                  <p class="text-[length:var(--index-template-pageform-section-subtitle-size)] text-[var(--index-template-pageform-section-subtitle-color)] [font-family:var(--index-template-pageform-section-subtitle-font)] [font-weight:var(--index-template-pageform-section-subtitle-weight)]">
                    {{ secondSectionSubtitle() }}
                  </p>
                }
              </div>
            }
            <div class="w-full">
              <ng-content select="[socPageSecondContent]" />
            </div>
          </div>
        }
      </div>
    </div>
  `, isInline: true, dependencies: [{ kind: "component", type: SocButton, selector: "button[socButton]", inputs: ["variant", "size"] }, { kind: "directive", type: SocButtonLeftIcon, selector: "[socButtonLeftIcon]" }, { kind: "component", type: LucideArrowLeft, selector: "svg[lucideArrowLeft]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageForm, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-page-form',
                    standalone: true,
                    imports: [SocButton, SocButtonLeftIcon, LucideArrowLeft],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: { class: 'flex size-full flex-col items-start' },
                    template: `
    <div class="flex w-full min-h-px flex-[1_0_0] flex-col items-center overflow-clip rounded-tl-[var(--bridges-shape-figure-radius-xl)] bg-[var(--index-template-pageform-fourth-bg)]">
      <div class="w-full shrink-0 px-[var(--index-template-pageform-breadcrumb-pad-h)] py-[var(--index-template-pageform-breadcrumb-pad-v)]">
        <ng-content select="[socPageBreadcrumb]" />
      </div>

      <div class="scrollbar-hide flex w-full min-h-0 flex-1 flex-col gap-[var(--index-template-pageform-content-gap)] overflow-y-auto pb-[120px]">
        @if (showBack()) {
          <div class="pl-[var(--index-template-pageform-back-zone-pad-left)] pr-[var(--index-template-pageform-back-zone-pad-right)]">
            <button socButton variant="secondary" (click)="back.emit()">
              <svg lucideArrowLeft socButtonLeftIcon class="size-full" [strokeWidth]="1.5"></svg>
              {{ backLabel() }}
            </button>
          </div>
        }

        <div class="flex w-full flex-col gap-[var(--index-template-pageform-title-block-gap)] px-[var(--index-template-pageform-pageheader-pad-h)]">
          <h1 class="text-[length:var(--index-template-pageform-page-title-size)] text-[var(--index-template-pageform-page-title-color)] [font-family:var(--index-template-pageform-page-title-font)] [font-weight:var(--index-template-pageform-page-title-weight)]">
            {{ title() }}
          </h1>
          @if (description()) {
            <p class="text-[length:var(--index-template-pageform-page-description-size)] text-[var(--index-template-pageform-page-description-color)] [font-family:var(--index-template-pageform-page-description-font)] [font-weight:var(--index-template-pageform-page-description-weight)]">
              {{ description() }}
            </p>
          }
        </div>

        <div class="h-px w-full bg-[var(--bridges-color-border-subtle)]"></div>

        @if (hasStepper()) {
          <div class="w-full px-[var(--index-template-pageform-stepper-zone-pad-h)]">
            <ng-content select="[socPageStepper]" />
          </div>
        }

        @if (hasMessage()) {
          <div class="w-full px-[var(--index-template-pageform-message-zone-pad-h)]">
            <ng-content select="[socPageMessage]" />
          </div>
        }

        <div class="flex w-full flex-col gap-[var(--index-template-pageform-section-zone-gap)] px-[var(--index-template-pageform-section-zone-pad-h)]">
          @if (sectionTitle() || sectionSubtitle()) {
            <div class="flex flex-col gap-[var(--index-template-pageform-titlesection-gap)]">
              @if (sectionTitle()) {
                <p class="text-[length:var(--index-template-pageform-section-title-size)] text-[var(--index-template-pageform-section-title-color)] [font-family:var(--index-template-pageform-section-title-font)] [font-weight:var(--index-template-pageform-section-title-weight)]">
                  {{ sectionTitle() }}
                </p>
              }
              @if (sectionSubtitle()) {
                <p class="text-[length:var(--index-template-pageform-section-subtitle-size)] text-[var(--index-template-pageform-section-subtitle-color)] [font-family:var(--index-template-pageform-section-subtitle-font)] [font-weight:var(--index-template-pageform-section-subtitle-weight)]">
                  {{ sectionSubtitle() }}
                </p>
              }
            </div>
          }
          <!-- The form column hugs its own width (595px, from the field slot) rather than stretching
               full-width — its left edge lines up with the section title above, but the actions are
               right-aligned within that same 595px column, flush with its right edge (Figma form_zone,
               items-end). -->
          <div class="flex w-fit flex-col items-end gap-[var(--index-template-pageform-form-zone-gap)]">
            <div class="flex w-[595px] max-w-full flex-col gap-[var(--bridges-position-gap-md)]">
              <ng-content />
            </div>
            @if (hasActions()) {
              <div class="flex items-center gap-[var(--index-template-pageform-actions-gap)] pt-[var(--index-template-pageform-actions-pad-top)]">
                <ng-content select="[socPageActions]" />
              </div>
            }
          </div>
        </div>

        @if (hasSecondContent()) {
          <div class="flex w-full flex-col gap-[var(--index-template-pageform-section-zone-gap)] px-[var(--index-template-pageform-section-zone-pad-h)]">
            @if (secondSectionTitle() || secondSectionSubtitle()) {
              <div class="flex flex-col gap-[var(--index-template-pageform-titlesection-gap)]">
                @if (secondSectionTitle()) {
                  <p class="text-[length:var(--index-template-pageform-section-title-size)] text-[var(--index-template-pageform-section-title-color)] [font-family:var(--index-template-pageform-section-title-font)] [font-weight:var(--index-template-pageform-section-title-weight)]">
                    {{ secondSectionTitle() }}
                  </p>
                }
                @if (secondSectionSubtitle()) {
                  <p class="text-[length:var(--index-template-pageform-section-subtitle-size)] text-[var(--index-template-pageform-section-subtitle-color)] [font-family:var(--index-template-pageform-section-subtitle-font)] [font-weight:var(--index-template-pageform-section-subtitle-weight)]">
                    {{ secondSectionSubtitle() }}
                  </p>
                }
              </div>
            }
            <div class="w-full">
              <ng-content select="[socPageSecondContent]" />
            </div>
          </div>
        }
      </div>
    </div>
  `,
                }]
        }] });

/**
 * ## Rôle
 * Page d'accueil d'un produit Socium: bannière de bienvenue personnalisée, recherche globale, puis une
 * section de contenu libre (`children`: grille de `soc-card`, `soc-data-table`, raccourcis…).
 * Pour une liste → `soc-page-list`; un détail/profil → `soc-page-details`/`soc-page-profile`.
 *
 * ## Contraintes de composition
 * Comme `soc-page-list`: seul le Breadcrumb a son propre padding vertical, le reste tire son espacement
 * du `content-gap` du conteneur scrollable. `welcome-pad-h`/`search-pad-h`/`section-pad-h` sont trois
 * tokens distincts (24px chacun aujourd'hui) pour pouvoir diverger si Figma les sépare un jour.
 *
 * - La bannière (fond + label + description) ne s'affiche que si `welcomeTitle` est donné.
 * - `onSearch` (sa présence affiche la recherche) -> `searchable` + sortie `search` (texte brut à chaque
 *   frappe, présentationnel: ne filtre rien lui-même) — même décision que `DataTable`.
 * - `sectionActions` -> slot `socPageSectionActions`, affiché seulement avec `sectionTitle` (comme Figma).
 * - Slot `socPageBreadcrumb`; padding-bottom fixe de 120px non exposé.
 *
 * Le fond de la bannière est `.pagehome-welcome-bg` (`styles/images.css`, JPEG embarqué).
 * Maps 1:1 to "Index/Template/PageHome/*" tokens — see packages/tokens/tokens/components/template.json.
 */
class SocPageHome {
    /** Small label above the welcome title (Figma: "Accueil"). */
    welcomeLabel = input();
    /** The banner's headline, e.g. "Bienvenue {name}" — its presence shows/hides the whole banner. */
    welcomeTitle = input();
    welcomeDescription = input();
    searchable = input(false, { transform: booleanAttribute });
    search = output();
    sectionTitle = input();
    sectionSubtitle = input();
    sectionActionsContent = contentChild(SocPageSectionActions);
    hasSectionActions = computed(() => !!this.sectionActionsContent());
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageHome, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocPageHome, isStandalone: true, selector: "soc-page-home", inputs: { welcomeLabel: { classPropertyName: "welcomeLabel", publicName: "welcomeLabel", isSignal: true, isRequired: false, transformFunction: null }, welcomeTitle: { classPropertyName: "welcomeTitle", publicName: "welcomeTitle", isSignal: true, isRequired: false, transformFunction: null }, welcomeDescription: { classPropertyName: "welcomeDescription", publicName: "welcomeDescription", isSignal: true, isRequired: false, transformFunction: null }, searchable: { classPropertyName: "searchable", publicName: "searchable", isSignal: true, isRequired: false, transformFunction: null }, sectionTitle: { classPropertyName: "sectionTitle", publicName: "sectionTitle", isSignal: true, isRequired: false, transformFunction: null }, sectionSubtitle: { classPropertyName: "sectionSubtitle", publicName: "sectionSubtitle", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { search: "search" }, host: { classAttribute: "flex size-full flex-col items-start" }, queries: [{ propertyName: "sectionActionsContent", first: true, predicate: SocPageSectionActions, descendants: true, isSignal: true }], ngImport: i0, template: `
    <div class="flex w-full min-h-px flex-[1_0_0] flex-col items-center overflow-clip rounded-tl-[var(--bridges-shape-figure-radius-xl)] bg-[var(--index-template-pagehome-fourth-bg)]">
      <div class="w-full shrink-0 px-[var(--index-template-pagehome-breadcrumb-pad-h)] py-[var(--index-template-pagehome-breadcrumb-pad-v)]">
        <ng-content select="[socPageBreadcrumb]" />
      </div>

      <div class="scrollbar-hide flex w-full min-h-0 flex-1 flex-col gap-[var(--index-template-pagehome-content-gap)] overflow-y-auto pb-[120px]">
        @if (welcomeTitle()) {
          <div class="w-full px-[var(--index-template-pagehome-welcome-pad-h)]">
            <div class="relative flex w-full flex-col items-start overflow-hidden rounded-[3px] px-[12px] pt-[10px] pb-[16px]">
              <div class="pagehome-welcome-bg pointer-events-none absolute inset-0 size-full bg-cover bg-center"></div>
              <div class="relative flex w-full max-w-[559px] flex-col items-start gap-[7px]">
                @if (welcomeLabel()) {
                  <p class="whitespace-nowrap text-[length:var(--index-template-pagehome-welcome-label-size)] leading-none text-[var(--index-template-pagehome-welcome-label-color)] [font-family:var(--index-template-pagehome-welcome-label-font)] [font-weight:var(--index-template-pagehome-welcome-label-weight)]">
                    {{ welcomeLabel() }}
                  </p>
                }
                <p class="whitespace-nowrap text-[length:var(--index-template-pagehome-welcome-title-size)] leading-[1.2] tracking-[-0.32px] text-[var(--index-template-pagehome-welcome-title-color)] [font-family:var(--index-template-pagehome-welcome-title-font)] [font-weight:var(--index-template-pagehome-welcome-title-weight)]">
                  {{ welcomeTitle() }}
                </p>
                @if (welcomeDescription()) {
                  <p class="w-full text-[length:14px] leading-[1.4] font-semibold text-[var(--index-template-pagehome-welcome-description-color)]">
                    {{ welcomeDescription() }}
                  </p>
                }
              </div>
            </div>
          </div>
        }

        @if (searchable()) {
          <div class="w-full px-[var(--index-template-pagehome-search-pad-h)]">
            <soc-search-bar placeholder="Rechercher ici" (valueChange)="search.emit($event)" class="w-[320px] h-[var(--index-template-pagehome-search-height)]" />
          </div>
        }

        <div class="flex w-full flex-1 flex-col gap-[var(--index-template-pagehome-content-section-gap)] px-[var(--index-template-pagehome-section-pad-h)]">
          @if (sectionTitle()) {
            <div class="flex w-full items-start gap-[var(--index-template-pagehome-section-title-gap)]">
              <div class="flex min-w-0 flex-1 flex-col gap-[var(--index-template-pagehome-section-title-gap)]">
                <p class="w-full text-[length:var(--index-template-pagehome-section-title-size)] text-[var(--index-template-pagehome-section-title-color)] [font-family:var(--index-template-pagehome-section-title-font)] [font-weight:var(--index-template-pagehome-section-title-weight)]">
                  {{ sectionTitle() }}
                </p>
                @if (sectionSubtitle()) {
                  <p class="w-full text-[length:var(--index-template-pagehome-section-subtitle-size)] text-[var(--index-template-pagehome-section-subtitle-color)] [font-family:var(--index-template-pagehome-section-subtitle-font)] [font-weight:var(--index-template-pagehome-section-subtitle-weight)]">
                    {{ sectionSubtitle() }}
                  </p>
                }
              </div>
              @if (hasSectionActions()) {
                <div class="flex shrink-0 items-center gap-[8px]">
                  <ng-content select="[socPageSectionActions]" />
                </div>
              }
            </div>
          }
          <ng-content />
        </div>
      </div>
    </div>
  `, isInline: true, dependencies: [{ kind: "component", type: SocSearchBar, selector: "soc-search-bar", inputs: ["placeholder", "value"], outputs: ["valueChange", "clear"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageHome, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-page-home',
                    standalone: true,
                    imports: [SocSearchBar],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: { class: 'flex size-full flex-col items-start' },
                    template: `
    <div class="flex w-full min-h-px flex-[1_0_0] flex-col items-center overflow-clip rounded-tl-[var(--bridges-shape-figure-radius-xl)] bg-[var(--index-template-pagehome-fourth-bg)]">
      <div class="w-full shrink-0 px-[var(--index-template-pagehome-breadcrumb-pad-h)] py-[var(--index-template-pagehome-breadcrumb-pad-v)]">
        <ng-content select="[socPageBreadcrumb]" />
      </div>

      <div class="scrollbar-hide flex w-full min-h-0 flex-1 flex-col gap-[var(--index-template-pagehome-content-gap)] overflow-y-auto pb-[120px]">
        @if (welcomeTitle()) {
          <div class="w-full px-[var(--index-template-pagehome-welcome-pad-h)]">
            <div class="relative flex w-full flex-col items-start overflow-hidden rounded-[3px] px-[12px] pt-[10px] pb-[16px]">
              <div class="pagehome-welcome-bg pointer-events-none absolute inset-0 size-full bg-cover bg-center"></div>
              <div class="relative flex w-full max-w-[559px] flex-col items-start gap-[7px]">
                @if (welcomeLabel()) {
                  <p class="whitespace-nowrap text-[length:var(--index-template-pagehome-welcome-label-size)] leading-none text-[var(--index-template-pagehome-welcome-label-color)] [font-family:var(--index-template-pagehome-welcome-label-font)] [font-weight:var(--index-template-pagehome-welcome-label-weight)]">
                    {{ welcomeLabel() }}
                  </p>
                }
                <p class="whitespace-nowrap text-[length:var(--index-template-pagehome-welcome-title-size)] leading-[1.2] tracking-[-0.32px] text-[var(--index-template-pagehome-welcome-title-color)] [font-family:var(--index-template-pagehome-welcome-title-font)] [font-weight:var(--index-template-pagehome-welcome-title-weight)]">
                  {{ welcomeTitle() }}
                </p>
                @if (welcomeDescription()) {
                  <p class="w-full text-[length:14px] leading-[1.4] font-semibold text-[var(--index-template-pagehome-welcome-description-color)]">
                    {{ welcomeDescription() }}
                  </p>
                }
              </div>
            </div>
          </div>
        }

        @if (searchable()) {
          <div class="w-full px-[var(--index-template-pagehome-search-pad-h)]">
            <soc-search-bar placeholder="Rechercher ici" (valueChange)="search.emit($event)" class="w-[320px] h-[var(--index-template-pagehome-search-height)]" />
          </div>
        }

        <div class="flex w-full flex-1 flex-col gap-[var(--index-template-pagehome-content-section-gap)] px-[var(--index-template-pagehome-section-pad-h)]">
          @if (sectionTitle()) {
            <div class="flex w-full items-start gap-[var(--index-template-pagehome-section-title-gap)]">
              <div class="flex min-w-0 flex-1 flex-col gap-[var(--index-template-pagehome-section-title-gap)]">
                <p class="w-full text-[length:var(--index-template-pagehome-section-title-size)] text-[var(--index-template-pagehome-section-title-color)] [font-family:var(--index-template-pagehome-section-title-font)] [font-weight:var(--index-template-pagehome-section-title-weight)]">
                  {{ sectionTitle() }}
                </p>
                @if (sectionSubtitle()) {
                  <p class="w-full text-[length:var(--index-template-pagehome-section-subtitle-size)] text-[var(--index-template-pagehome-section-subtitle-color)] [font-family:var(--index-template-pagehome-section-subtitle-font)] [font-weight:var(--index-template-pagehome-section-subtitle-weight)]">
                    {{ sectionSubtitle() }}
                  </p>
                }
              </div>
              @if (hasSectionActions()) {
                <div class="flex shrink-0 items-center gap-[8px]">
                  <ng-content select="[socPageSectionActions]" />
                </div>
              }
            </div>
          }
          <ng-content />
        </div>
      </div>
    </div>
  `,
                }]
        }] });

/**
 * ## Rôle
 * Afficher une liste d'instances d'un même type d'objet métier, avec recherche, filtres et
 * pagination, avant d'accéder au détail de l'un d'eux.
 *
 * ## Quand l'utiliser / ne pas l'utiliser
 * Chaque fois qu'un écran présente plusieurs éléments du même type à parcourir ou filtrer. Pour un seul
 * objet → `soc-page-details`; une personne → `soc-page-profile`; créer/modifier → `soc-page-form`.
 *
 * ## Contraintes de composition (inchangées par rapport à React)
 * - Seul le Breadcrumb a son propre padding vertical; l'espacement entre les autres zones vient
 *   uniquement du `content-gap` du conteneur scrollable — jamais un padding-top/bottom par zone.
 * - Le conteneur scrollable a un padding-bottom fixe de 120px (aucun token de l'échelle Position ne le
 *   couvre), non exposé. Aucune surcharge de style/espacement depuis l'extérieur : corriger le token.
 * - Liste vide → `Empty State`; sélection multiple → zone d'actions contextuelles; liste volumineuse →
 *   pagination obligatoire.
 *
 * Slots (marqueurs de `page-slots.ts`): `socPageBreadcrumb`, `socPageSecondaryTabs`, `socPageBadge`,
 * `socPageActions`, `socPageTabs`; contenu par défaut = `children` (typiquement un `soc-data-table`).
 * `title` est requis, `statusLabel`/`description` optionnels.
 *
 * Maps 1:1 to "Index/Template/PageList/*" tokens — see packages/tokens/tokens/components/template.json
 * in design_system (React reference repo, read only). `fourth-bg` (not `page-bg`) for the content
 * background; `page-bg` and the left inset belong to `soc-app-shell`'s Content Zone.
 */
class SocPageList {
    title = input.required();
    statusLabel = input();
    description = input();
    secondaryTabsContent = contentChild(SocPageSecondaryTabs);
    actionsContent = contentChild(SocPageActions);
    tabsContent = contentChild(SocPageTabs);
    hasSecondaryTabs = computed(() => !!this.secondaryTabsContent());
    hasActions = computed(() => !!this.actionsContent());
    hasTabs = computed(() => !!this.tabsContent());
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageList, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocPageList, isStandalone: true, selector: "soc-page-list", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, statusLabel: { classPropertyName: "statusLabel", publicName: "statusLabel", isSignal: true, isRequired: false, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "flex size-full flex-col items-start" }, queries: [{ propertyName: "secondaryTabsContent", first: true, predicate: SocPageSecondaryTabs, descendants: true, isSignal: true }, { propertyName: "actionsContent", first: true, predicate: SocPageActions, descendants: true, isSignal: true }, { propertyName: "tabsContent", first: true, predicate: SocPageTabs, descendants: true, isSignal: true }], ngImport: i0, template: `
    <div class="flex w-full min-h-px flex-[1_0_0] flex-col items-center overflow-clip rounded-tl-[var(--bridges-shape-figure-radius-xl)] bg-[var(--index-template-pagelist-fourth-bg)]">
      <!-- Fixed: only the breadcrumb stays put. Everything below it — secondary tabs, header, tab row,
           table — scrolls together internally, so it's the card that scrolls, not the whole page. -->
      <div class="w-full shrink-0 px-[var(--index-template-pagelist-breadcrumb-pad-h)] py-[var(--index-template-pagelist-breadcrumb-pad-v)]">
        <ng-content select="[socPageBreadcrumb]" />
      </div>

      <!-- pb-[120px]: no Bridges/Position/Padding step covers this (max is 4xl/48px) — fixed, not
           exposed as an input, so the last row never sits flush against the viewport's bottom edge. -->
      <div class="scrollbar-hide flex w-full min-h-0 flex-1 flex-col gap-[var(--index-template-pagelist-content-gap)] overflow-y-auto pb-[120px]">
        @if (hasSecondaryTabs()) {
          <div class="w-full pl-[var(--index-template-pagelist-tabs-pad-left)] pr-[var(--index-template-pagelist-tabs-pad-right)]">
            <ng-content select="[socPageSecondaryTabs]" />
          </div>
        }

        <div class="flex w-full items-start justify-between px-[var(--index-template-pagelist-pageheader-pad-h)]">
          <div class="flex min-w-0 flex-col gap-[var(--index-template-pagelist-title-block-gap)]">
            <div class="flex items-center gap-[var(--index-template-pagelist-title-row-gap)]">
              <h1 class="text-[length:var(--index-template-pagelist-page-title-size)] text-[var(--index-template-pagelist-page-title-color)] [font-family:var(--index-template-pagelist-page-title-font)] [font-weight:var(--index-template-pagelist-page-title-weight)]">
                {{ title() }}
              </h1>
              <ng-content select="[socPageBadge]" />
              @if (statusLabel()) {
                <span class="text-[length:var(--index-template-pagelist-status-label-size)] text-[var(--index-template-pagelist-status-label-color)] [font-family:var(--index-template-pagelist-status-label-font)] [font-weight:var(--index-template-pagelist-status-label-weight)]">
                  {{ statusLabel() }}
                </span>
              }
            </div>
            @if (description()) {
              <p class="text-[length:var(--index-template-pagelist-page-description-size)] text-[var(--index-template-pagelist-page-description-color)] [font-family:var(--index-template-pagelist-page-description-font)] [font-weight:var(--index-template-pagelist-page-description-weight)]">
                {{ description() }}
              </p>
            }
          </div>
          @if (hasActions()) {
            <div class="flex shrink-0 gap-[var(--index-template-pagelist-actions-gap)] pt-[var(--index-template-pagelist-actions-pad-top)]">
              <ng-content select="[socPageActions]" />
            </div>
          }
        </div>

        @if (hasTabs()) {
          <div class="w-full px-[var(--index-template-pagelist-tab-pad-h)]">
            <ng-content select="[socPageTabs]" />
          </div>
        }

        <div class="w-full px-[var(--index-template-pagelist-tab-pad-h)]">
          <ng-content />
        </div>
      </div>
    </div>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageList, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-page-list',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: { class: 'flex size-full flex-col items-start' },
                    template: `
    <div class="flex w-full min-h-px flex-[1_0_0] flex-col items-center overflow-clip rounded-tl-[var(--bridges-shape-figure-radius-xl)] bg-[var(--index-template-pagelist-fourth-bg)]">
      <!-- Fixed: only the breadcrumb stays put. Everything below it — secondary tabs, header, tab row,
           table — scrolls together internally, so it's the card that scrolls, not the whole page. -->
      <div class="w-full shrink-0 px-[var(--index-template-pagelist-breadcrumb-pad-h)] py-[var(--index-template-pagelist-breadcrumb-pad-v)]">
        <ng-content select="[socPageBreadcrumb]" />
      </div>

      <!-- pb-[120px]: no Bridges/Position/Padding step covers this (max is 4xl/48px) — fixed, not
           exposed as an input, so the last row never sits flush against the viewport's bottom edge. -->
      <div class="scrollbar-hide flex w-full min-h-0 flex-1 flex-col gap-[var(--index-template-pagelist-content-gap)] overflow-y-auto pb-[120px]">
        @if (hasSecondaryTabs()) {
          <div class="w-full pl-[var(--index-template-pagelist-tabs-pad-left)] pr-[var(--index-template-pagelist-tabs-pad-right)]">
            <ng-content select="[socPageSecondaryTabs]" />
          </div>
        }

        <div class="flex w-full items-start justify-between px-[var(--index-template-pagelist-pageheader-pad-h)]">
          <div class="flex min-w-0 flex-col gap-[var(--index-template-pagelist-title-block-gap)]">
            <div class="flex items-center gap-[var(--index-template-pagelist-title-row-gap)]">
              <h1 class="text-[length:var(--index-template-pagelist-page-title-size)] text-[var(--index-template-pagelist-page-title-color)] [font-family:var(--index-template-pagelist-page-title-font)] [font-weight:var(--index-template-pagelist-page-title-weight)]">
                {{ title() }}
              </h1>
              <ng-content select="[socPageBadge]" />
              @if (statusLabel()) {
                <span class="text-[length:var(--index-template-pagelist-status-label-size)] text-[var(--index-template-pagelist-status-label-color)] [font-family:var(--index-template-pagelist-status-label-font)] [font-weight:var(--index-template-pagelist-status-label-weight)]">
                  {{ statusLabel() }}
                </span>
              }
            </div>
            @if (description()) {
              <p class="text-[length:var(--index-template-pagelist-page-description-size)] text-[var(--index-template-pagelist-page-description-color)] [font-family:var(--index-template-pagelist-page-description-font)] [font-weight:var(--index-template-pagelist-page-description-weight)]">
                {{ description() }}
              </p>
            }
          </div>
          @if (hasActions()) {
            <div class="flex shrink-0 gap-[var(--index-template-pagelist-actions-gap)] pt-[var(--index-template-pagelist-actions-pad-top)]">
              <ng-content select="[socPageActions]" />
            </div>
          }
        </div>

        @if (hasTabs()) {
          <div class="w-full px-[var(--index-template-pagelist-tab-pad-h)]">
            <ng-content select="[socPageTabs]" />
          </div>
        }

        <div class="w-full px-[var(--index-template-pagelist-tab-pad-h)]">
          <ng-content />
        </div>
      </div>
    </div>
  `,
                }]
        }] });

/**
 * ## Rôle
 * Présenter le profil complet d'une personne (employé, utilisateur connecté), avec une structure centrée
 * sur l'identité — avatar, nom, poste en en-tête. Pour un objet non-personne → `soc-page-details`.
 *
 * ## Cas particuliers
 * Plusieurs onglets/sections selon le produit; la structure d'en-tête (identité) reste fixe. "Vue par
 * soi-même" vs "vue par un gestionnaire": même structure, actions différentes.
 *
 * ## Zone flexible (slot) et éléments optionnels
 * Le contenu par défaut (`children`) est libre: choisir les composants du DS adaptés au besoin réel,
 * ne jamais le laisser vide. Pour un élément optionnel que les specs ne tranchent pas, demander
 * confirmation à l'utilisateur plutôt que de décider seul.
 *
 * `onBack` -> `showBack` + sortie `back` (voir `soc-page-details`). `className` de React = `class` sur
 * l'hôte. Slots: `socPageBreadcrumb`, `socPageHeader` (identité, typiquement `soc-profile-line`),
 * `socPageTag`, `socPageTabs`, `socPageMessage`. Pas de padding-bottom de 120px ici, comme en React.
 *
 * Maps 1:1 to "Index/Template/PageProfile/*" tokens — see packages/tokens/tokens/components/template.json.
 */
class SocPageProfile {
    showBack = input(false, { transform: booleanAttribute });
    backLabel = input('Retour');
    statusLabel = input();
    back = output();
    tabsContent = contentChild(SocPageTabs);
    messageContent = contentChild(SocPageMessage);
    hasTabs = computed(() => !!this.tabsContent());
    hasMessage = computed(() => !!this.messageContent());
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageProfile, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocPageProfile, isStandalone: true, selector: "soc-page-profile", inputs: { showBack: { classPropertyName: "showBack", publicName: "showBack", isSignal: true, isRequired: false, transformFunction: null }, backLabel: { classPropertyName: "backLabel", publicName: "backLabel", isSignal: true, isRequired: false, transformFunction: null }, statusLabel: { classPropertyName: "statusLabel", publicName: "statusLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { back: "back" }, host: { classAttribute: "flex size-full flex-col items-start" }, queries: [{ propertyName: "tabsContent", first: true, predicate: SocPageTabs, descendants: true, isSignal: true }, { propertyName: "messageContent", first: true, predicate: SocPageMessage, descendants: true, isSignal: true }], ngImport: i0, template: `
    <div class="flex w-full min-h-px flex-[1_0_0] flex-col items-center overflow-clip rounded-tl-[var(--bridges-shape-figure-radius-xl)] bg-[var(--index-template-pageprofile-fourth-bg)]">
      <div class="w-full shrink-0 px-[var(--index-template-pageprofile-breadcrumb-pad-h)] py-[var(--index-template-pageprofile-breadcrumb-pad-v)]">
        <ng-content select="[socPageBreadcrumb]" />
      </div>

      <div class="scrollbar-hide flex w-full min-h-0 flex-1 flex-col gap-[var(--index-template-pageprofile-content-gap)] overflow-y-auto">
        @if (showBack()) {
          <div class="pl-[var(--index-template-pageprofile-back-zone-pad-left)] pr-[var(--index-template-pageprofile-back-zone-pad-right)]">
            <button socButton variant="secondary" (click)="back.emit()">
              <svg lucideArrowLeft socButtonLeftIcon class="size-full" [strokeWidth]="1.5"></svg>
              {{ backLabel() }}
            </button>
          </div>
        }

        <div class="flex w-full items-center gap-[var(--index-template-pageprofile-pageheader-gap)] px-[var(--index-template-pageprofile-pageheader-pad-h)]">
          <ng-content select="[socPageHeader]" />
          <ng-content select="[socPageTag]" />
          @if (statusLabel()) {
            <span class="text-[length:var(--index-template-pageprofile-status-label-size)] text-[var(--index-template-pageprofile-status-label-color)] [font-family:var(--index-template-pageprofile-status-label-font)] [font-weight:var(--index-template-pageprofile-status-label-weight)]">
              {{ statusLabel() }}
            </span>
          }
        </div>

        <div class="h-px w-full bg-[var(--bridges-color-border-subtle)]"></div>

        @if (hasTabs()) {
          <div class="w-full px-[var(--index-template-pageprofile-pageheader-pad-h)]">
            <ng-content select="[socPageTabs]" />
          </div>
        }

        @if (hasMessage()) {
          <div class="w-full px-[var(--index-template-pageprofile-message-zone-pad-h)]">
            <ng-content select="[socPageMessage]" />
          </div>
        }

        <div class="w-full px-[var(--index-template-pageprofile-pageheader-pad-h)]">
          <ng-content />
        </div>
      </div>
    </div>
  `, isInline: true, dependencies: [{ kind: "component", type: SocButton, selector: "button[socButton]", inputs: ["variant", "size"] }, { kind: "directive", type: SocButtonLeftIcon, selector: "[socButtonLeftIcon]" }, { kind: "component", type: LucideArrowLeft, selector: "svg[lucideArrowLeft]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocPageProfile, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-page-profile',
                    standalone: true,
                    imports: [SocButton, SocButtonLeftIcon, LucideArrowLeft],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: { class: 'flex size-full flex-col items-start' },
                    template: `
    <div class="flex w-full min-h-px flex-[1_0_0] flex-col items-center overflow-clip rounded-tl-[var(--bridges-shape-figure-radius-xl)] bg-[var(--index-template-pageprofile-fourth-bg)]">
      <div class="w-full shrink-0 px-[var(--index-template-pageprofile-breadcrumb-pad-h)] py-[var(--index-template-pageprofile-breadcrumb-pad-v)]">
        <ng-content select="[socPageBreadcrumb]" />
      </div>

      <div class="scrollbar-hide flex w-full min-h-0 flex-1 flex-col gap-[var(--index-template-pageprofile-content-gap)] overflow-y-auto">
        @if (showBack()) {
          <div class="pl-[var(--index-template-pageprofile-back-zone-pad-left)] pr-[var(--index-template-pageprofile-back-zone-pad-right)]">
            <button socButton variant="secondary" (click)="back.emit()">
              <svg lucideArrowLeft socButtonLeftIcon class="size-full" [strokeWidth]="1.5"></svg>
              {{ backLabel() }}
            </button>
          </div>
        }

        <div class="flex w-full items-center gap-[var(--index-template-pageprofile-pageheader-gap)] px-[var(--index-template-pageprofile-pageheader-pad-h)]">
          <ng-content select="[socPageHeader]" />
          <ng-content select="[socPageTag]" />
          @if (statusLabel()) {
            <span class="text-[length:var(--index-template-pageprofile-status-label-size)] text-[var(--index-template-pageprofile-status-label-color)] [font-family:var(--index-template-pageprofile-status-label-font)] [font-weight:var(--index-template-pageprofile-status-label-weight)]">
              {{ statusLabel() }}
            </span>
          }
        </div>

        <div class="h-px w-full bg-[var(--bridges-color-border-subtle)]"></div>

        @if (hasTabs()) {
          <div class="w-full px-[var(--index-template-pageprofile-pageheader-pad-h)]">
            <ng-content select="[socPageTabs]" />
          </div>
        }

        @if (hasMessage()) {
          <div class="w-full px-[var(--index-template-pageprofile-message-zone-pad-h)]">
            <ng-content select="[socPageMessage]" />
          </div>
        }

        <div class="w-full px-[var(--index-template-pageprofile-pageheader-pad-h)]">
          <ng-content />
        </div>
      </div>
    </div>
  `,
                }]
        }] });

/*
 * Public API Surface of @socium-design/angular-components
 *
 * Miroir de packages/react/src/index.ts dans le dépôt design_system (React) — chaque composant
 * migré doit être ré-exporté ici, dans le même ordre de lots que la spec de migration :
 * primitifs d'abord (src/primitifs/*), puis composés (src/composes/*), puis templates
 * (src/templates/*). Les trois lots sont migrés (primitifs, composés, templates).
 */

/**
 * Generated bundle index. Do not edit.
 */

export { APP_SWITCH_ITEMS, APP_SWITCH_PRODUCTS, NAVIGATION_PRESETS, SELECT_DEFAULT_PLACEHOLDER, SocAccordion, SocAccordionRightSlot, SocAppIcon, SocAppIconGlyph, SocAppShell, SocAppShellHeaderAvatar, SocAppShellHeaderAvatarMenu, SocAppShellHeaderLanguageSelect, SocAppShellHeaderLeft, SocAppSwitch, SocAppSwitchLogo, SocAvatar, SocAvatarMenu, SocBadge, SocBreadcrumb, SocButton, SocButtonLeftIcon, SocButtonRightIcon, SocCard, SocCardActionSlot, SocCardFooter, SocCardGrid, SocCardIcon, SocCheckbox, SocChips, SocDataTable, SocDataTableActions, SocDataTableBadge, SocDataTableFilters, SocDialog, SocDocumentLine, SocDrawer, SocDrawerDetailItem, SocEnterpriseSelect, SocHeaderApp, SocHeaderAppAvatar, SocHeaderAppAvatarMenu, SocHeaderAppLanguageSelect, SocHeaderAppLeft, SocInputArea, SocInputChip, SocInputNumber, SocInputText, SocInputTextLeftIcon, SocInputTextRightIcon, SocLanguageSelect, SocMenu, SocMenuItem, SocMenuItemIcon, SocMessage, SocMessageContent, SocMessageIcon, SocMultiSelect, SocOverlay, SocPageActions, SocPageBadge, SocPageBreadcrumb, SocPageDetails, SocPageForm, SocPageHeader, SocPageHome, SocPageList, SocPageMessage, SocPageProfile, SocPageSecondContent, SocPageSecondaryTabs, SocPageSectionActions, SocPageStepper, SocPageTabs, SocPageTag, SocPagination, SocPassword, SocPopover, SocPopoverTrigger, SocProfileLine, SocProgressBar, SocProgressBarTag, SocRadioButton, SocSearchBar, SocSelect, SocSelectableChips, SocSideNavSection, SocSideNavigation, SocSplitButton, SocStepper, SocSwitch, SocSwitchLogo, SocTableFilterSelect, SocTabs, SocTag, SocTooltip, SocTooltipContent, SocTooltipLabel, SocUploadFile, buttonIconSizeVar, buttonPaddingClasses, buttonRadiusClasses, buttonRadiusLeftClasses, buttonRadiusRightClasses, buttonTypographyClass, buttonVariantClasses };
//# sourceMappingURL=socium-design-angular-components.mjs.map
