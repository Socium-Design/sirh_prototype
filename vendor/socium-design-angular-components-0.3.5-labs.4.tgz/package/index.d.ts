/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@socium-design/angular-components" />
export * from './public-api';
