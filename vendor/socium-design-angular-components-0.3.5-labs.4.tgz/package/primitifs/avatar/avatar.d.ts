import * as i0 from "@angular/core";
export type AvatarColor = 'blue' | 'green' | 'purple' | 'orange';
export type AvatarSize = 'xs' | 'sm' | 'md' | 'lg';
export type AvatarMode = 'soft' | 'solid';
export type AvatarNamePosition = 'left' | 'right';
/**
 * No native HTML equivalent and no single element being wrapped — plain standalone wrapper
 * component (`soc-avatar` element selector), not an attribute selector. `label`/`name`/`subtitle`
 * are all plain strings (not ReactNode in the React source), so plain `input()`s, no content
 * projection needed.
 *
 * Maps 1:1 to "Index/Social/Avatar/*" tokens — see packages/tokens/tokens/components/social.json
 * in design_system (React reference repo, read only). Only the "initials" type is implemented —
 * React `Avatar.tsx`'s own doc comment: a photo is a plain image-filled frame, a generic icon is a
 * bare Lucide icon, neither goes through this component.
 */
export declare class SocAvatar {
    readonly label: import("@angular/core").InputSignal<string>;
    readonly color: import("@angular/core").InputSignal<AvatarColor>;
    readonly size: import("@angular/core").InputSignal<AvatarSize>;
    readonly mode: import("@angular/core").InputSignal<AvatarMode>;
    readonly name: import("@angular/core").InputSignal<string | undefined>;
    readonly subtitle: import("@angular/core").InputSignal<string | undefined>;
    readonly namePosition: import("@angular/core").InputSignal<AvatarNamePosition>;
    protected readonly hostClasses: import("@angular/core").Signal<"inline-flex items-center gap-[var(--index-social-avatar-group-gap)]" | "">;
    protected readonly circleClass: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocAvatar, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocAvatar, "soc-avatar", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; "namePosition": { "alias": "namePosition"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
