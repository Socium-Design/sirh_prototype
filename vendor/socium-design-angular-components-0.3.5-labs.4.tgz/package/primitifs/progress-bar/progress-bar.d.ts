import * as i0 from "@angular/core";
export type ProgressBarStatus = 'information' | 'success' | 'warning' | 'error';
export type ProgressBarSize = 'tiny' | 'sm' | 'md' | 'lg';
/** Marks the element projected into the extra row below the bar (typically a `<soc-tag>`) — React
 * `ProgressBar`'s `tag?: ReactNode` prop. Ignored when `size()` is `"tiny"`, same as React. */
export declare class SocProgressBarTag {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocProgressBarTag, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocProgressBarTag, "[socProgressBarTag]", never, {}, {}, never, never, true, never>;
}
/**
 * No native HTML equivalent (the `role="progressbar"` div is hand-rolled, same as React) — plain
 * wrapper (`soc-progress-bar`). Maps 1:1 to "Index/Feedback/ProgressBar/*" tokens — see
 * packages/tokens/tokens/components/feedback.json in design_system (React reference repo, read
 * only). The `progress-indeterminate` keyframes it references live in
 * src/styles/tailwind-entry.css (global), matching where React's own src/index.css defines them —
 * not local to this component in either repo.
 */
export declare class SocProgressBar {
    readonly value: import("@angular/core").InputSignal<number>;
    readonly status: import("@angular/core").InputSignal<ProgressBarStatus>;
    readonly size: import("@angular/core").InputSignal<ProgressBarSize>;
    readonly label: import("@angular/core").InputSignal<string | undefined>;
    readonly helpTextLeft: import("@angular/core").InputSignal<string | undefined>;
    readonly helpTextRight: import("@angular/core").InputSignal<string | undefined>;
    readonly tinyLabel: import("@angular/core").InputSignal<string | undefined>;
    readonly indeterminate: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    private readonly tagContent;
    protected readonly hasTag: import("@angular/core").Signal<boolean>;
    protected readonly isTiny: import("@angular/core").Signal<boolean>;
    protected readonly clamped: import("@angular/core").Signal<number>;
    protected readonly trackClass: import("@angular/core").Signal<string>;
    protected readonly fillClass: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocProgressBar, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocProgressBar, "soc-progress-bar", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "status": { "alias": "status"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "helpTextLeft": { "alias": "helpTextLeft"; "required": false; "isSignal": true; }; "helpTextRight": { "alias": "helpTextRight"; "required": false; "isSignal": true; }; "tinyLabel": { "alias": "tinyLabel"; "required": false; "isSignal": true; }; "indeterminate": { "alias": "indeterminate"; "required": false; "isSignal": true; }; }, {}, ["tagContent"], ["[socProgressBarTag]"], true, never>;
}
