import * as i0 from "@angular/core";
export type TooltipPosition = 'top' | 'bottom' | 'left' | 'right';
export type TooltipVariant = 'default' | 'extend' | 'message';
export type TooltipMessageStatus = 'success' | 'error' | 'warning' | 'info';
/** React `Tooltip`'s `label: ReactNode` (default/message variants). */
export declare class SocTooltipLabel {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocTooltipLabel, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocTooltipLabel, "[socTooltipLabel]", never, {}, {}, never, never, true, never>;
}
/** React `Tooltip`'s `content: ReactNode` (extend variant only — its `title` stays a plain
 * string input, it's typed `string` in React too). */
export declare class SocTooltipContent {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocTooltipContent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocTooltipContent, "[socTooltipContent]", never, {}, {}, never, never, true, never>;
}
/**
 * No native HTML equivalent — plain wrapper (`soc-tooltip`). React's version uses `cloneElement`
 * to inject `aria-describedby`/a composed `onClick` directly onto its `children` element — Angular
 * has no equivalent of cloning an arbitrary projected element with extra props (there's no
 * `TemplateRef`-free way to reach into projected content and add attributes/listeners to it).
 * Worked around it rather than reproducing it: the hover/focus/click listeners live on this
 * component's own HOST element instead (matching React's outer wrapper `<span ref={wrapperRef}>`,
 * which already carries the hover/focus listeners in React too) — `(focusout)`/`(focusin)` bubble
 * from any projected content the same way React's synthetic `onFocus`/`onBlur` do, and a host
 * `(click)` catches bubbled clicks from the trigger to dismiss the tooltip, without needing to
 * clone or modify the projected element itself. The one bit of fidelity this trades away:
 * `aria-describedby` lands on the wrapper host rather than the actual trigger element.
 *
 * Bubble is portaled to `document.body` via a direct `appendChild` in `ngAfterViewInit` (Angular
 * has no CDK Overlay in this project) — same reasoning as React's `createPortal`: a relatively-
 * positioned bubble gets silently clipped by any scrollable/`overflow` ancestor. Position-computing
 * functions (`computeFixedPosition`/`flipIfNeeded`) are ported 1:1 from React's own.
 *
 * Maps 1:1 to "Index/Feedback/Tooltip/*" tokens — see packages/tokens/tokens/components/feedback.json
 * in design_system (React reference repo, read only).
 */
export declare class SocTooltip {
    readonly position: import("@angular/core").InputSignal<TooltipPosition>;
    readonly variant: import("@angular/core").InputSignal<TooltipVariant>;
    readonly title: import("@angular/core").InputSignal<string | undefined>;
    readonly status: import("@angular/core").InputSignal<TooltipMessageStatus>;
    readonly showIcon: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    protected readonly arrowPositionClasses: Record<TooltipPosition, string>;
    protected readonly tooltipId: string;
    protected readonly visible: import("@angular/core").WritableSignal<boolean>;
    protected readonly resolvedPosition: import("@angular/core").WritableSignal<TooltipPosition>;
    protected readonly topPx: import("@angular/core").WritableSignal<number>;
    protected readonly leftPx: import("@angular/core").WritableSignal<number>;
    private readonly hostRef;
    private readonly bubbleRef;
    private appended;
    constructor();
    protected show(): void;
    protected hide(): void;
    private reposition;
    protected readonly arrowStyle: import("@angular/core").Signal<string>;
    protected readonly bubbleClass: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocTooltip, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocTooltip, "soc-tooltip", never, { "position": { "alias": "position"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "status": { "alias": "status"; "required": false; "isSignal": true; }; "showIcon": { "alias": "showIcon"; "required": false; "isSignal": true; }; }, {}, never, ["*", "[socTooltipContent]", "[socTooltipLabel]"], true, never>;
}
