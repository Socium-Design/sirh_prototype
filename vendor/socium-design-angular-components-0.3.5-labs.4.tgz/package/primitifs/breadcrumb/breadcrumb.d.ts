import * as i0 from "@angular/core";
export interface BreadcrumbItemData {
    label: string;
    onClick?: () => void;
}
/**
 * No native HTML equivalent — plain wrapper (`soc-breadcrumb`). `items: BreadcrumbItemData[]` is
 * plain data (not ReactNode), so a plain `input()`, same as `Message`'s `primaryAction` object —
 * each item's own `onClick` stays a plain callback field on the data, since it's tied to that
 * specific item, not a single component-wide event. `onHomeClick`, by contrast, IS a single
 * component-wide handler (not nested in an array item) — that one becomes an `output()`
 * (`homeClick`), matching how `SplitButton`'s direct handler props became outputs.
 *
 * Maps 1:1 to "Index/Navigation/Breadcrumb/*" tokens — see packages/tokens/tokens/components/navigation.json
 * in design_system (React reference repo, read only).
 */
export declare class SocBreadcrumb {
    readonly items: import("@angular/core").InputSignal<BreadcrumbItemData[]>;
    readonly truncated: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly homeClick: import("@angular/core").OutputEmitterRef<void>;
    protected readonly iconThickness = "var(--index-navigation-breadcrumb-icon-thickness)";
    protected readonly visibleItems: import("@angular/core").Signal<BreadcrumbItemData[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocBreadcrumb, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocBreadcrumb, "soc-breadcrumb", never, { "items": { "alias": "items"; "required": true; "isSignal": true; }; "truncated": { "alias": "truncated"; "required": false; "isSignal": true; }; }, { "homeClick": "homeClick"; }, never, never, true, never>;
}
