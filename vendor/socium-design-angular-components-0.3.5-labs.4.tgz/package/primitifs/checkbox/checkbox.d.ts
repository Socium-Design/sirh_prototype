import { SocFormControl } from '../../internal/form-control';
import * as i0 from "@angular/core";
/** GAP-DECISION (flagged, not decided silently): the migration spec's rule for Checkbox was
 * "attribute selector on `input[type=checkbox]`". Read the real React source before writing
 * anything — Checkbox.tsx does NOT use a native `<input type="checkbox">` at all: it's a
 * `<button role="checkbox" aria-checked>` wrapped in a `<label>`, with an optional sibling
 * `<span>` for the label text. Same "can't render siblings from inside an attribute selector"
 * problem as InputText's whole family (see that component's own docstring) — the `<label>`
 * wrapper and text span sit OUTSIDE the button. Wrapper component instead (`soc-checkbox`), self-
 * contained the same way React's `Checkbox` is (its own `label` prop, not something the consumer
 * assembles by hand). Same reasoning applies to RadioButton and Switch, not repeated on each.
 *
 * Maps 1:1 to "Index/Contrôleur/Checkbox/*" tokens — see packages/tokens/tokens/components/contrôleur.json
 * in design_system (React reference repo, read only). Figma only defines unchecked/checked (no
 * indeterminate variant yet), same as React.
 */
export declare class SocCheckbox extends SocFormControl<boolean> {
    readonly checked: import("@angular/core").ModelSignal<boolean>;
    protected readonly valueModel: import("@angular/core").ModelSignal<boolean>;
    protected coerce(value: unknown): boolean;
    readonly label: import("@angular/core").InputSignal<string | undefined>;
    readonly id: import("@angular/core").InputSignal<string | undefined>;
    private readonly generatedId;
    protected get checkboxId(): string;
    protected toggle(): void;
    protected readonly hostClass: import("@angular/core").Signal<string>;
    protected readonly buttonClass: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocCheckbox, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocCheckbox, "soc-checkbox", never, { "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; }, { "checked": "checkedChange"; }, never, never, true, never>;
}
