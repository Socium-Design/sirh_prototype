import * as i0 from "@angular/core";
export type TagColor = 'success' | 'warning' | 'error' | 'information' | 'purple' | 'orange';
export type TagSize = 'sm' | 'lg';
/**
 * No native HTML equivalent — plain wrapper (`soc-tag` element selector). `children: ReactNode`
 * becomes a default `<ng-content>`.
 *
 * React's `onRemove?: () => void` prop doubles as both "show the remove button" and "the handler"
 * — an `output()` can't be introspected the same way (no public "is anyone listening" signal), so
 * this splits into a `removable` input (controls whether the button renders) plus a `remove`
 * output (the handler) instead of inferring visibility from whether `(remove)` was bound.
 *
 * The remove (×) button draws its own icon (`LucideX`, `@lucide/angular`) rather than projecting
 * one — same as React's own `<X className="size-3" .../>`, not a consumer-supplied slot.
 *
 * Maps 1:1 to "Index/Feedback/Tag/*" tokens — see packages/tokens/tokens/components/feedback.json
 * in design_system (React reference repo, read only).
 */
export declare class SocTag {
    readonly color: import("@angular/core").InputSignal<TagColor>;
    readonly size: import("@angular/core").InputSignal<TagSize>;
    readonly removable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly remove: import("@angular/core").OutputEmitterRef<void>;
    protected readonly hostClasses: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocTag, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocTag, "soc-tag", never, { "color": { "alias": "color"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "removable": { "alias": "removable"; "required": false; "isSignal": true; }; }, { "remove": "remove"; }, never, ["*"], true, never>;
}
