import { type NavigationProduct, type SideNavActionData, type SideNavItemData, type SideNavSectionData } from './navigation-presets';
import * as i0 from "@angular/core";
/**
 * Internal — one collapsible section of the nav (React's own local `NavSection` function
 * component, promoted to its own Angular component since Angular doesn't have React's casual
 * "just define another function in the same file" pattern for a stateful sub-view — this needs
 * its own `open` signal per section instance). Not exported from `public-api.ts`.
 */
export declare class SocSideNavSection {
    readonly section: import("@angular/core").InputSignal<SideNavSectionData>;
    readonly selectedId: import("@angular/core").InputSignal<string | undefined>;
    readonly collapsed: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly itemSelect: import("@angular/core").OutputEmitterRef<string>;
    protected readonly open: import("@angular/core").WritableSignal<boolean>;
    protected readonly chevronThickness = "var(--index-navigation-sidenavigation-menu-title-chevron-thickness)";
    protected readonly itemIconInputs: {
        class: string;
        strokeWidth: string;
    };
    protected itemClick(item: SideNavItemData): void;
    protected itemClass(id: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocSideNavSection, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocSideNavSection, "soc-side-nav-section", never, { "section": { "alias": "section"; "required": true; "isSignal": true; }; "selectedId": { "alias": "selectedId"; "required": false; "isSignal": true; }; "collapsed": { "alias": "collapsed"; "required": false; "isSignal": true; }; }, { "itemSelect": "itemSelect"; }, never, never, true, never>;
}
/**
 * No native HTML equivalent — plain wrapper (`soc-side-navigation`). Maps 1:1 to
 * "Index/Navigation/SideNavigation/*" tokens — see packages/tokens/tokens/components/navigation.json
 * in design_system (React reference repo, read only). `collapsed` has no internal
 * uncontrolled/default fallback in React either (purely controlled, parent owns it entirely via
 * `onToggleCollapse`) — plain `input()`, not `model()`, unlike Accordion/Checkbox/Switch.
 * `onSelect`/`onToggleCollapse` are direct component-level handlers -> `output()`s
 * (`select`/`toggleCollapse`).
 */
export declare class SocSideNavigation {
    readonly product: import("@angular/core").InputSignal<NavigationProduct | undefined>;
    readonly title: import("@angular/core").InputSignal<string | undefined>;
    readonly sections: import("@angular/core").InputSignal<SideNavSectionData[] | undefined>;
    readonly actionSection: import("@angular/core").InputSignal<{
        title: string;
        items: SideNavActionData[];
    } | undefined>;
    readonly selectedId: import("@angular/core").InputSignal<string | undefined>;
    readonly collapsed: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly select: import("@angular/core").OutputEmitterRef<string>;
    readonly toggleCollapse: import("@angular/core").OutputEmitterRef<void>;
    protected readonly titleIconThickness = "var(--index-navigation-sidenavigation-title-icon-thickness)";
    protected readonly actionIconInputs: {
        class: string;
        strokeWidth: string;
    };
    private readonly preset;
    protected readonly hostClasses: import("@angular/core").Signal<string>;
    protected readonly resolvedTitle: import("@angular/core").Signal<string>;
    protected readonly resolvedSections: import("@angular/core").Signal<SideNavSectionData[]>;
    protected readonly resolvedActionSection: import("@angular/core").Signal<{
        title: string;
        items: SideNavActionData[];
    } | undefined>;
    protected actionClick(action: SideNavActionData): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocSideNavigation, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocSideNavigation, "soc-side-navigation", never, { "product": { "alias": "product"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "sections": { "alias": "sections"; "required": false; "isSignal": true; }; "actionSection": { "alias": "actionSection"; "required": false; "isSignal": true; }; "selectedId": { "alias": "selectedId"; "required": false; "isSignal": true; }; "collapsed": { "alias": "collapsed"; "required": false; "isSignal": true; }; }, { "select": "select"; "toggleCollapse": "toggleCollapse"; }, never, never, true, never>;
}
