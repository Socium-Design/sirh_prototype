import type { Type } from '@angular/core';
export type NavigationProduct = 'workspace' | 'job' | 'workflow' | 'perfs' | 'doc' | 'payroll';
/** A reference to an icon COMPONENT CLASS (e.g. `LucideHouse` itself, not an instance) — the
 * Angular equivalent of React storing a rendered `<House />` element directly in plain preset
 * data. React's `ReactNode` can hold an already-rendered element; Angular has nothing structurally
 * equivalent for a plain non-component .ts data file (no live template context exists here to
 * declare a `TemplateRef` against, unlike a consumer's own component template — see `Tabs.icon`'s
 * docstring for that alternative, used where a live template context *does* exist). Rendered via
 * `NgComponentOutlet`, which correctly instantiates an attribute-selector component like
 * `svg[lucideHouse]` using the selector's own tag (`svg`) as the host element. */
export type IconComponent = Type<unknown>;
export interface SideNavItemData {
    id: string;
    label: string;
    icon: IconComponent;
    /** Called in addition to the component's own `select` output whenever this item is clicked —
     * matches React `SideNavItem`'s own `onClick?: () => void`. None of the built-in presets above
     * set one (consistent with React's presets), but a consumer-supplied item can. */
    onClick?: () => void;
}
export interface SideNavSectionData {
    title: string;
    items: SideNavItemData[];
}
export interface SideNavActionData {
    id: string;
    label: string;
    icon: IconComponent;
    /** Matches React `SideNavAction`'s own `onClick?: () => void`. */
    onClick?: () => void;
}
export interface NavigationPreset {
    title: string;
    sections: SideNavSectionData[];
    actionSection?: {
        title: string;
        items: SideNavActionData[];
    };
}
/**
 * One preset per "Produit" variant of Figma's SiteNavigation component — transcribed label-by-
 * label and icon-by-icon from design_system (React)'s own navigationPresets.ts, itself
 * transcribed from the Figma file (icons identified there by comparing each exported SVG's
 * geometry against lucide-react's own icon path data, not guessed from the label text — carried
 * over verbatim, not re-derived here). Section/item ids are slugs of their label, prefixed with
 * the product, so the same label reused across products never collides.
 */
export declare const NAVIGATION_PRESETS: Record<NavigationProduct, NavigationPreset>;
