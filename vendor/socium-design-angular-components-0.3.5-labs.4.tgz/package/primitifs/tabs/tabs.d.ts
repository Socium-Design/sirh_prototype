import { TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
export interface TabItem {
    id: string;
    label: string;
    /** React's `icon?: ReactNode` — a per-item piece of arbitrary content embedded in a plain data
     * array, not a component's own content-projection slot. Angular's equivalent for "renderable
     * content living inside a data value" is a `TemplateRef`, not a plain input — the consumer
     * defines it with `<ng-template #tpl>...</ng-template>` in their own component and puts the
     * resulting `TemplateRef` in this field, same idea as Angular Material's own table cell
     * templates. */
    icon?: TemplateRef<void>;
    disabled?: boolean;
}
export type TabsVariant = 'underline' | 'pill';
/**
 * No native HTML equivalent — plain wrapper (`soc-tabs`). Maps to "Index/Navigation/Tab/*"
 * (underline) or "Index/Navigation/Tab2/*" (pill) tokens in design_system (React reference repo,
 * read only). Both variants live in one component/template (an `@if`), same as React's own
 * `Tabs` picking between its two internal `UnderlineTabs`/`PillTabs` functions.
 */
export declare class SocTabs {
    readonly items: import("@angular/core").InputSignal<TabItem[]>;
    readonly value: import("@angular/core").InputSignal<string>;
    readonly variant: import("@angular/core").InputSignal<TabsVariant>;
    readonly change: import("@angular/core").OutputEmitterRef<string>;
    protected readonly hostClasses: import("@angular/core").Signal<"inline-flex items-center gap-[var(--index-navigation-tab2-container-gap)] rounded-[var(--index-navigation-tab2-container-radius)] bg-[var(--index-navigation-tab2-container-bg)] p-[var(--index-navigation-tab2-container-padding)]" | "flex border-b-[1px] border-[var(--index-navigation-tab-border-bottom)]">;
    protected pillItemClass(item: TabItem): string;
    protected underlineButtonClass(item: TabItem): string;
    protected underlineInnerClass(item: TabItem): string;
    protected underlineIconClass(item: TabItem): string;
    protected underlineIndicatorClass(item: TabItem): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocTabs, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocTabs, "soc-tabs", never, { "items": { "alias": "items"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": true; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; }, { "change": "change"; }, never, never, true, never>;
}
