import { SocTextFieldBase } from '../../internal/form-control';
import * as i0 from "@angular/core";
/** Same structural GAP-DECISION as InputText — see that component's own docstring, not repeated
 * here. Maps 1:1 to "Index/Input/Input number/*" tokens — see
 * packages/tokens/tokens/components/input.json in design_system (React reference repo, read
 * only). `value`/`defaultValue`'s controlled-vs-uncontrolled split in React collapses to a single
 * `model()` here — a signal always holds the current value regardless of whether the consumer
 * binds `[(value)]` or just reads/sets the initial one, so there's no separate "was a value prop
 * given" branch to reproduce.
 */
export declare class SocInputNumber extends SocTextFieldBase<number | null> {
    readonly showSteppers: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly min: import("@angular/core").InputSignal<number | undefined>;
    readonly max: import("@angular/core").InputSignal<number | undefined>;
    readonly step: import("@angular/core").InputSignal<number>;
    /** `null` = empty field (what a form `reset()` produces); React's version is always a number. */
    readonly value: import("@angular/core").ModelSignal<number | null>;
    protected readonly valueModel: import("@angular/core").ModelSignal<number | null>;
    private readonly fieldRef;
    protected nativeField: () => HTMLInputElement | undefined;
    protected coerce(value: unknown): number | null;
    private readonly generatedId;
    protected get inputId(): string;
    protected readonly helpIconThickness = "var(--index-input-input-number-icon-help-thickness)";
    protected readonly atMax: import("@angular/core").Signal<boolean>;
    protected readonly atMin: import("@angular/core").Signal<boolean>;
    protected commit(next: number): void;
    protected handleInputChange(event: Event): void;
    protected readonly labelClass: import("@angular/core").Signal<string>;
    protected readonly fieldClass: import("@angular/core").Signal<string>;
    protected readonly helperTextClass: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocInputNumber, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocInputNumber, "soc-input-number", never, { "showSteppers": { "alias": "showSteppers"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}
