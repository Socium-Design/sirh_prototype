import * as i0 from "@angular/core";
export type PaginationVariant = 'numbered' | 'dots';
/**
 * No native HTML equivalent — plain wrapper (`soc-pagination`). Maps 1:1 to
 * "Index/Navigation/Pagination/*" tokens — see packages/tokens/tokens/components/navigation.json
 * in design_system (React reference repo, read only). `onPageChange`/`onPageSizeChange` are direct
 * component-level handlers (not per-item data), so both become `output()`s
 * (`pageChange`/`pageSizeChange`) rather than input callbacks.
 */
export declare class SocPagination {
    readonly currentPage: import("@angular/core").InputSignal<number>;
    readonly totalPages: import("@angular/core").InputSignal<number>;
    readonly variant: import("@angular/core").InputSignal<PaginationVariant>;
    readonly hasFirstLast: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly totalEntries: import("@angular/core").InputSignal<number | undefined>;
    readonly pageSize: import("@angular/core").InputSignal<number | undefined>;
    readonly pageSizeOptions: import("@angular/core").InputSignal<number[]>;
    readonly pageChange: import("@angular/core").OutputEmitterRef<number>;
    readonly pageSizeChange: import("@angular/core").OutputEmitterRef<number>;
    protected readonly navButtonClass = "flex size-[var(--index-navigation-pagination-item-size)] items-center justify-center rounded-[var(--index-navigation-pagination-item-radius)] text-[var(--index-navigation-pagination-icon-default)] hover:text-[var(--index-navigation-pagination-icon-hover)] disabled:cursor-not-allowed disabled:text-[var(--index-navigation-pagination-icon-disabled)]";
    protected readonly iconThickness = "var(--index-navigation-pagination-icon-thickness)";
    protected readonly pages: import("@angular/core").Signal<(number | "ellipsis")[]>;
    protected readonly dotPages: import("@angular/core").Signal<number[]>;
    protected readonly showPageSize: import("@angular/core").Signal<boolean>;
    protected readonly fromEntry: import("@angular/core").Signal<number | undefined>;
    protected readonly toEntry: import("@angular/core").Signal<number | undefined>;
    protected dotClass(page: number): string;
    protected pageButtonClass(page: number): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocPagination, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocPagination, "soc-pagination", never, { "currentPage": { "alias": "currentPage"; "required": true; "isSignal": true; }; "totalPages": { "alias": "totalPages"; "required": true; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "hasFirstLast": { "alias": "hasFirstLast"; "required": false; "isSignal": true; }; "totalEntries": { "alias": "totalEntries"; "required": false; "isSignal": true; }; "pageSize": { "alias": "pageSize"; "required": false; "isSignal": true; }; "pageSizeOptions": { "alias": "pageSizeOptions"; "required": false; "isSignal": true; }; }, { "pageChange": "pageChange"; "pageSizeChange": "pageSizeChange"; }, never, never, true, never>;
}
