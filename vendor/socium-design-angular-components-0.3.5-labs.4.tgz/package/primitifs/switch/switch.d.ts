import { SocFormControl } from '../../internal/form-control';
import * as i0 from "@angular/core";
export type SwitchSize = 'sm' | 'md' | 'lg';
/** Same structural GAP-DECISION as Checkbox — see that component's own docstring, not repeated
 * here. Maps 1:1 to "Index/Contrôleur/Switch/*" tokens — see
 * packages/tokens/tokens/components/contrôleur.json in design_system (React reference repo, read
 * only).
 */
export declare class SocSwitch extends SocFormControl<boolean> {
    readonly checked: import("@angular/core").ModelSignal<boolean>;
    readonly size: import("@angular/core").InputSignal<SwitchSize>;
    protected readonly valueModel: import("@angular/core").ModelSignal<boolean>;
    protected coerce(value: unknown): boolean;
    readonly label: import("@angular/core").InputSignal<string | undefined>;
    readonly id: import("@angular/core").InputSignal<string | undefined>;
    private readonly generatedId;
    protected get switchId(): string;
    protected toggle(): void;
    protected readonly hostClass: import("@angular/core").Signal<string>;
    protected readonly trackClass: import("@angular/core").Signal<string>;
    protected readonly thumbClass: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocSwitch, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocSwitch, "soc-switch", never, { "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; }, { "checked": "checkedChange"; }, never, never, true, never>;
}
