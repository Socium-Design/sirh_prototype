import * as i0 from "@angular/core";
/**
 * No native HTML equivalent — plain wrapper (`soc-document-line`). All three props are plain
 * strings in React (`title`/`date`/`fileSize`), no ReactNode anywhere, so plain `input()`s, no
 * content projection. The file icon is self-drawn (`LucideFileText`), same as React's own
 * `<FileText />` — not a consumer-supplied slot.
 *
 * Maps 1:1 to "Index/Données/DocumentLine/*" tokens — see packages/tokens/tokens/components/données.json
 * in design_system (React reference repo, read only).
 */
export declare class SocDocumentLine {
    readonly title: import("@angular/core").InputSignal<string>;
    readonly date: import("@angular/core").InputSignal<string>;
    readonly fileSize: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocDocumentLine, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocDocumentLine, "soc-document-line", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "date": { "alias": "date"; "required": true; "isSignal": true; }; "fileSize": { "alias": "fileSize"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
