import { SocTextFieldBase } from '../../internal/form-control';
import * as i0 from "@angular/core";
/** Same structural GAP-DECISION as InputText — see that component's own docstring, not repeated
 * here. Maps 1:1 to "Index/Input/Input area/*" tokens — see
 * packages/tokens/tokens/components/input.json in design_system (React reference repo, read
 * only). Grows with its content (auto-height) instead of scrolling internally, same as React's
 * own `useLayoutEffect` — done here with `viewChild` + `effect()` instead, reading `value()` so it
 * re-measures on every change exactly like React's `[value]` dependency array.
 */
export declare class SocInputArea extends SocTextFieldBase<string> {
    readonly rows: import("@angular/core").InputSignal<number>;
    readonly maxlength: import("@angular/core").InputSignal<number | undefined>;
    readonly value: import("@angular/core").ModelSignal<string>;
    protected readonly valueModel: import("@angular/core").ModelSignal<string>;
    protected nativeField: () => HTMLTextAreaElement | undefined;
    protected coerce(value: unknown): string;
    private readonly generatedId;
    protected get inputId(): string;
    protected readonly helpIconThickness = "var(--index-input-input-area-icon-help-thickness)";
    private readonly textareaRef;
    constructor();
    protected readonly labelClass: import("@angular/core").Signal<string>;
    protected readonly fieldClass: import("@angular/core").Signal<string>;
    protected readonly helperTextClass: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocInputArea, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocInputArea, "soc-input-area", never, { "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "maxlength": { "alias": "maxlength"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}
