import { ControlValueAccessor } from '@angular/forms';
import * as i0 from "@angular/core";
/** Same structural GAP-DECISION as Checkbox — see that component's own docstring, not repeated
 * here. Maps 1:1 to "Index/Contrôleur/Radio/*" tokens — see
 * packages/tokens/tokens/components/contrôleur.json in design_system (React reference repo, read
 * only). Unlike Checkbox/Switch, React's `RadioButton` has no internal `useState`/`defaultSelected`
 * at all — purely controlled (`selected` prop + `onSelect` callback) — so this is a plain
 * `input()` + `output()` pair, no `model()`/uncontrolled-fallback needed.
 */
export declare class SocRadioButton implements ControlValueAccessor {
    /** Controlled like React (`selected` + `(select)`), but a `model()` so a form can drive it too. */
    readonly selected: import("@angular/core").ModelSignal<boolean>;
    readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    private readonly formDisabled;
    readonly isDisabled: import("@angular/core").Signal<boolean>;
    readonly label: import("@angular/core").InputSignal<string | undefined>;
    readonly name: import("@angular/core").InputSignal<string | undefined>;
    readonly id: import("@angular/core").InputSignal<string | undefined>;
    readonly select: import("@angular/core").OutputEmitterRef<void>;
    /** Forms: the value this radio stands for. Give every radio of a group the same `formControlName`/
     * `[formControl]`/`ngModel` and its own `value` — the group's value selects the matching radio, and
     * clicking one writes its `value` back to the control (the standard pattern for custom radios). */
    readonly value: import("@angular/core").InputSignal<unknown>;
    private onChange;
    protected onTouched: () => void;
    constructor();
    protected handleClick(): void;
    writeValue(groupValue: unknown): void;
    registerOnChange(fn: (value: unknown) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    protected readonly hostClass: import("@angular/core").Signal<string>;
    protected readonly buttonClass: import("@angular/core").Signal<string>;
    protected readonly dotClass: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocRadioButton, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocRadioButton, "soc-radio-button", never, { "selected": { "alias": "selected"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "selected": "selectedChange"; "select": "select"; }, never, never, true, never>;
}
