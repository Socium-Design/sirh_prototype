import * as i0 from "@angular/core";
export type PopoverPosition = 'top' | 'bottom' | 'left' | 'right' | 'bottom-end';
/** React `Popover`'s `trigger: ReactElement` — receives a click handler (React clones it in;
 * here the click listener lives on this component's own wrapper around the projected content
 * instead, same workaround as `Tooltip`'s trigger — see that component's own docstring for why
 * cloning has no Angular equivalent). */
export declare class SocPopoverTrigger {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocPopoverTrigger, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocPopoverTrigger, "[socPopoverTrigger]", never, {}, {}, never, never, true, never>;
}
/**
 * No native HTML equivalent — plain wrapper (`soc-popover`). Maps 1:1 to
 * "Index/Conteneur/Menu/popover-*" tokens (Figma has no standalone Popover token set — Menu is
 * the only component that binds the floating-surface tokens) — see
 * packages/tokens/tokens/components/conteneur.json in design_system (React reference repo, read
 * only). `trigger` -> named content slot (`socPopoverTrigger`); panel content -> default
 * unnamed slot, same split as `Card`'s icon-slots-vs-default-children precedent.
 *
 * Portaled to `document.body` via a direct `appendChild`, positioned with computed `position:
 * fixed` — same reasoning and same technique as `Tooltip`'s own bubble (see its docstring).
 * `computePosition` ported 1:1 from React. React's controlled-vs-uncontrolled `open` collapses to
 * one `model()`, same pattern as `Checkbox`/`Accordion`.
 */
export declare class SocPopover {
    readonly position: import("@angular/core").InputSignal<PopoverPosition>;
    readonly open: import("@angular/core").ModelSignal<boolean>;
    readonly matchTriggerWidth: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /** React `Popover`'s `className` — extra classes merged onto the portaled panel (e.g.
     * `EnterpriseSelect`'s explicit `w-[400px]`). A literal `class` on `<soc-popover>` can't do this:
     * the panel is portaled out to `document.body`, away from the host element. */
    readonly panelClass: import("@angular/core").InputSignal<string | undefined>;
    private readonly triggerWrapperRef;
    private readonly panelRef;
    private appended;
    protected readonly topPx: import("@angular/core").WritableSignal<number>;
    protected readonly leftPx: import("@angular/core").WritableSignal<number>;
    protected readonly triggerWidthPx: import("@angular/core").WritableSignal<number>;
    constructor();
    protected toggle(): void;
    private reposition;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocPopover, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocPopover, "soc-popover", never, { "position": { "alias": "position"; "required": false; "isSignal": true; }; "open": { "alias": "open"; "required": false; "isSignal": true; }; "matchTriggerWidth": { "alias": "matchTriggerWidth"; "required": false; "isSignal": true; }; "panelClass": { "alias": "panelClass"; "required": false; "isSignal": true; }; }, { "open": "openChange"; }, never, ["[socPopoverTrigger]", "*"], true, never>;
}
