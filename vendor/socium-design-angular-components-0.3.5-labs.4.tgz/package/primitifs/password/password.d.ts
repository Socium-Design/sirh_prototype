import { SocTextFieldBase } from '../../internal/form-control';
import * as i0 from "@angular/core";
/** Same structural GAP-DECISION as InputText — see that component's own docstring, not repeated
 * here. Maps 1:1 to "Index/Input/Input password/*" tokens — see
 * packages/tokens/tokens/components/input.json in design_system (React reference repo, read
 * only). The show/hide toggle is local component state (a plain `signal`), same as React's own
 * `useState` — not exposed as an input/output, nothing outside this component needs to know or
 * control it.
 */
export declare class SocPassword extends SocTextFieldBase<string> {
    readonly maxlength: import("@angular/core").InputSignal<number | undefined>;
    readonly value: import("@angular/core").ModelSignal<string>;
    protected readonly valueModel: import("@angular/core").ModelSignal<string>;
    private readonly fieldRef;
    protected nativeField: () => HTMLInputElement | undefined;
    protected coerce(value: unknown): string;
    protected readonly visible: import("@angular/core").WritableSignal<boolean>;
    private readonly generatedId;
    protected get inputId(): string;
    protected readonly helpIconThickness = "var(--index-input-input-password-icon-help-thickness)";
    protected readonly eyeThickness = "var(--index-input-input-password-icon-eye-thickness)";
    protected readonly labelClass: import("@angular/core").Signal<string>;
    protected readonly fieldClass: import("@angular/core").Signal<string>;
    protected readonly helperTextClass: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocPassword, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocPassword, "soc-password", never, { "maxlength": { "alias": "maxlength"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}
