import type { NavigationProduct } from '../side-navigation/navigation-presets';
import type { AppIconName } from './app-icons';
export interface AppSwitchItemData {
    id: string;
    name: AppIconName;
    label: string;
}
/**
 * One entry per "Produit" variant — the same 6 values `SocSideNavigation`'s `product` input
 * resolves against (see navigation-presets.ts). `name` maps to the matching AppIconName glyph;
 * note `perfs` (NavigationProduct) draws the `performance` glyph — the two are spelled
 * differently between Figma's SideNavigation and AppIcon components (carried over verbatim from
 * React's own appSwitchPresets.ts).
 */
export declare const APP_SWITCH_ITEMS: Record<NavigationProduct, AppSwitchItemData>;
export declare const APP_SWITCH_PRODUCTS: NavigationProduct[];
