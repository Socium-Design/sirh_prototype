import * as i0 from "@angular/core";
/**
 * Real vector glyphs exported from the Figma "AppIcon" component (Index/Navigation/AppIcon), one
 * per named app. Fill colors mirror the exact bindings used on the Figma instances: Default ->
 * Index/Button/Button/icon-default, Hover -> Index/Navigation/AppIcon/icon-hover, Selected -> a
 * mix of Index/Navigation/AppIcon/icon-selected (white parts) and icon-accent (green parts, same
 * token for every app including BAAS). Path data ported verbatim from design_system (React)'s own
 * appIcons.tsx — read-only reference, not re-derived.
 */
export type AppIconName = 'workspace' | 'job' | 'workflow' | 'performance' | 'doc' | 'payroll' | 'time' | 'baas';
/**
 * Renders one named glyph via a `@switch`, each shape's fill picked by `selected()` + whether that
 * particular shape is an "accent" one — same three-class logic as React's own `renderShapes`
 * helper, just inlined per shape here instead of mapped over a shape-description array (Angular
 * templates can't easily interpolate arbitrary SVG element types — `<path>` vs `<circle>` vs
 * `<ellipse>` — the way a single JS `.map()` callback can, so this stays closer to hand-written SVG
 * markup per icon rather than porting `renderShapes`/`GlyphShape` as data).
 */
export declare class SocAppIconGlyph {
    readonly name: import("@angular/core").InputSignal<AppIconName>;
    readonly selected: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    protected shapeClass(accent: boolean): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocAppIconGlyph, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocAppIconGlyph, "soc-app-icon-glyph", never, { "name": { "alias": "name"; "required": true; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
/** Real vector mark exported from the Figma "Logo" node (rendered above the icon list in
 * AppSwitch). Ported verbatim from React's own `SwitchLogo`. */
export declare class SocSwitchLogo {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocSwitchLogo, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocSwitchLogo, "soc-switch-logo", never, {}, {}, never, never, true, never>;
}
