import type { NavigationProduct } from '../side-navigation/navigation-presets';
import { type AppIconName } from './app-icons';
import { type AppSwitchItemData } from './app-switch-presets';
import * as i0 from "@angular/core";
/** React `AppSwitch`'s `logo?: ReactNode` — rendered above the icon list (pass the Logo
 * component, e.g. `SocSwitchLogo`, once it exists — same "not implemented yet" note as React's
 * own doc comment). */
export declare class SocAppSwitchLogo {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocAppSwitchLogo, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocAppSwitchLogo, "[socAppSwitchLogo]", never, {}, {}, never, never, true, never>;
}
/**
 * Attribute selector on a real `<button>` (`button[socAppIcon]`) — structurally just a button
 * with a self-drawn icon inside, no siblings needed, same shape as `Button` itself. Maps 1:1 to
 * "Index/Navigation/AppIcon/*" tokens — see packages/tokens/tokens/components/navigation.json in
 * design_system (React reference repo, read only).
 */
export declare class SocAppIcon {
    readonly name: import("@angular/core").InputSignal<AppIconName>;
    readonly label: import("@angular/core").InputSignal<string>;
    readonly selected: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    protected readonly hostClasses: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocAppIcon, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocAppIcon, "button[socAppIcon]", never, { "name": { "alias": "name"; "required": true; "isSignal": true; }; "label": { "alias": "label"; "required": true; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
/**
 * No native HTML equivalent — plain wrapper (`soc-app-switch`). Maps 1:1 to
 * "Index/Navigation/AppSwitch/*" tokens — see packages/tokens/tokens/components/navigation.json
 * in design_system (React reference repo, read only). `onSelect` -> `select` output(); `logo` ->
 * named content slot (`socAppSwitchLogo`), same reasoning as every other `ReactNode` slot this
 * migration.
 */
export declare class SocAppSwitch {
    readonly product: import("@angular/core").InputSignal<NavigationProduct | undefined>;
    readonly items: import("@angular/core").InputSignal<AppSwitchItemData[] | undefined>;
    readonly selectedId: import("@angular/core").InputSignal<string | undefined>;
    readonly select: import("@angular/core").OutputEmitterRef<string>;
    private readonly logoContent;
    protected readonly hasLogo: import("@angular/core").Signal<boolean>;
    protected readonly resolvedItems: import("@angular/core").Signal<AppSwitchItemData[]>;
    protected readonly resolvedSelectedId: import("@angular/core").Signal<string | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocAppSwitch, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocAppSwitch, "soc-app-switch", never, { "product": { "alias": "product"; "required": false; "isSignal": true; }; "items": { "alias": "items"; "required": false; "isSignal": true; }; "selectedId": { "alias": "selectedId"; "required": false; "isSignal": true; }; }, { "select": "select"; }, ["logoContent"], ["[socAppSwitchLogo]"], true, never>;
}
