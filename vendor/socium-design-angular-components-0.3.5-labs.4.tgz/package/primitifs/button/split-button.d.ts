import { type ButtonSize, type ButtonVariant } from './button';
import * as i0 from "@angular/core";
/**
 * Two real `<button>` elements internally (main action + dropdown trigger) — unlike `SocButton`,
 * this can't be a bare attribute selector: its host isn't itself a single clickable button, so
 * native `(click)` doesn't just pass through one level. Exposes `click`/`triggerClick` outputs
 * explicitly instead — matches React `SplitButtonProps` already being its own type rather than
 * extending `ButtonProps`, and its `onClick`/`onTriggerClick` being two distinct handlers.
 *
 * Reuses `SocButtonLeftIcon` from `./button` for its leading icon slot (React `SplitButton` only
 * has a `leftIcon` prop, no `rightIcon`) — same content-projection mechanism as `SocButton`, one
 * marker directive shared between both instead of a second one that would behave identically.
 *
 * The chevron is the one icon this component draws itself (`ChevronDown`, via `@lucide/angular` —
 * Angular's equivalent of `lucide-react`, already a dependency of `design_system`) — React
 * `SplitButton.tsx` does the same with `lucide-react`'s `ChevronDown`, nothing for a consumer to
 * project there.
 */
export declare class SocSplitButton {
    readonly variant: import("@angular/core").InputSignal<ButtonVariant>;
    readonly size: import("@angular/core").InputSignal<ButtonSize>;
    readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly triggerLabel: import("@angular/core").InputSignal<string>;
    readonly click: import("@angular/core").OutputEmitterRef<MouseEvent>;
    readonly triggerClick: import("@angular/core").OutputEmitterRef<MouseEvent>;
    protected readonly iconSize = "var(--index-button-button-icon-size)";
    protected readonly dividerWidth = "var(--index-button-split-divider-width)";
    protected readonly splitPad = "var(--index-button-split-split-pad)";
    protected readonly chevronSize = "var(--index-button-split-chevron-size)";
    protected readonly chevronThickness = "var(--index-button-split-chevron-thickness)";
    private readonly leftIconContent;
    protected readonly hasLeftIcon: import("@angular/core").Signal<boolean>;
    protected readonly mainButtonClasses: import("@angular/core").Signal<string>;
    protected readonly triggerButtonClasses: import("@angular/core").Signal<string>;
    protected readonly dividerClass: import("@angular/core").Signal<string>;
    protected readonly chevronColor: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocSplitButton, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocSplitButton, "soc-split-button", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "triggerLabel": { "alias": "triggerLabel"; "required": false; "isSignal": true; }; }, { "click": "click"; "triggerClick": "triggerClick"; }, ["leftIconContent"], ["[socButtonLeftIcon]", "*"], true, never>;
}
