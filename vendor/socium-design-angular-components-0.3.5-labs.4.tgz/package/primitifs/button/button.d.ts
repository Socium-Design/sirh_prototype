import * as i0 from "@angular/core";
export type ButtonVariant = 'primary' | 'secondary' | 'tertiary' | 'danger' | 'ghost';
export type ButtonSize = 'sm' | 'lg';
/**
 * Marks the element projected into `SocButton`'s leading icon slot (`<ng-content
 * select="[socButtonLeftIcon]">`) — see `SocButtonRightIcon` for the trailing one. Angular's
 * equivalent of React `Button`'s `leftIcon?: ReactNode` prop: the consumer supplies their own icon
 * (in `currentColor`), this component never draws one itself. A plain marker, not a real directive
 * behavior — only its selector matters, for `<ng-content>` routing and presence detection via
 * `contentChild()`.
 */
export declare class SocButtonLeftIcon {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocButtonLeftIcon, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocButtonLeftIcon, "[socButtonLeftIcon]", never, {}, {}, never, never, true, never>;
}
/** Trailing icon slot — see `SocButtonLeftIcon`. React `Button`'s `rightIcon?: ReactNode`. */
export declare class SocButtonRightIcon {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocButtonRightIcon, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocButtonRightIcon, "[socButtonRightIcon]", never, {}, {}, never, never, true, never>;
}
/**
 * Class names below must stay as literal strings (no template-built class names) — Tailwind's
 * compiler scans source text statically and can't see classes assembled at runtime. Each one maps
 * 1:1 to an "Index/Button/Button/*" or "Index/Button/Split/*" token from
 * packages/tokens/tokens/components/button.json in design_system (the React reference repo, read
 * only). Exported so `SocSplitButton` shares the exact same variant styling — mirrors React
 * `Button.tsx`'s own exported class maps verbatim.
 */
export declare const buttonPaddingClasses: Record<ButtonSize, string>;
export declare const buttonRadiusClasses: Record<ButtonSize, string>;
export declare const buttonRadiusLeftClasses: Record<ButtonSize, string>;
export declare const buttonRadiusRightClasses: Record<ButtonSize, string>;
export declare const buttonTypographyClass = "[font-family:var(--index-button-button-text-font-family)] [font-weight:var(--index-button-button-text-font-weight)] text-[length:var(--index-button-button-text-size)]";
export declare const buttonVariantClasses: Record<ButtonVariant, string>;
/** Both dimensions bind to the same token — `Button.tsx`'s `buttonIconSizeStyle` has `width` and
 * `height` set to the identical `var(--index-button-button-icon-size)` value. */
export declare const buttonIconSizeVar = "var(--index-button-button-icon-size)";
/**
 * Attribute selector on a real `<button>` — not a wrapper component — so native attributes and
 * events (`type`, `[disabled]`, `(click)`, `aria-label`, …) just work as plain HTML on the host
 * element, the Angular equivalent of React `Button`'s `...props` spread onto its own `<button>`.
 * No `output()`/`input()` re-declares any of them. See this repo's CLAUDE.md, "Attribute-selector
 * components" — the pattern to reuse for every future component wrapping a single native
 * interactive element (InputText, Checkbox, RadioButton, Switch…).
 *
 * `[class]` merges with any static `class` a consumer adds directly on the same `<button socButton
 * class="...">` — Angular composes host class bindings with a literal class attribute rather than
 * one overwriting the other, so there's no separate `className`-style input to accept and merge by
 * hand the way React's version needs one.
 */
export declare class SocButton {
    readonly variant: import("@angular/core").InputSignal<ButtonVariant>;
    readonly size: import("@angular/core").InputSignal<ButtonSize>;
    protected readonly iconSize = "var(--index-button-button-icon-size)";
    private readonly leftIconContent;
    private readonly rightIconContent;
    protected readonly hasLeftIcon: import("@angular/core").Signal<boolean>;
    protected readonly hasRightIcon: import("@angular/core").Signal<boolean>;
    protected readonly hostClasses: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocButton, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocButton, "button[socButton]", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, {}, ["leftIconContent", "rightIconContent"], ["[socButtonLeftIcon]", "*", "[socButtonRightIcon]"], true, never>;
}
