import * as i0 from "@angular/core";
/** React `Accordion`'s `rightSlot?: ReactNode` — extra content next to the label (info text, a
 * Tag, row actions, …). */
export declare class SocAccordionRightSlot {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocAccordionRightSlot, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocAccordionRightSlot, "[socAccordionRightSlot]", never, {}, {}, never, never, true, never>;
}
/**
 * No native HTML equivalent (the disclosure triangle is hand-rolled with a `<button>` + rotating
 * chevron, same as React — no `<details>`/`<summary>`) — plain wrapper (`soc-accordion`). Maps 1:1
 * to "Index/Conteneur/Accordion/*" tokens — see packages/tokens/tokens/components/conteneur.json
 * in design_system (React reference repo, read only). React's controlled-vs-uncontrolled
 * `open`/`defaultOpen` collapses to one `model()`, same reasoning as `Checkbox`/`Switch`.
 */
export declare class SocAccordion {
    readonly label: import("@angular/core").InputSignal<string>;
    readonly error: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly warning: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly open: import("@angular/core").ModelSignal<boolean>;
    protected readonly iconThickness = "var(--index-conteneur-accordion-icon-thickness)";
    private readonly rightSlotContent;
    protected readonly hasRightSlot: import("@angular/core").Signal<boolean>;
    protected toggle(): void;
    protected readonly hostClasses: import("@angular/core").Signal<string>;
    protected readonly headerClasses: import("@angular/core").Signal<string>;
    protected readonly chevronClasses: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocAccordion, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocAccordion, "soc-accordion", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "warning": { "alias": "warning"; "required": false; "isSignal": true; }; "open": { "alias": "open"; "required": false; "isSignal": true; }; }, { "open": "openChange"; }, ["rightSlotContent"], ["[socAccordionRightSlot]", "*"], true, never>;
}
