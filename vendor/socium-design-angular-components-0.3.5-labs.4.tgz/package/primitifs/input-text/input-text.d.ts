import { SocTextFieldBase } from '../../internal/form-control';
import * as i0 from "@angular/core";
/** GAP-DECISION (flagged, not decided silently): the migration spec's rule says text-input-like
 * primitives should be attribute selectors on the native element, for free native
 * attribute/event passthrough. That works for `Button` (a `<button>` can have projected content
 * around it inside its own tag), but `InputText` — read from the real source before writing this —
 * isn't a thin wrapper around a bare `<input>`: it renders a `<label>` BEFORE the field and a
 * helper-text row AFTER it, around a bordered container with icon slots. An attribute-selector
 * component's template can only fill the CONTENT of the element it decorates, and `<input>` is a
 * void element — it can't have any injected content at all, so there is no way to make an
 * attribute selector on `<input>` also render a sibling `<label>`/helper text. Used a wrapper
 * component instead (`soc-input-text`). What an attribute selector would have given for free is
 * rebuilt explicitly (see `SocTextFieldBase`): dedicated inputs for `id`/`name`/`autocomplete`/
 * `readonly`/`maxlength`, `inputClass` (React's `className` on the `<input>`), and `inputAttrs`
 * for any other native attribute; it is also a `ControlValueAccessor` (`formControl`,
 * `formControlName`, `ngModel`). Same shape applies to InputArea, InputNumber, Password.
 */
export declare class SocInputTextLeftIcon {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocInputTextLeftIcon, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocInputTextLeftIcon, "[socInputTextLeftIcon]", never, {}, {}, never, never, true, never>;
}
export declare class SocInputTextRightIcon {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocInputTextRightIcon, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocInputTextRightIcon, "[socInputTextRightIcon]", never, {}, {}, never, never, true, never>;
}
/** Maps 1:1 to "Index/Input/Input text/*" tokens — see packages/tokens/tokens/components/input.json
 * in design_system (React reference repo, read only). */
export declare class SocInputText extends SocTextFieldBase<string> {
    readonly type: import("@angular/core").InputSignal<string>;
    readonly maxlength: import("@angular/core").InputSignal<number | undefined>;
    /** The one property that actually needs two-way sync — `model()` gives `[(value)]` plus a
     * `valueChange` output for free, the Angular equivalent of React's `value`+`onChange` pair
     * (or `defaultValue` for the uncontrolled case, via the initial signal value). */
    readonly value: import("@angular/core").ModelSignal<string>;
    protected readonly valueModel: import("@angular/core").ModelSignal<string>;
    private readonly fieldRef;
    protected nativeField: () => HTMLInputElement | undefined;
    protected coerce(value: unknown): string;
    private readonly generatedId;
    protected get inputId(): string;
    protected readonly helpIconThickness = "var(--index-input-input-text-icon-help-thickness)";
    private readonly leftIconContent;
    private readonly rightIconContent;
    protected readonly hasLeftIcon: import("@angular/core").Signal<boolean>;
    protected readonly hasRightIcon: import("@angular/core").Signal<boolean>;
    protected readonly labelClass: import("@angular/core").Signal<string>;
    protected readonly fieldClass: import("@angular/core").Signal<string>;
    protected readonly helperTextClass: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocInputText, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocInputText, "soc-input-text", never, { "type": { "alias": "type"; "required": false; "isSignal": true; }; "maxlength": { "alias": "maxlength"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, ["leftIconContent", "rightIconContent"], ["[socInputTextLeftIcon]", "[socInputTextRightIcon]"], true, never>;
}
