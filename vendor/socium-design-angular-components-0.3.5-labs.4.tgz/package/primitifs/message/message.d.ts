import * as i0 from "@angular/core";
export type MessageStatus = 'success' | 'error' | 'warning' | 'info';
/** banner = "Type One" (filled, title+content+actions), inline = "Type Two" (pill bg),
 * plain = "Type Three" (no bg) — see packages/tokens/tokens/components/feedback.json. */
export type MessageVariant = 'banner' | 'inline' | 'plain';
export interface MessageAction {
    label: string;
    onClick?: () => void;
}
/** Marks a consumer-projected custom icon — React `Message`'s `icon?: ReactNode | null` prop, the
 * "override" branch (a plain `ReactNode`). React's `icon === undefined` (nothing passed at all)
 * defaults to a status-matching icon, and explicit `icon={null}` renders none — content projection
 * can't distinguish "nothing projected" from "explicitly told: render nothing" the way an optional
 * `ReactNode | null` prop can, so that second case is `hideIcon` below instead. */
export declare class SocMessageIcon {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocMessageIcon, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocMessageIcon, "[socMessageIcon]", never, {}, {}, never, never, true, never>;
}
/** React `Message`'s required `content: ReactNode` — content projection (not a string input)
 * since it accepts arbitrary rich content, same reasoning as `Button`'s icon slots. */
export declare class SocMessageContent {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocMessageContent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocMessageContent, "[socMessageContent]", never, {}, {}, never, never, true, never>;
}
/**
 * No native HTML equivalent — plain wrapper (`soc-message`). Maps 1:1 to
 * "Index/Feedback/Message/*" tokens — see packages/tokens/tokens/components/feedback.json in
 * design_system (React reference repo, read only). `primaryAction`/`secondaryAction` stay plain
 * `input()` objects (`{ label, onClick? }`), matching React's own `MessageAction` shape exactly —
 * the click handler is consumer-supplied data on the object itself, not a component-level
 * notification, so no separate `output()` per action.
 *
 * Composition constraint carried over verbatim from React's own docstring — the "banner" variant
 * always sits top-right of the main content zone (24px from its right/top edges, right of
 * SiteNavigation, never relative to the whole window); this is fixed positioning, not a per-screen
 * choice. No 4th "outlined" variant either — Figma defines exactly banner/inline/plain.
 */
export declare class SocMessage {
    readonly status: import("@angular/core").InputSignal<MessageStatus>;
    readonly variant: import("@angular/core").InputSignal<MessageVariant>;
    /** Equivalent of React's explicit `icon={null}` — suppresses the icon entirely, default (false)
     * matches React's default behavior of always showing one. */
    readonly hideIcon: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly title: import("@angular/core").InputSignal<string | undefined>;
    readonly primaryAction: import("@angular/core").InputSignal<MessageAction | undefined>;
    readonly secondaryAction: import("@angular/core").InputSignal<MessageAction | undefined>;
    protected readonly iconThickness = "var(--index-feedback-message-icon-thickness)";
    protected readonly inlineIconClasses: Record<MessageStatus, string>;
    protected readonly inlineTextClasses: Record<MessageStatus, string>;
    private readonly customIconContent;
    protected readonly hasCustomIcon: import("@angular/core").Signal<boolean>;
    protected readonly hostClasses: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocMessage, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocMessage, "soc-message", never, { "status": { "alias": "status"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "hideIcon": { "alias": "hideIcon"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "primaryAction": { "alias": "primaryAction"; "required": false; "isSignal": true; }; "secondaryAction": { "alias": "secondaryAction"; "required": false; "isSignal": true; }; }, {}, ["customIconContent"], ["[socMessageIcon]", "[socMessageContent]"], true, never>;
}
