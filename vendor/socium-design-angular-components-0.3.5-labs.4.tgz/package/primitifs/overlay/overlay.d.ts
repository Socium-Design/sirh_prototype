import * as i0 from "@angular/core";
/**
 * Full-bleed dark backdrop — sits behind a Dialog/Drawer/floating panel. Standalone: neither
 * Dialog nor Drawer render one themselves yet (not migrated in this batch either), so pair this
 * manually (`@if (open()) { <soc-overlay /> }`) until they do — same as React's own doc comment.
 * Maps 1:1 to "Index/Conteneur/Overlay/*" tokens — see packages/tokens/tokens/components/conteneur.json
 * in design_system (React reference repo, read only). `onClick` is a direct component-level
 * handler -> output(), same reasoning as every other direct handler prop this batch.
 */
export declare class SocOverlay {
    readonly overlayClick: import("@angular/core").OutputEmitterRef<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocOverlay, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocOverlay, "soc-overlay", never, {}, { "overlayClick": "overlayClick"; }, never, never, true, never>;
}
