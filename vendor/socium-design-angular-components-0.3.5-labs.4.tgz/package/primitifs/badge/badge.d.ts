import * as i0 from "@angular/core";
export type BadgeColor = 'primary' | 'success' | 'warning' | 'danger';
export type BadgeSize = 'sm' | 'lg';
/**
 * No native HTML equivalent — plain wrapper (`soc-badge` element selector). `children: ReactNode`
 * becomes a default `<ng-content>` (no named slot needed, there's only one content region).
 *
 * Maps 1:1 to "Index/Feedback/Badge/*" tokens — see packages/tokens/tokens/components/feedback.json
 * in design_system (React reference repo, read only).
 */
export declare class SocBadge {
    readonly color: import("@angular/core").InputSignal<BadgeColor>;
    readonly size: import("@angular/core").InputSignal<BadgeSize>;
    protected readonly hostClasses: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocBadge, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocBadge, "soc-badge", never, { "color": { "alias": "color"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
