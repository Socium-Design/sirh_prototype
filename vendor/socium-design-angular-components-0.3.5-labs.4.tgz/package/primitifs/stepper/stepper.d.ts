import * as i0 from "@angular/core";
export type StepperItemStatus = 'completed' | 'current' | 'upcoming';
export interface StepperItemData {
    label: string;
    status: StepperItemStatus;
}
export type StepperOrientation = 'horizontal' | 'vertical';
/**
 * No native HTML equivalent — plain wrapper (`soc-stepper`). `items: StepperItemData[]` is plain
 * data, a straight `input()`. Maps 1:1 to "Index/Navigation/Stepper/*" tokens — see
 * packages/tokens/tokens/components/navigation.json in design_system (React reference repo, read
 * only).
 */
export declare class SocStepper {
    readonly items: import("@angular/core").InputSignal<StepperItemData[]>;
    readonly orientation: import("@angular/core").InputSignal<StepperOrientation>;
    protected readonly vertical: import("@angular/core").Signal<boolean>;
    protected readonly hostClasses: import("@angular/core").Signal<string>;
    private active;
    protected horizontalSeparatorClass(status: StepperItemStatus): string;
    protected verticalSeparatorClass(status: StepperItemStatus): string;
    protected circleClass(status: StepperItemStatus): string;
    protected labelClass(status: StepperItemStatus): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocStepper, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocStepper, "soc-stepper", never, { "items": { "alias": "items"; "required": true; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
