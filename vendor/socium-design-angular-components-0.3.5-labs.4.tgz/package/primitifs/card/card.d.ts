import * as i0 from "@angular/core";
export type CardType = 'default' | 'selectable';
/** Content slots — React's `icon`/`actionSlot`/`footer` (all `ReactNode`) and `children`. `children`
 * stays the default unnamed `<ng-content>` (there's no ambiguity with the other three, all named). */
export declare class SocCardIcon {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocCardIcon, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocCardIcon, "[socCardIcon]", never, {}, {}, never, never, true, never>;
}
export declare class SocCardActionSlot {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocCardActionSlot, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocCardActionSlot, "[socCardActionSlot]", never, {}, {}, never, never, true, never>;
}
export declare class SocCardFooter {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocCardFooter, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocCardFooter, "[socCardFooter]", never, {}, {}, never, never, true, never>;
}
/**
 * No native HTML equivalent — plain wrapper (`soc-card`). Maps 1:1 to "Index/Conteneur/Card/*"
 * tokens — see packages/tokens/tokens/components/conteneur.json in design_system (React reference
 * repo, read only). `colSpan`/`rowSpan` only matter inside a `soc-card-grid` in `mode="bento"` —
 * see that component's own docstring for the 75%-of-row clamp rule. The *rendered* span is resolved
 * here from `CARD_GRID_CONTEXT` (see `internal/card-grid-context.ts`), because React's
 * `cloneElement` rewrite of a child's props has no Angular equivalent; a card with no grid ancestor
 * renders exactly the span it was given, same as React.
 *
 * `children` presence (`{children && <div>...}` in React) is checked via a content query — Angular
 * has no direct way to ask "was any content passed to the default `<ng-content>` slot", so this
 * uses `contentChild` against a broad marker... actually, kept simpler: unlike named slots, the
 * default slot's presence can't be queried the same way, so the content wrapper always renders
 * (an empty content region is harmless — no min-height without content, `min-h-0` already handles
 * that) rather than reproducing the exact conditional. Documented here since it's a deliberate,
 * minor behavior difference, not an oversight.
 */
export declare class SocCard {
    readonly title: import("@angular/core").InputSignal<string>;
    readonly subtitle: import("@angular/core").InputSignal<string | undefined>;
    readonly type: import("@angular/core").InputSignal<CardType>;
    readonly colSpan: import("@angular/core").InputSignal<2 | 1 | 3>;
    readonly rowSpan: import("@angular/core").InputSignal<2 | 1>;
    readonly action: import("@angular/core").OutputEmitterRef<void>;
    readonly cardClick: import("@angular/core").OutputEmitterRef<void>;
    protected readonly actionIconThickness = "var(--index-conteneur-card-action-icon-thickness)";
    private readonly iconContent;
    private readonly actionSlotContent;
    private readonly footerContent;
    protected readonly hasIcon: import("@angular/core").Signal<boolean>;
    protected readonly hasActionSlot: import("@angular/core").Signal<boolean>;
    protected readonly hasFooter: import("@angular/core").Signal<boolean>;
    protected handleActionClick(event: MouseEvent): void;
    protected handleHostClick(): void;
    private readonly grid;
    private readonly placement;
    protected readonly hostClasses: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocCard, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocCard, "soc-card", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "colSpan": { "alias": "colSpan"; "required": false; "isSignal": true; }; "rowSpan": { "alias": "rowSpan"; "required": false; "isSignal": true; }; }, { "action": "action"; "cardClick": "cardClick"; }, ["iconContent", "actionSlotContent", "footerContent"], ["[socCardIcon]", "[socCardActionSlot]", "*", "[socCardFooter]"], true, never>;
}
