import { SocFormControl } from '../../internal/form-control';
import * as i0 from "@angular/core";
/** Same structural GAP-DECISION as InputText — its outer element is a `<div>` with a sibling icon
 * before and a sibling clear button after the `<input>`, not the `<input>` itself, so an attribute
 * selector on `<input>` alone couldn't render them (see InputText's own docstring for the full
 * reasoning; not repeated here). Wrapper component (`soc-search-bar`) instead.
 *
 * Maps 1:1 to "Index/Input/SearchBar/*" tokens — see packages/tokens/tokens/components/input.json
 * in design_system (React reference repo, read only). No fixed height of its own on purpose, same
 * as React — see that file's own doc comment: Figma gives this field a different flat height per
 * usage context, so each consumer applies its own height token via `class` rather than this
 * component picking one to hardcode.
 */
export declare class SocSearchBar extends SocFormControl<string> {
    readonly placeholder: import("@angular/core").InputSignal<string>;
    readonly value: import("@angular/core").ModelSignal<string>;
    protected readonly valueModel: import("@angular/core").ModelSignal<string>;
    protected coerce(value: unknown): string;
    readonly clear: import("@angular/core").OutputEmitterRef<void>;
    private readonly inputRef;
    protected readonly iconThickness = "var(--index-input-searchbar-icon-thickness)";
    protected readonly hasValue: import("@angular/core").Signal<boolean>;
    protected handleClear(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocSearchBar, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocSearchBar, "soc-search-bar", never, { "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "clear": "clear"; }, never, never, true, never>;
}
