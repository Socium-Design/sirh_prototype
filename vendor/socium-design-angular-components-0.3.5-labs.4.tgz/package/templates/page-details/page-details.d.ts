import * as i0 from "@angular/core";
/**
 * ## Rôle
 * Présenter en lecture les informations complètes d'un seul objet métier (non-personne), organisées en
 * sections, avec des actions contextuelles (modifier, supprimer, valider…). Pour une personne →
 * `soc-page-profile`; créer/modifier → `soc-page-form`; une liste → `soc-page-list`.
 *
 * ## Contraintes de composition (inchangées par rapport à React)
 * - Seul le Breadcrumb a son propre padding vertical; l'espacement entre zones vient du `content-gap`
 *   du conteneur scrollable. Padding-bottom fixe de 120px non exposé. Aucune surcharge de style.
 * - Les boutons de `socPageActions` sont toujours en variante `tertiary`, icône seule (`aria-label`),
 *   chacun enveloppé dans `<soc-tooltip>` (même texte) pour que son nom soit visible au survol — c'est
 *   au consommateur de le faire, `socPageActions` est un slot libre.
 *
 * `onBack` (React: sa présence affiche le bouton "Retour") -> `showBack` + sortie `back`, même décision
 * que partout dans le kit (un `output()` ne peut pas dire s'il a un abonné). Slots: `socPageBreadcrumb`,
 * `socPageBadge`, `socPageTag`, `socPageActions`, `socPageTabs`; contenu par défaut = `children`, empilé
 * avec un gap constant.
 *
 * Maps 1:1 to "Index/Template/PageDetails/*" tokens — see packages/tokens/tokens/components/template.json.
 */
export declare class SocPageDetails {
    readonly showBack: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly backLabel: import("@angular/core").InputSignal<string>;
    /** Small label above the title. */
    readonly topStatusLabel: import("@angular/core").InputSignal<string | undefined>;
    readonly title: import("@angular/core").InputSignal<string>;
    readonly statusLabel: import("@angular/core").InputSignal<string | undefined>;
    readonly description: import("@angular/core").InputSignal<string | undefined>;
    readonly back: import("@angular/core").OutputEmitterRef<void>;
    private readonly actionsContent;
    private readonly tabsContent;
    protected readonly hasActions: import("@angular/core").Signal<boolean>;
    protected readonly hasTabs: import("@angular/core").Signal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocPageDetails, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocPageDetails, "soc-page-details", never, { "showBack": { "alias": "showBack"; "required": false; "isSignal": true; }; "backLabel": { "alias": "backLabel"; "required": false; "isSignal": true; }; "topStatusLabel": { "alias": "topStatusLabel"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": true; "isSignal": true; }; "statusLabel": { "alias": "statusLabel"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; }, { "back": "back"; }, ["actionsContent", "tabsContent"], ["[socPageBreadcrumb]", "[socPageBadge]", "[socPageTag]", "[socPageActions]", "[socPageTabs]", "*"], true, never>;
}
