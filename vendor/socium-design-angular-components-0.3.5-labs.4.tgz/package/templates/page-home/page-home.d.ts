import * as i0 from "@angular/core";
/**
 * ## Rôle
 * Page d'accueil d'un produit Socium: bannière de bienvenue personnalisée, recherche globale, puis une
 * section de contenu libre (`children`: grille de `soc-card`, `soc-data-table`, raccourcis…).
 * Pour une liste → `soc-page-list`; un détail/profil → `soc-page-details`/`soc-page-profile`.
 *
 * ## Contraintes de composition
 * Comme `soc-page-list`: seul le Breadcrumb a son propre padding vertical, le reste tire son espacement
 * du `content-gap` du conteneur scrollable. `welcome-pad-h`/`search-pad-h`/`section-pad-h` sont trois
 * tokens distincts (24px chacun aujourd'hui) pour pouvoir diverger si Figma les sépare un jour.
 *
 * - La bannière (fond + label + description) ne s'affiche que si `welcomeTitle` est donné.
 * - `onSearch` (sa présence affiche la recherche) -> `searchable` + sortie `search` (texte brut à chaque
 *   frappe, présentationnel: ne filtre rien lui-même) — même décision que `DataTable`.
 * - `sectionActions` -> slot `socPageSectionActions`, affiché seulement avec `sectionTitle` (comme Figma).
 * - Slot `socPageBreadcrumb`; padding-bottom fixe de 120px non exposé.
 *
 * Le fond de la bannière est `.pagehome-welcome-bg` (`styles/images.css`, JPEG embarqué).
 * Maps 1:1 to "Index/Template/PageHome/*" tokens — see packages/tokens/tokens/components/template.json.
 */
export declare class SocPageHome {
    /** Small label above the welcome title (Figma: "Accueil"). */
    readonly welcomeLabel: import("@angular/core").InputSignal<string | undefined>;
    /** The banner's headline, e.g. "Bienvenue {name}" — its presence shows/hides the whole banner. */
    readonly welcomeTitle: import("@angular/core").InputSignal<string | undefined>;
    readonly welcomeDescription: import("@angular/core").InputSignal<string | undefined>;
    readonly searchable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly search: import("@angular/core").OutputEmitterRef<string>;
    readonly sectionTitle: import("@angular/core").InputSignal<string | undefined>;
    readonly sectionSubtitle: import("@angular/core").InputSignal<string | undefined>;
    private readonly sectionActionsContent;
    protected readonly hasSectionActions: import("@angular/core").Signal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocPageHome, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocPageHome, "soc-page-home", never, { "welcomeLabel": { "alias": "welcomeLabel"; "required": false; "isSignal": true; }; "welcomeTitle": { "alias": "welcomeTitle"; "required": false; "isSignal": true; }; "welcomeDescription": { "alias": "welcomeDescription"; "required": false; "isSignal": true; }; "searchable": { "alias": "searchable"; "required": false; "isSignal": true; }; "sectionTitle": { "alias": "sectionTitle"; "required": false; "isSignal": true; }; "sectionSubtitle": { "alias": "sectionSubtitle"; "required": false; "isSignal": true; }; }, { "search": "search"; }, ["sectionActionsContent"], ["[socPageBreadcrumb]", "[socPageSectionActions]", "*"], true, never>;
}
