import * as i0 from "@angular/core";
/**
 * ## Rôle
 * Présenter le profil complet d'une personne (employé, utilisateur connecté), avec une structure centrée
 * sur l'identité — avatar, nom, poste en en-tête. Pour un objet non-personne → `soc-page-details`.
 *
 * ## Cas particuliers
 * Plusieurs onglets/sections selon le produit; la structure d'en-tête (identité) reste fixe. "Vue par
 * soi-même" vs "vue par un gestionnaire": même structure, actions différentes.
 *
 * ## Zone flexible (slot) et éléments optionnels
 * Le contenu par défaut (`children`) est libre: choisir les composants du DS adaptés au besoin réel,
 * ne jamais le laisser vide. Pour un élément optionnel que les specs ne tranchent pas, demander
 * confirmation à l'utilisateur plutôt que de décider seul.
 *
 * `onBack` -> `showBack` + sortie `back` (voir `soc-page-details`). `className` de React = `class` sur
 * l'hôte. Slots: `socPageBreadcrumb`, `socPageHeader` (identité, typiquement `soc-profile-line`),
 * `socPageTag`, `socPageTabs`, `socPageMessage`. Pas de padding-bottom de 120px ici, comme en React.
 *
 * Maps 1:1 to "Index/Template/PageProfile/*" tokens — see packages/tokens/tokens/components/template.json.
 */
export declare class SocPageProfile {
    readonly showBack: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly backLabel: import("@angular/core").InputSignal<string>;
    readonly statusLabel: import("@angular/core").InputSignal<string | undefined>;
    readonly back: import("@angular/core").OutputEmitterRef<void>;
    private readonly tabsContent;
    private readonly messageContent;
    protected readonly hasTabs: import("@angular/core").Signal<boolean>;
    protected readonly hasMessage: import("@angular/core").Signal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocPageProfile, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocPageProfile, "soc-page-profile", never, { "showBack": { "alias": "showBack"; "required": false; "isSignal": true; }; "backLabel": { "alias": "backLabel"; "required": false; "isSignal": true; }; "statusLabel": { "alias": "statusLabel"; "required": false; "isSignal": true; }; }, { "back": "back"; }, ["tabsContent", "messageContent"], ["[socPageBreadcrumb]", "[socPageHeader]", "[socPageTag]", "[socPageTabs]", "[socPageMessage]", "*"], true, never>;
}
