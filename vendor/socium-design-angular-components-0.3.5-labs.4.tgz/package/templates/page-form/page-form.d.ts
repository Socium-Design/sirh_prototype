import * as i0 from "@angular/core";
/**
 * Page de création/modification d'un objet: titre, stepper et message optionnels, une section de
 * formulaire (`children`, colonne de 595px) avec ses actions alignées à droite, puis un second bloc
 * optionnel (`socPageSecondContent`) avec son propre titre de section.
 *
 * `onBack` -> `showBack` + sortie `back` (voir `soc-page-details`). Slots: `socPageBreadcrumb`,
 * `socPageStepper`, `socPageMessage`, `socPageActions`, `socPageSecondContent`. Padding-bottom fixe de
 * 120px, comme `soc-page-list`. Les champs placés dans le slot par défaut sont typiquement des
 * `soc-input-text`… liés à un `FormGroup` (voir Guides/Formulaires).
 *
 * Maps 1:1 to "Index/Template/PageForm/*" tokens — see packages/tokens/tokens/components/template.json
 * in design_system (React reference repo, read only).
 */
export declare class SocPageForm {
    readonly showBack: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly backLabel: import("@angular/core").InputSignal<string>;
    readonly title: import("@angular/core").InputSignal<string>;
    readonly description: import("@angular/core").InputSignal<string | undefined>;
    readonly sectionTitle: import("@angular/core").InputSignal<string | undefined>;
    readonly sectionSubtitle: import("@angular/core").InputSignal<string | undefined>;
    readonly secondSectionTitle: import("@angular/core").InputSignal<string | undefined>;
    readonly secondSectionSubtitle: import("@angular/core").InputSignal<string | undefined>;
    readonly back: import("@angular/core").OutputEmitterRef<void>;
    private readonly stepperContent;
    private readonly messageContent;
    private readonly actionsContent;
    private readonly secondContent;
    protected readonly hasStepper: import("@angular/core").Signal<boolean>;
    protected readonly hasMessage: import("@angular/core").Signal<boolean>;
    protected readonly hasActions: import("@angular/core").Signal<boolean>;
    protected readonly hasSecondContent: import("@angular/core").Signal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocPageForm, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocPageForm, "soc-page-form", never, { "showBack": { "alias": "showBack"; "required": false; "isSignal": true; }; "backLabel": { "alias": "backLabel"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": true; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "sectionTitle": { "alias": "sectionTitle"; "required": false; "isSignal": true; }; "sectionSubtitle": { "alias": "sectionSubtitle"; "required": false; "isSignal": true; }; "secondSectionTitle": { "alias": "secondSectionTitle"; "required": false; "isSignal": true; }; "secondSectionSubtitle": { "alias": "secondSectionSubtitle"; "required": false; "isSignal": true; }; }, { "back": "back"; }, ["stepperContent", "messageContent", "actionsContent", "secondContent"], ["[socPageBreadcrumb]", "[socPageStepper]", "[socPageMessage]", "*", "[socPageActions]", "[socPageSecondContent]"], true, never>;
}
