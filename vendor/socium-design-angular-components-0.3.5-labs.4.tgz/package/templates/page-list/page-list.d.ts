import * as i0 from "@angular/core";
/**
 * ## Rôle
 * Afficher une liste d'instances d'un même type d'objet métier, avec recherche, filtres et
 * pagination, avant d'accéder au détail de l'un d'eux.
 *
 * ## Quand l'utiliser / ne pas l'utiliser
 * Chaque fois qu'un écran présente plusieurs éléments du même type à parcourir ou filtrer. Pour un seul
 * objet → `soc-page-details`; une personne → `soc-page-profile`; créer/modifier → `soc-page-form`.
 *
 * ## Contraintes de composition (inchangées par rapport à React)
 * - Seul le Breadcrumb a son propre padding vertical; l'espacement entre les autres zones vient
 *   uniquement du `content-gap` du conteneur scrollable — jamais un padding-top/bottom par zone.
 * - Le conteneur scrollable a un padding-bottom fixe de 120px (aucun token de l'échelle Position ne le
 *   couvre), non exposé. Aucune surcharge de style/espacement depuis l'extérieur : corriger le token.
 * - Liste vide → `Empty State`; sélection multiple → zone d'actions contextuelles; liste volumineuse →
 *   pagination obligatoire.
 *
 * Slots (marqueurs de `page-slots.ts`): `socPageBreadcrumb`, `socPageSecondaryTabs`, `socPageBadge`,
 * `socPageActions`, `socPageTabs`; contenu par défaut = `children` (typiquement un `soc-data-table`).
 * `title` est requis, `statusLabel`/`description` optionnels.
 *
 * Maps 1:1 to "Index/Template/PageList/*" tokens — see packages/tokens/tokens/components/template.json
 * in design_system (React reference repo, read only). `fourth-bg` (not `page-bg`) for the content
 * background; `page-bg` and the left inset belong to `soc-app-shell`'s Content Zone.
 */
export declare class SocPageList {
    readonly title: import("@angular/core").InputSignal<string>;
    readonly statusLabel: import("@angular/core").InputSignal<string | undefined>;
    readonly description: import("@angular/core").InputSignal<string | undefined>;
    private readonly secondaryTabsContent;
    private readonly actionsContent;
    private readonly tabsContent;
    protected readonly hasSecondaryTabs: import("@angular/core").Signal<boolean>;
    protected readonly hasActions: import("@angular/core").Signal<boolean>;
    protected readonly hasTabs: import("@angular/core").Signal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocPageList, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocPageList, "soc-page-list", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "statusLabel": { "alias": "statusLabel"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; }, {}, ["secondaryTabsContent", "actionsContent", "tabsContent"], ["[socPageBreadcrumb]", "[socPageSecondaryTabs]", "[socPageBadge]", "[socPageActions]", "[socPageTabs]", "*"], true, never>;
}
