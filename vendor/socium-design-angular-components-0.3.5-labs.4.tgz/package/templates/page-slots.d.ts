import * as i0 from "@angular/core";
/**
 * Content-slot markers shared by the page templates (`PageList`, `PageDetails`, `PageForm`,
 * `PageProfile`, `PageHome`) — React's `ReactNode` props (`breadcrumb`, `badge`, `actions`, `tabs`, …)
 * become named `<ng-content>` slots, selected by these attributes. One set for all templates: the same
 * slot reads the same everywhere (`<soc-breadcrumb socPageBreadcrumb>`, `<div socPageActions>`), and
 * each template simply ignores the markers it has no slot for. The default (unnamed) slot is always
 * React's `children`.
 */
export declare class SocPageBreadcrumb {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocPageBreadcrumb, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocPageBreadcrumb, "[socPageBreadcrumb]", never, {}, {}, never, never, true, never>;
}
/** Secondary tab row above the page header (`PageList`) — typically a pill `soc-tabs`. */
export declare class SocPageSecondaryTabs {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocPageSecondaryTabs, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocPageSecondaryTabs, "[socPageSecondaryTabs]", never, {}, {}, never, never, true, never>;
}
/** Badge next to the title (`PageList`, `PageDetails`). */
export declare class SocPageBadge {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocPageBadge, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocPageBadge, "[socPageBadge]", never, {}, {}, never, never, true, never>;
}
/** Tag next to the title (`PageDetails`, `PageProfile`). */
export declare class SocPageTag {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocPageTag, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocPageTag, "[socPageTag]", never, {}, {}, never, never, true, never>;
}
/** Buttons rendered top-right of the header (`PageList`, `PageDetails`) or under the form (`PageForm`). */
export declare class SocPageActions {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocPageActions, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocPageActions, "[socPageActions]", never, {}, {}, never, never, true, never>;
}
/** Tab row below the header — typically a `soc-tabs`. */
export declare class SocPageTabs {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocPageTabs, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocPageTabs, "[socPageTabs]", never, {}, {}, never, never, true, never>;
}
/** Identity block (`PageProfile`) — typically a `soc-profile-line`. */
export declare class SocPageHeader {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocPageHeader, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocPageHeader, "[socPageHeader]", never, {}, {}, never, never, true, never>;
}
/** Stepper zone (`PageForm`). */
export declare class SocPageStepper {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocPageStepper, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocPageStepper, "[socPageStepper]", never, {}, {}, never, never, true, never>;
}
/** Message zone (`PageForm`, `PageProfile`) — typically a `soc-message`. */
export declare class SocPageMessage {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocPageMessage, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocPageMessage, "[socPageMessage]", never, {}, {}, never, never, true, never>;
}
/** Second content block with its own section title (`PageForm`). */
export declare class SocPageSecondContent {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocPageSecondContent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocPageSecondContent, "[socPageSecondContent]", never, {}, {}, never, never, true, never>;
}
/** Buttons next to the section title (`PageHome`). */
export declare class SocPageSectionActions {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocPageSectionActions, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocPageSectionActions, "[socPageSectionActions]", never, {}, {}, never, never, true, never>;
}
