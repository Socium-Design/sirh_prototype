import type { NavigationProduct } from '../../primitifs/side-navigation/navigation-presets';
import { LanguageOption } from '../../composes/language-select/language-select';
import * as i0 from "@angular/core";
export type AppShellProduct = NavigationProduct;
export interface AppShellHeaderUser {
    name: string;
    email: string;
    /** Initials shown in the avatar circle — 2 characters max. */
    avatarLabel: string;
}
/** HeaderApp's `left` slot — typically a `soc-enterprise-select`. Never a fixed generic instance: its
 * content depends on the signed-in user/enterprise context, which only the consumer has. */
export declare class SocAppShellHeaderLeft {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocAppShellHeaderLeft, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocAppShellHeaderLeft, "[socAppShellHeaderLeft]", never, {}, {}, never, never, true, never>;
}
/** HeaderApp's `avatar` slot — typically a `soc-avatar` (size="md", mode="solid"). */
export declare class SocAppShellHeaderAvatar {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocAppShellHeaderAvatar, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocAppShellHeaderAvatar, "[socAppShellHeaderAvatar]", never, {}, {}, never, never, true, never>;
}
/** Advanced/custom escape hatch — full control over the avatar menu's content, for cases `user` +
 * `showViewProfile`/`showEditAvatar`/`(disconnect)` can't express. Wins over `user` if both are given. */
export declare class SocAppShellHeaderAvatarMenu {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocAppShellHeaderAvatarMenu, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocAppShellHeaderAvatarMenu, "[socAppShellHeaderAvatarMenu]", never, {}, {}, never, never, true, never>;
}
/** Advanced/custom escape hatch for the language control — same idea; wins over `languages`. */
export declare class SocAppShellHeaderLanguageSelect {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocAppShellHeaderLanguageSelect, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocAppShellHeaderLanguageSelect, "[socAppShellHeaderLanguageSelect]", never, {}, {}, never, never, true, never>;
}
/**
 * ## Rôle
 * Conteneur racine de toute page applicative du Design System: assemble AppSwitch, HeaderApp,
 * SideNavigation et la Content Zone dans une seule structure fixe, identique quel que soit le produit ou
 * l'écran. À utiliser systématiquement comme racine d'une page applicative (jamais deux imbriqués, jamais
 * pour un écran hors-application: connexion, erreur plein écran).
 *
 * ## Cas particuliers
 * - `product` pilote à la fois AppSwitch (icône sélectionnée) et SideNavigation (contenu du menu): les
 *   deux ne doivent jamais être synchronisés manuellement ni diverger.
 * - SideNavigation reste scrollable indépendamment de la Content Zone.
 * - Espacements internes verrouillés (tokens du DS): aucune surcharge `style`/`class`/gap/padding.
 *
 * ## Menu avatar et sélecteur de langue
 * Usage recommandé: `[user]="{ name, email, avatarLabel }"` + `(disconnect)` (+ `showViewProfile`/
 * `showEditAvatar`) et `[languages]` + `[(language)]` — AppShell construit et câble lui-même
 * `soc-avatar-menu`/`soc-language-select`. `socAppShellHeaderAvatarMenu`/`socAppShellHeaderLanguageSelect`
 * restent en secours pour un contenu totalement custom (ils gagnent si les deux sont fournis).
 *
 * ## Différences avec React (décisions signalées)
 * 1. `product`, `navSelectedId`, `navCollapsed`, `language` sont des `model()` (`[(product)]`…): AppShell
 *    suit le clic tout seul, là où React exige que le parent mette à jour `navSelectedId`/`navCollapsed`
 *    depuis `onNavSelect`/`onNavToggleCollapse` (sinon l'item actif ne bouge pas et le bouton de repli ne
 *    fait rien). Les sorties `productChange`/`navSelectedIdChange`/`navCollapsedChange`/`languageChange`
 *    jouent le rôle des callbacks React; le routage de la page affichée reste au consommateur.
 * 2. `onViewProfile`/`onEditAvatar` (leur présence affichait les boutons) -> `showViewProfile`/
 *    `showEditAvatar` + sorties (même décision que `soc-avatar-menu`).
 * 3. Slots `ReactNode` (`headerLeft`, `headerAvatar`, `headerAvatarMenu`, `headerLanguageSelect`) ->
 *    marqueurs `socAppShellHeader*`. Chacun est ré-exposé à HeaderApp via un wrapper `display: contents`
 *    déclaré ici: un `<ng-content>` transmis tel quel ne porterait pas les marqueurs de HeaderApp, et les
 *    requêtes de contenu de HeaderApp ne voient que les nœuds déclarés dans CE template.
 * 4. `children` = la page (`soc-page-list`/`details`/`form`/`profile`/`home`) dans la Content Zone.
 *
 * Maps 1:1 to "Index/Template/AppShell/*" tokens — see packages/tokens/tokens/components/template.json.
 */
export declare class SocAppShell {
    /** Which app is active — drives AppSwitch's selected icon and SideNavigation's preset content at
     * once. AppShell has no meaningful "no product" state, so this is required. */
    readonly product: import("@angular/core").ModelSignal<NavigationProduct>;
    /** Forwarded to HeaderApp's `userName` — rendered in its AvatarZone next to the avatar slot. */
    readonly headerUserName: import("@angular/core").InputSignal<string>;
    readonly helpClick: import("@angular/core").OutputEmitterRef<void>;
    readonly notificationsClick: import("@angular/core").OutputEmitterRef<void>;
    /** Signed-in user shown in the avatar menu — standard way to get a clickable avatar menu. */
    readonly user: import("@angular/core").InputSignal<AppShellHeaderUser | undefined>;
    readonly showViewProfile: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly showEditAvatar: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly viewProfile: import("@angular/core").OutputEmitterRef<void>;
    readonly editAvatar: import("@angular/core").OutputEmitterRef<void>;
    readonly disconnect: import("@angular/core").OutputEmitterRef<void>;
    /** Standard way to get a language control next to the notification icon. */
    readonly languages: import("@angular/core").InputSignal<LanguageOption[] | undefined>;
    readonly language: import("@angular/core").ModelSignal<string | undefined>;
    /** Which item is highlighted within the product's preset menu. Kept in sync with the clicked item;
     * the consumer reacts to `navSelectedIdChange` to show the matching page. */
    readonly navSelectedId: import("@angular/core").ModelSignal<string | undefined>;
    readonly navCollapsed: import("@angular/core").ModelSignal<boolean>;
    private readonly customAvatarMenu;
    private readonly customLanguageSelect;
    protected readonly hasCustomAvatarMenu: import("@angular/core").Signal<boolean>;
    protected readonly hasCustomLanguageSelect: import("@angular/core").Signal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocAppShell, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocAppShell, "soc-app-shell", never, { "product": { "alias": "product"; "required": true; "isSignal": true; }; "headerUserName": { "alias": "headerUserName"; "required": true; "isSignal": true; }; "user": { "alias": "user"; "required": false; "isSignal": true; }; "showViewProfile": { "alias": "showViewProfile"; "required": false; "isSignal": true; }; "showEditAvatar": { "alias": "showEditAvatar"; "required": false; "isSignal": true; }; "languages": { "alias": "languages"; "required": false; "isSignal": true; }; "language": { "alias": "language"; "required": false; "isSignal": true; }; "navSelectedId": { "alias": "navSelectedId"; "required": false; "isSignal": true; }; "navCollapsed": { "alias": "navCollapsed"; "required": false; "isSignal": true; }; }, { "product": "productChange"; "helpClick": "helpClick"; "notificationsClick": "notificationsClick"; "viewProfile": "viewProfile"; "editAvatar": "editAvatar"; "disconnect": "disconnect"; "language": "languageChange"; "navSelectedId": "navSelectedIdChange"; "navCollapsed": "navCollapsedChange"; }, ["customAvatarMenu", "customLanguageSelect"], ["[socAppShellHeaderLeft]", "[socAppShellHeaderAvatar]", "[socAppShellHeaderLanguageSelect]", "[socAppShellHeaderAvatarMenu]", "*"], true, never>;
}
