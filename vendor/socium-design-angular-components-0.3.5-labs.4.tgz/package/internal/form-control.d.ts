import { ModelSignal, Provider, Type } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import * as i0 from "@angular/core";
/** Registers a component as its own `ControlValueAccessor` (`formControl`, `formControlName`,
 * `ngModel`). `type` is a thunk because the class isn't defined yet where the decorator runs. */
export declare function provideFormControl(type: () => Type<unknown>): Provider;
/** Plain native attributes forwarded to the inner control — the Angular counterpart of React's
 * `{...props}` spread on `<input>`: anything without a dedicated input (`inputmode`, `pattern`,
 * `aria-*`, `data-*`, `autofocus`, …). `null`/`undefined`/`false` remove the attribute, `true` sets
 * it empty (boolean attribute), anything else is stringified. */
export type NativeAttributes = Record<string, string | number | boolean | null | undefined>;
/** Keeps `attrs()` applied on the element returned by `element()`; call from an injection context. */
export declare function syncNativeAttributes(element: () => HTMLElement | undefined, attrs: () => NativeAttributes | undefined): void;
/**
 * Turns a component whose value already lives in a `model()` into a form control.
 *
 * The model stays the single source of truth (so `[(value)]`/`[(checked)]` keep working exactly as
 * before): `writeValue` sets it with change notification muted, and every *other* write — i.e. a user
 * interaction — is forwarded to the form through the model's own change stream. No template needs to
 * call `onChange` by hand; only `onTouched` is wired to blur/close where it makes sense.
 *
 * `disabled` is the plain input (`[disabled]="x"` or the bare attribute); `isDisabled()` combines it with
 * the state the form writes through `setDisabledState` — templates and computed classes read that one.
 */
export declare abstract class SocFormControl<T> implements ControlValueAccessor {
    /** The model carrying this control's value (`value`, `checked`, …). */
    protected abstract readonly valueModel: ModelSignal<T>;
    /** `[disabled]` / bare `disabled` attribute. (An `input()` rather than a `model()` so the bare-attribute
     * form works — models can't take a transform.) Templates read `isDisabled()`, not this. */
    readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    private readonly formDisabled;
    /** The input OR'ed with the state the form writes through `setDisabledState`. */
    readonly isDisabled: import("@angular/core").Signal<boolean>;
    protected onTouched: () => void;
    private writing;
    private subscription?;
    /** Maps whatever the form hands in (`null` after `reset()`, …) onto this control's value type. */
    protected abstract coerce(value: unknown): T;
    writeValue(value: unknown): void;
    registerOnChange(fn: (value: T) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocFormControl<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocFormControl<any>, never, never, { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
/**
 * Shared surface of the label + bordered field + helper-text inputs (`InputText`, `InputArea`,
 * `InputNumber`, `Password`): everything React gets for free from `InputHTMLAttributes` spread.
 *
 * - dedicated inputs for the common native attributes (`id`, `name`, `autocomplete`, `readonly`);
 * - `inputClass` = React's `className` (lands on the inner control; a plain `class` on the host is
 *   React's `wrapperClassName`);
 * - `inputAttrs` = the escape hatch for every other native attribute.
 *
 * `id`/`name` are meant for the inner control, so the host's own copies are cleared — a static
 * `id="…"`/`name="…"` on `<soc-input-text>` would otherwise be a duplicate DOM id and a bogus
 * attribute on a custom element.
 */
export declare abstract class SocTextFieldBase<T> extends SocFormControl<T> {
    readonly label: import("@angular/core").InputSignal<string | undefined>;
    readonly required: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly error: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly helperText: import("@angular/core").InputSignal<string | undefined>;
    readonly placeholder: import("@angular/core").InputSignal<string | undefined>;
    readonly id: import("@angular/core").InputSignal<string | undefined>;
    readonly name: import("@angular/core").InputSignal<string | undefined>;
    readonly autocomplete: import("@angular/core").InputSignal<string | undefined>;
    readonly readonly: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly inputClass: import("@angular/core").InputSignal<string | undefined>;
    readonly inputAttrs: import("@angular/core").InputSignal<NativeAttributes | undefined>;
    /** The inner `<input>`/`<textarea>`, for `inputAttrs`. */
    protected abstract readonly nativeField: () => HTMLElement | undefined;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<SocTextFieldBase<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocTextFieldBase<any>, never, never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "helperText": { "alias": "helperText"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "autocomplete": { "alias": "autocomplete"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "inputClass": { "alias": "inputClass"; "required": false; "isSignal": true; }; "inputAttrs": { "alias": "inputAttrs"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
