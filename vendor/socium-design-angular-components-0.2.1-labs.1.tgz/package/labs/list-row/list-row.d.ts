import * as i0 from "@angular/core";
/** Slot à gauche de la ligne : icône, pastille (`soc-labs-chart-type-chip`), avatar… */
export declare class SocLabsListRowLeading {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsListRowLeading, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocLabsListRowLeading, "[socLabsListRowLeading]", never, {}, {}, never, never, true, never>;
}
/** Slot d'action à droite (typiquement un `soc-labs-icon-button`). Inerte quand la ligne est verrouillée. */
export declare class SocLabsListRowAction {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsListRowAction, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocLabsListRowAction, "[socLabsListRowAction]", never, {}, {}, never, never, true, never>;
}
/**
 * ## Rôle
 * Ligne de liste **compacte** pour les catalogues en panneau latéral : slot à gauche, titre +
 * sous-titre tronqués sur une ligne, slot d'action à droite.
 *
 * ## États
 * - **survol** : fond léger ; si `draggable`, une poignée de glisser apparaît à gauche.
 * - **sélectionné / ajouté** (`selected`) : fond bleu clair, titre bleu en gras, « Ajouté » lu par
 *   les lecteurs d'écran (`selectedLabel`).
 * - **verrouillé** (`locked`) : opacité 50 %, curseur interdit, action inerte ; `lockedReason`
 *   s'affiche en info-bulle (`soc-tooltip` du kit) au survol et au focus clavier.
 *
 * ## Glisser-déposer (`@angular/cdk/drag-drop`)
 * Poser `cdkDrag` sur `<soc-labs-list-row>` : la poignée interne est un `cdkDragHandle` rattaché au
 * `cdkDrag` de l'hôte, la ligne ne se saisit donc que par elle (le clic sur la ligne et sur l'action
 * reste libre). Désactiver le glisser d'une ligne verrouillée avec `[cdkDragDisabled]="locked"`. Le
 * glisser n'est pas accessible au clavier : l'action à droite reste le chemin principal.
 *
 * L'hôte porte `role="listitem"` : placer les lignes dans un conteneur `role="list"` (ou `<ul>`).
 */
export declare class SocLabsListRow {
    readonly title: import("@angular/core").InputSignal<string>;
    readonly subtitle: import("@angular/core").InputSignal<string | undefined>;
    /** Ajouté / sélectionné. */
    readonly selected: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly locked: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /** Raison du verrouillage, en info-bulle. */
    readonly lockedReason: import("@angular/core").InputSignal<string | undefined>;
    /** Affiche la poignée de glisser au survol (avec `cdkDrag` sur l'hôte). */
    readonly draggable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /** Texte lu par les lecteurs d'écran pour l'état sélectionné. */
    readonly selectedLabel: import("@angular/core").InputSignal<string>;
    protected readonly focusRing = "outline-none focus-visible:outline-[length:var(--bridges-shape-line-thick)] focus-visible:outline-offset-[length:var(--bridges-position-gap-xs)] focus-visible:outline-[var(--bridges-color-border-focus)]";
    private readonly leading;
    private readonly action;
    protected readonly hasLeading: import("@angular/core").Signal<boolean>;
    protected readonly hasAction: import("@angular/core").Signal<boolean>;
    protected readonly state: import("@angular/core").Signal<"locked" | "selected" | "default">;
    protected readonly hostClasses: import("@angular/core").Signal<"group/row flex w-full min-w-0 items-center gap-[var(--bridges-position-gap-sm)] rounded-[var(--bridges-shape-figure-radius-md)] px-[var(--bridges-position-padding-3xs)] py-[var(--bridges-position-padding-2xs)] [font-family:var(--bridges-shape-text-body-font)] transition-colors cursor-not-allowed opacity-50" | "group/row flex w-full min-w-0 items-center gap-[var(--bridges-position-gap-sm)] rounded-[var(--bridges-shape-figure-radius-md)] px-[var(--bridges-position-padding-3xs)] py-[var(--bridges-position-padding-2xs)] [font-family:var(--bridges-shape-text-body-font)] transition-colors bg-[var(--bridges-color-surface-selected)]" | "group/row flex w-full min-w-0 items-center gap-[var(--bridges-position-gap-sm)] rounded-[var(--bridges-shape-figure-radius-md)] px-[var(--bridges-position-padding-3xs)] py-[var(--bridges-position-padding-2xs)] [font-family:var(--bridges-shape-text-body-font)] transition-colors hover:bg-[var(--bridges-color-background-layer-1)]">;
    protected readonly titleClasses: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsListRow, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocLabsListRow, "soc-labs-list-row", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; "locked": { "alias": "locked"; "required": false; "isSignal": true; }; "lockedReason": { "alias": "lockedReason"; "required": false; "isSignal": true; }; "draggable": { "alias": "draggable"; "required": false; "isSignal": true; }; "selectedLabel": { "alias": "selectedLabel"; "required": false; "isSignal": true; }; }, {}, ["leading", "action"], ["[socLabsListRowLeading]", "[socLabsListRowAction]"], true, never>;
}
