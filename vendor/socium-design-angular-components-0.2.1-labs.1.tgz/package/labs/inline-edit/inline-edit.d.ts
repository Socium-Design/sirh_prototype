import * as i0 from "@angular/core";
/**
 * ## Rôle
 * Libellé **modifiable sur place** (nom d'une section, titre d'un widget) : le texte s'affiche tel
 * quel, un crayon apparaît au survol ; un clic le remplace par un champ **à la même place et à la
 * même taille** (le champ hérite de la police du parent et s'élargit avec son contenu).
 *
 * ## Comportement
 * - Entrée ou perte du focus : valide ; Échap : annule (le texte d'origine revient).
 * - Valeur vide (après `trim`) : revient à `defaultValue`.
 * - `value` est un `model` (↔) : `(valueChange)` n'est émis que si la valeur change réellement.
 *
 * ## Accessibilité
 * Hors édition, le libellé est un `<button>` (« Modifier {ariaLabel} : {valeur} ») — atteignable au
 * clavier, Entrée/Espace ouvrent l'édition ; le focus revient sur ce bouton après Entrée ou Échap.
 */
export declare class SocLabsInlineEdit {
    readonly value: import("@angular/core").ModelSignal<string>;
    /** Valeur reprise quand le champ est validé vide. */
    readonly defaultValue: import("@angular/core").InputSignal<string>;
    /** Ce qui est modifié (« le nom de la section ») — nomme le champ et le bouton. */
    readonly ariaLabel: import("@angular/core").InputSignal<string>;
    /** Texte affiché quand la valeur et la valeur par défaut sont vides. */
    readonly placeholder: import("@angular/core").InputSignal<string>;
    readonly maxlength: import("@angular/core").InputSignal<number | undefined>;
    readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    protected readonly focusRing = "outline-none focus-visible:outline-[length:var(--bridges-shape-line-thick)] focus-visible:outline-offset-[length:var(--bridges-position-gap-xs)] focus-visible:outline-[var(--bridges-color-border-focus)]";
    protected readonly editing: import("@angular/core").WritableSignal<boolean>;
    protected readonly draft: import("@angular/core").WritableSignal<string>;
    protected readonly isPlaceholder: import("@angular/core").Signal<boolean>;
    protected readonly shown: import("@angular/core").Signal<string>;
    private readonly field;
    private readonly display;
    private refocusDisplay;
    constructor();
    protected start(): void;
    protected onKeydown(event: KeyboardEvent): void;
    /** Validates the draft; `refocus` returns focus to the label (keyboard validation). */
    protected commit(refocus: boolean): void;
    protected cancel(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsInlineEdit, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocLabsInlineEdit, "soc-labs-inline-edit", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "defaultValue": { "alias": "defaultValue"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "maxlength": { "alias": "maxlength"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}
