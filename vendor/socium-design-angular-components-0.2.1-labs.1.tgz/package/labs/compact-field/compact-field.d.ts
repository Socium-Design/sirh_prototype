import { SocLabsFormControl } from '../internal/form-control';
import * as i0 from "@angular/core";
export type LabsCompactFieldMode = 'read' | 'edit';
export type LabsCompactFieldControl = 'text' | 'textarea' | 'select';
export interface LabsCompactFieldOption {
    value: string;
    label: string;
}
/**
 * ## Rôle
 * Champ **compact pour panneau latéral** (≥ 220 px) : libellé en petites capitales, puis la valeur
 * — en lecture (texte) ou en édition (champ texte, zone multiligne ou liste déroulante native, 28 px
 * de haut). Un séparateur fin sous chaque champ (`separator`, actif par défaut) rythme le panneau.
 *
 * Même composant pour « Détail » et « Modifier » : on bascule `mode` sans changer la mise en page.
 *
 * Champ de formulaire (`formControl`, `formControlName`, `ngModel`) ; valeur `value` (↔, chaîne).
 * En lecture, une liste affiche le libellé de l'option, une valeur vide affiche `emptyText`.
 */
export declare class SocLabsCompactField extends SocLabsFormControl<string> {
    readonly label: import("@angular/core").InputSignal<string>;
    readonly mode: import("@angular/core").InputSignal<LabsCompactFieldMode>;
    readonly control: import("@angular/core").InputSignal<LabsCompactFieldControl>;
    readonly value: import("@angular/core").ModelSignal<string>;
    /** Options de la liste déroulante (`control="select"`). */
    readonly options: import("@angular/core").InputSignal<LabsCompactFieldOption[]>;
    readonly placeholder: import("@angular/core").InputSignal<string | undefined>;
    /** Texte affiché en lecture quand la valeur est vide. */
    readonly emptyText: import("@angular/core").InputSignal<string>;
    readonly rows: import("@angular/core").InputSignal<number>;
    readonly separator: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /** Id du contrôle natif (sinon généré). */
    readonly id: import("@angular/core").InputSignal<string | undefined>;
    protected readonly valueModel: import("@angular/core").ModelSignal<string>;
    protected readonly labelClass = "uppercase tracking-wider [font-family:var(--bridges-shape-text-label-font)] [font-weight:var(--bridges-shape-text-label-weight)] text-[length:var(--bridges-size-text-text-size-tiny)] text-[var(--bridges-color-text-secondary)]";
    protected readonly inputClass = "w-full min-w-0 rounded-[var(--bridges-shape-figure-radius-sm)] border-[length:var(--bridges-shape-line-hairline)] border-[var(--bridges-color-border-tertiary)] bg-[var(--bridges-color-surface-neutral-white)] px-[var(--bridges-position-padding-3xs)] text-[length:var(--bridges-size-text-text-size-sm)] text-[var(--bridges-color-text-primary)] [font-family:var(--bridges-shape-text-body-font)] placeholder:text-[var(--bridges-color-text-tertiary)] hover:border-[var(--bridges-color-border-secondary)] outline-none focus:border-[var(--bridges-color-border-focus)] focus:outline-[length:var(--bridges-shape-line-hairline)] focus:outline-[var(--bridges-color-border-focus)] disabled:cursor-not-allowed disabled:bg-[var(--bridges-color-surface-neutral-disabled)] disabled:text-[var(--bridges-color-text-disabled)] h-[calc(var(--bridges-size-icon-lg)+var(--bridges-position-gap-2xs))]";
    protected readonly selectClass = "w-full min-w-0 rounded-[var(--bridges-shape-figure-radius-sm)] border-[length:var(--bridges-shape-line-hairline)] border-[var(--bridges-color-border-tertiary)] bg-[var(--bridges-color-surface-neutral-white)] px-[var(--bridges-position-padding-3xs)] text-[length:var(--bridges-size-text-text-size-sm)] text-[var(--bridges-color-text-primary)] [font-family:var(--bridges-shape-text-body-font)] placeholder:text-[var(--bridges-color-text-tertiary)] hover:border-[var(--bridges-color-border-secondary)] outline-none focus:border-[var(--bridges-color-border-focus)] focus:outline-[length:var(--bridges-shape-line-hairline)] focus:outline-[var(--bridges-color-border-focus)] disabled:cursor-not-allowed disabled:bg-[var(--bridges-color-surface-neutral-disabled)] disabled:text-[var(--bridges-color-text-disabled)] h-[calc(var(--bridges-size-icon-lg)+var(--bridges-position-gap-2xs))] appearance-none pr-[calc(var(--bridges-size-icon-sm)+var(--bridges-position-padding-3xs)*2)] truncate";
    protected readonly textareaClass = "w-full min-w-0 rounded-[var(--bridges-shape-figure-radius-sm)] border-[length:var(--bridges-shape-line-hairline)] border-[var(--bridges-color-border-tertiary)] bg-[var(--bridges-color-surface-neutral-white)] px-[var(--bridges-position-padding-3xs)] text-[length:var(--bridges-size-text-text-size-sm)] text-[var(--bridges-color-text-primary)] [font-family:var(--bridges-shape-text-body-font)] placeholder:text-[var(--bridges-color-text-tertiary)] hover:border-[var(--bridges-color-border-secondary)] outline-none focus:border-[var(--bridges-color-border-focus)] focus:outline-[length:var(--bridges-shape-line-hairline)] focus:outline-[var(--bridges-color-border-focus)] disabled:cursor-not-allowed disabled:bg-[var(--bridges-color-surface-neutral-disabled)] disabled:text-[var(--bridges-color-text-disabled)] resize-y py-[var(--bridges-position-padding-2xs)] [line-height:var(--bridges-size-text-line-height-sm)]";
    protected readonly readClass = "whitespace-pre-line break-words text-[length:var(--bridges-size-text-text-size-sm)] [font-family:var(--bridges-shape-text-body-font)] [line-height:var(--bridges-size-text-line-height-sm)]";
    private readonly generatedId;
    protected readonly controlId: import("@angular/core").Signal<string>;
    protected readonly selectedOption: import("@angular/core").Signal<LabsCompactFieldOption | undefined>;
    protected readonly readText: import("@angular/core").Signal<{
        text: string;
        empty: boolean;
    }>;
    protected readonly hostClasses: import("@angular/core").Signal<string>;
    protected coerce(value: unknown): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsCompactField, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocLabsCompactField, "soc-labs-compact-field", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "control": { "alias": "control"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "emptyText": { "alias": "emptyText"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "separator": { "alias": "separator"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}
