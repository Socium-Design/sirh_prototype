import * as i0 from "@angular/core";
export type ChipsSize = 'sm' | 'lg';
/**
 * React's Chips.tsx exports three components sharing one file — mirrored the same way here rather
 * than splitting into three files, since they share the `ChipsSize` type and padding/text classes.
 * `label` is a plain `string` in all three (not `ReactNode`), so plain `input()`s throughout, no
 * content projection — same reasoning as `DocumentLine`. `onRemove`/`onClick` follow the same
 * split as `Tag`'s `removable`/`remove`: a boolean input controls visibility, an output is the
 * handler (an `output()` can't be introspected for "is anyone listening" the way an optional
 * callback prop can).
 *
 * Maps 1:1 to "Index/Selection/Chips/*" tokens — see packages/tokens/tokens/components/selection.json
 * in design_system (React reference repo, read only).
 */
export declare class SocChips {
    readonly label: import("@angular/core").InputSignal<string>;
    readonly size: import("@angular/core").InputSignal<ChipsSize>;
    readonly removable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly remove: import("@angular/core").OutputEmitterRef<void>;
    protected readonly closeIconThickness = "var(--index-selection-chips-close-icon-thickness)";
    protected readonly hostClasses: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocChips, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocChips, "soc-chips", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "removable": { "alias": "removable"; "required": false; "isSignal": true; }; }, { "remove": "remove"; }, never, never, true, never>;
}
/**
 * Maps 1:1 to "Index/Selection/Chips/*" tokens (type=Selectable). Structurally this one IS just a
 * bare `<button>{label}</button>`, same shape as `Button` — could have been an attribute selector.
 * Kept as a wrapper element instead, consistent with the migration spec explicitly categorizing
 * "Chips" (this whole file, all three exports) under the wrapper list rather than the native-
 * element-attribute-selector one, and to stay consistent with its two siblings above/below sharing
 * this same file.
 */
export declare class SocSelectableChips {
    readonly label: import("@angular/core").InputSignal<string>;
    readonly size: import("@angular/core").InputSignal<ChipsSize>;
    readonly selected: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly click: import("@angular/core").OutputEmitterRef<void>;
    protected readonly hostClasses: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocSelectableChips, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocSelectableChips, "soc-selectable-chips", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; }, { "click": "click"; }, never, never, true, never>;
}
/** Maps 1:1 to "Index/Selection/Chips/*" tokens (type=Input) — used for the tags shown inside a
 * Multi-select's field once options are selected. */
export declare class SocInputChip {
    readonly label: import("@angular/core").InputSignal<string>;
    readonly removable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly remove: import("@angular/core").OutputEmitterRef<void>;
    protected readonly closeIconThickness = "var(--index-selection-chips-close-icon-input-thickness)";
    static ɵfac: i0.ɵɵFactoryDeclaration<SocInputChip, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocInputChip, "soc-input-chip", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "removable": { "alias": "removable"; "required": false; "isSignal": true; }; }, { "remove": "remove"; }, never, never, true, never>;
}
