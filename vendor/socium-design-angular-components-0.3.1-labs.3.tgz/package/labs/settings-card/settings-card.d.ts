import * as i0 from "@angular/core";
/** Contrôle à droite du titre (typiquement un `soc-switch` qui active la carte). Jamais grisé. */
export declare class SocLabsSettingsCardAction {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsSettingsCardAction, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocLabsSettingsCardAction, "[socLabsSettingsCardAction]", never, {}, {}, never, never, true, never>;
}
/** Note de bas de carte dans un encadré pointillé (règle de calcul, remarque). Grisée avec le corps. */
export declare class SocLabsSettingsCardFootnote {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsSettingsCardFootnote, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocLabsSettingsCardFootnote, "[socLabsSettingsCardFootnote]", never, {}, {}, never, never, true, never>;
}
/**
 * ## Rôle
 * Carte d'un **bloc de réglages** dans une page de configuration : sur-titre en petites capitales
 * (« BARÈME »), titre, contrôle à droite du titre (interrupteur), corps libre (champs du kit), puis une
 * note optionnelle dans un encadré pointillé (« Règle de calcul »), sur le fond de la carte : `text-secondary` y garde
 * 4,8:1 (sur `background-layer-1`, il tomberait à 4,4:1).
 *
 * Diffère de `soc-card` du kit : sur-titre, titre jamais tronqué, pas de bouton « ••• » (#15), état
 * **désactivé** (#11) et encadré de note.
 *
 * ## État désactivé (`disabled`)
 * Le corps et la note sont grisés (`--bridges-texture-opacity-disabled`) et **inertes** (`inert` :
 * ni clic, ni saisie, ni focus clavier, quel que soit le contrôle du kit qu'ils contiennent). Le
 * contrôle d'en-tête reste actif — c'est lui qui réactive la carte — et `disabledNote`, s'il est
 * fourni, s'affiche sous l'en-tête en couleur normale (contraste ≥ 4,5:1) pour dire pourquoi.
 *
 * ## Accessibilité
 * `role="group"` nommé par le titre (`aria-labelledby`). Le corps inerte est retiré de l'arbre
 * d'accessibilité : `disabledNote` est l'information lue à la place.
 *
 * ## Slots
 * - `socLabsSettingsCardAction` (optionnel) : à droite du titre, aligné en haut, jamais rétréci.
 * - contenu sans marqueur : le corps (colonne, espacement `gap-lg`).
 * - `socLabsSettingsCardFootnote` (optionnel) : encadré pointillé en bas de carte.
 */
export declare class SocLabsSettingsCard {
    readonly title: import("@angular/core").InputSignal<string>;
    /** Sur-titre en petites capitales au-dessus du titre (« BARÈME »). */
    readonly overline: import("@angular/core").InputSignal<string | undefined>;
    /** Corps et note grisés et inertes ; le contrôle d'en-tête reste actif. */
    readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /** Mention affichée sous l'en-tête quand la carte est désactivée (« Barème désactivé : … »). */
    readonly disabledNote: import("@angular/core").InputSignal<string | undefined>;
    protected readonly titleId: string;
    protected readonly overlineClass = "uppercase tracking-wider [font-family:var(--bridges-shape-text-label-font)] [font-weight:var(--bridges-shape-text-label-weight)] text-[length:var(--bridges-size-text-text-size-tiny)] text-[var(--bridges-color-text-secondary)]";
    private readonly action;
    private readonly footnote;
    protected readonly hasAction: import("@angular/core").Signal<boolean>;
    protected readonly hasFootnote: import("@angular/core").Signal<boolean>;
    protected readonly bodyClass: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsSettingsCard, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocLabsSettingsCard, "soc-labs-settings-card", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "overline": { "alias": "overline"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "disabledNote": { "alias": "disabledNote"; "required": false; "isSignal": true; }; }, {}, ["action", "footnote"], ["[socLabsSettingsCardAction]", "*", "[socLabsSettingsCardFootnote]"], true, never>;
}
