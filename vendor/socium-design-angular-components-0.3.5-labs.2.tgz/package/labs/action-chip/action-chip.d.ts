import * as i0 from "@angular/core";
/**
 * ## Rôle
 * Puce **avec une action textuelle** : un élément acquis (option payante souscrite) et le bouton qui le retire
 * (« Désactiver »). Diffère de `soc-chips removable` du kit, dont l'action est une croix « Retirer » : ici l'action est
 * nommée, visible, et ne supprime rien (elle change un état).
 *
 * ## Accessibilité
 * Le bouton est nommé avec le libellé de la puce (« Désactiver Intranet ») : il reste compréhensible hors contexte
 * (liste des boutons d'un lecteur d'écran). Libellé `text-primary` (9,4:1), action `text-action` (6,2:1) sur
 * `background-layer-1`. Placer les puces dans une liste (`<ul>` / `<li>`).
 */
export declare class SocLabsActionChip {
    readonly label: import("@angular/core").InputSignal<string>;
    readonly actionLabel: import("@angular/core").InputSignal<string>;
    readonly action: import("@angular/core").OutputEmitterRef<void>;
    protected readonly buttonClass = "shrink-0 rounded-full px-[var(--bridges-position-padding-sm)] py-[var(--bridges-position-gap-2xs)] text-[var(--bridges-color-text-action)] [font-weight:var(--bridges-shape-text-label-weight)] hover:bg-[var(--bridges-color-surface-selected)] outline-none focus-visible:outline-solid focus-visible:outline-[length:var(--bridges-shape-line-thick)] focus-visible:outline-offset-[length:var(--bridges-position-gap-xs)] focus-visible:outline-[var(--bridges-color-border-focus)]";
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsActionChip, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocLabsActionChip, "soc-labs-action-chip", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "actionLabel": { "alias": "actionLabel"; "required": false; "isSignal": true; }; }, { "action": "action"; }, never, never, true, never>;
}
