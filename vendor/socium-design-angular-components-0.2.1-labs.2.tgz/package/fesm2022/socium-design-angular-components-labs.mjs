import { NgTemplateOutlet } from '@angular/common';
import * as i0 from '@angular/core';
import { input, booleanAttribute, computed, ViewEncapsulation, ChangeDetectionStrategy, Component, forwardRef, signal, Directive, model, viewChildren, viewChild, effect, contentChild, output, inject, DestroyRef, untracked } from '@angular/core';
import { SocTooltip, SocTooltipLabel } from '@socium-design/angular-components';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { LucideChartLine, LucideChartArea, LucideChartColumn, LucideChartBar, LucideChartColumnStacked, LucideChartPie, LucideDonut, LucideGauge, LucideHash, LucidePencil, LucideChevronDown, LucideGripVertical, LucidePlus, LucideX, LucidePanelLeftClose, LucidePanelLeftOpen, LucidePanelRightClose, LucidePanelRightOpen } from '@lucide/angular';
import { CdkDragHandle, CdkDropList } from '@angular/cdk/drag-drop';

/**
 * Class strings shared by several Labs components. Literal strings only — Tailwind scans source text
 * statically (see the labs `@source` line in `src/styles/tailwind-entry.css`).
 */
/** Visible keyboard focus ring, kit focus color. */
const labsFocusRing = 'outline-none focus-visible:outline-[length:var(--bridges-shape-line-thick)] focus-visible:outline-offset-[length:var(--bridges-position-gap-xs)] focus-visible:outline-[var(--bridges-color-border-focus)]';
/** Small-caps section label used in side panels (compact field, panel titles). */
const labsOverlineText = 'uppercase tracking-wider [font-family:var(--bridges-shape-text-label-font)] [font-weight:var(--bridges-shape-text-label-weight)] text-[length:var(--bridges-size-text-text-size-tiny)] text-[var(--bridges-color-text-secondary)]';
/** Visually hidden but read by screen readers. */
const labsSrOnly = 'sr-only';

/** xs 20px / sm 24px / md 28px — the first two are the kit's icon sizes, md has no token of its own
 * (kit icon `lg` + `gap-2xs`). */
const sizeClasses$2 = {
    xs: 'size-[var(--bridges-size-icon-md)]',
    sm: 'size-[var(--bridges-size-icon-lg)]',
    md: 'size-[calc(var(--bridges-size-icon-lg)+var(--bridges-position-gap-2xs))]',
};
const iconSizeClasses$1 = {
    xs: 'size-[var(--bridges-size-icon-xs)]',
    sm: 'size-[var(--bridges-size-icon-sm)]',
    md: 'size-[var(--bridges-size-icon-2sm)]',
};
const variantClasses = {
    ghost: 'bg-transparent text-[var(--bridges-color-icon-secondary)] hover:bg-[var(--bridges-color-background-layer-1)] hover:text-[var(--bridges-color-icon-primary)] active:bg-[var(--bridges-color-background-layer-2)] disabled:bg-transparent',
    'primary-subtle': 'bg-[var(--bridges-color-accent-blue-bg)] text-[var(--bridges-color-text-action)] hover:bg-[var(--bridges-color-surface-primary-default)] hover:text-[var(--bridges-color-text-on-primary)] active:bg-[var(--bridges-color-surface-primary-pressed)] disabled:bg-[var(--bridges-color-surface-neutral-disabled)]',
};
const shapeClasses = {
    square: 'rounded-[var(--bridges-shape-figure-radius-sm)]',
    round: 'rounded-[var(--bridges-shape-figure-radius-full)]',
};
/**
 * ## Rôle
 * Bouton icône compact pour les barres d'outils denses (lignes de liste, en-têtes de panneau,
 * cartes en composition) — là où `button[socButton]` (32px minimum) est trop haut.
 *
 * ## Accessibilité
 * - `ariaLabel` est **obligatoire** (input requis : le build échoue sans lui) — un bouton sans texte
 *   visible n'a pas d'autre nom accessible.
 * - `ariaExpanded` / `ariaControls` (optionnels) : bouton de divulgation (ex. replier un panneau).
 * - `tooltip` (optionnel) affiche une info-bulle du kit (`soc-tooltip`) au survol et au focus.
 *
 * ## Écart avec la convention du kit (GAP-DECISION)
 * Composant élément (`soc-labs-icon-button`) qui contient le `<button>`, et non un sélecteur
 * d'attribut : c'est ce qui permet de rendre `ariaLabel` obligatoire et d'envelopper le bouton dans
 * l'info-bulle. Le `(click)` natif du bouton remonte jusqu'à l'hôte : `(click)` s'écoute directement
 * sur `<soc-labs-icon-button>` (un bouton désactivé n'émet pas de clic).
 *
 * L'icône est projetée (contenu par défaut) : `<svg lucidePlus class="size-full">`.
 */
class SocLabsIconButton {
    /** Nom accessible du bouton (obligatoire). */
    ariaLabel = input.required();
    size = input('sm');
    variant = input('ghost');
    shape = input('square');
    /** Texte de l'info-bulle ; absent = pas d'info-bulle. */
    tooltip = input();
    tooltipPosition = input('top');
    disabled = input(false, { transform: booleanAttribute });
    type = input('button');
    /** Bouton bascule : `true`/`false` posent `aria-pressed` ; absent = bouton simple. */
    pressed = input(undefined);
    /** Bouton de divulgation (repli d'un panneau…) : `true`/`false` posent `aria-expanded` ; absent = rien. */
    ariaExpanded = input(undefined);
    /** `id` de l'élément contrôlé (`aria-controls`), avec `ariaExpanded`. */
    ariaControls = input(undefined);
    buttonClasses = computed(() => `inline-flex shrink-0 items-center justify-center transition-colors disabled:cursor-not-allowed disabled:text-[var(--bridges-color-icon-disabled)] ${labsFocusRing} ${sizeClasses$2[this.size()]} ${variantClasses[this.variant()]} ${shapeClasses[this.shape()]}`);
    iconClasses = computed(() => `inline-flex shrink-0 ${iconSizeClasses$1[this.size()]}`);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsIconButton, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocLabsIconButton, isStandalone: true, selector: "soc-labs-icon-button", inputs: { ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: true, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, shape: { classPropertyName: "shape", publicName: "shape", isSignal: true, isRequired: false, transformFunction: null }, tooltip: { classPropertyName: "tooltip", publicName: "tooltip", isSignal: true, isRequired: false, transformFunction: null }, tooltipPosition: { classPropertyName: "tooltipPosition", publicName: "tooltipPosition", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, pressed: { classPropertyName: "pressed", publicName: "pressed", isSignal: true, isRequired: false, transformFunction: null }, ariaExpanded: { classPropertyName: "ariaExpanded", publicName: "ariaExpanded", isSignal: true, isRequired: false, transformFunction: null }, ariaControls: { classPropertyName: "ariaControls", publicName: "ariaControls", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "inline-flex" }, ngImport: i0, template: `
    <ng-template #button>
      <button
        [attr.type]="type()"
        [attr.aria-label]="ariaLabel()"
        [attr.aria-pressed]="pressed() ?? null"
        [attr.aria-expanded]="ariaExpanded() ?? null"
        [attr.aria-controls]="ariaControls() ?? null"
        [disabled]="disabled()"
        [class]="buttonClasses()"
      >
        <span aria-hidden="true" [class]="iconClasses()"><ng-content /></span>
      </button>
    </ng-template>
    @if (tooltip()) {
      <soc-tooltip [position]="tooltipPosition()">
        <ng-container [ngTemplateOutlet]="button" />
        <span socTooltipLabel>{{ tooltip() }}</span>
      </soc-tooltip>
    } @else {
      <ng-container [ngTemplateOutlet]="button" />
    }
  `, isInline: true, dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: SocTooltip, selector: "soc-tooltip", inputs: ["position", "variant", "title", "status", "showIcon"] }, { kind: "directive", type: SocTooltipLabel, selector: "[socTooltipLabel]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsIconButton, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-labs-icon-button',
                    standalone: true,
                    imports: [NgTemplateOutlet, SocTooltip, SocTooltipLabel],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: { class: 'inline-flex' },
                    template: `
    <ng-template #button>
      <button
        [attr.type]="type()"
        [attr.aria-label]="ariaLabel()"
        [attr.aria-pressed]="pressed() ?? null"
        [attr.aria-expanded]="ariaExpanded() ?? null"
        [attr.aria-controls]="ariaControls() ?? null"
        [disabled]="disabled()"
        [class]="buttonClasses()"
      >
        <span aria-hidden="true" [class]="iconClasses()"><ng-content /></span>
      </button>
    </ng-template>
    @if (tooltip()) {
      <soc-tooltip [position]="tooltipPosition()">
        <ng-container [ngTemplateOutlet]="button" />
        <span socTooltipLabel>{{ tooltip() }}</span>
      </soc-tooltip>
    } @else {
      <ng-container [ngTemplateOutlet]="button" />
    }
  `,
                }]
        }] });

/**
 * Copy of the kit's `SocFormControl` (`src/internal/form-control.ts`), which is internal and not
 * exported by the primary entry point — a secondary entry point can only import the primary through
 * its public API. Same contract: the `model()` stays the source of truth, `writeValue` mutes the
 * change stream, `disabled` is an input OR'ed with the form's own state. On promotion to the kit, a
 * Labs component switches to the kit's base class and this file goes away.
 */
function provideLabsFormControl(type) {
    return { provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(type), multi: true };
}
class SocLabsFormControl {
    disabled = input(false, { transform: booleanAttribute });
    formDisabled = signal(false);
    isDisabled = computed(() => this.disabled() || this.formDisabled());
    onTouched = () => { };
    writing = false;
    subscription;
    writeValue(value) {
        this.writing = true;
        try {
            this.valueModel.set(this.coerce(value));
        }
        finally {
            this.writing = false;
        }
    }
    registerOnChange(fn) {
        this.subscription?.unsubscribe();
        this.subscription = this.valueModel.subscribe((value) => {
            if (!this.writing)
                fn(value);
        });
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.formDisabled.set(isDisabled);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsFormControl, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "19.2.25", type: SocLabsFormControl, isStandalone: true, inputs: { disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsFormControl, decorators: [{
            type: Directive
        }] });

const selectedClasses = {
    blue: 'bg-[var(--bridges-color-accent-blue-bg)] text-[var(--bridges-color-accent-blue-text)]',
    green: 'bg-[var(--bridges-color-accent-green-bg)] text-[var(--bridges-color-accent-green-text)]',
    gray: 'bg-[var(--bridges-color-surface-neutral-default)] text-[var(--bridges-color-text-primary)]',
    amber: 'bg-[var(--bridges-color-accent-amber-bg)] text-[var(--bridges-color-text-warning)]',
    red: 'bg-[var(--bridges-color-accent-red-bg)] text-[var(--bridges-color-accent-red-text)]',
    indigo: 'bg-[var(--bridges-color-accent-indigo-bg)] text-[var(--bridges-color-accent-indigo-text)]',
    purple: 'bg-[var(--bridges-color-accent-purple-bg)] text-[var(--bridges-color-accent-purple-text)]',
    orange: 'bg-[var(--bridges-color-accent-orange-bg)] text-[var(--bridges-color-accent-orange-text)]',
};
/** sm 24px / md 28px de haut (md : kit icon `lg` + `gap-2xs`, pas de token propre). */
const sizeClasses$1 = {
    sm: 'h-[var(--bridges-size-icon-lg)] px-[var(--bridges-position-padding-3xs)] text-[length:var(--bridges-size-text-text-size-xs)]',
    md: 'h-[calc(var(--bridges-size-icon-lg)+var(--bridges-position-gap-2xs))] px-[var(--bridges-position-padding-sm)] text-[length:var(--bridges-size-text-text-size-sm)]',
};
/**
 * ## Rôle
 * Bascule en pastilles, **choix unique** parmi 2 à 4 options courtes et immédiates : statut
 * (Actif / Inactif / Archivé), opérateur logique (ET / OU) d'une population.
 *
 * ## Accessibilité
 * `role="radiogroup"` (nommé par `ariaLabel`) contenant des `role="radio"` ; tabulation itinérante
 * (une seule pastille dans l'ordre de tabulation) ; ← → ↑ ↓ déplacent le focus **et** la sélection,
 * Origine / Fin vont aux extrémités ; les options désactivées sont sautées.
 *
 * Champ de formulaire (`formControl`, `formControlName`, `ngModel`) ; la valeur est `value` (↔).
 * La couleur est propre à chaque option (`color`, tokens `--bridges-color-accent-*`).
 */
class SocLabsPillToggle extends SocLabsFormControl {
    options = input.required();
    value = model(null);
    size = input('md');
    /** Nom accessible du groupe (ex. « Statut »). */
    ariaLabel = input();
    valueModel = this.value;
    pills = viewChildren('pill');
    /** Index of the only pill in the tab order: the selected one, else the first enabled one. */
    tabStop = computed(() => {
        const opts = this.options();
        const selected = opts.findIndex((o) => this.isSelected(o));
        return selected >= 0 ? selected : opts.findIndex((o) => !o.disabled);
    });
    coerce(value) {
        return (value ?? null);
    }
    isSelected(option) {
        return Object.is(option.value, this.value());
    }
    select(option) {
        if (this.isDisabled() || option.disabled)
            return;
        this.value.set(option.value);
    }
    onKeydown(event, index) {
        const opts = this.options();
        const enabled = opts.map((o, i) => (o.disabled ? -1 : i)).filter((i) => i >= 0);
        if (!enabled.length || this.isDisabled())
            return;
        const pos = enabled.indexOf(index);
        let next;
        switch (event.key) {
            case 'ArrowRight':
            case 'ArrowDown':
                next = enabled[(pos + 1) % enabled.length];
                break;
            case 'ArrowLeft':
            case 'ArrowUp':
                next = enabled[(pos - 1 + enabled.length) % enabled.length];
                break;
            case 'Home':
                next = enabled[0];
                break;
            case 'End':
                next = enabled[enabled.length - 1];
                break;
            default:
                return;
        }
        event.preventDefault();
        this.select(opts[next]);
        this.pills()[next]?.nativeElement.focus();
    }
    pillClasses(option) {
        const state = this.isSelected(option)
            ? `${selectedClasses[option.color ?? 'blue']} [font-weight:var(--bridges-shape-text-label-weight)]`
            : 'bg-transparent text-[var(--bridges-color-text-secondary)] hover:bg-[var(--bridges-color-surface-neutral-white)] hover:text-[var(--bridges-color-text-primary)]';
        return `inline-flex items-center justify-center whitespace-nowrap rounded-[var(--bridges-shape-figure-radius-full)] [font-family:var(--bridges-shape-text-body-font)] transition-colors disabled:cursor-not-allowed disabled:opacity-[var(--bridges-texture-opacity-disabled)] ${labsFocusRing} ${sizeClasses$1[this.size()]} ${state}`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsPillToggle, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocLabsPillToggle, isStandalone: true, selector: "soc-labs-pill-toggle", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, host: { classAttribute: "inline-flex" }, providers: [provideLabsFormControl(() => SocLabsPillToggle)], viewQueries: [{ propertyName: "pills", predicate: ["pill"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: `
    <div
      role="radiogroup"
      [attr.aria-label]="ariaLabel() ?? null"
      [attr.aria-disabled]="isDisabled() || null"
      class="inline-flex items-center gap-[var(--bridges-position-gap-xs)] rounded-[var(--bridges-shape-figure-radius-full)] bg-[var(--bridges-color-background-layer-1)] p-[var(--bridges-position-gap-xs)]"
    >
      @for (option of options(); track option.value; let i = $index) {
        <button
          #pill
          type="button"
          role="radio"
          [attr.aria-checked]="isSelected(option)"
          [attr.data-value]="option.value"
          [tabIndex]="i === tabStop() ? 0 : -1"
          [disabled]="isDisabled() || !!option.disabled"
          [class]="pillClasses(option)"
          (click)="select(option)"
          (keydown)="onKeydown($event, i)"
          (blur)="onTouched()"
        >
          {{ option.label }}
        </button>
      }
    </div>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsPillToggle, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-labs-pill-toggle',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    providers: [provideLabsFormControl(() => SocLabsPillToggle)],
                    host: { class: 'inline-flex' },
                    template: `
    <div
      role="radiogroup"
      [attr.aria-label]="ariaLabel() ?? null"
      [attr.aria-disabled]="isDisabled() || null"
      class="inline-flex items-center gap-[var(--bridges-position-gap-xs)] rounded-[var(--bridges-shape-figure-radius-full)] bg-[var(--bridges-color-background-layer-1)] p-[var(--bridges-position-gap-xs)]"
    >
      @for (option of options(); track option.value; let i = $index) {
        <button
          #pill
          type="button"
          role="radio"
          [attr.aria-checked]="isSelected(option)"
          [attr.data-value]="option.value"
          [tabIndex]="i === tabStop() ? 0 : -1"
          [disabled]="isDisabled() || !!option.disabled"
          [class]="pillClasses(option)"
          (click)="select(option)"
          (keydown)="onKeydown($event, i)"
          (blur)="onTouched()"
        >
          {{ option.label }}
        </button>
      }
    </div>
  `,
                }]
        }] });

/** Libellé (nom accessible par défaut) de chaque type. */
const LABS_CHART_TYPE_LABELS = {
    courbe: 'Courbe',
    aire: 'Aire',
    histogramme: 'Histogramme',
    'barres-horizontales': 'Barres horizontales',
    'barres-empilees': 'Barres empilées',
    camembert: 'Camembert',
    anneau: 'Anneau',
    jauge: 'Jauge',
    kpi: 'KPI',
};
/**
 * One kit accent per type (`--bridges-color-accent-*-bg` + its text token). Two exceptions, for
 * contrast: amber and lime use the kit's `text-warning` / `text-success` instead of their own accent
 * text token (accent-amber-text / accent-lime-text are under 3:1 on their background). KPI is neutral.
 */
const toneClasses = {
    courbe: 'bg-[var(--bridges-color-accent-blue-bg)] text-[var(--bridges-color-accent-blue-text)]',
    aire: 'bg-[var(--bridges-color-accent-indigo-bg)] text-[var(--bridges-color-accent-indigo-text)]',
    histogramme: 'bg-[var(--bridges-color-accent-purple-bg)] text-[var(--bridges-color-accent-purple-text)]',
    'barres-horizontales': 'bg-[var(--bridges-color-accent-orange-bg)] text-[var(--bridges-color-accent-orange-text)]',
    'barres-empilees': 'bg-[var(--bridges-color-accent-red-bg)] text-[var(--bridges-color-accent-red-text)]',
    camembert: 'bg-[var(--bridges-color-accent-green-bg)] text-[var(--bridges-color-accent-green-text)]',
    anneau: 'bg-[var(--bridges-color-accent-amber-bg)] text-[var(--bridges-color-text-warning)]',
    jauge: 'bg-[var(--bridges-color-accent-lime-bg)] text-[var(--bridges-color-text-success)]',
    kpi: 'bg-[var(--bridges-color-surface-neutral-default)] text-[var(--bridges-color-text-primary)]',
};
const sizeClasses = {
    20: 'size-[var(--bridges-size-icon-md)] rounded-[var(--bridges-shape-figure-radius-sm)]',
    28: 'size-[calc(var(--bridges-size-icon-lg)+var(--bridges-position-gap-2xs))] rounded-[var(--bridges-shape-figure-radius-md)]',
};
const iconSizeClasses = {
    20: 'size-[var(--bridges-size-icon-xs)]',
    28: 'size-[var(--bridges-size-icon-sm)]',
};
/**
 * ## Rôle
 * Pastille identifiant un **type de graphique** (catalogue d'indicateurs, cartes de composition) :
 * icône Lucide sur un fond teinté propre au type, tailles 20 et 28 px.
 *
 * ## Accessibilité
 * `role="img"` nommé par le libellé du type (`label` pour le remplacer). À côté d'un texte qui dit
 * déjà le type, passer `decorative` : la pastille est alors masquée aux technologies d'assistance.
 */
class SocLabsChartTypeChip {
    type = input.required();
    size = input(20);
    /** Nom accessible ; défaut : libellé du type (`LABS_CHART_TYPE_LABELS`). */
    label = input();
    decorative = input(false, { transform: booleanAttribute });
    accessibleName = computed(() => this.label() ?? LABS_CHART_TYPE_LABELS[this.type()]);
    hostClasses = computed(() => `inline-flex shrink-0 items-center justify-center ${sizeClasses[this.size()]} ${toneClasses[this.type()]}`);
    iconClass = computed(() => `inline-flex ${iconSizeClasses[this.size()]}`);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsChartTypeChip, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocLabsChartTypeChip, isStandalone: true, selector: "soc-labs-chart-type-chip", inputs: { type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: true, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, decorative: { classPropertyName: "decorative", publicName: "decorative", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()", "attr.role": "decorative() ? null : \"img\"", "attr.aria-label": "decorative() ? null : accessibleName()", "attr.aria-hidden": "decorative() ? \"true\" : null", "attr.data-type": "type()" } }, ngImport: i0, template: `
    <span [class]="iconClass()">
      @switch (type()) {
        @case ('courbe') { <svg lucideChartLine class="size-full" [strokeWidth]="2"></svg> }
        @case ('aire') { <svg lucideChartArea class="size-full" [strokeWidth]="2"></svg> }
        @case ('histogramme') { <svg lucideChartColumn class="size-full" [strokeWidth]="2"></svg> }
        @case ('barres-horizontales') { <svg lucideChartBar class="size-full" [strokeWidth]="2"></svg> }
        @case ('barres-empilees') { <svg lucideChartColumnStacked class="size-full" [strokeWidth]="2"></svg> }
        @case ('camembert') { <svg lucideChartPie class="size-full" [strokeWidth]="2"></svg> }
        @case ('anneau') { <svg lucideDonut class="size-full" [strokeWidth]="2"></svg> }
        @case ('jauge') { <svg lucideGauge class="size-full" [strokeWidth]="2"></svg> }
        @default { <svg lucideHash class="size-full" [strokeWidth]="2"></svg> }
      }
    </span>
  `, isInline: true, dependencies: [{ kind: "component", type: LucideChartLine, selector: "svg[lucideChartLine], svg[lucideLineChart]" }, { kind: "component", type: LucideChartArea, selector: "svg[lucideChartArea], svg[lucideAreaChart]" }, { kind: "component", type: LucideChartColumn, selector: "svg[lucideChartColumn], svg[lucideBarChart3]" }, { kind: "component", type: LucideChartBar, selector: "svg[lucideChartBar], svg[lucideBarChartHorizontal]" }, { kind: "component", type: LucideChartColumnStacked, selector: "svg[lucideChartColumnStacked]" }, { kind: "component", type: LucideChartPie, selector: "svg[lucideChartPie], svg[lucidePieChart]" }, { kind: "component", type: LucideDonut, selector: "svg[lucideDonut]" }, { kind: "component", type: LucideGauge, selector: "svg[lucideGauge]" }, { kind: "component", type: LucideHash, selector: "svg[lucideHash]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsChartTypeChip, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-labs-chart-type-chip',
                    standalone: true,
                    imports: [
                        LucideChartLine,
                        LucideChartArea,
                        LucideChartColumn,
                        LucideChartBar,
                        LucideChartColumnStacked,
                        LucideChartPie,
                        LucideDonut,
                        LucideGauge,
                        LucideHash,
                    ],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[class]': 'hostClasses()',
                        '[attr.role]': 'decorative() ? null : "img"',
                        '[attr.aria-label]': 'decorative() ? null : accessibleName()',
                        '[attr.aria-hidden]': 'decorative() ? "true" : null',
                        '[attr.data-type]': 'type()',
                    },
                    template: `
    <span [class]="iconClass()">
      @switch (type()) {
        @case ('courbe') { <svg lucideChartLine class="size-full" [strokeWidth]="2"></svg> }
        @case ('aire') { <svg lucideChartArea class="size-full" [strokeWidth]="2"></svg> }
        @case ('histogramme') { <svg lucideChartColumn class="size-full" [strokeWidth]="2"></svg> }
        @case ('barres-horizontales') { <svg lucideChartBar class="size-full" [strokeWidth]="2"></svg> }
        @case ('barres-empilees') { <svg lucideChartColumnStacked class="size-full" [strokeWidth]="2"></svg> }
        @case ('camembert') { <svg lucideChartPie class="size-full" [strokeWidth]="2"></svg> }
        @case ('anneau') { <svg lucideDonut class="size-full" [strokeWidth]="2"></svg> }
        @case ('jauge') { <svg lucideGauge class="size-full" [strokeWidth]="2"></svg> }
        @default { <svg lucideHash class="size-full" [strokeWidth]="2"></svg> }
      }
    </span>
  `,
                }]
        }] });

/**
 * ## Rôle
 * Libellé **modifiable sur place** (nom d'une section, titre d'un widget) : le texte s'affiche tel
 * quel, un crayon apparaît au survol ; un clic le remplace par un champ **à la même place et à la
 * même taille** (le champ hérite de la police du parent et s'élargit avec son contenu).
 *
 * ## Comportement
 * - Entrée ou perte du focus : valide ; Échap : annule (le texte d'origine revient).
 * - Valeur vide (après `trim`) : revient à `defaultValue`.
 * - `value` est un `model` (↔) : `(valueChange)` n'est émis que si la valeur change réellement.
 *
 * ## Accessibilité
 * Hors édition, le libellé est un `<button>` (« Modifier {ariaLabel} : {valeur} ») — atteignable au
 * clavier, Entrée/Espace ouvrent l'édition ; le focus revient sur ce bouton après Entrée ou Échap.
 */
class SocLabsInlineEdit {
    value = model('');
    /** Valeur reprise quand le champ est validé vide. */
    defaultValue = input('');
    /** Ce qui est modifié (« le nom de la section ») — nomme le champ et le bouton. */
    ariaLabel = input('le libellé');
    /** Texte affiché quand la valeur et la valeur par défaut sont vides. */
    placeholder = input('Sans titre');
    maxlength = input();
    disabled = input(false, { transform: booleanAttribute });
    focusRing = labsFocusRing;
    editing = signal(false);
    draft = signal('');
    isPlaceholder = computed(() => !this.value() && !this.defaultValue());
    shown = computed(() => this.value() || this.defaultValue() || this.placeholder());
    field = viewChild('field');
    display = viewChild('display');
    refocusDisplay = false;
    constructor() {
        effect(() => {
            const el = this.field()?.nativeElement;
            if (el) {
                el.focus();
                el.select();
            }
        });
        effect(() => {
            const el = this.display()?.nativeElement;
            if (el && this.refocusDisplay) {
                this.refocusDisplay = false;
                el.focus();
            }
        });
    }
    start() {
        if (this.disabled())
            return;
        this.draft.set(this.value() || this.defaultValue());
        this.editing.set(true);
    }
    onKeydown(event) {
        if (event.key === 'Enter') {
            event.preventDefault();
            this.commit(true);
        }
        else if (event.key === 'Escape') {
            event.preventDefault();
            event.stopPropagation(); // don't also close an enclosing overlay
            this.cancel();
        }
    }
    /** Validates the draft; `refocus` returns focus to the label (keyboard validation). */
    commit(refocus) {
        if (!this.editing())
            return;
        const next = this.draft().trim() || this.defaultValue();
        this.refocusDisplay = refocus;
        this.editing.set(false);
        if (next !== this.value())
            this.value.set(next);
    }
    cancel() {
        if (!this.editing())
            return;
        this.refocusDisplay = true;
        this.editing.set(false);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsInlineEdit, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocLabsInlineEdit, isStandalone: true, selector: "soc-labs-inline-edit", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, defaultValue: { classPropertyName: "defaultValue", publicName: "defaultValue", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, maxlength: { classPropertyName: "maxlength", publicName: "maxlength", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, host: { classAttribute: "inline-flex min-w-0 max-w-full align-baseline" }, viewQueries: [{ propertyName: "field", first: true, predicate: ["field"], descendants: true, isSignal: true }, { propertyName: "display", first: true, predicate: ["display"], descendants: true, isSignal: true }], ngImport: i0, template: `
    @if (editing()) {
      <span class="inline-grid min-w-0 max-w-full">
        <span aria-hidden="true" class="invisible whitespace-pre [grid-area:1/1] px-[var(--bridges-position-gap-2xs)]">{{ draft() || ' ' }}</span>
        <input
          #field
          type="text"
          [attr.aria-label]="ariaLabel()"
          [attr.maxlength]="maxlength() ?? null"
          [value]="draft()"
          (input)="draft.set($any($event.target).value)"
          (keydown)="onKeydown($event)"
          (blur)="commit(false)"
          class="[grid-area:1/1] w-full min-w-[2ch] rounded-[var(--bridges-shape-figure-radius-sm)] border-none bg-[var(--bridges-color-surface-neutral-white)] px-[var(--bridges-position-gap-2xs)] text-inherit [font:inherit] outline-[length:var(--bridges-shape-line-thick)] outline-offset-0 outline-[var(--bridges-color-border-focus)] [outline-style:solid]"
        />
      </span>
    } @else {
      <button
        #display
        type="button"
        [disabled]="disabled()"
        [attr.aria-label]="'Modifier ' + ariaLabel() + ' : ' + shown()"
        (click)="start()"
        class="group inline-flex min-w-0 max-w-full items-center gap-[var(--bridges-position-gap-2xs)] rounded-[var(--bridges-shape-figure-radius-sm)] px-[var(--bridges-position-gap-2xs)] text-left text-inherit [font:inherit] hover:bg-[var(--bridges-color-background-layer-1)] disabled:cursor-default disabled:hover:bg-transparent {{ focusRing }}"
      >
        <span [class]="isPlaceholder() ? 'truncate text-[var(--bridges-color-text-tertiary)]' : 'truncate'">{{ shown() }}</span>
        @if (!disabled()) {
          <svg
            lucidePencil
            aria-hidden="true"
            class="size-[var(--bridges-size-icon-xs)] shrink-0 text-[var(--bridges-color-icon-secondary)] opacity-0 transition-opacity group-hover:opacity-100 group-focus-visible:opacity-100"
            [strokeWidth]="2"
          ></svg>
        }
      </button>
    }
  `, isInline: true, dependencies: [{ kind: "component", type: LucidePencil, selector: "svg[lucidePencil]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsInlineEdit, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-labs-inline-edit',
                    standalone: true,
                    imports: [LucidePencil],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: { class: 'inline-flex min-w-0 max-w-full align-baseline' },
                    template: `
    @if (editing()) {
      <span class="inline-grid min-w-0 max-w-full">
        <span aria-hidden="true" class="invisible whitespace-pre [grid-area:1/1] px-[var(--bridges-position-gap-2xs)]">{{ draft() || ' ' }}</span>
        <input
          #field
          type="text"
          [attr.aria-label]="ariaLabel()"
          [attr.maxlength]="maxlength() ?? null"
          [value]="draft()"
          (input)="draft.set($any($event.target).value)"
          (keydown)="onKeydown($event)"
          (blur)="commit(false)"
          class="[grid-area:1/1] w-full min-w-[2ch] rounded-[var(--bridges-shape-figure-radius-sm)] border-none bg-[var(--bridges-color-surface-neutral-white)] px-[var(--bridges-position-gap-2xs)] text-inherit [font:inherit] outline-[length:var(--bridges-shape-line-thick)] outline-offset-0 outline-[var(--bridges-color-border-focus)] [outline-style:solid]"
        />
      </span>
    } @else {
      <button
        #display
        type="button"
        [disabled]="disabled()"
        [attr.aria-label]="'Modifier ' + ariaLabel() + ' : ' + shown()"
        (click)="start()"
        class="group inline-flex min-w-0 max-w-full items-center gap-[var(--bridges-position-gap-2xs)] rounded-[var(--bridges-shape-figure-radius-sm)] px-[var(--bridges-position-gap-2xs)] text-left text-inherit [font:inherit] hover:bg-[var(--bridges-color-background-layer-1)] disabled:cursor-default disabled:hover:bg-transparent {{ focusRing }}"
      >
        <span [class]="isPlaceholder() ? 'truncate text-[var(--bridges-color-text-tertiary)]' : 'truncate'">{{ shown() }}</span>
        @if (!disabled()) {
          <svg
            lucidePencil
            aria-hidden="true"
            class="size-[var(--bridges-size-icon-xs)] shrink-0 text-[var(--bridges-color-icon-secondary)] opacity-0 transition-opacity group-hover:opacity-100 group-focus-visible:opacity-100"
            [strokeWidth]="2"
          ></svg>
        }
      </button>
    }
  `,
                }]
        }], ctorParameters: () => [] });

let counter = 0;
/** Same helper as the kit's `src/internal/unique-id.ts` — a secondary entry point can't import the
 * primary entry's internals (ng-packagr only lets it reach the primary through its public API). */
function nextLabsId(prefix) {
    counter += 1;
    return `${prefix}-${counter}`;
}

const controlBase = 'w-full min-w-0 rounded-[var(--bridges-shape-figure-radius-sm)] border-[length:var(--bridges-shape-line-hairline)] border-[var(--bridges-color-border-tertiary)] bg-[var(--bridges-color-surface-neutral-white)] text-[var(--bridges-color-text-primary)] [font-family:var(--bridges-shape-text-body-font)] placeholder:text-[var(--bridges-color-text-tertiary)] hover:border-[var(--bridges-color-border-secondary)] outline-none focus:border-[var(--bridges-color-border-focus)] focus:outline-[length:var(--bridges-shape-line-hairline)] focus:outline-[var(--bridges-color-border-focus)] disabled:cursor-not-allowed disabled:bg-[var(--bridges-color-surface-neutral-disabled)] disabled:text-[var(--bridges-color-text-disabled)]';
/** Per-size classes. Literal strings only (Tailwind scans the source). */
const SIZES = {
    /** 14px text; controls 28px high (kit icon `lg` + `gap-2xs`) — fits a 220px side panel. */
    md: {
        text: 'text-[length:var(--bridges-size-text-text-size-sm)]',
        leading: '[line-height:var(--bridges-size-text-line-height-sm)]',
        padX: 'px-[var(--bridges-position-padding-3xs)]',
        height: 'h-[calc(var(--bridges-size-icon-lg)+var(--bridges-position-gap-2xs))]',
        textareaPadY: 'py-[var(--bridges-position-padding-2xs)]',
        chevron: 'right-[var(--bridges-position-padding-3xs)] size-[var(--bridges-size-icon-sm)]',
        selectPadRight: 'pr-[calc(var(--bridges-size-icon-sm)+var(--bridges-position-padding-3xs)*2)]',
        gap: 'gap-[var(--bridges-position-gap-2xs)]',
        separatorPad: 'pb-[var(--bridges-position-padding-3xs)]',
    },
    /** 12px text; controls 24px high (kit icon `lg`) — denser panels. */
    sm: {
        text: 'text-[length:var(--bridges-size-text-text-size-xs)]',
        leading: '[line-height:var(--bridges-size-text-line-height-xs)]',
        padX: 'px-[var(--bridges-position-padding-2xs)]',
        height: 'h-[var(--bridges-size-icon-lg)]',
        textareaPadY: 'py-[var(--bridges-position-padding-xs)]',
        chevron: 'right-[var(--bridges-position-padding-2xs)] size-[var(--bridges-size-icon-xs)]',
        selectPadRight: 'pr-[calc(var(--bridges-size-icon-xs)+var(--bridges-position-padding-2xs)*2)]',
        gap: 'gap-[var(--bridges-position-gap-xs)]',
        separatorPad: 'pb-[var(--bridges-position-padding-xs)]',
    },
};
/**
 * ## Rôle
 * Champ **compact pour panneau latéral** (≥ 220 px) : libellé en petites capitales, puis la valeur
 * — en lecture (texte) ou en édition (champ texte, zone multiligne ou liste déroulante native, 28 px
 * de haut). Un séparateur fin sous chaque champ (`separator`, actif par défaut) rythme le panneau.
 *
 * ## Taille (`size`)
 * - **`md`** (défaut) : valeur et contrôles en 14 px, contrôles de 28 px de haut.
 * - **`sm`** : panneaux denses — valeur et contrôles (texte, zone multiligne, liste, lecture) en 12 px,
 *   contrôles de 24 px de haut (icône `lg` du kit), chevron 12 px, espacements réduits. Le libellé reste
 *   en petites capitales 10 px dans les deux tailles.
 * L'hôte expose `data-size` (`md` | `sm`).
 *
 * Même composant pour « Détail » et « Modifier » : on bascule `mode` sans changer la mise en page.
 *
 * Champ de formulaire (`formControl`, `formControlName`, `ngModel`) ; valeur `value` (↔, chaîne).
 * En lecture, une liste affiche le libellé de l'option, une valeur vide affiche `emptyText`.
 */
class SocLabsCompactField extends SocLabsFormControl {
    label = input.required();
    mode = input('read');
    control = input('text');
    value = model('');
    /** Options de la liste déroulante (`control="select"`). */
    options = input([]);
    placeholder = input();
    /** Texte affiché en lecture quand la valeur est vide. */
    emptyText = input('—');
    rows = input(3);
    separator = input(true, { transform: booleanAttribute });
    /** Id du contrôle natif (sinon généré). */
    id = input();
    /** `md` (défaut, 14 px) ou `sm` (12 px, contrôles de 24 px) pour les panneaux denses. */
    size = input('md');
    valueModel = this.value;
    labelClass = labsOverlineText;
    sz = computed(() => SIZES[this.size()] ?? SIZES.md);
    inputClass = computed(() => `${controlBase} ${this.sz().text} ${this.sz().padX} ${this.sz().height}`);
    selectClass = computed(() => `${controlBase} ${this.sz().text} ${this.sz().padX} ${this.sz().height} appearance-none ${this.sz().selectPadRight} truncate`);
    textareaClass = computed(() => `${controlBase} ${this.sz().text} ${this.sz().padX} resize-y ${this.sz().textareaPadY} ${this.sz().leading}`);
    chevronClass = computed(() => `pointer-events-none absolute top-1/2 -translate-y-1/2 text-[var(--bridges-color-icon-secondary)] ${this.sz().chevron}`);
    readClass = computed(() => `whitespace-pre-line break-words [font-family:var(--bridges-shape-text-body-font)] ${this.sz().text} ${this.sz().leading}`);
    generatedId = nextLabsId('soc-labs-compact-field');
    controlId = computed(() => this.id() ?? this.generatedId);
    selectedOption = computed(() => this.options().find((o) => o.value === this.value()));
    readText = computed(() => {
        const text = this.control() === 'select' ? (this.selectedOption()?.label ?? this.value()) : this.value();
        return text ? { text, empty: false } : { text: this.emptyText(), empty: true };
    });
    hostClasses = computed(() => `flex w-full min-w-0 flex-col ${this.sz().gap} ${this.separator() ? `border-b-[length:var(--bridges-shape-line-hairline)] border-[var(--bridges-color-border-subtle)] ${this.sz().separatorPad}` : ''}`);
    coerce(value) {
        return value == null ? '' : String(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsCompactField, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocLabsCompactField, isStandalone: true, selector: "soc-labs-compact-field", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, mode: { classPropertyName: "mode", publicName: "mode", isSignal: true, isRequired: false, transformFunction: null }, control: { classPropertyName: "control", publicName: "control", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, emptyText: { classPropertyName: "emptyText", publicName: "emptyText", isSignal: true, isRequired: false, transformFunction: null }, rows: { classPropertyName: "rows", publicName: "rows", isSignal: true, isRequired: false, transformFunction: null }, separator: { classPropertyName: "separator", publicName: "separator", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, host: { properties: { "attr.id": "null", "class": "hostClasses()", "attr.data-size": "size()" } }, providers: [provideLabsFormControl(() => SocLabsCompactField)], usesInheritance: true, ngImport: i0, template: `
    @if (mode() === 'edit') {
      <label [attr.for]="controlId()" [class]="labelClass">{{ label() }}</label>
      @switch (control()) {
        @case ('textarea') {
          <textarea
            [id]="controlId()"
            [rows]="rows()"
            [value]="value()"
            [attr.placeholder]="placeholder() ?? null"
            [disabled]="isDisabled()"
            (input)="value.set($any($event.target).value)"
            (blur)="onTouched()"
            [class]="textareaClass()"
          ></textarea>
        }
        @case ('select') {
          <span class="relative flex w-full min-w-0">
            <select
              [id]="controlId()"
              [disabled]="isDisabled()"
              (change)="value.set($any($event.target).value)"
              (blur)="onTouched()"
              [class]="selectClass()"
            >
              @if (placeholder() || !selectedOption()) {
                <option value="" [selected]="!selectedOption()" disabled>{{ placeholder() ?? '' }}</option>
              }
              @for (option of options(); track option.value) {
                <option [value]="option.value" [selected]="option.value === value()">{{ option.label }}</option>
              }
            </select>
            <svg
              lucideChevronDown
              aria-hidden="true"
              [class]="chevronClass()"
              [strokeWidth]="2"
            ></svg>
          </span>
        }
        @default {
          <input
            type="text"
            [id]="controlId()"
            [value]="value()"
            [attr.placeholder]="placeholder() ?? null"
            [disabled]="isDisabled()"
            (input)="value.set($any($event.target).value)"
            (blur)="onTouched()"
            [class]="inputClass()"
          />
        }
      }
    } @else {
      <span [id]="controlId() + '-label'" [class]="labelClass">{{ label() }}</span>
      <p
        [attr.aria-labelledby]="controlId() + '-label'"
        [class]="readText().empty ? readClass() + ' text-[var(--bridges-color-text-tertiary)]' : readClass() + ' text-[var(--bridges-color-text-primary)]'"
      >{{ readText().text }}</p>
    }
  `, isInline: true, dependencies: [{ kind: "component", type: LucideChevronDown, selector: "svg[lucideChevronDown]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsCompactField, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-labs-compact-field',
                    standalone: true,
                    imports: [LucideChevronDown],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    providers: [provideLabsFormControl(() => SocLabsCompactField)],
                    host: {
                        '[attr.id]': 'null',
                        '[class]': 'hostClasses()',
                        '[attr.data-size]': 'size()',
                    },
                    template: `
    @if (mode() === 'edit') {
      <label [attr.for]="controlId()" [class]="labelClass">{{ label() }}</label>
      @switch (control()) {
        @case ('textarea') {
          <textarea
            [id]="controlId()"
            [rows]="rows()"
            [value]="value()"
            [attr.placeholder]="placeholder() ?? null"
            [disabled]="isDisabled()"
            (input)="value.set($any($event.target).value)"
            (blur)="onTouched()"
            [class]="textareaClass()"
          ></textarea>
        }
        @case ('select') {
          <span class="relative flex w-full min-w-0">
            <select
              [id]="controlId()"
              [disabled]="isDisabled()"
              (change)="value.set($any($event.target).value)"
              (blur)="onTouched()"
              [class]="selectClass()"
            >
              @if (placeholder() || !selectedOption()) {
                <option value="" [selected]="!selectedOption()" disabled>{{ placeholder() ?? '' }}</option>
              }
              @for (option of options(); track option.value) {
                <option [value]="option.value" [selected]="option.value === value()">{{ option.label }}</option>
              }
            </select>
            <svg
              lucideChevronDown
              aria-hidden="true"
              [class]="chevronClass()"
              [strokeWidth]="2"
            ></svg>
          </span>
        }
        @default {
          <input
            type="text"
            [id]="controlId()"
            [value]="value()"
            [attr.placeholder]="placeholder() ?? null"
            [disabled]="isDisabled()"
            (input)="value.set($any($event.target).value)"
            (blur)="onTouched()"
            [class]="inputClass()"
          />
        }
      }
    } @else {
      <span [id]="controlId() + '-label'" [class]="labelClass">{{ label() }}</span>
      <p
        [attr.aria-labelledby]="controlId() + '-label'"
        [class]="readText().empty ? readClass() + ' text-[var(--bridges-color-text-tertiary)]' : readClass() + ' text-[var(--bridges-color-text-primary)]'"
      >{{ readText().text }}</p>
    }
  `,
                }]
        }] });

/**
 * Fond « sélectionné » de l'apparence `flush` : aucun token de bleu plus clair que `surface-selected`
 * n'existe — il est éclairci de moitié vers le blanc du kit (dérivé des tokens, aucune valeur en dur).
 */
const flushSelectedBg = 'bg-[color-mix(in_srgb,var(--bridges-color-surface-selected)_50%,var(--bridges-color-surface-neutral-white))]';
/** Slot à gauche de la ligne : icône, pastille (`soc-labs-chart-type-chip`), avatar… */
class SocLabsListRowLeading {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsListRowLeading, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocLabsListRowLeading, isStandalone: true, selector: "[socLabsListRowLeading]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsListRowLeading, decorators: [{
            type: Directive,
            args: [{ selector: '[socLabsListRowLeading]', standalone: true }]
        }] });
/** Slot d'action à droite (typiquement un `soc-labs-icon-button`). Inerte quand la ligne est verrouillée. */
class SocLabsListRowAction {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsListRowAction, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocLabsListRowAction, isStandalone: true, selector: "[socLabsListRowAction]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsListRowAction, decorators: [{
            type: Directive,
            args: [{ selector: '[socLabsListRowAction]', standalone: true }]
        }] });
/**
 * ## Rôle
 * Ligne de liste **compacte** pour les catalogues en panneau latéral : slot à gauche, titre +
 * sous-titre tronqués sur une ligne, slot d'action à droite.
 *
 * ## États
 * - **survol** : fond léger ; si `draggable`, une poignée de glisser apparaît à gauche.
 * - **sélectionné / ajouté** (`selected`) : fond bleu clair, titre bleu en gras, « Ajouté » lu par
 *   les lecteurs d'écran (`selectedLabel`).
 * - **verrouillé** (`locked`) : opacité 50 %, curseur interdit, action inerte ; `lockedReason`
 *   s'affiche en info-bulle (`soc-tooltip` du kit) au survol et au focus clavier.
 *
 * ## Glisser-déposer (`@angular/cdk/drag-drop`)
 * Poser `cdkDrag` sur `<soc-labs-list-row>` : la poignée interne est un `cdkDragHandle` rattaché au
 * `cdkDrag` de l'hôte, la ligne ne se saisit donc que par elle (le clic sur la ligne et sur l'action
 * reste libre). Désactiver le glisser d'une ligne verrouillée avec `[cdkDragDisabled]="locked"`. Le
 * glisser n'est pas accessible au clavier : l'action à droite reste le chemin principal.
 *
 * ## Apparence (`appearance`)
 * - **`card`** (défaut) : bloc arrondi, titre 14 px — les lignes s'espacent avec un `gap` sur le conteneur.
 * - **`flush`** : liste dense de panneau (catalogue de la Bibliothèque) — sans arrondi ni espacement, les
 *   lignes se touchent, séparées par un filet fin (`border-subtle`) ; padding vertical réduit, titre
 *   12 px, sous-titre 11 px. Survol : fond léger. Sélectionné : fond bleu très clair (le bleu
 *   `surface-selected` éclairci de moitié vers le blanc, `color-mix`), titre bleu action en demi-gras.
 *   Verrouillé : inchangé. Placer les lignes dans un conteneur sans `gap`.
 *
 * L'hôte porte `role="listitem"` : placer les lignes dans un conteneur `role="list"` (ou `<ul>`).
 * Il expose `data-state` (`default` | `selected` | `locked`) et `data-appearance` (`card` | `flush`).
 */
class SocLabsListRow {
    title = input.required();
    subtitle = input();
    /** Ajouté / sélectionné. */
    selected = input(false, { transform: booleanAttribute });
    locked = input(false, { transform: booleanAttribute });
    /** Raison du verrouillage, en info-bulle. */
    lockedReason = input();
    /** Affiche la poignée de glisser au survol (avec `cdkDrag` sur l'hôte). */
    draggable = input(false, { transform: booleanAttribute });
    /** Texte lu par les lecteurs d'écran pour l'état sélectionné. */
    selectedLabel = input('Ajouté');
    /** `card` (défaut, bloc arrondi) ou `flush` (liste dense : lignes jointives séparées par un filet). */
    appearance = input('card');
    focusRing = labsFocusRing;
    leading = contentChild(SocLabsListRowLeading);
    action = contentChild(SocLabsListRowAction);
    hasLeading = computed(() => !!this.leading());
    hasAction = computed(() => !!this.action());
    state = computed(() => (this.locked() ? 'locked' : this.selected() ? 'selected' : 'default'));
    hostClasses = computed(() => {
        if (this.appearance() === 'flush') {
            const flush = 'group/row flex w-full min-w-0 items-center gap-[var(--bridges-position-gap-sm)] border-b-[length:var(--bridges-shape-line-hairline)] border-[var(--bridges-color-border-subtle)] px-[var(--bridges-position-padding-3xs)] py-[var(--bridges-position-padding-xs)] [font-family:var(--bridges-shape-text-body-font)] transition-colors';
            if (this.locked())
                return `${flush} cursor-not-allowed opacity-50`;
            if (this.selected())
                return `${flush} ${flushSelectedBg}`;
            return `${flush} hover:bg-[var(--bridges-color-background-layer-1)]`;
        }
        const base = 'group/row flex w-full min-w-0 items-center gap-[var(--bridges-position-gap-sm)] rounded-[var(--bridges-shape-figure-radius-md)] px-[var(--bridges-position-padding-3xs)] py-[var(--bridges-position-padding-2xs)] [font-family:var(--bridges-shape-text-body-font)] transition-colors';
        if (this.locked())
            return `${base} cursor-not-allowed opacity-50`;
        if (this.selected())
            return `${base} bg-[var(--bridges-color-surface-selected)]`;
        return `${base} hover:bg-[var(--bridges-color-background-layer-1)]`;
    });
    titleClasses = computed(() => {
        const active = this.selected() && !this.locked();
        if (this.appearance() === 'flush') {
            return `truncate text-[length:var(--bridges-size-text-text-size-xs)] [line-height:var(--bridges-size-text-line-height-xs)] ${active
                ? 'text-[var(--bridges-color-text-action)] [font-weight:var(--bridges-shape-text-heading-2-weight)]'
                : 'text-[var(--bridges-color-text-primary)]'}`;
        }
        return `truncate text-[length:var(--bridges-size-text-text-size-sm)] [line-height:var(--bridges-size-text-line-height-sm)] ${active
            ? 'text-[var(--bridges-color-text-action)] [font-weight:var(--bridges-shape-text-label-weight)]'
            : 'text-[var(--bridges-color-text-primary)]'}`;
    });
    subtitleClasses = computed(() => this.appearance() === 'flush'
        ? 'truncate text-[length:calc((var(--bridges-size-text-text-size-tiny)+var(--bridges-size-text-text-size-xs))/2)] text-[var(--bridges-color-text-secondary)] [line-height:var(--bridges-size-text-line-height-xs)]'
        : 'truncate text-[length:var(--bridges-size-text-text-size-xs)] text-[var(--bridges-color-text-secondary)] [line-height:var(--bridges-size-text-line-height-xs)]');
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsListRow, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocLabsListRow, isStandalone: true, selector: "soc-labs-list-row", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, subtitle: { classPropertyName: "subtitle", publicName: "subtitle", isSignal: true, isRequired: false, transformFunction: null }, selected: { classPropertyName: "selected", publicName: "selected", isSignal: true, isRequired: false, transformFunction: null }, locked: { classPropertyName: "locked", publicName: "locked", isSignal: true, isRequired: false, transformFunction: null }, lockedReason: { classPropertyName: "lockedReason", publicName: "lockedReason", isSignal: true, isRequired: false, transformFunction: null }, draggable: { classPropertyName: "draggable", publicName: "draggable", isSignal: true, isRequired: false, transformFunction: null }, selectedLabel: { classPropertyName: "selectedLabel", publicName: "selectedLabel", isSignal: true, isRequired: false, transformFunction: null }, appearance: { classPropertyName: "appearance", publicName: "appearance", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "listitem" }, properties: { "class": "hostClasses()", "attr.aria-disabled": "locked() || null", "attr.data-state": "state()", "attr.data-appearance": "appearance()" } }, queries: [{ propertyName: "leading", first: true, predicate: SocLabsListRowLeading, descendants: true, isSignal: true }, { propertyName: "action", first: true, predicate: SocLabsListRowAction, descendants: true, isSignal: true }], ngImport: i0, template: `
    <ng-template #content>
      @if (draggable()) {
        <span
          cdkDragHandle
          aria-hidden="true"
          data-drag-handle
          class="flex size-[var(--bridges-size-icon-sm)] shrink-0 cursor-grab items-center justify-center text-[var(--bridges-color-icon-tertiary)] opacity-0 transition-opacity group-hover/row:opacity-100 active:cursor-grabbing"
        >
          <svg lucideGripVertical class="size-full" [strokeWidth]="2"></svg>
        </span>
      }
      @if (hasLeading()) {
        <span class="flex shrink-0 items-center"><ng-content select="[socLabsListRowLeading]" /></span>
      }
      <span class="flex min-w-0 flex-1 flex-col">
        <span [class]="titleClasses()" [attr.title]="locked() ? null : title()">{{ title() }}</span>
        @if (subtitle()) {
          <span
            [class]="subtitleClasses()"
            [attr.title]="locked() ? null : subtitle()"
          >{{ subtitle() }}</span>
        }
        @if (selected()) {
          <span class="sr-only">{{ selectedLabel() }}</span>
        }
      </span>
      @if (hasAction()) {
        <span class="flex shrink-0 items-center" [attr.inert]="locked() ? '' : null"><ng-content select="[socLabsListRowAction]" /></span>
      }
    </ng-template>

    @if (locked() && lockedReason()) {
      <soc-tooltip position="top" tabindex="0" [class]="'w-full min-w-0 items-center gap-[var(--bridges-position-gap-sm)] rounded-[var(--bridges-shape-figure-radius-sm)] ' + focusRing">
        <ng-container [ngTemplateOutlet]="content" />
        <span socTooltipLabel>{{ lockedReason() }}</span>
      </soc-tooltip>
    } @else {
      <ng-container [ngTemplateOutlet]="content" />
    }
  `, isInline: true, dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: CdkDragHandle, selector: "[cdkDragHandle]", inputs: ["cdkDragHandleDisabled"] }, { kind: "component", type: LucideGripVertical, selector: "svg[lucideGripVertical]" }, { kind: "component", type: SocTooltip, selector: "soc-tooltip", inputs: ["position", "variant", "title", "status", "showIcon"] }, { kind: "directive", type: SocTooltipLabel, selector: "[socTooltipLabel]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsListRow, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-labs-list-row',
                    standalone: true,
                    imports: [NgTemplateOutlet, CdkDragHandle, LucideGripVertical, SocTooltip, SocTooltipLabel],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        role: 'listitem',
                        '[class]': 'hostClasses()',
                        '[attr.aria-disabled]': 'locked() || null',
                        '[attr.data-state]': 'state()',
                        '[attr.data-appearance]': 'appearance()',
                    },
                    template: `
    <ng-template #content>
      @if (draggable()) {
        <span
          cdkDragHandle
          aria-hidden="true"
          data-drag-handle
          class="flex size-[var(--bridges-size-icon-sm)] shrink-0 cursor-grab items-center justify-center text-[var(--bridges-color-icon-tertiary)] opacity-0 transition-opacity group-hover/row:opacity-100 active:cursor-grabbing"
        >
          <svg lucideGripVertical class="size-full" [strokeWidth]="2"></svg>
        </span>
      }
      @if (hasLeading()) {
        <span class="flex shrink-0 items-center"><ng-content select="[socLabsListRowLeading]" /></span>
      }
      <span class="flex min-w-0 flex-1 flex-col">
        <span [class]="titleClasses()" [attr.title]="locked() ? null : title()">{{ title() }}</span>
        @if (subtitle()) {
          <span
            [class]="subtitleClasses()"
            [attr.title]="locked() ? null : subtitle()"
          >{{ subtitle() }}</span>
        }
        @if (selected()) {
          <span class="sr-only">{{ selectedLabel() }}</span>
        }
      </span>
      @if (hasAction()) {
        <span class="flex shrink-0 items-center" [attr.inert]="locked() ? '' : null"><ng-content select="[socLabsListRowAction]" /></span>
      }
    </ng-template>

    @if (locked() && lockedReason()) {
      <soc-tooltip position="top" tabindex="0" [class]="'w-full min-w-0 items-center gap-[var(--bridges-position-gap-sm)] rounded-[var(--bridges-shape-figure-radius-sm)] ' + focusRing">
        <ng-container [ngTemplateOutlet]="content" />
        <span socTooltipLabel>{{ lockedReason() }}</span>
      </soc-tooltip>
    } @else {
      <ng-container [ngTemplateOutlet]="content" />
    }
  `,
                }]
        }] });

const DEFAULT_LABELS = {
    empty: 'Glissez un élément ici ou cliquez pour ajouter',
    slot: 'Ajouter…',
};
/**
 * ## Rôle
 * Zone de dépôt, **cliquable** (le clic reste le chemin principal, le glisser un raccourci) :
 * - `empty` : grand cadre pointillé avec une icône + et un texte — section ou liste vide ;
 * - `slot` : emplacement compact « + Ajouter… » en bas d'une liste ;
 * - état **survol de dépôt** (`data-state="over"`) : contour pointillé bleu et léger fond bleu.
 *
 * ## Glisser-déposer (`@angular/cdk/drag-drop`)
 * Poser `cdkDropList` sur `<soc-labs-drop-zone>` : le composant écoute ses événements `entered` /
 * `exited` / `dropped` et passe seul à l'état « survol de dépôt » ; le placeholder du CDK est masqué
 * à l'intérieur de la zone. Sans CDK (ou pour un autre mécanisme), forcer l'état avec `active`.
 *
 * ## Accessibilité
 * Un vrai `<button>` (texte visible = nom accessible) ; `(activate)` est émis au clic, à Entrée et à
 * Espace. `disabled` désactive le bouton et l'état de survol.
 */
class SocLabsDropZone {
    variant = input('empty');
    /** Texte de la zone ; défaut selon la variante. */
    label = input();
    /** Texte secondaire (variante `empty`). */
    hint = input();
    /** Force l'état « survol de dépôt » (sans CDK, ou glisser natif). */
    active = input(false, { transform: booleanAttribute });
    disabled = input(false, { transform: booleanAttribute });
    /** Clic, Entrée ou Espace sur la zone. */
    activate = output();
    cdkOver = signal(false);
    isOver = computed(() => !this.disabled() && (this.active() || this.cdkOver()));
    text = computed(() => this.label() ?? DEFAULT_LABELS[this.variant()]);
    constructor() {
        const dropList = inject(CdkDropList, { optional: true, self: true });
        if (dropList) {
            const subs = [
                dropList.entered.subscribe(() => this.cdkOver.set(true)),
                dropList.exited.subscribe(() => this.cdkOver.set(false)),
                dropList.dropped.subscribe(() => this.cdkOver.set(false)),
            ];
            inject(DestroyRef).onDestroy(() => subs.forEach((s) => s.unsubscribe()));
        }
    }
    buttonClasses = computed(() => {
        const over = this.isOver();
        const tone = over
            ? 'border-[var(--bridges-color-border-focus)] bg-[var(--bridges-color-accent-blue-bg)]'
            : 'border-[var(--bridges-color-border-tertiary)] bg-transparent hover:border-[var(--bridges-color-border-secondary)] hover:bg-[var(--bridges-color-background-layer-1)]';
        const base = `group flex w-full min-w-0 border-[length:var(--bridges-shape-line-default)] border-dashed [font-family:var(--bridges-shape-text-body-font)] text-[length:var(--bridges-size-text-text-size-sm)] transition-colors disabled:cursor-not-allowed disabled:border-[var(--bridges-color-border-subtle)] disabled:bg-transparent disabled:text-[var(--bridges-color-text-disabled)] ${labsFocusRing} ${tone}`;
        return this.variant() === 'empty'
            ? `${base} min-h-[calc(var(--bridges-size-icon-2xl)*4)] flex-col items-center justify-center gap-[var(--bridges-position-gap-md)] rounded-[var(--bridges-shape-figure-radius-lg)] p-[var(--bridges-position-padding-xl)] text-center text-[var(--bridges-color-text-secondary)]`
            : `${base} items-center gap-[var(--bridges-position-gap-2xs)] rounded-[var(--bridges-shape-figure-radius-md)] px-[var(--bridges-position-padding-3xs)] py-[var(--bridges-position-padding-2xs)] text-left text-[var(--bridges-color-text-action)]`;
    });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsDropZone, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocLabsDropZone, isStandalone: true, selector: "soc-labs-drop-zone", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, hint: { classPropertyName: "hint", publicName: "hint", isSignal: true, isRequired: false, transformFunction: null }, active: { classPropertyName: "active", publicName: "active", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { activate: "activate" }, host: { properties: { "attr.data-state": "isOver() ? \"over\" : null" }, classAttribute: "flex w-full min-w-0 [&_.cdk-drag-placeholder]:hidden" }, ngImport: i0, template: `
    <button type="button" [disabled]="disabled()" [class]="buttonClasses()" (click)="activate.emit()">
      @if (variant() === 'empty') {
        <span
          aria-hidden="true"
          class="flex size-[var(--bridges-size-icon-2xl)] items-center justify-center rounded-[var(--bridges-shape-figure-radius-full)] bg-[var(--bridges-color-background-layer-1)] text-[var(--bridges-color-icon-action)] group-disabled:text-[var(--bridges-color-icon-disabled)]"
        >
          <svg lucidePlus class="size-[var(--bridges-size-icon-md)]" [strokeWidth]="2"></svg>
        </span>
        <span class="flex flex-col gap-[var(--bridges-position-gap-2xs)]">
          <span>{{ text() }}</span>
          @if (hint()) {
            <span class="text-[length:var(--bridges-size-text-text-size-xs)] text-[var(--bridges-color-text-tertiary)]">{{ hint() }}</span>
          }
        </span>
      } @else {
        <svg lucidePlus aria-hidden="true" class="size-[var(--bridges-size-icon-sm)] shrink-0" [strokeWidth]="2"></svg>
        <span class="truncate">{{ text() }}</span>
      }
    </button>
  `, isInline: true, dependencies: [{ kind: "component", type: LucidePlus, selector: "svg[lucidePlus]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsDropZone, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-labs-drop-zone',
                    standalone: true,
                    imports: [LucidePlus],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        // CdkDropList moves its drag placeholder into the drop container (this host) — keep it invisible.
                        class: 'flex w-full min-w-0 [&_.cdk-drag-placeholder]:hidden',
                        '[attr.data-state]': 'isOver() ? "over" : null',
                    },
                    template: `
    <button type="button" [disabled]="disabled()" [class]="buttonClasses()" (click)="activate.emit()">
      @if (variant() === 'empty') {
        <span
          aria-hidden="true"
          class="flex size-[var(--bridges-size-icon-2xl)] items-center justify-center rounded-[var(--bridges-shape-figure-radius-full)] bg-[var(--bridges-color-background-layer-1)] text-[var(--bridges-color-icon-action)] group-disabled:text-[var(--bridges-color-icon-disabled)]"
        >
          <svg lucidePlus class="size-[var(--bridges-size-icon-md)]" [strokeWidth]="2"></svg>
        </span>
        <span class="flex flex-col gap-[var(--bridges-position-gap-2xs)]">
          <span>{{ text() }}</span>
          @if (hint()) {
            <span class="text-[length:var(--bridges-size-text-text-size-xs)] text-[var(--bridges-color-text-tertiary)]">{{ hint() }}</span>
          }
        </span>
      } @else {
        <svg lucidePlus aria-hidden="true" class="size-[var(--bridges-size-icon-sm)] shrink-0" [strokeWidth]="2"></svg>
        <span class="truncate">{{ text() }}</span>
      }
    </button>
  `,
                }]
        }], ctorParameters: () => [] });

/** Badge à côté du titre (ex. `<soc-tag socLabsOverlayBadge>Données simulées</soc-tag>`). */
class SocLabsOverlayBadge {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsOverlayBadge, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocLabsOverlayBadge, isStandalone: true, selector: "[socLabsOverlayBadge]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsOverlayBadge, decorators: [{
            type: Directive,
            args: [{ selector: '[socLabsOverlayBadge]', standalone: true }]
        }] });
const FOCUSABLE = 'a[href], area[href], button:not([disabled]), input:not([disabled]):not([type=hidden]), select:not([disabled]), textarea:not([disabled]), iframe, [contenteditable=""], [contenteditable=true], [tabindex]:not([tabindex="-1"])';
/**
 * ## Rôle
 * Calque **plein écran** qui recouvre toute l'application (bandeau et menu compris) : prévisualiser
 * un tableau de bord, consulter un contenu dense sans le shell. Barre du haut (titre, sous-titre,
 * badge, bouton Fermer) et contenu qui défile.
 *
 * ## Comportement et accessibilité
 * - `role="dialog"` + `aria-modal`, nommé par le titre et décrit par le sous-titre.
 * - À l'ouverture : le focus entre dans le calque, le défilement de la page est bloqué.
 * - **Piège du focus** : Tab / Maj+Tab bouclent dans le calque.
 * - **Échap** ou le bouton Fermer : `open` repasse à `false` et `(close)` est émis.
 * - À la fermeture : le focus revient à l'élément qui l'avait avant l'ouverture.
 *
 * `open` est un `model` (↔) : `[(open)]="apercu"` suit la fermeture tout seul. Rendu dans `<body>`
 * (comme `soc-dialog`), au-dessus des autres overlays du kit.
 */
class SocLabsFullscreenOverlay {
    open = model(false);
    title = input.required();
    subtitle = input();
    closeLabel = input('Fermer');
    /** Émis à la fermeture par Échap ou par le bouton Fermer. */
    close = output();
    titleId = nextLabsId('soc-labs-overlay-title');
    subtitleId = nextLabsId('soc-labs-overlay-subtitle');
    badge = contentChild(SocLabsOverlayBadge);
    hasBadge = computed(() => !!this.badge());
    panel = viewChild('panel');
    returnFocusTo = null;
    previousOverflow = null;
    constructor() {
        effect(() => {
            const el = this.panel()?.nativeElement;
            if (el) {
                if (el.parentElement !== document.body)
                    document.body.appendChild(el);
                if (this.previousOverflow === null) {
                    this.returnFocusTo = document.activeElement instanceof HTMLElement ? document.activeElement : null;
                    this.previousOverflow = document.body.style.overflow;
                    document.body.style.overflow = 'hidden';
                    el.focus();
                }
            }
            else {
                this.release();
            }
        });
        const onKeydown = (e) => {
            if (this.open() && e.key === 'Escape') {
                e.preventDefault();
                this.dismiss();
            }
        };
        document.addEventListener('keydown', onKeydown);
        inject(DestroyRef).onDestroy(() => {
            document.removeEventListener('keydown', onKeydown);
            this.panel()?.nativeElement.remove();
            this.release();
        });
    }
    dismiss() {
        this.open.set(false);
        this.close.emit();
    }
    trapFocus(event) {
        if (event.key !== 'Tab')
            return;
        const panel = this.panel()?.nativeElement;
        if (!panel)
            return;
        const items = [...panel.querySelectorAll(FOCUSABLE)].filter((el) => !el.closest('[inert]'));
        if (!items.length) {
            event.preventDefault();
            return;
        }
        const first = items[0];
        const last = items[items.length - 1];
        const active = document.activeElement;
        if (event.shiftKey && (active === first || active === panel)) {
            event.preventDefault();
            last.focus();
        }
        else if (!event.shiftKey && active === last) {
            event.preventDefault();
            first.focus();
        }
    }
    /** Unlocks page scroll and gives focus back (once per opening). */
    release() {
        if (this.previousOverflow === null)
            return;
        document.body.style.overflow = this.previousOverflow;
        this.previousOverflow = null;
        const target = this.returnFocusTo;
        this.returnFocusTo = null;
        if (target?.isConnected)
            target.focus();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsFullscreenOverlay, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocLabsFullscreenOverlay, isStandalone: true, selector: "soc-labs-fullscreen-overlay", inputs: { open: { classPropertyName: "open", publicName: "open", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, subtitle: { classPropertyName: "subtitle", publicName: "subtitle", isSignal: true, isRequired: false, transformFunction: null }, closeLabel: { classPropertyName: "closeLabel", publicName: "closeLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { open: "openChange", close: "close" }, queries: [{ propertyName: "badge", first: true, predicate: SocLabsOverlayBadge, descendants: true, isSignal: true }], viewQueries: [{ propertyName: "panel", first: true, predicate: ["panel"], descendants: true, isSignal: true }], ngImport: i0, template: `
    @if (open()) {
      <div
        #panel
        role="dialog"
        aria-modal="true"
        tabindex="-1"
        [attr.aria-labelledby]="titleId"
        [attr.aria-describedby]="subtitle() ? subtitleId : null"
        (keydown)="trapFocus($event)"
        class="fixed inset-0 z-[60] flex flex-col bg-[var(--bridges-color-background-layer-1)] outline-none"
      >
        <header
          class="flex shrink-0 items-center gap-[var(--bridges-position-gap-lg)] border-b-[length:var(--bridges-shape-line-hairline)] border-[var(--bridges-color-border-subtle)] bg-[var(--bridges-color-surface-neutral-white)] px-[var(--bridges-position-padding-xl)] py-[var(--bridges-position-padding-md)]"
        >
          <div class="flex min-w-0 flex-1 flex-col gap-[var(--bridges-position-gap-2xs)]">
            <div class="flex min-w-0 items-center gap-[var(--bridges-position-gap-sm)]">
              <h2
                [id]="titleId"
                class="truncate text-[length:var(--bridges-size-text-text-size-xl)] text-[var(--bridges-color-text-primary)] [font-family:var(--bridges-shape-text-label-font)] [font-weight:var(--bridges-shape-text-label-weight)]"
              >{{ title() }}</h2>
              @if (hasBadge()) {
                <span class="flex shrink-0"><ng-content select="[socLabsOverlayBadge]" /></span>
              }
            </div>
            @if (subtitle()) {
              <p [id]="subtitleId" class="truncate text-[length:var(--bridges-size-text-text-size-sm)] text-[var(--bridges-color-text-secondary)]">{{ subtitle() }}</p>
            }
          </div>
          <soc-labs-icon-button data-close [ariaLabel]="closeLabel()" [tooltip]="closeLabel()" tooltipPosition="bottom" size="md" (click)="dismiss()">
            <svg lucideX class="size-full" [strokeWidth]="2"></svg>
          </soc-labs-icon-button>
        </header>
        <div class="min-h-0 flex-1 overflow-auto p-[var(--bridges-position-padding-xl)]">
          <ng-content />
        </div>
      </div>
    }
  `, isInline: true, dependencies: [{ kind: "component", type: SocLabsIconButton, selector: "soc-labs-icon-button", inputs: ["ariaLabel", "size", "variant", "shape", "tooltip", "tooltipPosition", "disabled", "type", "pressed", "ariaExpanded", "ariaControls"] }, { kind: "component", type: LucideX, selector: "svg[lucideX]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsFullscreenOverlay, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-labs-fullscreen-overlay',
                    standalone: true,
                    imports: [SocLabsIconButton, LucideX],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    template: `
    @if (open()) {
      <div
        #panel
        role="dialog"
        aria-modal="true"
        tabindex="-1"
        [attr.aria-labelledby]="titleId"
        [attr.aria-describedby]="subtitle() ? subtitleId : null"
        (keydown)="trapFocus($event)"
        class="fixed inset-0 z-[60] flex flex-col bg-[var(--bridges-color-background-layer-1)] outline-none"
      >
        <header
          class="flex shrink-0 items-center gap-[var(--bridges-position-gap-lg)] border-b-[length:var(--bridges-shape-line-hairline)] border-[var(--bridges-color-border-subtle)] bg-[var(--bridges-color-surface-neutral-white)] px-[var(--bridges-position-padding-xl)] py-[var(--bridges-position-padding-md)]"
        >
          <div class="flex min-w-0 flex-1 flex-col gap-[var(--bridges-position-gap-2xs)]">
            <div class="flex min-w-0 items-center gap-[var(--bridges-position-gap-sm)]">
              <h2
                [id]="titleId"
                class="truncate text-[length:var(--bridges-size-text-text-size-xl)] text-[var(--bridges-color-text-primary)] [font-family:var(--bridges-shape-text-label-font)] [font-weight:var(--bridges-shape-text-label-weight)]"
              >{{ title() }}</h2>
              @if (hasBadge()) {
                <span class="flex shrink-0"><ng-content select="[socLabsOverlayBadge]" /></span>
              }
            </div>
            @if (subtitle()) {
              <p [id]="subtitleId" class="truncate text-[length:var(--bridges-size-text-text-size-sm)] text-[var(--bridges-color-text-secondary)]">{{ subtitle() }}</p>
            }
          </div>
          <soc-labs-icon-button data-close [ariaLabel]="closeLabel()" [tooltip]="closeLabel()" tooltipPosition="bottom" size="md" (click)="dismiss()">
            <svg lucideX class="size-full" [strokeWidth]="2"></svg>
          </soc-labs-icon-button>
        </header>
        <div class="min-h-0 flex-1 overflow-auto p-[var(--bridges-position-padding-xl)]">
          <ng-content />
        </div>
      </div>
    }
  `,
                }]
        }], ctorParameters: () => [] });

/** Barre du haut, à gauche : bouton retour (ex. `soc-labs-icon-button` avec une flèche). */
class SocLabsWorkspaceBack {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsWorkspaceBack, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocLabsWorkspaceBack, isStandalone: true, selector: "[socLabsWorkspaceBack]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsWorkspaceBack, decorators: [{
            type: Directive,
            args: [{ selector: '[socLabsWorkspaceBack]', standalone: true }]
        }] });
/** Barre du haut : titre (texte, `soc-labs-inline-edit`…). */
class SocLabsWorkspaceTitle {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsWorkspaceTitle, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocLabsWorkspaceTitle, isStandalone: true, selector: "[socLabsWorkspaceTitle]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsWorkspaceTitle, decorators: [{
            type: Directive,
            args: [{ selector: '[socLabsWorkspaceTitle]', standalone: true }]
        }] });
/** Barre du haut, après le titre : badge ou indication (« Brouillon », « Ajoutez des graphes → »). */
class SocLabsWorkspaceHint {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsWorkspaceHint, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocLabsWorkspaceHint, isStandalone: true, selector: "[socLabsWorkspaceHint]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsWorkspaceHint, decorators: [{
            type: Directive,
            args: [{ selector: '[socLabsWorkspaceHint]', standalone: true }]
        }] });
/** Barre du haut, à droite : actions (Prévisualiser, Enregistrer…). */
class SocLabsWorkspaceActions {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsWorkspaceActions, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocLabsWorkspaceActions, isStandalone: true, selector: "[socLabsWorkspaceActions]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsWorkspaceActions, decorators: [{
            type: Directive,
            args: [{ selector: '[socLabsWorkspaceActions]', standalone: true }]
        }] });
/** Panneau gauche (optionnel). */
class SocLabsWorkspaceLeft {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsWorkspaceLeft, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocLabsWorkspaceLeft, isStandalone: true, selector: "[socLabsWorkspaceLeft]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsWorkspaceLeft, decorators: [{
            type: Directive,
            args: [{ selector: '[socLabsWorkspaceLeft]', standalone: true }]
        }] });
/** Panneau droit (optionnel). */
class SocLabsWorkspaceRight {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsWorkspaceRight, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocLabsWorkspaceRight, isStandalone: true, selector: "[socLabsWorkspaceRight]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsWorkspaceRight, decorators: [{
            type: Directive,
            args: [{ selector: '[socLabsWorkspaceRight]', standalone: true }]
        }] });
const panelBase = 'flex min-h-0 shrink-0 flex-col gap-[var(--bridges-position-gap-md)] overflow-y-auto border-[var(--bridges-color-border-subtle)] bg-[var(--bridges-color-surface-neutral-white)] p-[var(--bridges-position-padding-md)]';
/** Panneau replié : rail étroit = bouton `sm` (icône lg) + padding xs de chaque côté + bordure. */
const railBase = 'flex min-h-0 shrink-0 flex-col items-center gap-[var(--bridges-position-gap-sm)] overflow-hidden border-[var(--bridges-color-border-subtle)] bg-[var(--bridges-color-surface-neutral-white)] py-[var(--bridges-position-padding-xs)] w-[calc(var(--bridges-size-icon-lg)+2*var(--bridges-position-padding-xs)+var(--bridges-shape-line-hairline))]';
const railLabel = 'whitespace-nowrap [writing-mode:vertical-rl] text-[length:var(--bridges-size-text-text-size-sm)] text-[var(--bridges-color-text-secondary)] [font-family:var(--bridges-shape-text-label-font)] [font-weight:var(--bridges-shape-text-label-weight)]';
/** Contenu projeté d'un panneau (déplié). Jamais détruit : masqué par `hidden` quand le panneau est replié. */
const panelContent = 'flex shrink-0 flex-col gap-[var(--bridges-position-gap-md)]';
/**
 * ## Rôle
 * **Espace de travail plein écran** sous le bandeau de l'application (composition d'un tableau de
 * bord) : barre du haut, panneau gauche, zone centrale sur le fond gris du kit, panneau droit.
 * Chaque colonne défile indépendamment ; les panneaux sont blancs avec une bordure.
 *
 * ## Slots (tous optionnels)
 * Barre du haut : `socLabsWorkspaceBack`, `socLabsWorkspaceTitle`, `socLabsWorkspaceHint`,
 * `socLabsWorkspaceActions` (la barre n'est rendue que si l'un d'eux est présent). Colonnes :
 * `socLabsWorkspaceLeft`, `socLabsWorkspaceRight` ; le contenu sans marqueur va au centre.
 *
 * ## Mise en page
 * L'hôte prend toute la hauteur de son parent (`h-full`) : le placer dans une zone de hauteur
 * définie (contenu de `soc-app-shell`). Largeurs des panneaux : `leftWidth` (défaut 220px) et
 * `rightWidth` (défaut 240px), toute longueur CSS.
 *
 * **Panneaux repliables** (écrans de PC portables) : `collapsibleBelow` (px, défaut `null` = jamais)
 * fixe la largeur de fenêtre sous laquelle la mise en page passe en mode « étroit » (`matchMedia`,
 * suivi en direct). En entrant dans ce mode, les deux panneaux se replient ; en le quittant, ils se
 * déplient et les boutons disparaissent. Dans ce mode, chaque panneau présent porte un bouton
 * (`soc-labs-icon-button`) : déplié, en haut du panneau ; replié, le panneau devient un rail étroit
 * (largeur dérivée des tokens) avec le bouton et son libellé écrit verticalement. L'état est exposé
 * par `leftCollapsed` / `rightCollapsed` (`model`, liables en `[(leftCollapsed)]`) ; hors mode
 * étroit, les panneaux sont toujours dépliés quelle que soit leur valeur. Chaque `<aside>` porte
 * `data-state="collapsed|expanded"`.
 *
 * Le contenu d'un panneau replié reste dans le DOM (masqué par `hidden`) : son état (saisie,
 * recherche, composants) est conservé au dépliage.
 *
 * ## Accessibilité
 * Panneaux en `<aside>` et centre en `<section>`, nommés par `leftLabel` / `rightLabel` /
 * `centerLabel`. Boutons de repli : « Replier le panneau {libellé} » / « Déplier le panneau
 * {libellé} », avec `aria-expanded` et `aria-controls` vers le contenu du panneau ; le libellé
 * vertical du rail est décoratif (`aria-hidden`), l'`<aside>` restant nommé.
 */
class SocLabsWorkspaceLayout {
    /** Largeur du panneau gauche (longueur CSS). */
    leftWidth = input('220px');
    /** Largeur du panneau droit (longueur CSS). */
    rightWidth = input('240px');
    leftLabel = input('Informations');
    rightLabel = input('Bibliothèque');
    centerLabel = input('Espace de travail');
    /**
     * Largeur de fenêtre (px) sous laquelle les panneaux deviennent repliables (mode « étroit »).
     * `null` (défaut) = jamais : panneaux toujours dépliés, aucun bouton.
     */
    collapsibleBelow = input(null);
    /** Panneau gauche replié (effectif seulement en mode étroit). Mis à `true` en entrant dans ce mode. */
    leftCollapsed = model(false);
    /** Panneau droit replié (effectif seulement en mode étroit). Mis à `true` en entrant dans ce mode. */
    rightCollapsed = model(false);
    leftClass = `${panelBase} border-r-[length:var(--bridges-shape-line-hairline)]`;
    rightClass = `${panelBase} border-l-[length:var(--bridges-shape-line-hairline)]`;
    leftRailClass = `${railBase} border-r-[length:var(--bridges-shape-line-hairline)]`;
    rightRailClass = `${railBase} border-l-[length:var(--bridges-shape-line-hairline)]`;
    contentClass = panelContent;
    railLabelClass = railLabel;
    leftContentId = nextLabsId('soc-labs-workspace-left');
    rightContentId = nextLabsId('soc-labs-workspace-right');
    /** Fenêtre plus étroite que `collapsibleBelow`. */
    narrow = signal(false);
    leftIsCollapsed = computed(() => this.narrow() && this.leftCollapsed());
    rightIsCollapsed = computed(() => this.narrow() && this.rightCollapsed());
    back = contentChild(SocLabsWorkspaceBack);
    title = contentChild(SocLabsWorkspaceTitle);
    hint = contentChild(SocLabsWorkspaceHint);
    actions = contentChild(SocLabsWorkspaceActions);
    left = contentChild(SocLabsWorkspaceLeft);
    right = contentChild(SocLabsWorkspaceRight);
    hasBack = computed(() => !!this.back());
    hasTitle = computed(() => !!this.title());
    hasHint = computed(() => !!this.hint());
    hasActions = computed(() => !!this.actions());
    hasLeft = computed(() => !!this.left());
    hasRight = computed(() => !!this.right());
    hasTopBar = computed(() => this.hasBack() || this.hasTitle() || this.hasHint() || this.hasActions());
    constructor() {
        effect((onCleanup) => {
            const below = this.collapsibleBelow();
            const canMatch = typeof window !== 'undefined' && typeof window.matchMedia === 'function';
            const query = below == null || !canMatch ? null : window.matchMedia(`(max-width: ${below - 0.02}px)`);
            untracked(() => this.setNarrow(!!query?.matches));
            if (!query)
                return;
            const onChange = (event) => this.setNarrow(event.matches);
            query.addEventListener('change', onChange);
            onCleanup(() => query.removeEventListener('change', onChange));
        });
    }
    /** Entrer en mode étroit replie les deux panneaux ; en sortir les déplie. */
    setNarrow(narrow) {
        if (narrow === this.narrow())
            return;
        this.narrow.set(narrow);
        this.leftCollapsed.set(narrow);
        this.rightCollapsed.set(narrow);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsWorkspaceLayout, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocLabsWorkspaceLayout, isStandalone: true, selector: "soc-labs-workspace-layout", inputs: { leftWidth: { classPropertyName: "leftWidth", publicName: "leftWidth", isSignal: true, isRequired: false, transformFunction: null }, rightWidth: { classPropertyName: "rightWidth", publicName: "rightWidth", isSignal: true, isRequired: false, transformFunction: null }, leftLabel: { classPropertyName: "leftLabel", publicName: "leftLabel", isSignal: true, isRequired: false, transformFunction: null }, rightLabel: { classPropertyName: "rightLabel", publicName: "rightLabel", isSignal: true, isRequired: false, transformFunction: null }, centerLabel: { classPropertyName: "centerLabel", publicName: "centerLabel", isSignal: true, isRequired: false, transformFunction: null }, collapsibleBelow: { classPropertyName: "collapsibleBelow", publicName: "collapsibleBelow", isSignal: true, isRequired: false, transformFunction: null }, leftCollapsed: { classPropertyName: "leftCollapsed", publicName: "leftCollapsed", isSignal: true, isRequired: false, transformFunction: null }, rightCollapsed: { classPropertyName: "rightCollapsed", publicName: "rightCollapsed", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { leftCollapsed: "leftCollapsedChange", rightCollapsed: "rightCollapsedChange" }, host: { classAttribute: "flex h-full min-h-0 w-full min-w-0 flex-col [font-family:var(--bridges-shape-text-body-font)]" }, queries: [{ propertyName: "back", first: true, predicate: SocLabsWorkspaceBack, descendants: true, isSignal: true }, { propertyName: "title", first: true, predicate: SocLabsWorkspaceTitle, descendants: true, isSignal: true }, { propertyName: "hint", first: true, predicate: SocLabsWorkspaceHint, descendants: true, isSignal: true }, { propertyName: "actions", first: true, predicate: SocLabsWorkspaceActions, descendants: true, isSignal: true }, { propertyName: "left", first: true, predicate: SocLabsWorkspaceLeft, descendants: true, isSignal: true }, { propertyName: "right", first: true, predicate: SocLabsWorkspaceRight, descendants: true, isSignal: true }], ngImport: i0, template: `
    @if (hasTopBar()) {
      <div
        data-region="top-bar"
        class="flex shrink-0 items-center gap-[var(--bridges-position-gap-md)] border-b-[length:var(--bridges-shape-line-hairline)] border-[var(--bridges-color-border-subtle)] bg-[var(--bridges-color-surface-neutral-white)] px-[var(--bridges-position-padding-lg)] py-[var(--bridges-position-padding-3xs)]"
      >
        @if (hasBack()) {
          <span class="flex shrink-0 items-center"><ng-content select="[socLabsWorkspaceBack]" /></span>
        }
        <div class="flex min-w-0 flex-1 items-center gap-[var(--bridges-position-gap-sm)]">
          @if (hasTitle()) {
            <span
              class="flex min-w-0 items-center truncate text-[length:var(--bridges-size-text-text-size-lg)] text-[var(--bridges-color-text-primary)] [font-family:var(--bridges-shape-text-label-font)] [font-weight:var(--bridges-shape-text-label-weight)]"
            ><ng-content select="[socLabsWorkspaceTitle]" /></span>
          }
          @if (hasHint()) {
            <span class="flex shrink-0 items-center text-[length:var(--bridges-size-text-text-size-sm)] text-[var(--bridges-color-text-secondary)]"><ng-content select="[socLabsWorkspaceHint]" /></span>
          }
        </div>
        @if (hasActions()) {
          <span class="flex shrink-0 items-center gap-[var(--bridges-position-gap-sm)]"><ng-content select="[socLabsWorkspaceActions]" /></span>
        }
      </div>
    }
    <div class="flex min-h-0 flex-1">
      @if (hasLeft()) {
        <aside
          data-region="left"
          [attr.aria-label]="leftLabel()"
          [attr.data-state]="leftIsCollapsed() ? 'collapsed' : 'expanded'"
          [class]="leftIsCollapsed() ? leftRailClass : leftClass"
          [style.width]="leftIsCollapsed() ? null : leftWidth()"
        >
          @if (narrow()) {
            @if (leftIsCollapsed()) {
              <soc-labs-icon-button data-toggle="left" [ariaLabel]="'Déplier le panneau ' + leftLabel()" [ariaExpanded]="false" [ariaControls]="leftContentId" (click)="leftCollapsed.set(false)">
                <svg lucidePanelLeftOpen class="size-full" [strokeWidth]="1.5"></svg>
              </soc-labs-icon-button>
              <span aria-hidden="true" [class]="railLabelClass">{{ leftLabel() }}</span>
            } @else {
              <div class="flex shrink-0 justify-end">
                <soc-labs-icon-button data-toggle="left" [ariaLabel]="'Replier le panneau ' + leftLabel()" [ariaExpanded]="true" [ariaControls]="leftContentId" (click)="leftCollapsed.set(true)">
                  <svg lucidePanelLeftClose class="size-full" [strokeWidth]="1.5"></svg>
                </soc-labs-icon-button>
              </div>
            }
          }
          <div data-panel-content [id]="leftContentId" [hidden]="leftIsCollapsed()" [class]="leftIsCollapsed() ? 'hidden' : contentClass">
            <ng-content select="[socLabsWorkspaceLeft]" />
          </div>
        </aside>
      }
      <section
        data-region="center"
        [attr.aria-label]="centerLabel()"
        class="flex min-h-0 min-w-0 flex-1 flex-col gap-[var(--bridges-position-gap-lg)] overflow-y-auto bg-[var(--bridges-color-background-layer-1)] p-[var(--bridges-position-padding-lg)]"
      >
        <ng-content />
      </section>
      @if (hasRight()) {
        <aside
          data-region="right"
          [attr.aria-label]="rightLabel()"
          [attr.data-state]="rightIsCollapsed() ? 'collapsed' : 'expanded'"
          [class]="rightIsCollapsed() ? rightRailClass : rightClass"
          [style.width]="rightIsCollapsed() ? null : rightWidth()"
        >
          @if (narrow()) {
            @if (rightIsCollapsed()) {
              <soc-labs-icon-button data-toggle="right" [ariaLabel]="'Déplier le panneau ' + rightLabel()" [ariaExpanded]="false" [ariaControls]="rightContentId" (click)="rightCollapsed.set(false)">
                <svg lucidePanelRightOpen class="size-full" [strokeWidth]="1.5"></svg>
              </soc-labs-icon-button>
              <span aria-hidden="true" [class]="railLabelClass">{{ rightLabel() }}</span>
            } @else {
              <div class="flex shrink-0 justify-start">
                <soc-labs-icon-button data-toggle="right" [ariaLabel]="'Replier le panneau ' + rightLabel()" [ariaExpanded]="true" [ariaControls]="rightContentId" (click)="rightCollapsed.set(true)">
                  <svg lucidePanelRightClose class="size-full" [strokeWidth]="1.5"></svg>
                </soc-labs-icon-button>
              </div>
            }
          }
          <div data-panel-content [id]="rightContentId" [hidden]="rightIsCollapsed()" [class]="rightIsCollapsed() ? 'hidden' : contentClass">
            <ng-content select="[socLabsWorkspaceRight]" />
          </div>
        </aside>
      }
    </div>
  `, isInline: true, dependencies: [{ kind: "component", type: SocLabsIconButton, selector: "soc-labs-icon-button", inputs: ["ariaLabel", "size", "variant", "shape", "tooltip", "tooltipPosition", "disabled", "type", "pressed", "ariaExpanded", "ariaControls"] }, { kind: "component", type: LucidePanelLeftClose, selector: "svg[lucidePanelLeftClose], svg[lucideSidebarClose]" }, { kind: "component", type: LucidePanelLeftOpen, selector: "svg[lucidePanelLeftOpen], svg[lucideSidebarOpen]" }, { kind: "component", type: LucidePanelRightClose, selector: "svg[lucidePanelRightClose]" }, { kind: "component", type: LucidePanelRightOpen, selector: "svg[lucidePanelRightOpen]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsWorkspaceLayout, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-labs-workspace-layout',
                    standalone: true,
                    imports: [SocLabsIconButton, LucidePanelLeftClose, LucidePanelLeftOpen, LucidePanelRightClose, LucidePanelRightOpen],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: { class: 'flex h-full min-h-0 w-full min-w-0 flex-col [font-family:var(--bridges-shape-text-body-font)]' },
                    template: `
    @if (hasTopBar()) {
      <div
        data-region="top-bar"
        class="flex shrink-0 items-center gap-[var(--bridges-position-gap-md)] border-b-[length:var(--bridges-shape-line-hairline)] border-[var(--bridges-color-border-subtle)] bg-[var(--bridges-color-surface-neutral-white)] px-[var(--bridges-position-padding-lg)] py-[var(--bridges-position-padding-3xs)]"
      >
        @if (hasBack()) {
          <span class="flex shrink-0 items-center"><ng-content select="[socLabsWorkspaceBack]" /></span>
        }
        <div class="flex min-w-0 flex-1 items-center gap-[var(--bridges-position-gap-sm)]">
          @if (hasTitle()) {
            <span
              class="flex min-w-0 items-center truncate text-[length:var(--bridges-size-text-text-size-lg)] text-[var(--bridges-color-text-primary)] [font-family:var(--bridges-shape-text-label-font)] [font-weight:var(--bridges-shape-text-label-weight)]"
            ><ng-content select="[socLabsWorkspaceTitle]" /></span>
          }
          @if (hasHint()) {
            <span class="flex shrink-0 items-center text-[length:var(--bridges-size-text-text-size-sm)] text-[var(--bridges-color-text-secondary)]"><ng-content select="[socLabsWorkspaceHint]" /></span>
          }
        </div>
        @if (hasActions()) {
          <span class="flex shrink-0 items-center gap-[var(--bridges-position-gap-sm)]"><ng-content select="[socLabsWorkspaceActions]" /></span>
        }
      </div>
    }
    <div class="flex min-h-0 flex-1">
      @if (hasLeft()) {
        <aside
          data-region="left"
          [attr.aria-label]="leftLabel()"
          [attr.data-state]="leftIsCollapsed() ? 'collapsed' : 'expanded'"
          [class]="leftIsCollapsed() ? leftRailClass : leftClass"
          [style.width]="leftIsCollapsed() ? null : leftWidth()"
        >
          @if (narrow()) {
            @if (leftIsCollapsed()) {
              <soc-labs-icon-button data-toggle="left" [ariaLabel]="'Déplier le panneau ' + leftLabel()" [ariaExpanded]="false" [ariaControls]="leftContentId" (click)="leftCollapsed.set(false)">
                <svg lucidePanelLeftOpen class="size-full" [strokeWidth]="1.5"></svg>
              </soc-labs-icon-button>
              <span aria-hidden="true" [class]="railLabelClass">{{ leftLabel() }}</span>
            } @else {
              <div class="flex shrink-0 justify-end">
                <soc-labs-icon-button data-toggle="left" [ariaLabel]="'Replier le panneau ' + leftLabel()" [ariaExpanded]="true" [ariaControls]="leftContentId" (click)="leftCollapsed.set(true)">
                  <svg lucidePanelLeftClose class="size-full" [strokeWidth]="1.5"></svg>
                </soc-labs-icon-button>
              </div>
            }
          }
          <div data-panel-content [id]="leftContentId" [hidden]="leftIsCollapsed()" [class]="leftIsCollapsed() ? 'hidden' : contentClass">
            <ng-content select="[socLabsWorkspaceLeft]" />
          </div>
        </aside>
      }
      <section
        data-region="center"
        [attr.aria-label]="centerLabel()"
        class="flex min-h-0 min-w-0 flex-1 flex-col gap-[var(--bridges-position-gap-lg)] overflow-y-auto bg-[var(--bridges-color-background-layer-1)] p-[var(--bridges-position-padding-lg)]"
      >
        <ng-content />
      </section>
      @if (hasRight()) {
        <aside
          data-region="right"
          [attr.aria-label]="rightLabel()"
          [attr.data-state]="rightIsCollapsed() ? 'collapsed' : 'expanded'"
          [class]="rightIsCollapsed() ? rightRailClass : rightClass"
          [style.width]="rightIsCollapsed() ? null : rightWidth()"
        >
          @if (narrow()) {
            @if (rightIsCollapsed()) {
              <soc-labs-icon-button data-toggle="right" [ariaLabel]="'Déplier le panneau ' + rightLabel()" [ariaExpanded]="false" [ariaControls]="rightContentId" (click)="rightCollapsed.set(false)">
                <svg lucidePanelRightOpen class="size-full" [strokeWidth]="1.5"></svg>
              </soc-labs-icon-button>
              <span aria-hidden="true" [class]="railLabelClass">{{ rightLabel() }}</span>
            } @else {
              <div class="flex shrink-0 justify-start">
                <soc-labs-icon-button data-toggle="right" [ariaLabel]="'Replier le panneau ' + rightLabel()" [ariaExpanded]="true" [ariaControls]="rightContentId" (click)="rightCollapsed.set(true)">
                  <svg lucidePanelRightClose class="size-full" [strokeWidth]="1.5"></svg>
                </soc-labs-icon-button>
              </div>
            }
          }
          <div data-panel-content [id]="rightContentId" [hidden]="rightIsCollapsed()" [class]="rightIsCollapsed() ? 'hidden' : contentClass">
            <ng-content select="[socLabsWorkspaceRight]" />
          </div>
        </aside>
      }
    </div>
  `,
                }]
        }], ctorParameters: () => [] });

/**
 * Line clamp driven by the `--soc-labs-widget-card-lines` custom property set on the element (Tailwind
 * can't generate a class per dynamic line count). Literal string — Tailwind scans the source.
 */
const clamp = 'overflow-hidden [display:-webkit-box] [-webkit-box-orient:vertical] [-webkit-line-clamp:var(--soc-labs-widget-card-lines)]';
/** Icône à gauche du titre (≈ 28 px, pastille du kit). Optionnel. */
class SocLabsWidgetCardIcon {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsWidgetCardIcon, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocLabsWidgetCardIcon, isStandalone: true, selector: "[socLabsWidgetCardIcon]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsWidgetCardIcon, decorators: [{
            type: Directive,
            args: [{ selector: '[socLabsWidgetCardIcon]', standalone: true }]
        }] });
/** Actions à droite du titre (menu, bouton…), alignées en haut, jamais rétrécies. */
class SocLabsWidgetCardActions {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsWidgetCardActions, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocLabsWidgetCardActions, isStandalone: true, selector: "[socLabsWidgetCardActions]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsWidgetCardActions, decorators: [{
            type: Directive,
            args: [{ selector: '[socLabsWidgetCardActions]', standalone: true }]
        }] });
/**
 * Rangée de filtres sous le titre / la description, au-dessus du corps : les contrôles passent à la
 * ligne suivante plutôt que de déborder.
 */
class SocLabsWidgetCardFilters {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsWidgetCardFilters, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocLabsWidgetCardFilters, isStandalone: true, selector: "[socLabsWidgetCardFilters]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsWidgetCardFilters, decorators: [{
            type: Directive,
            args: [{ selector: '[socLabsWidgetCardFilters]', standalone: true }]
        }] });
/** Pied de carte (hauteur automatique), sous le corps. Optionnel. */
class SocLabsWidgetCardFooter {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsWidgetCardFooter, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: SocLabsWidgetCardFooter, isStandalone: true, selector: "[socLabsWidgetCardFooter]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsWidgetCardFooter, decorators: [{
            type: Directive,
            args: [{ selector: '[socLabsWidgetCardFooter]', standalone: true }]
        }] });
/**
 * ## Rôle
 * Carte d'un **widget de tableau de bord** (indicateur ou graphique) pour les grilles denses. Diffère
 * de `soc-card` du kit : titre sur plusieurs lignes (`titleLines`, 2 par défaut) puis « … », pied de
 * hauteur automatique, rangée de filtres, et aucun débordement horizontal.
 *
 * ## Slots
 * - `socLabsWidgetCardIcon` (optionnel) : icône à gauche du titre, dans la pastille du kit (28 px).
 * - `socLabsWidgetCardActions` (optionnel) : à droite du titre, alignées en haut, jamais rétrécies.
 * - `socLabsWidgetCardFilters` (optionnel) : rangée `flex-wrap` sous le titre et la description.
 * - contenu sans marqueur : le **corps** (valeur d'indicateur, graphique) — `flex-1`, `min-w-0`.
 * - `socLabsWidgetCardFooter` (optionnel) : pied, hauteur automatique.
 * Chaque région n'est rendue que si son slot est présent (`data-region` sur chacune).
 *
 * ## Mise en page
 * L'hôte est une colonne `flex h-full min-w-0` avec la surface de carte du kit (tokens
 * `--index-conteneur-card-*`) : dans une grille CSS, toutes les cartes d'une rangée prennent la même
 * hauteur et grandissent avec leur contenu. Rien ne déborde horizontalement (`min-w-0` partout).
 *
 * ## Typographie
 * Titre 13 px (dérivé : moyenne des tailles `xs` et `sm`), demi-gras
 * (`--bridges-shape-text-heading-2-weight`), couleur primaire, tronqué à `titleLines` lignes ; le titre
 * complet est dans l'attribut `title`. Description 12 px, couleur secondaire, tronquée à
 * `descriptionLines` lignes.
 *
 * ## Accessibilité
 * L'hôte porte `role="group"` et `aria-label` = titre. Le titre est un `<p>` (pas de niveau de titre
 * imposé : la page décide de sa hiérarchie).
 */
class SocLabsWidgetCard {
    title = input.required();
    description = input();
    /** Nombre de lignes du titre avant « … ». */
    titleLines = input(2);
    /** Nombre de lignes de la description avant « … ». */
    descriptionLines = input(2);
    icon = contentChild(SocLabsWidgetCardIcon);
    actions = contentChild(SocLabsWidgetCardActions);
    filters = contentChild(SocLabsWidgetCardFilters);
    footer = contentChild(SocLabsWidgetCardFooter);
    hasIcon = computed(() => !!this.icon());
    hasActions = computed(() => !!this.actions());
    hasFilters = computed(() => !!this.filters());
    hasFooter = computed(() => !!this.footer());
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsWidgetCard, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: SocLabsWidgetCard, isStandalone: true, selector: "soc-labs-widget-card", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null }, titleLines: { classPropertyName: "titleLines", publicName: "titleLines", isSignal: true, isRequired: false, transformFunction: null }, descriptionLines: { classPropertyName: "descriptionLines", publicName: "descriptionLines", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "group" }, properties: { "attr.aria-label": "title()", "attr.title": "null" }, classAttribute: "flex h-full min-w-0 flex-col gap-[var(--bridges-position-gap-sm)] rounded-[var(--index-conteneur-card-radius)] border-[length:var(--index-conteneur-card-border-width)] border-[var(--index-conteneur-card-border)] bg-[var(--index-conteneur-card-bg)] p-[var(--bridges-position-padding-md)] [font-family:var(--bridges-shape-text-body-font)]" }, queries: [{ propertyName: "icon", first: true, predicate: SocLabsWidgetCardIcon, descendants: true, isSignal: true }, { propertyName: "actions", first: true, predicate: SocLabsWidgetCardActions, descendants: true, isSignal: true }, { propertyName: "filters", first: true, predicate: SocLabsWidgetCardFilters, descendants: true, isSignal: true }, { propertyName: "footer", first: true, predicate: SocLabsWidgetCardFooter, descendants: true, isSignal: true }], ngImport: i0, template: "\n    <div data-region=\"header\" class=\"flex w-full min-w-0 items-start gap-[var(--bridges-position-gap-sm)]\">\n      @if (hasIcon()) {\n        <span\n          data-region=\"icon\"\n          class=\"flex size-[calc(var(--bridges-size-icon-lg)+var(--bridges-position-gap-2xs))] shrink-0 items-center justify-center rounded-[var(--index-conteneur-card-iconarea-bg-radius)] bg-[var(--index-conteneur-card-iconarea-bg)] text-[var(--index-conteneur-card-iconarea-icon-color)] [&>*]:size-[var(--index-conteneur-card-iconarea-icon-size)]\"\n        ><ng-content select=\"[socLabsWidgetCardIcon]\" /></span>\n      }\n      <div class=\"flex min-w-0 flex-1 flex-col gap-[var(--bridges-position-gap-xs)]\">\n        <p\n          data-region=\"title\"\n          class=\"overflow-hidden [display:-webkit-box] [-webkit-box-orient:vertical] [-webkit-line-clamp:var(--soc-labs-widget-card-lines)] min-w-0 break-words text-[length:calc((var(--bridges-size-text-text-size-xs)+var(--bridges-size-text-text-size-sm))/2)] text-[var(--bridges-color-text-primary)] [font-family:var(--bridges-shape-text-label-font)] [font-weight:var(--bridges-shape-text-heading-2-weight)] [line-height:var(--bridges-size-text-line-height-xl)]\"\n          [style.--soc-labs-widget-card-lines]=\"titleLines()\"\n          [attr.title]=\"title()\"\n        >{{ title() }}</p>\n        @if (description()) {\n          <p\n            data-region=\"description\"\n            class=\"overflow-hidden [display:-webkit-box] [-webkit-box-orient:vertical] [-webkit-line-clamp:var(--soc-labs-widget-card-lines)] min-w-0 break-words text-[length:var(--bridges-size-text-text-size-xs)] text-[var(--bridges-color-text-secondary)] [line-height:var(--bridges-size-text-line-height-xs)]\"\n            [style.--soc-labs-widget-card-lines]=\"descriptionLines()\"\n            [attr.title]=\"description()\"\n          >{{ description() }}</p>\n        }\n      </div>\n      @if (hasActions()) {\n        <span data-region=\"actions\" class=\"flex shrink-0 items-center gap-[var(--bridges-position-gap-2xs)] self-start\"\n          ><ng-content select=\"[socLabsWidgetCardActions]\"\n        /></span>\n      }\n    </div>\n    @if (hasFilters()) {\n      <div data-region=\"filters\" class=\"flex w-full min-w-0 flex-wrap items-center gap-[var(--bridges-position-gap-xs)] [&>*]:min-w-0 [&>*]:max-w-full\">\n        <ng-content select=\"[socLabsWidgetCardFilters]\" />\n      </div>\n    }\n    <div data-region=\"body\" class=\"flex w-full min-w-0 flex-1 flex-col\">\n      <ng-content />\n    </div>\n    @if (hasFooter()) {\n      <div data-region=\"footer\" class=\"flex w-full min-w-0 shrink-0 flex-col\">\n        <ng-content select=\"[socLabsWidgetCardFooter]\" />\n      </div>\n    }\n  ", isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: SocLabsWidgetCard, decorators: [{
            type: Component,
            args: [{
                    selector: 'soc-labs-widget-card',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        role: 'group',
                        '[attr.aria-label]': 'title()',
                        // `title` is an input: keep the native attribute off the host (no tooltip over the whole card).
                        '[attr.title]': 'null',
                        class: 'flex h-full min-w-0 flex-col gap-[var(--bridges-position-gap-sm)] rounded-[var(--index-conteneur-card-radius)] border-[length:var(--index-conteneur-card-border-width)] border-[var(--index-conteneur-card-border)] bg-[var(--index-conteneur-card-bg)] p-[var(--bridges-position-padding-md)] [font-family:var(--bridges-shape-text-body-font)]',
                    },
                    template: `
    <div data-region="header" class="flex w-full min-w-0 items-start gap-[var(--bridges-position-gap-sm)]">
      @if (hasIcon()) {
        <span
          data-region="icon"
          class="flex size-[calc(var(--bridges-size-icon-lg)+var(--bridges-position-gap-2xs))] shrink-0 items-center justify-center rounded-[var(--index-conteneur-card-iconarea-bg-radius)] bg-[var(--index-conteneur-card-iconarea-bg)] text-[var(--index-conteneur-card-iconarea-icon-color)] [&>*]:size-[var(--index-conteneur-card-iconarea-icon-size)]"
        ><ng-content select="[socLabsWidgetCardIcon]" /></span>
      }
      <div class="flex min-w-0 flex-1 flex-col gap-[var(--bridges-position-gap-xs)]">
        <p
          data-region="title"
          class="${clamp} min-w-0 break-words text-[length:calc((var(--bridges-size-text-text-size-xs)+var(--bridges-size-text-text-size-sm))/2)] text-[var(--bridges-color-text-primary)] [font-family:var(--bridges-shape-text-label-font)] [font-weight:var(--bridges-shape-text-heading-2-weight)] [line-height:var(--bridges-size-text-line-height-xl)]"
          [style.--soc-labs-widget-card-lines]="titleLines()"
          [attr.title]="title()"
        >{{ title() }}</p>
        @if (description()) {
          <p
            data-region="description"
            class="${clamp} min-w-0 break-words text-[length:var(--bridges-size-text-text-size-xs)] text-[var(--bridges-color-text-secondary)] [line-height:var(--bridges-size-text-line-height-xs)]"
            [style.--soc-labs-widget-card-lines]="descriptionLines()"
            [attr.title]="description()"
          >{{ description() }}</p>
        }
      </div>
      @if (hasActions()) {
        <span data-region="actions" class="flex shrink-0 items-center gap-[var(--bridges-position-gap-2xs)] self-start"
          ><ng-content select="[socLabsWidgetCardActions]"
        /></span>
      }
    </div>
    @if (hasFilters()) {
      <div data-region="filters" class="flex w-full min-w-0 flex-wrap items-center gap-[var(--bridges-position-gap-xs)] [&>*]:min-w-0 [&>*]:max-w-full">
        <ng-content select="[socLabsWidgetCardFilters]" />
      </div>
    }
    <div data-region="body" class="flex w-full min-w-0 flex-1 flex-col">
      <ng-content />
    </div>
    @if (hasFooter()) {
      <div data-region="footer" class="flex w-full min-w-0 shrink-0 flex-col">
        <ng-content select="[socLabsWidgetCardFooter]" />
      </div>
    }
  `,
                }]
        }] });

/*
 * Public API Surface of @socium-design/angular-components/labs
 *
 * Composants expérimentaux (zone Labs) — voir labs/README.md pour le cycle de vie. Rien ici n'est
 * exporté par le point d'entrée principal ; tout peut changer sans garantie de compatibilité.
 */

/**
 * Generated bundle index. Do not edit.
 */

export { LABS_CHART_TYPE_LABELS, SocLabsChartTypeChip, SocLabsCompactField, SocLabsDropZone, SocLabsFullscreenOverlay, SocLabsIconButton, SocLabsInlineEdit, SocLabsListRow, SocLabsListRowAction, SocLabsListRowLeading, SocLabsOverlayBadge, SocLabsPillToggle, SocLabsWidgetCard, SocLabsWidgetCardActions, SocLabsWidgetCardFilters, SocLabsWidgetCardFooter, SocLabsWidgetCardIcon, SocLabsWorkspaceActions, SocLabsWorkspaceBack, SocLabsWorkspaceHint, SocLabsWorkspaceLayout, SocLabsWorkspaceLeft, SocLabsWorkspaceRight, SocLabsWorkspaceTitle };
//# sourceMappingURL=socium-design-angular-components-labs.mjs.map
