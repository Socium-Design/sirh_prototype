import { type TagColor } from '@socium-design/angular-components';
import * as i0 from "@angular/core";
/** Contrôle à droite du titre (typiquement un `soc-switch` qui active la carte). Jamais grisé. */
export declare class SocLabsSettingsCardAction {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsSettingsCardAction, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocLabsSettingsCardAction, "[socLabsSettingsCardAction]", never, {}, {}, never, never, true, never>;
}
/** Note de bas de carte dans un encadré pointillé (règle de calcul, remarque). Grisée avec le corps. */
export declare class SocLabsSettingsCardFootnote {
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsSettingsCardFootnote, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SocLabsSettingsCardFootnote, "[socLabsSettingsCardFootnote]", never, {}, {}, never, never, true, never>;
}
/**
 * ## Rôle
 * Carte d'un **bloc de réglages** dans une page de configuration : sur-titre en petites capitales
 * (« BARÈME »), titre, contrôle à droite du titre (interrupteur), corps libre (champs du kit), puis une
 * note optionnelle dans un encadré pointillé (« Règle de calcul »), sur le fond de la carte : `text-secondary` y garde
 * 4,8:1 (sur `background-layer-1`, il tomberait à 4,4:1).
 *
 * Diffère de `soc-card` du kit : sur-titre, titre jamais tronqué, pas de bouton « ••• » (#15), état
 * **désactivé** (#11) et encadré de note.
 *
 * ## État désactivé (`disabled`)
 * Le corps et la note sont grisés (`--bridges-texture-opacity-disabled`) et **inertes** (`inert` :
 * ni clic, ni saisie, ni focus clavier, quel que soit le contrôle du kit qu'ils contiennent). Le
 * contrôle d'en-tête reste actif — c'est lui qui réactive la carte — et `disabledNote`, s'il est
 * fourni, s'affiche sous l'en-tête en couleur normale (contraste ≥ 4,5:1) pour dire pourquoi.
 *
 * ## Accessibilité
 * `role="group"` nommé par le titre (`aria-labelledby`). Le corps inerte est retiré de l'arbre
 * d'accessibilité : `disabledNote` est l'information lue à la place.
 *
 * ## Carte repliable (`collapsible`, désactivé par défaut)
 * - `expanded` (↔, `[(expanded)]`) : ouverte ou fermée. Carte fermée : seul l'en-tête reste, avec
 *   `summary` sous le titre (« /20 · 2 décimales · … »).
 * - Un clic sur l'en-tête ouvre ou ferme la carte, **sauf** sur le contrôle d'en-tête (l'interrupteur
 *   reste utilisable carte fermée et ne la replie jamais). Au clavier : le bouton chevron à droite
 *   (`aria-expanded`, `aria-controls` vers le corps, nommé par le titre), Entrée / Espace, focus visible.
 * - `lockExpanded` : la carte ne peut pas être refermée (ex. une valeur invalide à corriger) — le
 *   chevron passe en `aria-disabled`. Il faut une entrée dédiée : avec la seule liaison
 *   `[(expanded)]`, un parent qui remet `true` juste après une fermeture ne change pas la valeur liée
 *   et Angular ne la renvoie pas.
 * - Ouverture animée (hauteur, ~200 ms), sans animation si `prefers-reduced-motion`.
 * - Le corps replié est `inert` (ni focus, ni lecture par les lecteurs d'écran).
 *
 * ## Badge (`badge`, `badgeTone`)
 * Pastille dans l'en-tête (« Modifié », « Erreur »), visible carte ouverte ou fermée : `soc-tag` du kit,
 * ton = une couleur de `TagColor` (`information` par défaut, `error`, `warning`, `success`…).
 *
 * ## Slots
 * - `socLabsSettingsCardAction` (optionnel) : à droite du titre, aligné en haut, jamais rétréci.
 * - contenu sans marqueur : le corps (colonne, espacement `gap-lg`).
 * - `socLabsSettingsCardFootnote` (optionnel) : encadré pointillé en bas de carte.
 */
export declare class SocLabsSettingsCard {
    readonly title: import("@angular/core").InputSignal<string>;
    /** Sur-titre en petites capitales au-dessus du titre (« BARÈME »). */
    readonly overline: import("@angular/core").InputSignal<string | undefined>;
    /** Corps et note grisés et inertes ; le contrôle d'en-tête reste actif. */
    readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /** Mention affichée sous l'en-tête quand la carte est désactivée (« Barème désactivé : … »). */
    readonly disabledNote: import("@angular/core").InputSignal<string | undefined>;
    /** Carte repliable (en-tête cliquable + chevron). Faux par défaut : la carte est toujours ouverte. */
    readonly collapsible: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /** Ouverte (↔). Ignoré si la carte n'est pas repliable. */
    readonly expanded: import("@angular/core").ModelSignal<boolean>;
    /** Résumé sous le titre quand la carte repliable est fermée. */
    readonly summary: import("@angular/core").InputSignal<string | undefined>;
    /** Empêche de refermer la carte (valeur à corriger) ; le chevron est `aria-disabled`. */
    readonly lockExpanded: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /** Pastille de l'en-tête (« Modifié », « Erreur ») ; absente si vide. */
    readonly badge: import("@angular/core").InputSignal<string | undefined>;
    readonly badgeTone: import("@angular/core").InputSignal<TagColor>;
    protected readonly titleId: string;
    protected readonly summaryId: string;
    protected readonly panelId: string;
    protected readonly toggleClass = "flex size-[calc(var(--bridges-size-icon-lg)+var(--bridges-position-gap-2xs))] shrink-0 items-center justify-center rounded-[var(--bridges-shape-figure-radius-sm)] text-[var(--bridges-color-icon-secondary)] hover:bg-[var(--bridges-color-background-layer-1)] aria-disabled:cursor-not-allowed aria-disabled:text-[var(--bridges-color-icon-disabled)] aria-disabled:hover:bg-transparent outline-none focus-visible:outline-solid focus-visible:outline-[length:var(--bridges-shape-line-thick)] focus-visible:outline-offset-[length:var(--bridges-position-gap-xs)] focus-visible:outline-[var(--bridges-color-border-focus)]";
    protected readonly overlineClass = "uppercase tracking-wider [font-family:var(--bridges-shape-text-label-font)] [font-weight:var(--bridges-shape-text-label-weight)] text-[length:var(--bridges-size-text-text-size-tiny)] text-[var(--bridges-color-text-secondary)]";
    private readonly action;
    private readonly footnote;
    protected readonly hasAction: import("@angular/core").Signal<boolean>;
    protected readonly hasFootnote: import("@angular/core").Signal<boolean>;
    protected readonly isExpanded: import("@angular/core").Signal<boolean>;
    protected readonly headerClass: import("@angular/core").Signal<string>;
    protected readonly chevronClass: import("@angular/core").Signal<string>;
    /** Hauteur animée par `grid-template-rows` (0fr → 1fr) : pas de hauteur à mesurer. */
    protected readonly panelClass: import("@angular/core").Signal<string>;
    /** Clic n'importe où dans l'en-tête (y compris Entrée / Espace sur le chevron), sauf sur le contrôle d'en-tête. */
    protected onHeaderClick(event: MouseEvent): void;
    protected readonly bodyClass: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SocLabsSettingsCard, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SocLabsSettingsCard, "soc-labs-settings-card", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "overline": { "alias": "overline"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "disabledNote": { "alias": "disabledNote"; "required": false; "isSignal": true; }; "collapsible": { "alias": "collapsible"; "required": false; "isSignal": true; }; "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; "summary": { "alias": "summary"; "required": false; "isSignal": true; }; "lockExpanded": { "alias": "lockExpanded"; "required": false; "isSignal": true; }; "badge": { "alias": "badge"; "required": false; "isSignal": true; }; "badgeTone": { "alias": "badgeTone"; "required": false; "isSignal": true; }; }, { "expanded": "expandedChange"; }, ["action", "footnote"], ["[socLabsSettingsCardAction]", "*", "[socLabsSettingsCardFootnote]"], true, never>;
}
